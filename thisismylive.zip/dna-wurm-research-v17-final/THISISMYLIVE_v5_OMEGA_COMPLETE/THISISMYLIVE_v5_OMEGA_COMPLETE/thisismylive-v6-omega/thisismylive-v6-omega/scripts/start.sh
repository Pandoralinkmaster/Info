#!/bin/bash
# THISISMYLIVE v6.0 — OMEGA ULTIMATE
# Start-Skript für den Flask-Server

cd "$(dirname "$0")/server"
echo "🟢 THISISMYLIVE v6.0 OMEGA ULTIMATE"
echo "👤 Sovereign: Finn Jona Thorsten Lischke"
echo "🌐 Starting server on http://localhost:58133"
echo "═══════════════════════════════════════════════════"
python3 server.py
