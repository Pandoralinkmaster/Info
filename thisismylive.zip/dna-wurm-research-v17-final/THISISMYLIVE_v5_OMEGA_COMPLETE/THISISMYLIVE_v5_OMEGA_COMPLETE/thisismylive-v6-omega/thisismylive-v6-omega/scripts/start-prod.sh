#!/bin/bash
# THISISMYLIVE v6.0 — OMEGA ULTIMATE (Production)
# Gunicorn Production Server

cd "$(dirname "$0")/server"
echo "🟢 THISISMYLIVE v6.0 OMEGA ULTIMATE — PRODUCTION MODE"
echo "👤 Sovereign: Finn Jona Thorsten Lischke"
echo "🌐 Starting Gunicorn on http://0.0.0.0:58133"
echo "═══════════════════════════════════════════════════"
gunicorn -w 4 -b 0.0.0.0:58133 server:app
