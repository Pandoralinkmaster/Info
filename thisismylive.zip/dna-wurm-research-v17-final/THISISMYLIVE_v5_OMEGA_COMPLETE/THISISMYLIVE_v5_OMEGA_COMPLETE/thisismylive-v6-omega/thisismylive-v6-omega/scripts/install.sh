#!/bin/bash
# THISISMYLIVE v6.0 — Installation

echo "🔧 Installing THISISMYLIVE v6.0 OMEGA ULTIMATE..."
echo "👤 Sovereign: Finn Jona Thorsten Lischke"
echo ""

cd "$(dirname "$0")"

# Check Python
if ! command -v python3 &> /dev/null; then
    echo "❌ Python3 not found. Please install Python 3.8+"
    exit 1
fi

echo "✅ Python3 found"

# Create virtual environment
if [ ! -d ".venv" ]; then
    echo "📦 Creating virtual environment..."
    python3 -m venv .venv
fi

# Activate
source .venv/bin/activate

# Install dependencies
echo "📦 Installing dependencies..."
pip install --upgrade pip
pip install -r requirements.txt

echo ""
echo "✅ Installation complete!"
echo "🚀 Start with: ./start.sh"
echo "🌐 Access: http://localhost:58133"
echo "🔑 Auth: finn / sovereign2026"
