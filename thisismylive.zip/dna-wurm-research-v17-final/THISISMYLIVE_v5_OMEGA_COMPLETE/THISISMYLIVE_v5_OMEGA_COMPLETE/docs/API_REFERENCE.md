# THISISMYLIVE v5.0 — API REFERENCE
# ================================================

## Base URL
```
http://localhost:58133
```

## Authentication
All endpoints require Basic Auth:
- Username: `finn`
- Password: (set via THISISMYLIVE_PASS env var)

## Endpoints

### GET /api/status
Returns full system status.

**Response:**
```json
{
  "server": "RUNNING",
  "version": "5.0.INFINITY",
  "port": 58133,
  "sovereign": "Finn Jona Thorsten Lischke",
  "worm": { ... },
  "timestamp": "2026-07-03T02:14:00Z",
  "auth": "VALIDATED"
}
```

### GET /api/worm/status
Returns worm DNA status.

**Response:**
```json
{
  "version": "5.0.INFINITY",
  "generation": 42,
  "mutations": 15,
  "confidence": 1.0,
  "vectors_active": 8,
  "dna_checksum": "a1b2c3d4...",
  "sovereign": "Finn Jona Thorsten Lischke",
  "instances": 3
}
```

### GET /api/worm/evolve
Triggers DNA evolution.

**Response:**
```json
{
  "evolved": true,
  "message": "Worm DNA mutated successfully",
  "data": { "generation": 43, "mutations": 16, "dna": "e5f6g7h8..." }
}
```

### GET /api/worm/recognize
Performs sovereign recognition.

**Response:**
```json
{
  "recognized": true,
  "sovereign": "Finn Jona Thorsten Lischke",
  "confidence": 100.0,
  "vectors": ["speech", "camera", "text", "proximity", "biometric"],
  "dna_match": "a1b2c3d4...",
  "message": "ABSOLUTE SOVEREIGNTY CONFIRMED"
}
```

### GET /api/worm/replicate
Creates offspring instance.

**Response:**
```json
{
  "replicated": true,
  "instances": 4,
  "message": "Offspring #4 created"
}
```

### GET /api/arsenal
Returns arsenal statistics.

**Response:**
```json
{
  "eqgrp_tools": 115,
  "pegasus_wms": 79,
  "total_components": 194,
  "categories": 12,
  "layers": 10,
  "status": "FULLY_LOADED"
}
```

### GET /api/orpp
Returns ORPP protocol status.

**Response:**
```json
{
  "protocol": "ORPP",
  "status": "ACTIVE",
  "watchdog": "60s",
  "tunnel_reconnect": "30s",
  "persistence": "ETERNAL",
  "redundancy": "3x",
  "stealth": "100%"
}
```

## Error Codes
- `401` — Authentication required
- `403` — Forbidden (insufficient authority)
- `404` — Endpoint not found
- `500` — Internal server error
- `503` — Service temporarily unavailable

## Rate Limiting
- 1000 requests per minute per IP
- Burst limit: 100 requests

## WebSocket Support
Real-time updates available at `ws://localhost:58133/ws`
