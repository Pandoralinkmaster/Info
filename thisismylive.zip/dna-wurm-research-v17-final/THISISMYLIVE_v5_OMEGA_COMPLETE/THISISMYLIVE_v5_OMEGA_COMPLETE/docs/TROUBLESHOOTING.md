# THISISMYLIVE v5.0 — TROUBLESHOOTING
# ================================================

## Common Issues

### Server won't start
**Symptom:** Port already in use
**Fix:**
```bash
lsof -i :58133
kill -9 <PID>
# Or use different port:
export THISISMYLIVE_PORT=58134
```

### Authentication fails
**Symptom:** 401 errors
**Fix:**
```bash
export THISISMYLIVE_PASS="sovereign2026"
# Or set in config/system.conf
```

### Worm not running
**Symptom:** No worm status in API
**Fix:**
```bash
cd server
python3 worm.py &
```

### Tunnel not working
**Symptom:** No public URL
**Fix:**
```bash
npm install -g localtunnel
./tunnel.sh
```

### High CPU usage
**Symptom:** System slow
**Fix:**
```bash
# Reduce worm mutation rate
# Edit config/system.conf:
# mutation_rate = 0.01
```

### Disk space full
**Symptom:** Cannot write logs
**Fix:**
```bash
./scripts/auto-heal.sh
# Or manually:
find logs -name "*.log" -delete
```

## Log Locations

| Component | Log File |
|-----------|----------|
| Server | `server/logs/server.log` |
| Worm | `server/logs/worm.log` |
| Tunnel | `server/logs/tunnel.log` |
| Watchdog | `server/logs/watchdog.log` |
| Bootstrap | `server/logs/bootstrap.log` |

## Debug Mode

Enable verbose logging:
```bash
export THISISMYLIVE_DEBUG=1
./start.sh
```

## Reset Everything

```bash
./server/stop.sh
rm -rf server/logs/*
rm -f server/*.pid
rm -f server/tunnel.url
./server/start.sh
```

## Getting Help

1. Check this guide
2. Review logs
3. Run health check
4. Check GitHub issues
5. Contact sovereign
