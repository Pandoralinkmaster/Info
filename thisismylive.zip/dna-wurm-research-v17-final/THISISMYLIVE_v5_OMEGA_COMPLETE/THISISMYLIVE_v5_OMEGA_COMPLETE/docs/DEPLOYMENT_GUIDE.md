# THISISMYLIVE v5.0 — DEPLOYMENT GUIDE
# ================================================

## Quick Start

### 1. Local Deployment
```bash
cd server
./start.sh
```
Access: http://localhost:58133

### 2. Global Deployment
```bash
cd server
./master.sh global
```
Creates public URL via tunnel.

### 3. Eternal Mode
```bash
cd server
./master.sh eternal
```
Self-healing with watchdog.

## System Requirements

### Minimum
- Python 3.8+
- 512MB RAM
- 100MB disk space

### Recommended
- Python 3.11+
- 2GB RAM
- 1GB disk space
- Internet connection

## Installation Methods

### Method 1: Direct
```bash
git clone <repo>
cd THISISMYLIVE-v5
./scripts/install.sh
```

### Method 2: Systemd Service
```bash
sudo ./scripts/install.sh /opt/thisismylive
sudo systemctl start thisismylive
```

### Method 3: Docker (coming soon)
```bash
docker build -t thisismylive:v5 .
docker run -p 58133:58133 thisismylive:v5
```

## Configuration

Edit `config/system.conf`:
```ini
[server]
port = 58133
username = finn

[security]
auth_method = basic
encryption = aes-256-gcm
```

Set password:
```bash
export THISISMYLIVE_PASS="your_secure_password"
```

## Verification

Check status:
```bash
./server/status.sh
```

Health check:
```bash
./scripts/health-check.sh
```

## Troubleshooting

### Port already in use
```bash
export THISISMYLIVE_PORT=58134
./start.sh
```

### Permission denied
```bash
chmod +x server/*.sh
chmod +x server/*.py
```

### Python not found
```bash
# Ubuntu/Debian
sudo apt-get install python3

# CentOS/RHEL
sudo yum install python3

# macOS
brew install python3
```

## Security Notes

1. Change default password immediately
2. Use HTTPS in production
3. Enable firewall rules
4. Monitor access logs
5. Regular backups

## Support

For issues and updates:
- Check logs: `tail -f server/logs/*.log`
- Health check: `./scripts/health-check.sh`
- Auto-heal: `./scripts/auto-heal.sh`
