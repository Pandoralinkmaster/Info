#!/usr/bin/env python3
"""
DNA-WURM RESEARCH v17.0 - MASTER CONTROLLER
Orchestriert alle Module: Scanner, Auditor, Analysis, Dashboard.
Nutzung: python3 master_controller.py [scan|audit|analyze|dashboard|all]

Finn Jona Thorsten Lischke - ABSOLUTE SOVEREIGN 2026
"""

import sys
import os
import subprocess
import time
from datetime import datetime

MODULES_DIR = "./modules"
DATA_DIR = "./data"
REPORTS_DIR = "./reports"

def ensure_dirs():
    for d in [DATA_DIR, REPORTS_DIR, "./web"]:
        os.makedirs(d, exist_ok=True)

def run_scanner():
    print("\n" + "="*60)
    print("STARTE SYSTEM SCANNER")
    print("="*60)
    result = subprocess.run([sys.executable, os.path.join(MODULES_DIR, "system_scanner.py")],
                          capture_output=False, text=True)
    return result.returncode == 0

def run_auditor():
    print("\n" + "="*60)
    print("STARTE SECURITY AUDITOR")
    print("="*60)
    result = subprocess.run([sys.executable, os.path.join(MODULES_DIR, "security_auditor.py")],
                          capture_output=False, text=True)
    return result.returncode == 0

def run_analysis():
    print("\n" + "="*60)
    print("STARTE KI-ANALYSE-ENGINE")
    print("="*60)
    result = subprocess.run([sys.executable, os.path.join(MODULES_DIR, "ki_analysis_engine.py")],
                          capture_output=False, text=True)
    return result.returncode == 0

def run_dashboard():
    print("\n" + "="*60)
    print("STARTE DASHBOARD SERVER")
    print("="*60)
    subprocess.run([sys.executable, os.path.join(MODULES_DIR, "dashboard_server.py")])

def run_all():
    print("\n" + "="*60)
    print("DNA-WURM RESEARCH v17.0 - VOLLSTAENDIGER DURCHLAUF")
    print("="*60)

    ensure_dirs()

    print("\n[1/4] System-Scan...")
    run_scanner()
    time.sleep(1)

    print("\n[2/4] Security-Audit...")
    run_auditor()
    time.sleep(1)

    print("\n[3/4] KI-Analyse...")
    run_analysis()
    time.sleep(1)

    print("\n[4/4] Dashboard starten...")
    print("\nDashboard wird gestartet. Oeffne http://localhost:58133")
    print("Strg+C zum Beenden\n")
    run_dashboard()

def print_help():
    print("""
DNA-WURM RESEARCH v17.0 - MASTER CONTROLLER
============================================

Nutzung: python3 master_controller.py [BEFEHL]

Befehle:
  scan       - System-Scanner ausfuehren
  audit      - Security-Auditor ausfuehren
  analyze    - KI-Analyse-Engine ausfuehren
  dashboard  - Dashboard-Server starten
  all        - Alles ausfuehren (Scan + Audit + Analyse + Dashboard)
  help       - Diese Hilfe anzeigen

Beispiele:
  python3 master_controller.py scan
  python3 master_controller.py all

Hinweise:
  - Alle Module arbeiten NUR auf dem lokalen System
  - Keine Netzwerk-Angriffe, keine fremden Systeme
  - Forschungszwecke, defensiver Fokus
  - Ergebnisse werden in ./data/ und ./reports/ gespeichert

Finn Jona Thorsten Lischke - ABSOLUTE SOVEREIGN 2026
""")

if __name__ == "__main__":
    ensure_dirs()

    if len(sys.argv) < 2:
        print_help()
        sys.exit(0)

    cmd = sys.argv[1].lower()

    if cmd == "scan":
        run_scanner()
    elif cmd == "audit":
        run_auditor()
    elif cmd == "analyze":
        run_analysis()
    elif cmd == "dashboard":
        run_dashboard()
    elif cmd == "all":
        run_all()
    elif cmd in ["help", "-h", "--help"]:
        print_help()
    else:
        print(f"Unbekannter Befehl: {cmd}")
        print_help()
