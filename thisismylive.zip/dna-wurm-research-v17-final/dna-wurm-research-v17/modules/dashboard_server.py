#!/usr/bin/env python3
"""
DNA-WURM RESEARCH v17.0 - DASHBOARD SERVER
Web-basiertes Dashboard fuer Forschungsergebnisse.
Nutzung: Lokaler Zugriff. Forschungszwecke.

Finn Jona Thorsten Lischke - ABSOLUTE SOVEREIGN 2026
"""

import os
import json
import http.server
import socketserver
from datetime import datetime
from urllib.parse import urlparse

PORT = 58133
DATA_DIR = "./data"
REPORTS_DIR = "./reports"
WEB_DIR = "./web"

class DashboardHandler(http.server.SimpleHTTPRequestHandler):
    """HTTP-Handler fuer das Forschungs-Dashboard."""

    def do_GET(self):
        parsed = urlparse(self.path)
        path = parsed.path

        if path == "/":
            self.serve_dashboard()
        elif path == "/api/scans":
            self.serve_api_scans()
        elif path == "/api/audits":
            self.serve_api_audits()
        elif path == "/api/analysis":
            self.serve_api_analysis()
        elif path == "/api/stats":
            self.serve_api_stats()
        else:
            self.send_response(404)
            self.end_headers()

    def serve_dashboard(self):
        """Serviert das Haupt-Dashboard aus externer HTML-Datei."""
        html_path = os.path.join(WEB_DIR, "dashboard.html")
        if os.path.exists(html_path):
            self.send_response(200)
            self.send_header("Content-type", "text/html; charset=utf-8")
            self.end_headers()
            with open(html_path, 'rb') as f:
                self.wfile.write(f.read())
        else:
            self.send_response(500)
            self.end_headers()
            self.wfile.write(b"Dashboard HTML nicht gefunden")

    def serve_api_scans(self):
        scans = []
        if os.path.exists(DATA_DIR):
            for f in sorted(os.listdir(DATA_DIR)):
                if f.startswith("scan_") and f.endswith(".json"):
                    scans.append(f)
        self.send_json({"scans": scans, "count": len(scans)})

    def serve_api_audits(self):
        audits = []
        if os.path.exists(DATA_DIR):
            for f in sorted(os.listdir(DATA_DIR)):
                if f.startswith("audit_") and f.endswith(".json"):
                    audits.append(f)
        self.send_json({"audits": audits, "count": len(audits)})

    def serve_api_analysis(self):
        analyses = []
        if os.path.exists(REPORTS_DIR):
            for f in sorted(os.listdir(REPORTS_DIR)):
                if f.startswith("analysis_") and f.endswith(".json"):
                    analyses.append(f)

        if analyses:
            with open(os.path.join(REPORTS_DIR, analyses[-1])) as fh:
                data = json.load(fh)
            self.send_json(data)
        else:
            self.send_json({"error": "Keine Analyse vorhanden"})

    def serve_api_stats(self):
        scans = len([f for f in os.listdir(DATA_DIR) if f.startswith("scan_")]) if os.path.exists(DATA_DIR) else 0
        audits = len([f for f in os.listdir(DATA_DIR) if f.startswith("audit_")]) if os.path.exists(DATA_DIR) else 0
        analyses = len([f for f in os.listdir(REPORTS_DIR) if f.startswith("analysis_")]) if os.path.exists(REPORTS_DIR) else 0

        self.send_json({
            "scans": scans,
            "audits": audits,
            "analyses": analyses,
            "timestamp": datetime.now().isoformat(),
        })

    def send_json(self, data):
        self.send_response(200)
        self.send_header("Content-type", "application/json")
        self.end_headers()
        self.wfile.write(json.dumps(data, indent=2, default=str).encode('utf-8'))

def run_server(port=PORT):
    os.makedirs(DATA_DIR, exist_ok=True)
    os.makedirs(REPORTS_DIR, exist_ok=True)
    os.makedirs(WEB_DIR, exist_ok=True)

    with socketserver.TCPServer(("", port), DashboardHandler) as httpd:
        print("=" * 60)
        print("DNA-WURM RESEARCH v17.0 - DASHBOARD SERVER")
        print("Dashboard: http://localhost:" + str(port))
        print("=" * 60)
        print("Strg+C zum Beenden")
        try:
            httpd.serve_forever()
        except KeyboardInterrupt:
            print("\nServer beendet.")

if __name__ == "__main__":
    run_server()
