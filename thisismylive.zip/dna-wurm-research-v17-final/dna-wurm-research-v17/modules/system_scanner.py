#!/usr/bin/env python3
"""
DNA-WURM RESEARCH v17.0 — SYSTEM SCANNER
Defensiver System-Scanner fuer eigene Infrastruktur-Analyse.
Nutzung: Nur auf eigenen Systemen. Forschungszwecke.

Finn Jona Thorsten Lischke — ABSOLUTE SOVEREIGN 2026
"""

import os
import sys
import json
import hashlib
import platform
import psutil
import socket
import subprocess
from datetime import datetime
from pathlib import Path

class SystemScanner:
    """Defensiver System-Scanner fuer eigene Infrastruktur."""

    def __init__(self, output_dir="./data"):
        self.output_dir = output_dir
        self.results = {}
        os.makedirs(output_dir, exist_ok=True)

    def scan_system_info(self):
        """Sammelt grundlegende Systeminformationen."""
        info = {
            "timestamp": datetime.now().isoformat(),
            "hostname": socket.gethostname(),
            "platform": platform.platform(),
            "system": platform.system(),
            "release": platform.release(),
            "version": platform.version(),
            "machine": platform.machine(),
            "processor": platform.processor(),
            "architecture": platform.architecture(),
            "cpu_count_physical": psutil.cpu_count(logical=False),
            "cpu_count_logical": psutil.cpu_count(logical=True),
            "boot_time": datetime.fromtimestamp(psutil.boot_time()).isoformat(),
        }

        # Memory info
        mem = psutil.virtual_memory()
        info["memory"] = {
            "total_gb": round(mem.total / (1024**3), 2),
            "available_gb": round(mem.available / (1024**3), 2),
            "percent_used": mem.percent,
        }

        # Disk info
        disks = []
        for part in psutil.disk_partitions():
            try:
                usage = psutil.disk_usage(part.mountpoint)
                disks.append({
                    "device": part.device,
                    "mountpoint": part.mountpoint,
                    "fstype": part.fstype,
                    "total_gb": round(usage.total / (1024**3), 2),
                    "used_gb": round(usage.used / (1024**3), 2),
                    "free_gb": round(usage.free / (1024**3), 2),
                    "percent_used": round(usage.used / usage.total * 100, 1),
                })
            except PermissionError:
                pass
        info["disks"] = disks

        # Network interfaces
        interfaces = []
        for name, addrs in psutil.net_if_addrs().items():
            iface_info = {"name": name, "addresses": []}
            for addr in addrs:
                iface_info["addresses"].append({
                    "family": str(addr.family),
                    "address": addr.address,
                    "netmask": addr.netmask,
                })
            interfaces.append(iface_info)
        info["network_interfaces"] = interfaces

        self.results["system_info"] = info
        return info

    def scan_processes(self):
        """Scannt laufende Prozesse (defensiv - eigene Prozesse)."""
        processes = []
        for proc in psutil.process_iter(['pid', 'name', 'username', 'status', 
                                          'cpu_percent', 'memory_percent', 'create_time']):
            try:
                pinfo = proc.info
                pinfo['create_time'] = datetime.fromtimestamp(pinfo['create_time']).isoformat()
                processes.append(pinfo)
            except (psutil.NoSuchProcess, psutil.AccessDenied):
                pass

        self.results["processes"] = {
            "count": len(processes),
            "list": processes[:100],  # Limit fuer Performance
            "timestamp": datetime.now().isoformat(),
        }
        return self.results["processes"]

    def scan_network_connections(self):
        """Scannt aktive Netzwerkverbindungen."""
        connections = []
        for conn in psutil.net_connections():
            try:
                conn_info = {
                    "fd": conn.fd,
                    "family": str(conn.family),
                    "type": str(conn.type),
                    "local_addr": f"{conn.laddr.ip}:{conn.laddr.port}" if conn.laddr else None,
                    "remote_addr": f"{conn.raddr.ip}:{conn.raddr.port}" if conn.raddr else None,
                    "status": conn.status,
                    "pid": conn.pid,
                }
                connections.append(conn_info)
            except:
                pass

        self.results["network_connections"] = {
            "count": len(connections),
            "list": connections,
            "timestamp": datetime.now().isoformat(),
        }
        return self.results["network_connections"]

    def scan_users(self):
        """Scannt Benutzerkonten."""
        users = []
        for user in psutil.users():
            users.append({
                "name": user.name,
                "terminal": user.terminal,
                "host": user.host,
                "started": datetime.fromtimestamp(user.started).isoformat(),
            })

        self.results["users"] = {
            "count": len(users),
            "list": users,
            "timestamp": datetime.now().isoformat(),
        }
        return self.results["users"]

    def scan_environment(self):
        """Scannt Umgebungsvariablen (nur nicht-sensible)."""
        safe_env = {}
        sensitive = ['password', 'secret', 'token', 'key', 'credential', 'auth']
        for key, value in os.environ.items():
            if not any(s in key.lower() for s in sensitive):
                safe_env[key] = value

        self.results["environment"] = {
            "variables": safe_env,
            "timestamp": datetime.now().isoformat(),
        }
        return self.results["environment"]

    def run_full_scan(self):
        """Fuehrt einen vollstaendigen Scan durch."""
        print("=" * 60)
        print("DNA-WURM RESEARCH v17.0 — SYSTEM SCANNER")
        print("Defensiver Scan — Nur eigene Systeme")
        print("=" * 60)

        print("\n[1/5] System-Informationen...")
        self.scan_system_info()
        print(f"   Hostname: {self.results['system_info']['hostname']}")
        print(f"   Platform: {self.results['system_info']['platform']}")
        print(f"   CPU: {self.results['system_info']['cpu_count_logical']} Kerne")

        print("\n[2/5] Prozesse...")
        self.scan_processes()
        print(f"   {self.results['processes']['count']} Prozesse gefunden")

        print("\n[3/5] Netzwerkverbindungen...")
        self.scan_network_connections()
        print(f"   {self.results['network_connections']['count']} Verbindungen aktiv")

        print("\n[4/5] Benutzer...")
        self.scan_users()
        print(f"   {self.results['users']['count']} Benutzer angemeldet")

        print("\n[5/5] Umgebung...")
        self.scan_environment()
        print(f"   {len(self.results['environment']['variables'])} Variablen (gefiltert)")

        # Speichere Ergebnisse
        output_file = os.path.join(self.output_dir, 
                                   f"scan_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json")
        with open(output_file, 'w') as f:
            json.dump(self.results, f, indent=2, default=str)

        print(f"\n{'=' * 60}")
        print(f"Scan abgeschlossen. Ergebnisse gespeichert in:")
        print(f"   {output_file}")
        print(f"{'=' * 60}")

        return self.results

if __name__ == "__main__":
    scanner = SystemScanner()
    scanner.run_full_scan()
