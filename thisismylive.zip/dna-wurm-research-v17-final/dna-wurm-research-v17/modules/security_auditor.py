#!/usr/bin/env python3
"""
DNA-WURM RESEARCH v17.0 — SECURITY AUDITOR
Defensiver Sicherheits-Auditor fuer eigene Systeme.
Identifiziert Konfigurationsprobleme, offene Ports, veraltete Software.
Nutzung: Nur auf eigenen Systemen. Forschungszwecke.

Finn Jona Thorsten Lischke — ABSOLUTE SOVEREIGN 2026
"""

import os
import json
import socket
import subprocess
import platform
from datetime import datetime
from pathlib import Path

class SecurityAuditor:
    """Defensiver Sicherheits-Auditor fuer eigene Systeme."""

    def __init__(self, output_dir="./data"):
        self.output_dir = output_dir
        self.findings = []
        self.recommendations = []
        os.makedirs(output_dir, exist_ok=True)

    def check_open_ports(self, ports=[21, 22, 23, 25, 53, 80, 110, 143, 443, 445, 
                                       3306, 3389, 5432, 5900, 8080, 8443]):
        """Prueft offene Ports auf localhost (defensiv)."""
        open_ports = []
        for port in ports:
            try:
                sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                sock.settimeout(1)
                result = sock.connect_ex(('127.0.0.1', port))
                if result == 0:
                    open_ports.append(port)
                    # Bewertung
                    if port in [21, 23, 25, 110, 143]:
                        self.findings.append({
                            "severity": "MEDIUM",
                            "category": "Unverschluesseltes Protokoll",
                            "detail": f"Port {port} ist offen (unverschluesselt)",
                            "recommendation": f"Port {port} deaktivieren oder TLS erzwingen"
                        })
                    elif port in [22, 3389, 5900]:
                        self.findings.append({
                            "severity": "INFO",
                            "category": "Remote-Zugriff",
                            "detail": f"Port {port} ist offen (Remote-Zugriff)",
                            "recommendation": f"Zugriff auf localhost beschraenken, Key-Auth erzwingen"
                        })
                    else:
                        self.findings.append({
                            "severity": "INFO",
                            "category": "Offener Port",
                            "detail": f"Port {port} ist offen",
                            "recommendation": "Pruefen ob noetig"
                        })
                sock.close()
            except:
                pass

        return open_ports

    def check_file_permissions(self, paths=["/etc/passwd", "/etc/shadow", 
                                             "/etc/ssh/sshd_config", "/tmp"]):
        """Prueft Dateiberechtigungen (defensiv)."""
        for path in paths:
            if os.path.exists(path):
                stat = os.stat(path)
                mode = oct(stat.st_mode)[-3:]

                if path == "/etc/shadow" and mode != "000":
                    self.findings.append({
                        "severity": "HIGH",
                        "category": "Dateiberechtigungen",
                        "detail": f"/etc/shadow hat Berechtigungen {mode}",
                        "recommendation": "Berechtigungen auf 000 setzen"
                    })
                elif path == "/tmp" and int(mode[0]) < 1:
                    self.findings.append({
                        "severity": "MEDIUM",
                        "category": "Dateiberechtigungen",
                        "detail": f"/tmp hat keine Sticky-Bit ({mode})",
                        "recommendation": "chmod +t /tmp"
                    })

    def check_ssh_config(self):
        """Prueft SSH-Konfiguration (defensiv)."""
        ssh_config = "/etc/ssh/sshd_config"
        if os.path.exists(ssh_config):
            try:
                with open(ssh_config, 'r') as f:
                    config = f.read()

                checks = {
                    "PasswordAuthentication": ("no", "HIGH", "Passwort-Auth deaktivieren"),
                    "PermitRootLogin": ("no", "HIGH", "Root-Login deaktivieren"),
                    "PubkeyAuthentication": ("yes", "MEDIUM", "Key-Auth aktivieren"),
                    "X11Forwarding": ("no", "LOW", "X11-Forwarding deaktivieren"),
                }

                for key, (expected, severity, rec) in checks.items():
                    if key in config:
                        for line in config.split('\n'):
                            if line.strip().startswith(key):
                                value = line.split()[1].strip()
                                if value != expected:
                                    self.findings.append({
                                        "severity": severity,
                                        "category": "SSH-Konfiguration",
                                        "detail": f"{key} = {value} (erwartet: {expected})",
                                        "recommendation": rec
                                    })
            except PermissionError:
                self.findings.append({
                    "severity": "INFO",
                    "category": "SSH-Konfiguration",
                    "detail": "Kein Zugriff auf sshd_config",
                    "recommendation": "Als root ausfuehren"
                })

    def check_sudo_config(self):
        """Prueft sudo-Konfiguration (defensiv)."""
        sudoers = "/etc/sudoers"
        if os.path.exists(sudoers):
            try:
                with open(sudoers, 'r') as f:
                    content = f.read()

                if "NOPASSWD" in content:
                    self.findings.append({
                        "severity": "MEDIUM",
                        "category": "Sudo-Konfiguration",
                        "detail": "NOPASSWD in sudoers gefunden",
                        "recommendation": "Passwort fuer sudo erzwingen"
                    })
            except PermissionError:
                pass

    def check_environment_secrets(self):
        """Prueft auf hartkodierte Secrets in Umgebung (defensiv)."""
        sensitive_patterns = ['password', 'secret', 'token', 'api_key', 'private_key']
        found = []
        for key, value in os.environ.items():
            if any(p in key.lower() for p in sensitive_patterns):
                masked = value[:3] + '*' * (len(value) - 6) + value[-3:] if len(value) > 6 else '***'
                found.append({"key": key, "value_masked": masked})

        if found:
            self.findings.append({
                "severity": "MEDIUM",
                "category": "Umgebungsvariablen",
                "detail": f"{len(found)} sensitive Variablen in Umgebung gefunden",
                "recommendation": "Secrets in sicheren Speicher (z.B. HashiCorp Vault) auslagern"
            })

    def generate_report(self):
        """Generiert einen Audit-Report."""
        severity_counts = {"CRITICAL": 0, "HIGH": 0, "MEDIUM": 0, "LOW": 0, "INFO": 0}
        for finding in self.findings:
            sev = finding.get("severity", "INFO")
            if sev in severity_counts:
                severity_counts[sev] += 1

        report = {
            "timestamp": datetime.now().isoformat(),
            "auditor": "DNA-WURM RESEARCH v17.0 — Security Auditor",
            "disclaimer": "Nur fuer eigene Systeme. Forschungszwecke.",
            "summary": {
                "total_findings": len(self.findings),
                "severity_distribution": severity_counts,
            },
            "findings": self.findings,
            "recommendations": list(set(f["recommendation"] for f in self.findings)),
        }

        output_file = os.path.join(self.output_dir,
                                   f"audit_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json")
        with open(output_file, 'w') as f:
            json.dump(report, f, indent=2)

        return report, output_file

    def run_audit(self):
        """Fuehrt vollstaendigen Audit durch."""
        print("=" * 60)
        print("DNA-WURM RESEARCH v17.0 — SECURITY AUDITOR")
        print("Defensiver Audit — Nur eigene Systeme")
        print("=" * 60)

        print("\n[1/5] Offene Ports pruefen...")
        open_ports = self.check_open_ports()
        print(f"   {len(open_ports)} offene Ports gefunden")

        print("\n[2/5] Dateiberechtigungen pruefen...")
        self.check_file_permissions()
        print(f"   {len(self.findings)} Findings bisher")

        print("\n[3/5] SSH-Konfiguration pruefen...")
        self.check_ssh_config()
        print(f"   {len(self.findings)} Findings bisher")

        print("\n[4/5] Sudo-Konfiguration pruefen...")
        self.check_sudo_config()
        print(f"   {len(self.findings)} Findings bisher")

        print("\n[5/5] Umgebungsvariablen pruefen...")
        self.check_environment_secrets()
        print(f"   {len(self.findings)} Findings bisher")

        report, output_file = self.generate_report()

        print(f"\n{'=' * 60}")
        print("AUDIT ZUSAMMENFASSUNG")
        print(f"{'=' * 60}")
        print(f"Gesamt-Findings: {report['summary']['total_findings']}")
        for sev, count in report['summary']['severity_distribution'].items():
            if count > 0:
                print(f"  {sev}: {count}")
        print(f"\nReport gespeichert: {output_file}")
        print(f"{'=' * 60}")

        return report

if __name__ == "__main__":
    auditor = SecurityAuditor()
    auditor.run_audit()
