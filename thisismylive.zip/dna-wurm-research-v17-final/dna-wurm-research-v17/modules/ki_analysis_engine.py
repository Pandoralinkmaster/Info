#!/usr/bin/env python3
"""
DNA-WURM RESEARCH v17.0 — KI-ANALYSE-ENGINE
Forschungs-Engine fuer Mustererkennung in Systemdaten.
Nutzt statistische Analyse und Heuristiken (kein ML-Training).
Nutzung: Forschungszwecke. Nur eigene Daten.

Finn Jona Thorsten Lischke — ABSOLUTE SOVEREIGN 2026
"""

import os
import json
import math
import statistics
from datetime import datetime
from collections import Counter, defaultdict

class KIAnalysisEngine:
    """Forschungs-Engine fuer Mustererkennung in Systemdaten."""

    def __init__(self, data_dir="./data", output_dir="./reports"):
        self.data_dir = data_dir
        self.output_dir = output_dir
        os.makedirs(output_dir, exist_ok=True)
        self.patterns = []

    def load_scan_data(self):
        """Laedt alle Scan-Ergebnisse."""
        scans = []
        for f in os.listdir(self.data_dir):
            if f.startswith("scan_") and f.endswith(".json"):
                with open(os.path.join(self.data_dir, f)) as fh:
                    scans.append(json.load(fh))
        return scans

    def analyze_process_patterns(self, scans):
        """Analysiert Prozess-Muster."""
        all_procs = []
        for scan in scans:
            if "processes" in scan and "list" in scan["processes"]:
                all_procs.extend(scan["processes"]["list"])

        if not all_procs:
            return None

        # Haeufigste Prozesse
        names = [p["name"] for p in all_procs if "name" in p]
        name_counts = Counter(names)

        # CPU-Nutzung
        cpu_values = [p.get("cpu_percent", 0) for p in all_procs if p.get("cpu_percent")]
        cpu_stats = {
            "mean": round(statistics.mean(cpu_values), 2) if cpu_values else 0,
            "max": round(max(cpu_values), 2) if cpu_values else 0,
        }

        # Memory-Nutzung
        mem_values = [p.get("memory_percent", 0) for p in all_procs if p.get("memory_percent")]
        mem_stats = {
            "mean": round(statistics.mean(mem_values), 2) if mem_values else 0,
            "max": round(max(mem_values), 2) if mem_values else 0,
        }

        analysis = {
            "total_processes_analyzed": len(all_procs),
            "unique_processes": len(name_counts),
            "top_processes": dict(name_counts.most_common(10)),
            "cpu_usage": cpu_stats,
            "memory_usage": mem_stats,
        }

        # Anomalie-Erkennung (einfache Heuristik)
        anomalies = []
        for name, count in name_counts.items():
            if count > len(scans) * 2:  # Mehr als 2x pro Scan
                anomalies.append({
                    "type": "high_frequency_process",
                    "process": name,
                    "count": count,
                    "note": "Prozess erscheint ungewoehnlich haeufig"
                })

        analysis["anomalies"] = anomalies
        return analysis

    def analyze_network_patterns(self, scans):
        """Analysiert Netzwerk-Muster."""
        all_conns = []
        for scan in scans:
            if "network_connections" in scan and "list" in scan["network_connections"]:
                all_conns.extend(scan["network_connections"]["list"])

        if not all_conns:
            return None

        # Status-Verteilung
        statuses = [c["status"] for c in all_conns if "status" in c]
        status_counts = Counter(statuses)

        # Remote-Adressen
        remotes = [c["remote_addr"] for c in all_conns if c.get("remote_addr")]
        remote_counts = Counter(remotes)

        # Offene Verbindungen
        open_conns = [c for c in all_conns if c.get("status") == "ESTABLISHED"]

        analysis = {
            "total_connections": len(all_conns),
            "established_connections": len(open_conns),
            "status_distribution": dict(status_counts),
            "top_remote_addresses": dict(remote_counts.most_common(10)),
        }

        # Anomalie: Viele Verbindungen zu einer Adresse
        anomalies = []
        for addr, count in remote_counts.most_common(5):
            if count > 10:
                anomalies.append({
                    "type": "high_connection_count",
                    "address": addr,
                    "count": count,
                    "note": "Ungewoehnlich viele Verbindungen zu dieser Adresse"
                })

        analysis["anomalies"] = anomalies
        return analysis

    def analyze_security_trends(self, audits):
        """Analysiert Sicherheits-Trends ueber Zeit."""
        if not audits:
            return None

        severity_timeline = defaultdict(lambda: defaultdict(int))

        for audit in audits:
            ts = audit.get("timestamp", "unknown")
            for finding in audit.get("findings", []):
                sev = finding.get("severity", "INFO")
                severity_timeline[ts][sev] += 1

        # Trend-Analyse
        trend = {
            "scans_analyzed": len(audits),
            "severity_timeline": dict(severity_timeline),
            "recommendations": list(set(
                rec for audit in audits 
                for rec in audit.get("recommendations", [])
            )),
        }

        return trend

    def calculate_entropy(self, data):
        """Berechnet Shannon-Entropie fuer Daten."""
        if not data:
            return 0

        if isinstance(data, str):
            data = data.encode('utf-8')

        entropy = 0
        for x in range(256):
            p_x = float(data.count(bytes([x]))) / len(data)
            if p_x > 0:
                entropy += -p_x * math.log(p_x, 2)
        return round(entropy, 4)

    def generate_insights(self, scans, audits):
        """Generiert Forschungs-Erkenntnisse."""
        insights = []

        proc_analysis = self.analyze_process_patterns(scans)
        if proc_analysis and proc_analysis.get("anomalies"):
            insights.append({
                "category": "Prozesse",
                "insight": f"{len(proc_analysis['anomalies'])} Prozess-Anomalien erkannt",
                "detail": proc_analysis["anomalies"]
            })

        net_analysis = self.analyze_network_patterns(scans)
        if net_analysis and net_analysis.get("anomalies"):
            insights.append({
                "category": "Netzwerk",
                "insight": f"{len(net_analysis['anomalies'])} Netzwerk-Anomalien erkannt",
                "detail": net_analysis["anomalies"]
            })

        trend = self.analyze_security_trends(audits)
        if trend:
            insights.append({
                "category": "Sicherheitstrends",
                "insight": f"{trend['scans_analyzed']} Audits analysiert",
                "detail": {"recommendations_count": len(trend["recommendations"])}
            })

        return insights

    def run_analysis(self):
        """Fuehrt vollstaendige Analyse durch."""
        print("=" * 60)
        print("DNA-WURM RESEARCH v17.0 — KI-ANALYSE-ENGINE")
        print("Forschungs-Engine fuer Mustererkennung")
        print("=" * 60)

        print("\n[1/4] Scan-Daten laden...")
        scans = self.load_scan_data()
        print(f"   {len(scans)} Scan-Ergebnisse geladen")

        print("\n[2/4] Audit-Daten laden...")
        audits = []
        for f in os.listdir(self.data_dir):
            if f.startswith("audit_") and f.endswith(".json"):
                with open(os.path.join(self.data_dir, f)) as fh:
                    audits.append(json.load(fh))
        print(f"   {len(audits)} Audit-Ergebnisse geladen")

        print("\n[3/4] Musteranalyse...")
        proc_analysis = self.analyze_process_patterns(scans)
        if proc_analysis:
            print(f"   Prozesse: {proc_analysis['total_processes_analyzed']} analysiert")
            print(f"   Anomalien: {len(proc_analysis.get('anomalies', []))}")

        net_analysis = self.analyze_network_patterns(scans)
        if net_analysis:
            print(f"   Verbindungen: {net_analysis['total_connections']} analysiert")
            print(f"   Anomalien: {len(net_analysis.get('anomalies', []))}")

        print("\n[4/4] Erkenntnisse generieren...")
        insights = self.generate_insights(scans, audits)
        print(f"   {len(insights)} Erkenntnisse generiert")

        # Speichere Report
        report = {
            "timestamp": datetime.now().isoformat(),
            "engine": "DNA-WURM RESEARCH v17.0 — KI-AnalysisEngine",
            "disclaimer": "Forschungszwecke. Nur eigene Daten.",
            "process_analysis": proc_analysis,
            "network_analysis": net_analysis,
            "security_trends": self.analyze_security_trends(audits),
            "insights": insights,
        }

        output_file = os.path.join(self.output_dir,
                                   f"analysis_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json")
        with open(output_file, 'w') as f:
            json.dump(report, f, indent=2, default=str)

        print(f"\n{'=' * 60}")
        print(f"Analyse abgeschlossen. Report gespeichert in:")
        print(f"   {output_file}")
        print(f"{'=' * 60}")

        return report

if __name__ == "__main__":
    engine = KIAnalysisEngine()
    engine.run_analysis()
