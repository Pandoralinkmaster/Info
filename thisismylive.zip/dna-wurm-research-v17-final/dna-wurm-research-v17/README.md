# DNA-WURM RESEARCH v17.0
## Defensives Forschungswerkzeug fuer Systemanalyse

### Ueberblick

DNA-WURM RESEARCH v17.0 ist eine modulare, defensiv ausgerichtete
Forschungsplattform fuer Systemanalyse und Sicherheitsaudit auf
eigenen Systemen.

### Module

| Modul | Datei | Funktion |
|-------|-------|----------|
| System Scanner | `modules/system_scanner.py` | Erfasst System-Info, Prozesse, Netzwerk, Benutzer |
| Security Auditor | `modules/security_auditor.py` | Prueft Konfiguration, Ports, Berechtigungen |
| KI-Analyse-Engine | `modules/ki_analysis_engine.py` | Mustererkennung, Anomalie-Detektion, Trends |
| Dashboard Server | `modules/dashboard_server.py` | Web-Dashboard auf localhost:58133 |
| Master Controller | `master_controller.py` | Orchestriert alle Module |

### Installation

```bash
# Abhaengigkeiten installieren
pip install psutil

# Ausfuehrbar machen (optional)
chmod +x master_controller.py
chmod +x modules/*.py
```

### Nutzung

```bash
# Einzelne Module
python3 master_controller.py scan
python3 master_controller.py audit
python3 master_controller.py analyze
python3 master_controller.py dashboard

# Alles auf einmal
python3 master_controller.py all

# Hilfe
python3 master_controller.py help
```

### Ausgabe

- Scan-Ergebnisse: `./data/scan_YYYYMMDD_HHMMSS.json`
- Audit-Reports: `./data/audit_YYYYMMDD_HHMMSS.json`
- Analyse-Reports: `./reports/analysis_YYYYMMDD_HHMMSS.json`
- Dashboard: http://localhost:58133

### Rechtlicher Hinweis

Dieses Tool ist ausschliesslich fuer:
- Defensive Sicherheitsforschung
- Analyse EIGENER Systeme
- Bildungszwecke
- Transparenz und Audit

Nicht fuer:
- Angriffe auf fremde Systeme
- Unautorisierten Zugriff
- Illegale Aktivitaeten

### Philosophie

"Angriff ist die beste Verteidigung" - Als theoretisches Prinzip:
Das Verstaendnis von Angriffsvektoren (durch legitime Forschung)
  -> staerkt die Verteidigung
  -> verbessert die Sicherheit
  -> schuetzt die eigenen Systeme

### Autor

Finn Jona Thorsten Lischke - ABSOLUTE SOVEREIGN 2026
