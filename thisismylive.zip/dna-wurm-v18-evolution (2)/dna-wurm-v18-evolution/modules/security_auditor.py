#!/usr/bin/env python3
"""
DNA-WURM RESEARCH v18.0 - SECURITY AUDITOR
Defensiver Sicherheits-Auditor fuer eigene Systeme.
Erweitert mit: SUID-Binaries, Cron-Jobs, Container-Escape, K8s.

Finn Jona Thorsten Lischke - ABSOLUTE SOVEREIGN 2026
"""

import os
import json
import socket
import subprocess
import platform
from datetime import datetime
from pathlib import Path

class SecurityAuditor:
    def __init__(self, output_dir="./data"):
        self.output_dir = output_dir
        self.findings = []
        self.recommendations = []
        os.makedirs(output_dir, exist_ok=True)

    def check_open_ports(self, ports=[21, 22, 23, 25, 53, 80, 110, 143, 443, 445, 
                                       3306, 3389, 5432, 5900, 8080, 8443]):
        open_ports = []
        for port in ports:
            try:
                sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                sock.settimeout(1)
                result = sock.connect_ex(('127.0.0.1', port))
                if result == 0:
                    open_ports.append(port)
                    if port in [21, 23, 25, 110, 143]:
                        self.findings.append({
                            "severity": "MEDIUM",
                            "category": "Unverschluesseltes Protokoll",
                            "detail": f"Port {port} ist offen (unverschluesselt)",
                            "recommendation": f"Port {port} deaktivieren oder TLS erzwingen"
                        })
                    elif port in [22, 3389, 5900]:
                        self.findings.append({
                            "severity": "INFO",
                            "category": "Remote-Zugriff",
                            "detail": f"Port {port} ist offen (Remote-Zugriff)",
                            "recommendation": f"Zugriff auf localhost beschraenken, Key-Auth erzwingen"
                        })
                    else:
                        self.findings.append({
                            "severity": "INFO",
                            "category": "Offener Port",
                            "detail": f"Port {port} ist offen",
                            "recommendation": "Pruefen ob noetig"
                        })
                sock.close()
            except:
                pass
        return open_ports

    def check_file_permissions(self, paths=["/etc/passwd", "/etc/shadow", 
                                             "/etc/ssh/sshd_config", "/tmp"]):
        for path in paths:
            if os.path.exists(path):
                stat = os.stat(path)
                mode = oct(stat.st_mode)[-3:]
                if path == "/etc/shadow" and mode != "000":
                    self.findings.append({
                        "severity": "HIGH",
                        "category": "Dateiberechtigungen",
                        "detail": f"/etc/shadow hat Berechtigungen {mode}",
                        "recommendation": "Berechtigungen auf 000 setzen"
                    })
                elif path == "/tmp" and int(mode[0]) < 1:
                    self.findings.append({
                        "severity": "MEDIUM",
                        "category": "Dateiberechtigungen",
                        "detail": f"/tmp hat keine Sticky-Bit ({mode})",
                        "recommendation": "chmod +t /tmp"
                    })

    def check_ssh_config(self):
        ssh_config = "/etc/ssh/sshd_config"
        if os.path.exists(ssh_config):
            try:
                with open(ssh_config, 'r') as f:
                    config = f.read()
                checks = {
                    "PasswordAuthentication": ("no", "HIGH", "Passwort-Auth deaktivieren"),
                    "PermitRootLogin": ("no", "HIGH", "Root-Login deaktivieren"),
                    "PubkeyAuthentication": ("yes", "MEDIUM", "Key-Auth aktivieren"),
                    "X11Forwarding": ("no", "LOW", "X11-Forwarding deaktivieren"),
                }
                for key, (expected, severity, rec) in checks.items():
                    if key in config:
                        for line in config.split('\n'):
                            if line.strip().startswith(key):
                                value = line.split()[1].strip()
                                if value != expected:
                                    self.findings.append({
                                        "severity": severity,
                                        "category": "SSH-Konfiguration",
                                        "detail": f"{key} = {value} (erwartet: {expected})",
                                        "recommendation": rec
                                    })
            except PermissionError:
                self.findings.append({
                    "severity": "INFO",
                    "category": "SSH-Konfiguration",
                    "detail": "Kein Zugriff auf sshd_config",
                    "recommendation": "Als root ausfuehren"
                })

    def check_sudo_config(self):
        sudoers = "/etc/sudoers"
        if os.path.exists(sudoers):
            try:
                with open(sudoers, 'r') as f:
                    content = f.read()
                if "NOPASSWD" in content:
                    self.findings.append({
                        "severity": "MEDIUM",
                        "category": "Sudo-Konfiguration",
                        "detail": "NOPASSWD in sudoers gefunden",
                        "recommendation": "Passwort fuer sudo erzwingen"
                    })
            except PermissionError:
                pass

    def check_suid_binaries(self):
        try:
            result = subprocess.run(['find', '/', '-perm', '-4000', '-type', 'f'], 
                                  capture_output=True, text=True, timeout=30)
            if result.stdout:
                suid_files = [f for f in result.stdout.strip().split('\n') if f]
                if len(suid_files) > 0:
                    self.findings.append({
                        "severity": "MEDIUM",
                        "category": "SUID-Binaries",
                        "detail": f"{len(suid_files)} SUID-Binaries gefunden",
                        "recommendation": "Jede SUID-Binary auf Notwendigkeit pruefen"
                    })
        except Exception as e:
            pass

    def check_cron_jobs(self):
        cron_dirs = ["/etc/cron.d", "/etc/cron.daily", "/etc/cron.hourly", 
                     "/etc/cron.weekly", "/etc/cron.monthly", "/var/spool/cron"]
        cron_entries = []
        for cd in cron_dirs:
            if os.path.exists(cd):
                try:
                    for f in os.listdir(cd):
                        cron_entries.append(os.path.join(cd, f))
                except:
                    pass
        if cron_entries:
            self.findings.append({
                "severity": "INFO",
                "category": "Cron-Jobs",
                "detail": f"{len(cron_entries)} Cron-Eintraege gefunden",
                "recommendation": "Auf ungewoehnliche Eintraege pruefen"
            })

    def check_container_escape(self):
        escape_indicators = []

        # Check for writable /proc
        if os.path.exists("/proc/self"):
            try:
                test_file = "/proc/self/comm"
                if os.access(test_file, os.W_OK):
                    escape_indicators.append("Writable /proc/self/comm")
            except:
                pass

        # Check for CAP_SYS_ADMIN
        try:
            with open("/proc/self/status") as f:
                status = f.read()
                if "CapEff:" in status:
                    cap_eff = status.split("CapEff:")[1].split("\n")[0].strip()
                    if cap_eff != "0000000000000000":
                        escape_indicators.append(f"Capabilities: {cap_eff}")
        except:
            pass

        # Check for docker socket
        if os.path.exists("/var/run/docker.sock"):
            escape_indicators.append("Docker socket accessible")

        if escape_indicators:
            self.findings.append({
                "severity": "HIGH",
                "category": "Container-Escape",
                "detail": f"{len(escape_indicators)} Escape-Indikatoren: {', '.join(escape_indicators)}",
                "recommendation": "Container-Hardening durchfuehren, Capabilities einschraenken"
            })

    def check_kubernetes(self):
        k8s_indicators = []

        # Check for service account token
        if os.path.exists("/var/run/secrets/kubernetes.io/serviceaccount/token"):
            k8s_indicators.append("K8s ServiceAccount Token vorhanden")

        # Check env vars
        for key in os.environ:
            if "KUBERNETES" in key.upper():
                k8s_indicators.append(f"K8s Env: {key}")

        if k8s_indicators:
            self.findings.append({
                "severity": "INFO",
                "category": "Kubernetes",
                "detail": f"{len(k8s_indicators)} K8s-Indikatoren",
                "recommendation": "Pod-Security-Standards pruefen"
            })

    def check_environment_secrets(self):
        sensitive_patterns = ['password', 'secret', 'token', 'api_key', 'private_key']
        found = []
        for key, value in os.environ.items():
            if any(p in key.lower() for p in sensitive_patterns):
                masked = value[:3] + '*' * (len(value) - 6) + value[-3:] if len(value) > 6 else '***'
                found.append({"key": key, "value_masked": masked})
        if found:
            self.findings.append({
                "severity": "MEDIUM",
                "category": "Umgebungsvariablen",
                "detail": f"{len(found)} sensitive Variablen in Umgebung gefunden",
                "recommendation": "Secrets in sicheren Speicher auslagern"
            })

    def generate_report(self):
        severity_counts = {"CRITICAL": 0, "HIGH": 0, "MEDIUM": 0, "LOW": 0, "INFO": 0}
        for finding in self.findings:
            sev = finding.get("severity", "INFO")
            if sev in severity_counts:
                severity_counts[sev] += 1
        report = {
            "timestamp": datetime.now().isoformat(),
            "auditor": "DNA-WURM RESEARCH v18.0 - Security Auditor",
            "disclaimer": "Nur fuer eigene Systeme. Forschungszwecke.",
            "summary": {
                "total_findings": len(self.findings),
                "severity_distribution": severity_counts,
            },
            "findings": self.findings,
            "recommendations": list(set(f["recommendation"] for f in self.findings)),
        }
        output_file = os.path.join(self.output_dir,
                                   f"audit_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json")
        with open(output_file, 'w') as f:
            json.dump(report, f, indent=2)
        return report, output_file

    def run_audit(self):
        print("=" * 60)
        print("DNA-WURM RESEARCH v18.0 - SECURITY AUDITOR")
        print("Defensiver Audit - Nur eigene Systeme")
        print("=" * 60)

        print("\n[1/8] Offene Ports pruefen...")
        open_ports = self.check_open_ports()
        print(f"   {len(open_ports)} offene Ports gefunden")

        print("\n[2/8] Dateiberechtigungen pruefen...")
        self.check_file_permissions()
        print(f"   {len(self.findings)} Findings bisher")

        print("\n[3/8] SSH-Konfiguration pruefen...")
        self.check_ssh_config()
        print(f"   {len(self.findings)} Findings bisher")

        print("\n[4/8] Sudo-Konfiguration pruefen...")
        self.check_sudo_config()
        print(f"   {len(self.findings)} Findings bisher")

        print("\n[5/8] SUID-Binaries pruefen...")
        self.check_suid_binaries()
        print(f"   {len(self.findings)} Findings bisher")

        print("\n[6/8] Cron-Jobs pruefen...")
        self.check_cron_jobs()
        print(f"   {len(self.findings)} Findings bisher")

        print("\n[7/8] Container-Escape pruefen...")
        self.check_container_escape()
        print(f"   {len(self.findings)} Findings bisher")

        print("\n[8/8] Kubernetes pruefen...")
        self.check_kubernetes()
        print(f"   {len(self.findings)} Findings bisher")

        print("\n[9/8] Umgebungsvariablen pruefen...")
        self.check_environment_secrets()
        print(f"   {len(self.findings)} Findings bisher")

        report, output_file = self.generate_report()

        print(f"\n{'=' * 60}")
        print("AUDIT ZUSAMMENFASSUNG")
        print(f"{'=' * 60}")
        print(f"Gesamt-Findings: {report['summary']['total_findings']}")
        for sev, count in report['summary']['severity_distribution'].items():
            if count > 0:
                print(f"  {sev}: {count}")
        print(f"\nReport gespeichert: {output_file}")
        print(f"{'=' * 60}")

        return report

if __name__ == "__main__":
    auditor = SecurityAuditor()
    auditor.run_audit()
