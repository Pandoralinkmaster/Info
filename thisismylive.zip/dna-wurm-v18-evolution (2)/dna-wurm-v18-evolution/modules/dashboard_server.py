#!/usr/bin/env python3
"""
DNA-WURM RESEARCH v18.0 - DASHBOARD SERVER
Web-basiertes Dashboard fuer Forschungsergebnisse.
Erweitert mit: Evolution-API, Mutations-API, Wissensbasis-API.

Finn Jona Thorsten Lischke - ABSOLUTE SOVEREIGN 2026
"""

import os
import json
import http.server
import socketserver
from datetime import datetime
from urllib.parse import urlparse

PORT = 58133
DATA_DIR = "./data"
REPORTS_DIR = "./reports"
WEB_DIR = "./web"
EVOLUTION_DIR = "./evolution"
MUTATIONS_DIR = "./mutations"
KNOWLEDGE_DIR = "./knowledge"

class DashboardHandler(http.server.SimpleHTTPRequestHandler):
    def do_GET(self):
        parsed = urlparse(self.path)
        path = parsed.path

        if path == "/":
            self.serve_dashboard()
        elif path == "/api/scans":
            self.serve_api_scans()
        elif path == "/api/audits":
            self.serve_api_audits()
        elif path == "/api/analysis":
            self.serve_api_analysis()
        elif path == "/api/stats":
            self.serve_api_stats()
        elif path == "/api/evolution":
            self.serve_api_evolution()
        elif path == "/api/mutations":
            self.serve_api_mutations()
        elif path == "/api/knowledge":
            self.serve_api_knowledge()
        else:
            self.send_response(404)
            self.end_headers()

    def serve_dashboard(self):
        html_path = os.path.join(WEB_DIR, "dashboard.html")
        if os.path.exists(html_path):
            self.send_response(200)
            self.send_header("Content-type", "text/html; charset=utf-8")
            self.end_headers()
            with open(html_path, 'rb') as f:
                self.wfile.write(f.read())
        else:
            self.send_response(500)
            self.end_headers()
            self.wfile.write(b"Dashboard HTML nicht gefunden")

    def serve_api_scans(self):
        scans = []
        if os.path.exists(DATA_DIR):
            for f in sorted(os.listdir(DATA_DIR)):
                if f.startswith("scan_") and f.endswith(".json"):
                    scans.append(f)
        self.send_json({"scans": scans, "count": len(scans)})

    def serve_api_audits(self):
        audits = []
        if os.path.exists(DATA_DIR):
            for f in sorted(os.listdir(DATA_DIR)):
                if f.startswith("audit_") and f.endswith(".json"):
                    audits.append(f)
        self.send_json({"audits": audits, "count": len(audits)})

    def serve_api_analysis(self):
        analyses = []
        if os.path.exists(REPORTS_DIR):
            for f in sorted(os.listdir(REPORTS_DIR)):
                if f.startswith("analysis_") and f.endswith(".json"):
                    analyses.append(f)
        if analyses:
            with open(os.path.join(REPORTS_DIR, analyses[-1])) as fh:
                data = json.load(fh)
            self.send_json(data)
        else:
            self.send_json({"error": "Keine Analyse vorhanden"})

    def serve_api_stats(self):
        scans = len([f for f in os.listdir(DATA_DIR) if f.startswith("scan_")]) if os.path.exists(DATA_DIR) else 0
        audits = len([f for f in os.listdir(DATA_DIR) if f.startswith("audit_")]) if os.path.exists(DATA_DIR) else 0
        analyses = len([f for f in os.listdir(REPORTS_DIR) if f.startswith("analysis_")]) if os.path.exists(REPORTS_DIR) else 0
        mutations = len([f for f in os.listdir(MUTATIONS_DIR) if f.startswith("mutation_")]) if os.path.exists(MUTATIONS_DIR) else 0

        # Get generation
        generation = 1
        gen_file = os.path.join(EVOLUTION_DIR, "generation.json")
        if os.path.exists(gen_file):
            with open(gen_file) as f:
                gen_data = json.load(f)
                generation = gen_data.get("generation", 1)

        self.send_json({
            "scans": scans,
            "audits": audits,
            "analyses": analyses,
            "mutations": mutations,
            "generation": generation,
            "timestamp": datetime.now().isoformat(),
        })

    def serve_api_evolution(self):
        gen_file = os.path.join(EVOLUTION_DIR, "generation.json")
        generation = {"generation": 1, "timestamp": datetime.now().isoformat()}
        if os.path.exists(gen_file):
            with open(gen_file) as f:
                generation = json.load(f)

        # Get latest mutations
        mutations = []
        if os.path.exists(MUTATIONS_DIR):
            mut_files = sorted([f for f in os.listdir(MUTATIONS_DIR) if f.startswith("mutation_")])[-5:]
            for mf in mut_files:
                try:
                    with open(os.path.join(MUTATIONS_DIR, mf)) as f:
                        mutations.append(json.load(f))
                except:
                    pass

        self.send_json({
            "generation": generation,
            "recent_mutations": mutations,
            "total_mutations": len([f for f in os.listdir(MUTATIONS_DIR) if f.startswith("mutation_")]) if os.path.exists(MUTATIONS_DIR) else 0,
        })

    def serve_api_mutations(self):
        mutations = []
        if os.path.exists(MUTATIONS_DIR):
            for f in sorted(os.listdir(MUTATIONS_DIR)):
                if f.startswith("mutation_") and f.endswith(".json"):
                    mutations.append(f)
        self.send_json({"mutations": mutations, "count": len(mutations)})

    def serve_api_knowledge(self):
        knowledge = {"patterns": [], "anomalies": [], "optimizations": [], "strategies": []}
        kb_file = os.path.join(KNOWLEDGE_DIR, "base.json")
        if os.path.exists(kb_file):
            with open(kb_file) as f:
                knowledge = json.load(f)
        self.send_json(knowledge)

    def send_json(self, data):
        self.send_response(200)
        self.send_header("Content-type", "application/json")
        self.end_headers()
        self.wfile.write(json.dumps(data, indent=2, default=str).encode('utf-8'))

def run_server(port=PORT):
    for d in [DATA_DIR, REPORTS_DIR, WEB_DIR, EVOLUTION_DIR, MUTATIONS_DIR, KNOWLEDGE_DIR]:
        os.makedirs(d, exist_ok=True)

    with socketserver.TCPServer(("", port), DashboardHandler) as httpd:
        print("=" * 60)
        print("DNA-WURM RESEARCH v18.0 - DASHBOARD SERVER")
        print("Dashboard: http://localhost:" + str(port))
        print("=" * 60)
        print("Strg+C zum Beenden")
        try:
            httpd.serve_forever()
        except KeyboardInterrupt:
            print("\nServer beendet.")

if __name__ == "__main__":
    run_server()
