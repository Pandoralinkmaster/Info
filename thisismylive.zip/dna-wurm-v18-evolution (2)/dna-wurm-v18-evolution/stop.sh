#!/bin/bash
# DNA-WURM RESEARCH v18.0 - STOP SCRIPT

cd "$(dirname "$0")"

GREEN='\033[0;32m'
RED='\033[0;31m'
NC='\033[0m'

echo -e "${RED}Stoppe DNA-WURM v18.0...${NC}"

# Stoppe Dashboard
if [ -f .dashboard.pid ]; then
    PID=$(cat .dashboard.pid)
    if kill -0 $PID 2>/dev/null; then
        kill $PID
        echo -e "${GREEN}Dashboard gestoppt (PID: $PID)${NC}"
    fi
    rm -f .dashboard.pid
fi

# Stoppe Evolution
if [ -f .evolution.pid ]; then
    PID=$(cat .evolution.pid)
    if kill -0 $PID 2>/dev/null; then
        kill $PID
        echo -e "${GREEN}Evolution gestoppt (PID: $PID)${NC}"
    fi
    rm -f .evolution.pid
fi

# Stoppe Evolution-Loop
if [ -f .evolution_loop.pid ]; then
    PID=$(cat .evolution_loop.pid)
    if kill -0 $PID 2>/dev/null; then
        kill $PID
        echo -e "${GREEN}Evolution-Loop gestoppt (PID: $PID)${NC}"
    fi
    rm -f .evolution_loop.pid
fi

# Stoppe Pinggy-Tunnel
if [ -f .pinggy.pid ]; then
    PID=$(cat .pinggy.pid)
    if kill -0 $PID 2>/dev/null; then
        kill $PID
        echo -e "${GREEN}Pinggy-Tunnel gestoppt (PID: $PID)${NC}"
    fi
    rm -f .pinggy.pid
fi

# Kill alle verbleibenden Prozesse
pkill -f "dashboard_server.py" 2>/dev/null
pkill -f "evolution_engine.py" 2>/dev/null
pkill -f ".evolution_loop.sh" 2>/dev/null

echo -e "${GREEN}Alle Prozesse gestoppt.${NC}"

# Update Status
if [ -f .status.json ]; then
    python3 -c "
import json
with open('.status.json') as f:
    d = json.load(f)
d['status'] = 'stopped'
d['stopped'] = '$(date -Iseconds)'
with open('.status.json', 'w') as f:
    json.dump(d, f, indent=2)
"
fi
