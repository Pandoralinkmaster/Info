#!/bin/bash
# DNA-WURM RESEARCH v18.0 - SOFORTIGE EVOLUTION

cd "$(dirname "$0")"

CYAN='\033[0;36m'
GREEN='\033[0;32m'
NC='\033[0m'

echo -e "${CYAN}"
echo "============================================================"
echo "  DNA-WURM v18.0 - SOFORTIGE EVOLUTION"
echo "============================================================"
echo -e "${NC}"

python3 evolution/evolution_engine.py

echo -e "${GREEN}Evolution abgeschlossen.${NC}"
