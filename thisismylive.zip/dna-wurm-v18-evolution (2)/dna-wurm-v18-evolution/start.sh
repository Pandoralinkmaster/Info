#!/bin/bash
# DNA-WURM RESEARCH v18.0 - START SCRIPT
# Startet Dashboard + Evolution im Hintergrund
# Mit optionaler Pinggy-Tunnel-Unterstuetzung

cd "$(dirname "$0")"

PORT=58133
EVOLVE_INTERVAL=300

# Farben
GREEN='\033[0;32m'
CYAN='\033[0;36m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m'

echo -e "${CYAN}"
echo "============================================================"
echo "  DNA-WURM RESEARCH v18.0 - SELBST-EVOLVIERENDE PLATTFORM"
echo "============================================================"
echo -e "${NC}"

# Pruefe Abhaengigkeiten
if ! python3 -c "import psutil" 2>/dev/null; then
    echo -e "${YELLOW}psutil nicht installiert. Installiere...${NC}"
    pip install psutil
fi

# Erstelle Verzeichnisse
mkdir -p data reports web evolution mutations knowledge logs

echo -e "${GREEN}[1/5] Starte Dashboard Server auf Port $PORT...${NC}"
nohup python3 modules/dashboard_server.py > logs/dashboard.log 2>&1 &
DASHBOARD_PID=$!
echo $DASHBOARD_PID > .dashboard.pid
echo -e "${GREEN}   Dashboard PID: $DASHBOARD_PID${NC}"
sleep 2

# Pruefe ob Dashboard laeuft
if kill -0 $DASHBOARD_PID 2>/dev/null; then
    echo -e "${GREEN}   Dashboard laeuft auf http://localhost:$PORT${NC}"
else
    echo -e "${RED}   Dashboard konnte nicht gestartet werden!${NC}"
    cat logs/dashboard.log
    exit 1
fi

echo -e "${GREEN}[2/5] Starte ersten Evolution-Zyklus...${NC}"
python3 evolution/evolution_engine.py > logs/evolution_$(date +%Y%m%d_%H%M%S).log 2>&1 &
EVO_PID=$!
echo $EVO_PID > .evolution.pid
echo -e "${GREEN}   Evolution PID: $EVO_PID${NC}"

echo -e "${GREEN}[3/5] Starte dauerhafte Evolution (Intervall: ${EVOLVE_INTERVAL}s)...${NC}"
cat > .evolution_loop.sh << 'LOOP'
#!/bin/bash
cd "$(dirname "$0")"
INTERVAL=300
while true; do
    sleep $INTERVAL
    python3 evolution/evolution_engine.py >> logs/evolution_continuous.log 2>&1
done
LOOP
chmod +x .evolution_loop.sh
nohup ./.evolution_loop.sh > /dev/null 2>&1 &
LOOP_PID=$!
echo $LOOP_PID > .evolution_loop.pid
echo -e "${GREEN}   Evolution-Loop PID: $LOOP_PID${NC}"

echo -e "${GREEN}[4/5] Speichere Status...${NC}"
cat > .status.json << STATUS
{
  "status": "running",
  "dashboard_pid": $DASHBOARD_PID,
  "evolution_pid": $EVO_PID,
  "evolution_loop_pid": $LOOP_PID,
  "port": $PORT,
  "started": "$(date -Iseconds)",
  "local_url": "http://localhost:$PORT",
  "global_url": null
}
STATUS
echo -e "${GREEN}   Status gespeichert in .status.json${NC}"

echo -e "${YELLOW}[5/5] Pinggy-Tunnel starten? (j/n)${NC}"
read -t 5 -n 1 -r START_TUNNEL
if [[ $START_TUNNEL =~ ^[Jj]$ ]]; then
    echo -e "\n${CYAN}Starte Pinggy-Tunnel...${NC}"
    nohup ssh -p 443 -o StrictHostKeyChecking=no -o ServerAliveInterval=30 -R0:127.0.0.1:$PORT free@a.pinggy.io > logs/pinggy.log 2>&1 &
    TUNNEL_PID=$!
    echo $TUNNEL_PID > .pinggy.pid
    echo -e "${GREEN}   Tunnel PID: $TUNNEL_PID${NC}"
    sleep 3
    if grep -q "http://" logs/pinggy.log 2>/dev/null; then
        URL=$(grep "http://" logs/pinggy.log | head -1 | awk '{print $1}')
        echo -e "${GREEN}   Globale URL: $URL${NC}"
        sed -i "s|"global_url": null|"global_url": "$URL"|" .status.json
    fi
else
    echo -e "\n${YELLOW}   Tunnel uebersprungen. Starte manuell mit: ./tunnel.sh${NC}"
fi

echo -e "\n${CYAN}============================================================"
echo "  DNA-WURM v18.0 LAUEFT"
echo "============================================================"
echo -e "  Lokale URL:    http://localhost:$PORT"
if [ -f .status.json ]; then
    GLOBAL=$(python3 -c "import json; print(json.load(open('.status.json')).get('global_url','nicht verfuegbar'))")
    echo -e "  Globale URL:   $GLOBAL"
fi
echo -e "  Dashboard PID: $DASHBOARD_PID"
echo -e "  Evolution PID: $LOOP_PID"
echo -e "============================================================${NC}"
echo -e "\n${YELLOW}Befehle:${NC}"
echo -e "  ./stop.sh       - Server stoppen"
echo -e "  ./status.sh     - Status anzeigen"
echo -e "  ./tunnel.sh     - Pinggy-Tunnel starten"
echo -e "  ./evolve.sh     - Sofortige Evolution"
echo -e "  tail -f logs/dashboard.log"
echo -e "  tail -f logs/evolution_continuous.log"
