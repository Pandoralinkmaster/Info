#!/usr/bin/env python3
"""
DNA-WURM RESEARCH v18.0 - MASTER CONTROLLER
Orchestriert alle Module + Evolution Engine.
Nutzung: python3 master_controller.py [scan|audit|analyze|dashboard|evolve|all|help]

Finn Jona Thorsten Lischke - ABSOLUTE SOVEREIGN 2026
"""

import sys
import os
import subprocess
import time
import threading
import signal
from datetime import datetime

MODULES_DIR = "./modules"
EVOLUTION_DIR = "./evolution"
DATA_DIR = "./data"
REPORTS_DIR = "./reports"

# Globaler Zustand fuer dauerhafte Evolution
evolution_running = False
evolution_thread = None

def ensure_dirs():
    for d in [DATA_DIR, REPORTS_DIR, "./web", EVOLUTION_DIR, "./mutations", "./knowledge", "./logs"]:
        os.makedirs(d, exist_ok=True)

def run_scanner():
    print("\n" + "="*60)
    print("STARTE SYSTEM SCANNER")
    print("="*60)
    result = subprocess.run([sys.executable, os.path.join(MODULES_DIR, "system_scanner.py")],
                          capture_output=False, text=True)
    return result.returncode == 0

def run_auditor():
    print("\n" + "="*60)
    print("STARTE SECURITY AUDITOR")
    print("="*60)
    result = subprocess.run([sys.executable, os.path.join(MODULES_DIR, "security_auditor.py")],
                          capture_output=False, text=True)
    return result.returncode == 0

def run_analysis():
    print("\n" + "="*60)
    print("STARTE KI-ANALYSE-ENGINE")
    print("="*60)
    result = subprocess.run([sys.executable, os.path.join(MODULES_DIR, "ki_analysis_engine.py")],
                          capture_output=False, text=True)
    return result.returncode == 0

def run_dashboard():
    print("\n" + "="*60)
    print("STARTE DASHBOARD SERVER")
    print("="*60)
    subprocess.run([sys.executable, os.path.join(MODULES_DIR, "dashboard_server.py")])

def run_evolution():
    print("\n" + "="*60)
    print("STARTE EVOLUTION ENGINE")
    print("="*60)
    result = subprocess.run([sys.executable, os.path.join(EVOLUTION_DIR, "evolution_engine.py")],
                          capture_output=False, text=True)
    return result.returncode == 0

def run_continuous_evolution(interval=300):
    global evolution_running
    print("\n" + "="*60)
    print("DAUERHAFTE EVOLUTION WIRD GESTARTET")
    print(f"Intervall: {interval}s")
    print("="*60)

    evolution_running = True

    def evolution_worker():
        while evolution_running:
            try:
                subprocess.run([sys.executable, os.path.join(EVOLUTION_DIR, "evolution_engine.py")],
                              capture_output=False, text=True, timeout=120)
                print(f"\n[Naechste Evolution in {interval}s...]\n")
                time.sleep(interval)
            except subprocess.TimeoutExpired:
                print("Evolution-Zyklus abgebrochen (Timeout)")
            except Exception as e:
                print(f"Evolution-Fehler: {e}")

    thread = threading.Thread(target=evolution_worker, daemon=True)
    thread.start()

    print("\nEvolution laeuft im Hintergrund.")
    print("Strg+C zum Beenden oder 'master_controller.py stop-evolution'")

    try:
        while evolution_running:
            time.sleep(1)
    except KeyboardInterrupt:
        evolution_running = False
        print("\nEvolution gestoppt.")

def run_all():
    print("\n" + "="*60)
    print("DNA-WURM RESEARCH v18.0 - VOLLSTAENDIGER DURCHLAUF")
    print("="*60)

    ensure_dirs()

    print("\n[1/5] System-Scan...")
    run_scanner()
    time.sleep(1)

    print("\n[2/5] Security-Audit...")
    run_auditor()
    time.sleep(1)

    print("\n[3/5] KI-Analyse...")
    run_analysis()
    time.sleep(1)

    print("\n[4/5] Evolution...")
    run_evolution()
    time.sleep(1)

    print("\n[5/5] Dashboard starten...")
    print("\nDashboard wird gestartet. Oeffne http://localhost:58133")
    print("Strg+C zum Beenden\n")
    run_dashboard()

def run_auto_mode():
    print("\n" + "="*70)
    print("DNA-WURM RESEARCH v18.0 - AUTO-MODUS (DAUERHAFTE WEITERENTWICKLUNG)")
    print("="*70)
    print("\nDieser Modus fuehrt kontinuierlich durch:")
    print("  1. System-Scan")
    print("  2. Security-Audit")
    print("  3. KI-Analyse")
    print("  4. Evolution (Mutation + Fitness + Selektion)")
    print("  5. Dashboard-Update")
    print("\nDer Wurm entwickelt sich selbststaendig weiter.")
    print("Strg+C zum Beenden")
    print("="*70 + "\n")

    ensure_dirs()

    cycle = 0
    try:
        while True:
            cycle += 1
            print(f"\n{'='*70}")
            print(f"ZYKLUS {cycle} - {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
            print(f"{'='*70}")

            print("\n[1/5] System-Scan...")
            run_scanner()

            print("\n[2/5] Security-Audit...")
            run_auditor()

            print("\n[3/5] KI-Analyse...")
            run_analysis()

            print("\n[4/5] Evolution...")
            run_evolution()

            print("\n[5/5] Warte auf naechsten Zyklus...")
            print(f"\n{'='*70}")
            print(f"Zyklus {cycle} abgeschlossen. Naechster in 60s...")
            print(f"{'='*70}")
            time.sleep(60)

    except KeyboardInterrupt:
        print(f"\n{'='*70}")
        print("AUTO-MODUS BEENDET")
        print(f"Gesamt-Zyklen: {cycle}")
        print(f"{'='*70}")

def print_help():
    print("""
DNA-WURM RESEARCH v18.0 - MASTER CONTROLLER
============================================

Nutzung: python3 master_controller.py [BEFEHL]

Befehle:
  scan              - System-Scanner ausfuehren
  audit             - Security-Auditor ausfuehren
  analyze           - KI-Analyse-Engine ausfuehren
  dashboard         - Dashboard-Server starten
  evolve            - Einzelne Evolution durchfuehren
  evolve-continuous - Dauerhafte Evolution starten
  auto              - Auto-Modus (Scan + Audit + Analyse + Evolution)
  all               - Alles ausfuehren (einmalig)
  help              - Diese Hilfe anzeigen

Beispiele:
  python3 master_controller.py scan
  python3 master_controller.py auto
  python3 master_controller.py evolve-continuous 600

Hinweise:
  - Alle Module arbeiten NUR auf dem lokalen System
  - Keine Netzwerk-Angriffe, keine fremden Systeme
  - Forschungszwecke, defensiver Fokus
  - Ergebnisse werden in ./data/ und ./reports/ gespeichert
  - Mutationen in ./mutations/
  - Wissensbasis in ./knowledge/
  - Logs in ./logs/

Evolution:
  Der Wurm entwickelt sich durch:
  - Mutation: Neue Faehigkeiten generieren
  - Fitness: Mutationen bewerten
  - Selektion: Beste Mutationen behalten
  - Wissen: Gelernte Muster speichern

Finn Jona Thorsten Lischke - ABSOLUTE SOVEREIGN 2026
""")

if __name__ == "__main__":
    ensure_dirs()

    if len(sys.argv) < 2:
        print_help()
        sys.exit(0)

    cmd = sys.argv[1].lower()

    if cmd == "scan":
        run_scanner()
    elif cmd == "audit":
        run_auditor()
    elif cmd == "analyze":
        run_analysis()
    elif cmd == "dashboard":
        run_dashboard()
    elif cmd == "evolve":
        run_evolution()
    elif cmd == "evolve-continuous":
        interval = int(sys.argv[2]) if len(sys.argv) > 2 else 300
        run_continuous_evolution(interval)
    elif cmd == "auto":
        run_auto_mode()
    elif cmd == "all":
        run_all()
    elif cmd in ["help", "-h", "--help"]:
        print_help()
    else:
        print(f"Unbekannter Befehl: {cmd}")
        print_help()
