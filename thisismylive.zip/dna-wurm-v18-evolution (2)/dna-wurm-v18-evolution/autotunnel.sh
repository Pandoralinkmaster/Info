#!/bin/bash
# DNA-WURM RESEARCH v18.0 - AUTO-RECONNECT TUNNEL
# Startet den Tunnel automatisch neu wenn er abbricht

cd "$(dirname "$0")"

PORT=58133
CYAN='\033[0;36m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m'

echo -e "${CYAN}"
echo "============================================================"
echo "  DNA-WURM v18.0 - AUTO-RECONNECT TUNNEL"
echo "============================================================"
echo -e "${NC}"

while true; do
    echo -e "${GREEN}[$(date '+%H:%M:%S')] Starte Tunnel...${NC}"

    ssh -p 443 \
        -o StrictHostKeyChecking=no \
        -o ServerAliveInterval=30 \
        -o ServerAliveCountMax=3 \
        -o ExitOnForwardFailure=yes \
        -R0:127.0.0.1:$PORT \
        free@a.pinggy.io 2>&1 | tee logs/pinggy_autotunnel.log | while read line; do
            if echo "$line" | grep -q "http://"; then
                URL=$(echo "$line" | grep "http://" | awk '{print $1}')
                echo -e "${GREEN}"
                echo "============================================================"
                echo "  NEUE URL: $URL"
                echo "============================================================"
                echo -e "${NC}"
                echo "$URL" > .global_url
            fi
            echo "[$(date '+%H:%M:%S')] $line" >> logs/pinggy_history.log
        done

    echo -e "${YELLOW}[$(date '+%H:%M:%S')] Tunnel abgebrochen. Reconnect in 5s...${NC}"
    sleep 5
done
