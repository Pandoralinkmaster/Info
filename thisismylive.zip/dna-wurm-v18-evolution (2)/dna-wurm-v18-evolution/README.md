# DNA-WURM RESEARCH v18.0
## Selbst-Evolvierende Forschungsplattform fuer Systemanalyse

### Ueberblick

DNA-WURM RESEARCH v18.0 ist eine modulare, **selbst-evolvierende**
Forschungsplattform fuer Systemanalyse und Sicherheitsaudit auf
eigenen Systemen. Der Wurm lernt, mutiert und verbessert sich
dauerhaft durch Evolution.

### Module

| Modul | Datei | Funktion |
|-------|-------|----------|
| System Scanner | `modules/system_scanner.py` | System-Info, Prozesse, Netzwerk, Container-Erkennung |
| Security Auditor | `modules/security_auditor.py` | Konfiguration, Ports, SUID, Cron, Container-Escape, K8s |
| KI-Analyse-Engine | `modules/ki_analysis_engine.py` | Mustererkennung, Anomalie-Detektion, Trends, Wissensintegration |
| Dashboard Server | `modules/dashboard_server.py` | Web-Dashboard auf localhost:58133 |
| Evolution Engine | `evolution/evolution_engine.py` | Mutation, Fitness, Selektion, Wissensbasis |
| Master Controller | `master_controller.py` | Orchestriert alle Module + Evolution |

### Verzeichnisstruktur

```
dna-wurm-v18-evolution/
├── master_controller.py      # Hauptsteuerung
├── modules/
│   ├── system_scanner.py      # System-Scanner
│   ├── security_auditor.py    # Security-Auditor
│   ├── ki_analysis_engine.py  # KI-Analyse
│   └── dashboard_server.py    # Dashboard-Server
├── evolution/
│   └── evolution_engine.py    # Evolution-Engine
├── web/
│   └── dashboard.html         # Dashboard-UI
├── data/                      # Scan- und Audit-Daten
├── reports/                   # Analyse-Reports
├── mutations/                 # Generierte Mutationen
├── knowledge/                 # Wissensbasis
└── logs/                      # Evolutions-Logs
```

### Installation

```bash
# Abhaengigkeiten installieren
pip install psutil

# Ausfuehrbar machen (optional)
chmod +x master_controller.py
chmod +x modules/*.py
chmod +x evolution/*.py
```

### Nutzung

#### Einzelne Module
```bash
python3 master_controller.py scan
python3 master_controller.py audit
python3 master_controller.py analyze
python3 master_controller.py dashboard
python3 master_controller.py evolve
```

#### Dauerhafte Evolution
```bash
# Einzelne Evolution
python3 master_controller.py evolve

# Kontinuierliche Evolution (alle 5 Minuten)
python3 master_controller.py evolve-continuous

# Kontinuierliche Evolution (alle 10 Minuten)
python3 master_controller.py evolve-continuous 600
```

#### Auto-Modus (Vollautomatisch)
```bash
# Scan + Audit + Analyse + Evolution (Zyklus alle 60s)
python3 master_controller.py auto
```

#### Alles auf einmal
```bash
python3 master_controller.py all
```

#### Hilfe
```bash
python3 master_controller.py help
```

### Evolutions-Mechanismus

Der Wurm entwickelt sich durch einen genetischen Algorithmus:

1. **System-Analyse** - CPU, Memory, Prozesse, Netzwerk
2. **Mutation** - Neue Faehigkeit basierend auf Systemzustand generieren
   - Scanner-Enhancement
   - Auditor-Enhancement
   - Analyzer-Enhancement
   - Neue Detection-Module
   - Wissensintegration
   - Defensive Strategien
3. **Anwendung** - Code-Template erstellen und speichern
4. **Fitness** - Bewertung basierend auf Defensiv-Wert und System-Impact
5. **Selektion** - Beste Mutationen behalten, schlechte verwerfen
6. **Wissensintegration** - Gelernte Muster in Wissensbasis speichern

### Ausgabe

- Scan-Ergebnisse: `./data/scan_YYYYMMDD_HHMMSS.json`
- Audit-Reports: `./data/audit_YYYYMMDD_HHMMSS.json`
- Analyse-Reports: `./reports/analysis_YYYYMMDD_HHMMSS.json`
- Mutationen: `./mutations/mutation_GEN_ID.json`
- Wissensbasis: `./knowledge/base.json`
- Evolutions-Logs: `./logs/evolution_YYYYMMDD.json`
- Dashboard: http://localhost:58133

### Dashboard-Features

- Echtzeit-System-Statistiken
- Evolutions-Tracker (aktuelle Generation)
- Mutations-Log mit Prioritaeten
- Wissensbasis-Visualisierung
- System-Health-Monitor
- Auto-Refresh alle 30 Sekunden

### Rechtlicher Hinweis

Dieses Tool ist ausschliesslich fuer:
- Defensive Sicherheitsforschung
- Analyse EIGENER Systeme
- Bildungszwecke
- Transparenz und Audit

Nicht fuer:
- Angriffe auf fremde Systeme
- Unautorisierten Zugriff
- Illegale Aktivitaeten

### Philosophie

"Angriff ist die beste Verteidigung" - Als theoretisches Prinzip:
Das Verstaendnis von Angriffsvektoren (durch legitime Forschung)
  -> staerkt die Verteidigung
  -> verbessert die Sicherheit
  -> schuetzt die eigenen Systeme

Der Wurm wird nie fertig. Er wird immer besser.

### Autor

Finn Jona Thorsten Lischke - ABSOLUTE SOVEREIGN 2026
