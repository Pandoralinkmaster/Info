#!/bin/bash
# DNA-WURM RESEARCH v18.0 - STATUS SCRIPT

cd "$(dirname "$0")"

CYAN='\033[0;36m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m'

echo -e "${CYAN}"
echo "============================================================"
echo "  DNA-WURM RESEARCH v18.0 - STATUS"
echo "============================================================"
echo -e "${NC}"

# Pruefe Prozesse
check_process() {
    local pid_file=$1
    local name=$2
    if [ -f $pid_file ]; then
        PID=$(cat $pid_file)
        if kill -0 $PID 2>/dev/null; then
            echo -e "  ${GREEN}●${NC} $name (PID: $PID)"
            return 0
        else
            echo -e "  ${RED}○${NC} $name (PID: $PID - TOT)"
            return 1
        fi
    else
        echo -e "  ${YELLOW}○${NC} $name (nicht gestartet)"
        return 1
    fi
}

echo "Prozesse:"
check_process .dashboard.pid "Dashboard Server"
check_process .evolution.pid "Evolution Engine"
check_process .evolution_loop.pid "Evolution Loop"
check_process .pinggy.pid "Pinggy Tunnel"

echo ""
echo "URLs:"
if [ -f .status.json ]; then
    python3 -c "
import json
try:
    with open('.status.json') as f:
        d = json.load(f)
    print(f"  Lokale URL:  {d.get('local_url', 'N/A')}")
    print(f"  Globale URL: {d.get('global_url', 'N/A')}")
    print(f"  Status:      {d.get('status', 'unknown')}")
    print(f"  Gestartet:   {d.get('started', 'N/A')}")
except:
    print('  Status-Datei nicht lesbar')
"
else
    echo -e "  ${YELLOW}Keine Status-Datei gefunden${NC}"
fi

echo ""
echo "Dateien:"
for dir in data reports mutations knowledge logs; do
    count=$(ls $dir 2>/dev/null | wc -l)
    echo -e "  ${CYAN}$dir/${NC} $count Dateien"
done

echo ""
echo -e "${CYAN}============================================================${NC}"
