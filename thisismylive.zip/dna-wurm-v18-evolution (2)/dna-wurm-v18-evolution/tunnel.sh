#!/bin/bash
# DNA-WURM RESEARCH v18.0 - PINGGY TUNNEL SCRIPT
# Erstellt einen globalen Tunnel zu localhost:58133

cd "$(dirname "$0")"

PORT=58133
CYAN='\033[0;36m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m'

echo -e "${CYAN}"
echo "============================================================"
echo "  DNA-WURM v18.0 - PINGGY TUNNEL"
echo "============================================================"
echo -e "${NC}"

# Pruefe ob Dashboard laeuft
if ! [ -f .dashboard.pid ] || ! kill -0 $(cat .dashboard.pid) 2>/dev/null; then
    echo -e "${YELLOW}Dashboard laeuft nicht! Starte zuerst mit ./start.sh${NC}"
    exit 1
fi

# Stoppe bestehenden Tunnel
if [ -f .pinggy.pid ]; then
    OLD_PID=$(cat .pinggy.pid)
    if kill -0 $OLD_PID 2>/dev/null; then
        echo -e "${YELLOW}Stoppe bestehenden Tunnel...${NC}"
        kill $OLD_PID
        sleep 2
    fi
    rm -f .pinggy.pid
fi

echo -e "${GREEN}Starte Pinggy-Tunnel zu localhost:$PORT...${NC}"
echo -e "${YELLOW}Warte auf Verbindung (max 30s)...${NC}"

# Starte Tunnel im Hintergrund und speichere Output
nohup ssh -p 443 \
    -o StrictHostKeyChecking=no \
    -o ServerAliveInterval=30 \
    -o ServerAliveCountMax=3 \
    -o ExitOnForwardFailure=yes \
    -R0:127.0.0.1:$PORT \
    free@a.pinggy.io > logs/pinggy.log 2>&1 &

TUNNEL_PID=$!
echo $TUNNEL_PID > .pinggy.pid

# Warte auf URL
for i in {1..30}; do
    sleep 1
    if grep -q "http://" logs/pinggy.log 2>/dev/null; then
        URL=$(grep "http://" logs/pinggy.log | head -1 | awk '{print $1}')
        HTTPS_URL=$(grep "https://" logs/pinggy.log | head -1 | awk '{print $1}')

        echo -e "${GREEN}"
        echo "============================================================"
        echo "  TUNNEL AKTIV!"
        echo "============================================================"
        echo -e "${NC}"
        echo -e "${GREEN}  HTTP:  $URL${NC}"
        echo -e "${GREEN}  HTTPS: $HTTPS_URL${NC}"
        echo ""
        echo -e "${YELLOW}  Tunnel laeuft 60 Minuten (Free-Tier)${NC}"
        echo -e "${YELLOW}  Automatischer Reconnect aktiv${NC}"
        echo ""

        # Update Status
        if [ -f .status.json ]; then
            python3 -c "
import json
with open('.status.json') as f:
    d = json.load(f)
d['global_url'] = '$URL'
d['global_https_url'] = '$HTTPS_URL'
d['tunnel_pid'] = $TUNNEL_PID
d['tunnel_started'] = '$(date -Iseconds)'
with open('.status.json', 'w') as f:
    json.dump(d, f, indent=2)
"
        fi

        # Speichere URL
        echo "$URL" > .global_url
        echo "$HTTPS_URL" > .global_https_url

        exit 0
    fi
    echo -n "."
done

echo -e "\n${RED}Timeout! Tunnel konnte nicht erstellt werden.${NC}"
echo -e "${YELLOW}Log:${NC}"
cat logs/pinggy.log
cat .pinggy.pid | xargs kill 2>/dev/null
rm -f .pinggy.pid
exit 1
