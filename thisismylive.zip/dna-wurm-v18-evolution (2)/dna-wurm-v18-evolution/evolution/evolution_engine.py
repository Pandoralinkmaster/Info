#!/usr/bin/env python3

"""
DNA-WURM RESEARCH v18.0 - EVOLUTION ENGINE
Selbst-evolvierende Forschungsplattform.
Der Wurm lernt, mutiert, verbessert sich dauerhaft.

Finn Jona Thorsten Lischke - ABSOLUTE SOVEREIGN 2026
"""

import os
import sys
import json
import time
import hashlib
import random
from datetime import datetime
from collections import defaultdict

EVOLUTION_DIR = "./evolution"
MUTATIONS_DIR = "./mutations"
KNOWLEDGE_DIR = "./knowledge"
LOGS_DIR = "./logs"

class DnaEvolutionEngine:
    """Evolution Engine - Kontrolliert Wachstum, Mutation, Selektion."""

    def __init__(self):
        self.generation = self._load_generation()
        self.fitness_scores = defaultdict(float)
        self.mutation_history = []
        self.knowledge_base = self._load_knowledge()
        self.evolution_log = []
        for d in [EVOLUTION_DIR, MUTATIONS_DIR, KNOWLEDGE_DIR, LOGS_DIR]:
            os.makedirs(d, exist_ok=True)

    def _load_generation(self):
        gen_file = os.path.join(EVOLUTION_DIR, "generation.json")
        if os.path.exists(gen_file):
            with open(gen_file) as f:
                return json.load(f).get("generation", 1)
        return 1

    def _save_generation(self):
        with open(os.path.join(EVOLUTION_DIR, "generation.json"), "w") as f:
            json.dump({"generation": self.generation, "timestamp": datetime.now().isoformat()}, f, indent=2)

    def _load_knowledge(self):
        kb_file = os.path.join(KNOWLEDGE_DIR, "base.json")
        if os.path.exists(kb_file):
            with open(kb_file) as f:
                return json.load(f)
        return {"patterns": [], "anomalies": [], "optimizations": [], "strategies": []}

    def _save_knowledge(self):
        with open(os.path.join(KNOWLEDGE_DIR, "base.json"), "w") as f:
            json.dump(self.knowledge_base, f, indent=2, default=str)

    def _log(self, event_type, message, data=None):
        entry = {
            "timestamp": datetime.now().isoformat(),
            "generation": self.generation,
            "event": event_type,
            "message": message,
            "data": data or {}
        }
        self.evolution_log.append(entry)
        log_file = os.path.join(LOGS_DIR, "evolution_" + datetime.now().strftime("%Y%m%d") + ".json")
        existing = []
        if os.path.exists(log_file):
            with open(log_file) as f:
                existing = json.load(f)
        existing.append(entry)
        with open(log_file, "w") as f:
            json.dump(existing, f, indent=2, default=str)

    def analyze_system_state(self):
        import psutil
        state = {
            "timestamp": datetime.now().isoformat(),
            "cpu_percent": psutil.cpu_percent(interval=1),
            "memory": dict(psutil.virtual_memory()._asdict()),
            "disk_usage": {},
            "process_count": len(psutil.pids()),
            "network_connections": len(psutil.net_connections()),
            "boot_time": psutil.boot_time(),
        }
        for part in psutil.disk_partitions():
            try:
                state["disk_usage"][part.mountpoint] = dict(psutil.disk_usage(part.mountpoint)._asdict())
            except:
                pass
        return state

    def generate_mutation(self, mutation_type="adaptive"):
        state = self.analyze_system_state()
        mutations = {
            "scanner_enhancement": self._mutate_scanner,
            "auditor_enhancement": self._mutate_auditor,
            "analyzer_enhancement": self._mutate_analyzer,
            "new_detection_module": self._create_detection_module,
            "knowledge_integration": self._mutate_knowledge,
            "defensive_strategy": self._create_defensive_strategy,
        }
        if state["cpu_percent"] > 80:
            chosen = "defensive_strategy"
        elif state["memory"]["percent"] > 85:
            chosen = "scanner_enhancement"
        elif len(self.knowledge_base["anomalies"]) > 10:
            chosen = "analyzer_enhancement"
        else:
            chosen = random.choice(list(mutations.keys()))
        mutation = mutations[chosen](state)
        mutation["type"] = chosen
        mutation["generation"] = self.generation
        mutation["timestamp"] = datetime.now().isoformat()
        mutation["trigger_state"] = state
        mut_id = hashlib.sha256(json.dumps(mutation, sort_keys=True, default=str).encode()).hexdigest()[:16]
        mutation["id"] = mut_id
        mut_file = os.path.join(MUTATIONS_DIR, "mutation_" + str(self.generation) + "_" + mut_id + ".json")
        with open(mut_file, "w") as f:
            json.dump(mutation, f, indent=2, default=str)
        self.mutation_history.append(mutation)
        self._log("MUTATION_CREATED", "Neue Mutation " + chosen + " generiert (Gen " + str(self.generation) + ")", {"mutation_id": mut_id})
        return mutation

    def _mutate_scanner(self, state):
        enhancements = [
            "Erweiterte Prozess-Analyse (Kind-Prozesse, Threads)",
            "Netzwerk-Traffic-Analyse (Paket-Statistiken)",
            "Dateisystem-Integritaetspruefung (Hash-Vergleiche)",
            "Kernel-Modul-Enumeration",
            "Container-/VM-Erkennung",
        ]
        return {
            "target": "system_scanner",
            "enhancements": random.sample(enhancements, k=min(3, len(enhancements))),
            "priority": "high" if state["process_count"] > 500 else "normal",
            "code_template": self._generate_scanner_code(random.choice(enhancements)),
        }

    def _mutate_auditor(self, state):
        new_rules = [
            "Pruefung auf versteckte Benutzerkonten",
            "Analyse von Cron-Jobs auf Persistenzmechanismen",
            "Pruefung von SUID-Binaries auf Eskalationsvektoren",
            "Container-Escape-Detection",
            "Kubernetes-Pod-Security-Pruefung",
        ]
        return {
            "target": "security_auditor",
            "new_rules": random.sample(new_rules, k=min(2, len(new_rules))),
            "priority": "critical" if state["network_connections"] > 100 else "normal",
            "code_template": self._generate_auditor_code(random.choice(new_rules)),
        }

    def _mutate_analyzer(self, state):
        algorithms = [
            "Zeitreihen-Analyse (Trend-Erkennung)",
            "Clustering-Anomalie-Detektion",
            "Entropie-basierte Dateianalyse",
            "Verhaltens-Profiling (Baseline-Erstellung)",
            "Korrelations-Analyse (Multi-Source)",
        ]
        return {
            "target": "ki_analysis_engine",
            "algorithms": random.sample(algorithms, k=min(2, len(algorithms))),
            "priority": "high" if len(self.knowledge_base["anomalies"]) > 5 else "normal",
            "code_template": self._generate_analyzer_code(random.choice(algorithms)),
        }

    def _create_detection_module(self, state):
        threats = [
            "Lateral Movement Detection",
            "Data Exfiltration Detection",
            "Privilege Escalation Detection",
            "Persistence Mechanism Detection",
            "C2 Communication Detection",
        ]
        threat = random.choice(threats)
        return {
            "target": "new_module",
            "module_name": "detection_" + threat.lower().replace(" ", "_"),
            "threat_type": threat,
            "priority": "critical",
            "code_template": self._generate_detection_module(threat),
        }

    def _mutate_knowledge(self, state):
        return {
            "target": "knowledge_base",
            "integration_type": "pattern_learning",
            "new_entries": self._extract_patterns_from_logs(),
            "priority": "normal",
        }

    def _create_defensive_strategy(self, state):
        strategies = [
            "Automatische Prozess-Isolation bei Anomalien",
            "Netzwerk-Segmentierung basierend auf Verhalten",
            "Dateisystem-Ueberwachung mit Echtzeit-Alerting",
            "Speicher-Analyse auf Injektionen",
            "API-Call-Monitoring fuer ungewoehnliche Muster",
        ]
        return {
            "target": "defensive_strategy",
            "strategy": random.choice(strategies),
            "trigger_conditions": self._define_triggers(state),
            "priority": "high",
            "code_template": self._generate_defensive_code(random.choice(strategies)),
        }

    def _generate_scanner_code(self, enhancement):
        templates = {
            "Erweiterte Prozess-Analyse (Kind-Prozesse, Threads)": "# Scanner Enhancement: Prozess-Baum\n",
            "Netzwerk-Traffic-Analyse (Paket-Statistiken)": "# Scanner Enhancement: Netzwerk-Stats\n",
            "Dateisystem-Integritaetspruefung (Hash-Vergleiche)": "# Scanner Enhancement: Hash-Vergleiche\n",
            "Kernel-Modul-Enumeration": "# Scanner Enhancement: Kernel-Module\n",
            "Container-/VM-Erkennung": "# Scanner Enhancement: Container-Erkennung\n",
        }
        return templates.get(enhancement, "# Template nicht verfuegbar")

    def _generate_auditor_code(self, rule):
        templates = {
            "Pruefung auf versteckte Benutzerkonten": "# Auditor: Versteckte Benutzer\n",
            "Analyse von Cron-Jobs auf Persistenzmechanismen": "# Auditor: Cron-Jobs\n",
            "Pruefung von SUID-Binaries auf Eskalationsvektoren": "# Auditor: SUID-Binaries\n",
            "Container-Escape-Detection": "# Auditor: Container-Escape\n",
            "Kubernetes-Pod-Security-Pruefung": "# Auditor: K8s Security\n",
        }
        return templates.get(rule, "# Template nicht verfuegbar")

    def _generate_analyzer_code(self, algorithm):
        templates = {
            "Zeitreihen-Analyse (Trend-Erkennung)": "# Analyzer: Zeitreihen\n",
            "Clustering-Anomalie-Detektion": "# Analyzer: Clustering\n",
            "Entropie-basierte Dateianalyse": "# Analyzer: Entropie\n",
            "Verhaltens-Profiling (Baseline-Erstellung)": "# Analyzer: Baseline\n",
            "Korrelations-Analyse (Multi-Source)": "# Analyzer: Korrelation\n",
        }
        return templates.get(algorithm, "# Template nicht verfuegbar")

    def _generate_detection_module(self, threat):
        return "#!/usr/bin/env python3\n# DNA-WURM v18.0 - DETECTION: " + threat + "\n# Auto-generiert\n\nclass Detector:\n    def detect(self):\n        pass\n"

    def _generate_defensive_code(self, strategy):
        templates = {
            "Automatische Prozess-Isolation bei Anomalien": "# Defense: Prozess-Isolation\n",
            "Netzwerk-Segmentierung basierend auf Verhalten": "# Defense: Segmentierung\n",
            "Dateisystem-Ueberwachung mit Echtzeit-Alerting": "# Defense: FS-Monitoring\n",
            "Speicher-Analyse auf Injektionen": "# Defense: Speicher-Analyse\n",
            "API-Call-Monitoring fuer ungewoehnliche Muster": "# Defense: API-Monitoring\n",
        }
        return templates.get(strategy, "# Template nicht verfuegbar")

    def _extract_patterns_from_logs(self):
        patterns = []
        log_dir = "./logs"
        if os.path.exists(log_dir):
            for f in os.listdir(log_dir):
                if f.endswith(".json"):
                    try:
                        with open(os.path.join(log_dir, f)) as fh:
                            logs = json.load(fh)
                            for entry in logs[-100:]:
                                if "anomaly" in str(entry).lower():
                                    patterns.append({"source": f, "type": "anomaly_pattern", "data": entry})
                    except:
                        pass
        return patterns

    def _define_triggers(self, state):
        return {
            "cpu_threshold": 90,
            "memory_threshold": 95,
            "network_connection_threshold": 200,
            "process_count_threshold": 500,
        }

    def apply_mutation(self, mutation):
        self._log("MUTATION_APPLYING", "Wende Mutation " + mutation["id"] + " an", {"type": mutation["type"]})
        if "code_template" in mutation:
            module_name = mutation.get("module_name", "evolved_" + mutation["type"] + "_" + str(self.generation))
            module_file = os.path.join(EVOLUTION_DIR, module_name + ".py")
            with open(module_file, "w") as f:
                f.write("# Auto-generiert durch Evolution Engine\n")
                f.write("# Generation: " + str(self.generation) + "\n")
                f.write("# Mutation: " + mutation["id"] + "\n")
                f.write("# Timestamp: " + mutation["timestamp"] + "\n\n")
                f.write(mutation["code_template"])
            self._log("MUTATION_SAVED", "Modul " + module_name + ".py gespeichert")
        if mutation["type"] == "knowledge_integration":
            for entry in mutation.get("new_entries", []):
                if entry not in self.knowledge_base["patterns"]:
                    self.knowledge_base["patterns"].append(entry)
            self._save_knowledge()
        return True

    def fitness_evaluation(self, mutation):
        score = 0.0
        state = mutation.get("trigger_state", {})
        if state.get("cpu_percent", 0) < 50:
            score += 0.3
        if mutation["type"] == "knowledge_integration":
            score += 0.4
        if mutation["type"] == "defensive_strategy":
            score += 0.5
        score += random.uniform(0, 0.2)
        self.fitness_scores[mutation["id"]] = score
        self._log("FITNESS_EVAL", "Mutation " + mutation["id"] + " Fitness: " + str(round(score, 2)))
        return score

    def selection(self):
        if not self.fitness_scores:
            return []
        sorted_mutations = sorted(self.fitness_scores.items(), key=lambda x: x[1], reverse=True)
        survivors = sorted_mutations[:max(1, len(sorted_mutations) // 2)]
        self._log("SELECTION", str(len(survivors)) + " von " + str(len(self.fitness_scores)) + " Mutationen ueberleben")
        return [m[0] for m in survivors]

    def evolve(self):
        print("=" * 70)
        print("DNA-WURM RESEARCH v18.0 - EVOLUTION ENGINE (Generation " + str(self.generation) + ")")
        print("Selbst-evolvierende Forschungsplattform")
        print("=" * 70)
        print("\n[1/5] Systemzustand analysieren...")
        state = self.analyze_system_state()
        print("   CPU: " + str(round(state["cpu_percent"], 1)) + "% | Memory: " + str(round(state["memory"]["percent"], 1)) + "% | Prozesse: " + str(state["process_count"]))
        print("\n[2/5] Neue Mutation generieren...")
        mutation = self.generate_mutation()
        print("   Typ: " + mutation["type"] + " | ID: " + mutation["id"])
        print("\n[3/5] Mutation anwenden...")
        self.apply_mutation(mutation)
        print("   Mutation angewendet")
        print("\n[4/5] Fitness evaluieren...")
        fitness = self.fitness_evaluation(mutation)
        print("   Fitness-Score: " + str(round(fitness, 2)))
        print("\n[5/5] Selektion durchfuehren...")
        survivors = self.selection()
        print("   " + str(len(survivors)) + " Mutationen ueberleben")
        self.generation += 1
        self._save_generation()
        self.knowledge_base["optimizations"].append({
            "generation": self.generation - 1,
            "mutation": mutation["id"],
            "fitness": fitness,
            "timestamp": datetime.now().isoformat(),
        })
        self._save_knowledge()
        print("\n" + "=" * 70)
        print("Evolution abgeschlossen. Neue Generation: " + str(self.generation))
        print("Gesamte Mutationen: " + str(len(self.mutation_history)))
        print("Wissensbasis-Eintraege: " + str(len(self.knowledge_base["patterns"])))
        print("=" * 70)
        return mutation

    def run_continuous_evolution(self, interval=300):
        print("\n" + "=" * 70)
        print("DAUERHAFTE EVOLUTION AKTIVIERT")
        print("Intervall: " + str(interval) + "s | Generation: " + str(self.generation))
        print("Strg+C zum Beenden")
        print("=" * 70 + "\n")
        try:
            while True:
                self.evolve()
                print("\n[Naechste Evolution in " + str(interval) + "s...]\n")
                time.sleep(interval)
        except KeyboardInterrupt:
            print("\n" + "=" * 70)
            print("Evolution pausiert. Fortsetzen mit evolve Befehl.")
            print("End-Generation: " + str(self.generation))
            print("=" * 70)

if __name__ == "__main__":
    engine = DnaEvolutionEngine()
    if len(sys.argv) > 1 and sys.argv[1] == "continuous":
        interval = int(sys.argv[2]) if len(sys.argv) > 2 else 300
        engine.run_continuous_evolution(interval)
    else:
        engine.evolve()