#!/bin/bash
# THISISMYLIVE v5.0 — HEALTH CHECK
# ================================================

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR/.."

PORT="${THISISMYLIVE_PORT:-58133}"
HEALTHY=0
ISSUES=0

echo "═══════════════════════════════════════════════════"
echo "  THISISMYLIVE v5.0 — HEALTH CHECK"
echo "═══════════════════════════════════════════════════"
echo ""

# Check server
python3 -c "import socket; s=socket.socket(); s.settimeout(2); r=s.connect_ex(('127.0.0.1',$PORT)); s.close(); exit(r)" 2>/dev/null
if [ $? -eq 0 ]; then
    echo "  [✓] Server:     HEALTHY"
    HEALTHY=$((HEALTHY+1))
else
    echo "  [✗] Server:     DOWN"
    ISSUES=$((ISSUES+1))
fi

# Check worm
if [ -f server/worm.pid ] && kill -0 $(cat server/worm.pid) 2>/dev/null; then
    echo "  [✓] Worm:       HEALTHY"
    HEALTHY=$((HEALTHY+1))
else
    echo "  [✗] Worm:       DOWN"
    ISSUES=$((ISSUES+1))
fi

# Check disk
DISK_USAGE=$(df -h . | tail -1 | awk '{print $5}' | sed 's/%//')
if [ "$DISK_USAGE" -lt 80 ]; then
    echo "  [✓] Disk:       ${DISK_USAGE}% used"
    HEALTHY=$((HEALTHY+1))
else
    echo "  [✗] Disk:       ${DISK_USAGE}% CRITICAL"
    ISSUES=$((ISSUES+1))
fi

# Check memory
MEM_USAGE=$(free | awk '/^Mem:/ {printf "%.0f", $3/$2 * 100}')
if [ "$MEM_USAGE" -lt 90 ]; then
    echo "  [✓] Memory:     ${MEM_USAGE}% used"
    HEALTHY=$((HEALTHY+1))
else
    echo "  [✗] Memory:     ${MEM_USAGE}% CRITICAL"
    ISSUES=$((ISSUES+1))
fi

echo ""
echo "  Health Score: $HEALTHY/4 checks passed"
if [ $ISSUES -eq 0 ]; then
    echo "  Status:       ✅ ALL SYSTEMS HEALTHY"
else
    echo "  Status:       ⚠️  $ISSUES ISSUES DETECTED"
fi
echo "═══════════════════════════════════════════════════"
