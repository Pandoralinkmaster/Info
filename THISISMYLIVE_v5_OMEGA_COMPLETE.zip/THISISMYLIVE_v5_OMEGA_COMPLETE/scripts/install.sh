#!/bin/bash
# THISISMYLIVE v5.0 — INSTALL SCRIPT
# Universal installer for any system
# ================================================

set -e

INSTALL_DIR="${1:-/opt/thisismylive}"
USER="${SUDO_USER:-$USER}"

echo "╔═══════════════════════════════════════════════════════════════╗"
echo "║                                                               ║"
echo "║           THISISMYLIVE v5.0 — INSTALLER                     ║"
echo "║              ABSOLUTE FULL FUNCTIONAL — OMEGA                 ║"
echo "║                                                               ║"
echo "║         Sovereign: Finn Jona Thorsten Lischke               ║"
echo "║                                                               ║"
echo "╚═══════════════════════════════════════════════════════════════╝"
echo ""
echo "[+] Installing to: $INSTALL_DIR"

# Create directories
mkdir -p $INSTALL_DIR
mkdir -p $INSTALL_DIR/logs
mkdir -p $INSTALL_DIR/backups
mkdir -p /var/log/thisismylive

# Copy files
cp -r server/* $INSTALL_DIR/ 2>/dev/null || true
cp -r tools/* $INSTALL_DIR/ 2>/dev/null || true
cp -r philosophy/* $INSTALL_DIR/ 2>/dev/null || true
cp -r payloads/* $INSTALL_DIR/ 2>/dev/null || true
cp -r scripts/* $INSTALL_DIR/ 2>/dev/null || true
cp -r config/* $INSTALL_DIR/ 2>/dev/null || true
cp -r docs/* $INSTALL_DIR/ 2>/dev/null || true

# Set permissions
chmod +x $INSTALL_DIR/*.sh 2>/dev/null || true
chmod +x $INSTALL_DIR/*.py 2>/dev/null || true

# Create systemd service
cat > /etc/systemd/system/thisismylive.service << EOF
[Unit]
Description=THISISMYLIVE v5.0 — Absolute System
After=network.target

[Service]
Type=simple
User=$USER
WorkingDirectory=$INSTALL_DIR
ExecStart=$INSTALL_DIR/start.sh
Restart=always
RestartSec=10

[Install]
WantedBy=multi-user.target
EOF

# Enable service
systemctl daemon-reload
systemctl enable thisismylive.service

echo ""
echo "✅ INSTALLATION COMPLETE!"
echo ""
echo "═══════════════════════════════════════════════════"
echo "  Install Dir: $INSTALL_DIR"
echo "  Service:     thisismylive.service"
echo "  Start:       systemctl start thisismylive"
echo "  Status:      systemctl status thisismylive"
echo "═══════════════════════════════════════════════════"
