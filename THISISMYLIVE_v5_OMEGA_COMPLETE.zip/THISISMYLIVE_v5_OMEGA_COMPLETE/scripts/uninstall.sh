#!/bin/bash
# THISISMYLIVE v5.0 — UNINSTALL SCRIPT
# ================================================

echo "[+] Uninstalling THISISMYLIVE v5.0..."

# Stop service
systemctl stop thisismylive 2>/dev/null || true
systemctl disable thisismylive 2>/dev/null || true

# Remove service file
rm -f /etc/systemd/system/thisismylive.service
systemctl daemon-reload

# Remove installation
rm -rf /opt/thisismylive
rm -rf /var/log/thisismylive

echo "✅ THISISMYLIVE v5.0 uninstalled"
