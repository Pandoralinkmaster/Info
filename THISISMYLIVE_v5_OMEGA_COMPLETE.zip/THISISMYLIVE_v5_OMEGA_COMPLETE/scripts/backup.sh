#!/bin/bash
# THISISMYLIVE v5.0 — BACKUP SCRIPT
# ================================================

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR/.."

BACKUP_DIR="backups/$(date +%Y%m%d_%H%M%S)"
mkdir -p $BACKUP_DIR

echo "[+] Creating backup..."
cp -r server $BACKUP_DIR/
cp -r tools $BACKUP_DIR/
cp -r philosophy $BACKUP_DIR/
cp -r payloads $BACKUP_DIR/
cp -r scripts $BACKUP_DIR/
cp -r config $BACKUP_DIR/
cp -r docs $BACKUP_DIR/
cp MANIFEST.md $BACKUP_DIR/
cp MASTER_SPEC.md $BACKUP_DIR/
cp DOCUMENTATION.md $BACKUP_DIR/
cp ARCHITECTURE.md $BACKUP_DIR/

echo "✅ Backup created: $BACKUP_DIR"
