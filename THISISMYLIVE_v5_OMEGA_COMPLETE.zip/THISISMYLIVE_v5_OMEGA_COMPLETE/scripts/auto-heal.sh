#!/bin/bash
# THISISMYLIVE v5.0 — AUTO-HEAL SCRIPT
# Self-healing system recovery
# ================================================

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR/.."

LOG_FILE="logs/auto-heal.log"
mkdir -p logs

log() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] $1" | tee -a $LOG_FILE
}

log "Auto-heal started"

# Check and fix server
./scripts/health-check.sh | grep -q "Server:.*DOWN"
if [ $? -eq 0 ]; then
    log "⚠️  Server down — healing..."
    ./server/stop.sh 2>/dev/null || true
    sleep 2
    ./server/start.sh > /dev/null 2>&1
    log "✅ Server healed"
fi

# Check and fix worm
if [ -f server/worm.pid ] && ! kill -0 $(cat server/worm.pid) 2>/dev/null; then
    log "⚠️  Worm down — healing..."
    cd server && nohup python3 worm.py > logs/worm.log 2>&1 &
    echo $! > worm.pid
    log "✅ Worm healed"
fi

# Clean up if disk full
DISK_USAGE=$(df -h . | tail -1 | awk '{print $5}' | sed 's/%//')
if [ "$DISK_USAGE" -gt 85 ]; then
    log "⚠️  Disk critical — cleaning..."
    find logs -name "*.log" -mtime +3 -delete 2>/dev/null
    find /tmp -name "*.tmp" -mtime +1 -delete 2>/dev/null
    log "✅ Disk cleaned"
fi

log "Auto-heal complete"
