#!/bin/bash
# THISISMYLIVE v5.0 — UPDATE SCRIPT
# ================================================

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR/.."

echo "[+] Updating THISISMYLIVE v5.0..."

# Backup first
BACKUP_DIR="backups/$(date +%Y%m%d_%H%M%S)"
mkdir -p $BACKUP_DIR
cp -r . $BACKUP_DIR/
echo "[+] Backup created: $BACKUP_DIR"

# Pull updates
git pull 2>/dev/null || echo "⚠️  Git not available, manual update required"

# Restart
./server/stop.sh 2>/dev/null || true
sleep 2
./server/start.sh

echo "✅ Update complete"
