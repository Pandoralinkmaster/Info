#!/bin/bash
# THISISMYLIVE v5.0 — RESTORE SCRIPT
# ================================================

if [ -z "$1" ]; then
    echo "Usage: ./restore.sh <backup_directory>"
    echo "Available backups:"
    ls -la backups/ 2>/dev/null || echo "No backups found"
    exit 1
fi

BACKUP_DIR="$1"

if [ ! -d "$BACKUP_DIR" ]; then
    echo "✗ Backup directory not found: $BACKUP_DIR"
    exit 1
fi

echo "[+] Restoring from: $BACKUP_DIR"

# Stop current
./server/stop.sh 2>/dev/null || true

# Restore files
cp -r $BACKUP_DIR/* . 2>/dev/null || true

# Restart
./server/start.sh

echo "✅ Restore complete from: $BACKUP_DIR"
