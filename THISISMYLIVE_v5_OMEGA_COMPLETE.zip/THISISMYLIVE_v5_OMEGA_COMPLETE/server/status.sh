#!/bin/bash
# THISISMYLIVE v5.0 — STATUS SCRIPT
# ================================================

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

PORT="${THISISMYLIVE_PORT:-58133}"

echo "═══════════════════════════════════════════════════"
echo "  THISISMYLIVE v5.0 — SYSTEM STATUS"
echo "═══════════════════════════════════════════════════"
echo ""

# Check server
python3 -c "import socket; s=socket.socket(); s.settimeout(2); r=s.connect_ex(('127.0.0.1',$PORT)); s.close(); exit(r)" 2>/dev/null
if [ $? -eq 0 ]; then
    echo "  [✓] Server:      RUNNING on port $PORT"
    echo "  [✓] Local URL:   http://localhost:$PORT"
    echo "  [✓] Auth:        finn / [PROTECTED]"
else
    echo "  [✗] Server:      STOPPED"
fi

# Check worm
if [ -f worm.pid ] && kill -0 $(cat worm.pid) 2>/dev/null; then
    echo "  [✓] DNA Worm:    RUNNING (PID: $(cat worm.pid))"
else
    echo "  [✗] DNA Worm:    STOPPED"
fi

# Check tunnel
if [ -f tunnel.url ]; then
    echo "  [✓] Tunnel:      $(cat tunnel.url)"
else
    echo "  [✗] Tunnel:      NOT ACTIVE"
fi

echo ""
echo "  ─── Component Stats ───"
echo "  • Total Components: 194"
echo "  • EQGRP Arsenal:    115 Tools"
echo "  • Pegasus WMS:      79 Versions"
echo "  • Philosophical Layers: 10"
echo ""
echo "  ─── System Info ───"
echo "  • Hostname: $(hostname)"
echo "  • Uptime:   $(uptime | awk -F',' '{print $1}' | sed 's/^ *//')"
echo "  • Memory:   $(free -h 2>/dev/null | awk '/^Mem:/ {print $3 "/" $2}' || echo 'N/A')"
echo "═══════════════════════════════════════════════════"
