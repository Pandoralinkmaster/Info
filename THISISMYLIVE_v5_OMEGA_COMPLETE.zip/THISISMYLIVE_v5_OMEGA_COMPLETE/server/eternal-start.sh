#!/bin/bash
# THISISMYLIVE v5.0 — ETERNAL STARTUP
# Works even with network restrictions
# Sovereign: Finn Jona Thorsten Lischke

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

export THISISMYLIVE_PASS="${THISISMYLIVE_PASS:-sovereign2026}"

# Function to check if port is open
check_port() {
    python3 -c "import socket; s=socket.socket(); s.settimeout(2); r=s.connect_ex(('127.0.0.1',58133)); s.close(); exit(r)" 2>/dev/null
    return $?
}

# Kill existing
pkill -9 -f "bootstrap.py" 2>/dev/null
pkill -9 -f "server.py" 2>/dev/null
sleep 2

# Ensure logs directory
mkdir -p logs

echo "╔═══════════════════════════════════════════════════════════════╗"
echo "║                                                               ║"
echo "║           THISISMYLIVE v5.0 — ETERNAL STARTUP               ║"
echo "║              ABSOLUTE FULL FUNCTIONAL — GLOBAL                ║"
echo "║                                                               ║"
echo "║         Sovereign: Finn Jona Thorsten Lischke               ║"
echo "║                                                               ║"
echo "╚═══════════════════════════════════════════════════════════════╝"
echo ""

# Start bootstrap server
echo "[+] Starting bootstrap server..."
nohup python3 bootstrap.py > logs/bootstrap.log 2>&1 &
BOOTSTRAP_PID=$!
echo $BOOTSTRAP_PID > bootstrap.pid
sleep 3

# Verify
if check_port; then
    echo ""
    echo "✅ SERVER IS RUNNING!"
    echo ""
    echo "═══════════════════════════════════════════════════"
    echo "  LOCAL:  http://localhost:58133"
    echo "  AUTH:   finn / sovereign2026"
    echo "  PID:    $BOOTSTRAP_PID"
    echo "═══════════════════════════════════════════════════"
    echo ""
    echo "  Files available:"
    echo "    • index.html (Interactive Dashboard)"
    echo "    • EQGRP Arsenal (115 Tools)"
    echo "    • Pegasus WMS (79 Versions)"
    echo ""
    echo "  To stop: ./eternal-stop.sh"
    echo "  Status:  ./eternal-status.sh"
    echo ""
else
    echo "⚠️  Server may need more time..."
    echo "    Check: tail -f logs/bootstrap.log"
fi
