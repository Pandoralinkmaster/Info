#!/usr/bin/env python3
"""
THISISMYLIVE v5.0 — ABSOLUTE BOOTSTRAP SYSTEM
Self-healing, self-monitoring, eternal operation
Works even with network restrictions
"""

import subprocess
import os
import time
import json
import threading
import signal
import sys
import socket
import http.server
import socketserver
import base64
from datetime import datetime

# Configuration
PORT = 58133
USERNAME = "finn"
PASSWORD = os.environ.get("THISISMYLIVE_PASS", "sovereign2026")
AUTH_STRING = base64.b64encode(f"{USERNAME}:{PASSWORD}".encode()).decode()
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
LOG_FILE = os.path.join(BASE_DIR, "logs", "bootstrap.log")
PID_FILE = os.path.join(BASE_DIR, "bootstrap.pid")

def log(msg):
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    line = f"[{timestamp}] {msg}"
    print(line)
    with open(LOG_FILE, "a") as f:
        f.write(line + "\n")

class AuthHandler(http.server.SimpleHTTPRequestHandler):
    def do_AUTHHEAD(self):
        self.send_response(401)
        self.send_header("WWW-Authenticate", 'Basic realm="THISISMYLIVE v5.0"')
        self.send_header("Content-type", "text/html")
        self.end_headers()
        self.wfile.write(b"<html><body><h1>401 - ABSOLUTE SOVEREIGNTY REQUIRED</h1></body></html>")

    def do_GET(self):
        auth_header = self.headers.get("Authorization")
        if auth_header is None or not auth_header.startswith("Basic "):
            self.do_AUTHHEAD()
            return
        auth_token = auth_header.split(" ")[1]
        if auth_token != AUTH_STRING:
            self.do_AUTHHEAD()
            return
        if self.path == "/":
            self.path = "/index.html"
        return http.server.SimpleHTTPRequestHandler.do_GET(self)

    def log_message(self, format, *args):
        log(f"ACCESS {self.address_string()} - {format % args}")

def is_port_open(port):
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.settimeout(1)
        result = s.connect_ex(("localhost", port))
        s.close()
        return result == 0
    except:
        return False

def start_server():
    log("Starting THISISMYLIVE v5.0 Server...")
    os.chdir(BASE_DIR)
    try:
        httpd = socketserver.TCPServer(("", PORT), AuthHandler)
        log(f"Server running on port {PORT}")
        log(f"Auth: {USERNAME} / [PROTECTED]")
        httpd.serve_forever()
    except Exception as e:
        log(f"Server error: {e}")
        time.sleep(5)
        start_server()

def watchdog():
    """Monitor and restart server if needed"""
    while True:
        time.sleep(30)
        if not is_port_open(PORT):
            log("WATCHDOG: Server not responding, restarting...")
            start_server()

def main():
    log("=" * 60)
    log("THISISMYLIVE v5.0 — ABSOLUTE BOOTSTRAP")
    log("=" * 60)

    # Save PID
    with open(PID_FILE, "w") as f:
        f.write(str(os.getpid()))

    # Start watchdog thread
    watch_thread = threading.Thread(target=watchdog, daemon=True)
    watch_thread.start()

    # Start server
    start_server()

if __name__ == "__main__":
    main()
