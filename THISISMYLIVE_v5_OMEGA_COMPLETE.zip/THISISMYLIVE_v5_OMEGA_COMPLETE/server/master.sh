#!/bin/bash
# THISISMYLIVE v5.0 — MASTER CONTROL SCRIPT
# Ultimate control interface for all operations
# ================================================

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

show_banner() {
    echo "╔═══════════════════════════════════════════════════════════════╗"
    echo "║                                                               ║"
    echo "║           THISISMYLIVE v5.0 — MASTER CONTROL               ║"
    echo "║              ABSOLUTE FULL FUNCTIONAL — OMEGA                 ║"
    echo "║                                                               ║"
    echo "║         Sovereign: Finn Jona Thorsten Lischke               ║"
    echo "║                                                               ║"
    echo "╚═══════════════════════════════════════════════════════════════╝"
}

show_help() {
    echo ""
    echo "Usage: ./master.sh [command]"
    echo ""
    echo "Commands:"
    echo "  start       - Start all services"
    echo "  stop        - Stop all services"
    echo "  restart     - Restart all services"
    echo "  status      - Show system status"
    echo "  tunnel      - Create global tunnel"
    echo "  global      - Deploy globally (server + tunnel)"
    echo "  eternal     - Start eternal mode (watchdog + auto-heal)"
    echo "  backup      - Create backup"
    echo "  update      - Update system"
    echo "  logs        - Show recent logs"
    echo "  clean       - Clean old logs"
    echo "  help        - Show this help"
    echo ""
}

case "$1" in
    start)
        ./start.sh
        ;;
    stop)
        ./stop.sh
        ;;
    restart)
        ./stop.sh
        sleep 2
        ./start.sh
        ;;
    status)
        ./status.sh
        ;;
    tunnel)
        ./tunnel.sh
        ;;
    global)
        ./start.sh
        sleep 3
        ./tunnel-permanent.sh &
        echo "✅ Global deployment active"
        ;;
    eternal)
        ./start.sh
        sleep 3
        ./watchdog.sh &
        echo "✅ Eternal mode active — system is self-healing"
        ;;
    backup)
        BACKUP_DIR="backups/$(date +%Y%m%d_%H%M%S)"
        mkdir -p $BACKUP_DIR
        cp -r . $BACKUP_DIR/
        echo "✅ Backup created: $BACKUP_DIR"
        ;;
    update)
        echo "[+] Updating THISISMYLIVE..."
        git pull 2>/dev/null || echo "Manual update required"
        ;;
    logs)
        tail -n 50 logs/server.log 2>/dev/null || echo "No logs found"
        ;;
    clean)
        find logs -name "*.log" -mtime +7 -delete 2>/dev/null
        echo "✅ Old logs cleaned"
        ;;
    help|*)
        show_banner
        show_help
        ;;
esac
