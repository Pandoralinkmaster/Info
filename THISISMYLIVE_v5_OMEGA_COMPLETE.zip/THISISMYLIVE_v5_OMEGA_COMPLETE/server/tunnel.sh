#!/bin/bash
# THISISMYLIVE v5.0 — TUNNEL SCRIPT
# Creates public URL via localtunnel
# ================================================

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

PORT="${THISISMYLIVE_PORT:-58133}"

echo "[+] Creating global tunnel..."

# Check if npx is available
if ! command -v npx &> /dev/null; then
    echo "⚠️  npx not found. Installing..."
    npm install -g localtunnel 2>/dev/null || echo "Please install: npm install -g localtunnel"
fi

# Start tunnel
nohup npx localtunnel --port $PORT > logs/tunnel.log 2>&1 &
TUNNEL_PID=$!
echo $TUNNEL_PID > tunnel.pid

sleep 5

# Extract URL
URL=$(grep -oP 'https://[^\s]+\.loca\.lt' logs/tunnel.log | head -1)
if [ -n "$URL" ]; then
    echo $URL > tunnel.url
    echo ""
    echo "✅ GLOBAL TUNNEL ACTIVE!"
    echo ""
    echo "═══════════════════════════════════════════════════"
    echo "  PUBLIC URL: $URL"
    echo "  LOCAL:      http://localhost:$PORT"
    echo "  AUTH:       finn / [PROTECTED]"
    echo "═══════════════════════════════════════════════════"
    echo ""
    echo "  ⚠️  IMPORTANT: Tunnel URL changes on reconnect"
    echo "     Use ./tunnel-permanent.sh for persistent tunnel"
else
    echo "⚠️  Tunnel starting... check: tail -f logs/tunnel.log"
fi
