#!/bin/bash
# THISISMYLIVE v5.0 — GLOBAL DEPLOYMENT
# One-command global deployment
# ================================================

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

echo "🌍 DEPLOYING THISISMYLIVE v5.0 GLOBALLY..."
echo ""

# Step 1: Start local server
echo "[1/4] Starting local server..."
./start.sh > /dev/null 2>&1
sleep 3

# Step 2: Verify local server
echo "[2/4] Verifying local server..."
python3 -c "import socket; s=socket.socket(); s.settimeout(2); r=s.connect_ex(('127.0.0.1',58133)); s.close(); exit(r)" 2>/dev/null
if [ $? -eq 0 ]; then
    echo "      ✓ Local server running"
else
    echo "      ✗ Local server failed"
    exit 1
fi

# Step 3: Start permanent tunnel
echo "[3/4] Starting permanent tunnel..."
nohup ./tunnel-permanent.sh > logs/global-deploy.log 2>&1 &
sleep 5

# Step 4: Get tunnel URL
echo "[4/4] Getting global URL..."
if [ -f tunnel.url ]; then
    URL=$(cat tunnel.url)
    echo ""
    echo "═══════════════════════════════════════════════════"
    echo "  ✅ GLOBAL DEPLOYMENT SUCCESSFUL!"
    echo ""
    echo "  🌐 PUBLIC URL: $URL"
    echo "  🏠 LOCAL:      http://localhost:58133"
    echo "  🔐 AUTH:       finn / [PROTECTED]"
    echo ""
    echo "  📊 Components:"
    echo "     • 194 Total Components"
    echo "     • 115 EQGRP Tools"
    echo "     • 79 Pegasus WMS Versions"
    echo "     • 10 Philosophical Layers"
    echo ""
    echo "  ⚡ The system is now globally accessible!"
    echo "═══════════════════════════════════════════════════"
    echo ""
    echo "  💾 Save this URL: $URL"
    echo "  🔄 URL auto-updates on reconnect"
    echo ""
else
    echo "⚠️  Tunnel URL not yet available. Check: tail -f logs/tunnel-permanent.log"
fi
