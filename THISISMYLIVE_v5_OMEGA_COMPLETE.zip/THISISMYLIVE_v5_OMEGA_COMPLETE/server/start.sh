#!/bin/bash
# THISISMYLIVE v5.0 — START SCRIPT
# Sovereign: Finn Jona Thorsten Lischke
# ================================================

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

export THISISMYLIVE_PASS="${THISISMYLIVE_PASS:-sovereign2026}"
PORT="${THISISMYLIVE_PORT:-58133}"

echo "╔═══════════════════════════════════════════════════════════════╗"
echo "║                                                               ║"
echo "║           THISISMYLIVE v5.0 — ABSOLUTE STARTUP              ║"
echo "║              ABSOLUTE FULL FUNCTIONAL — GLOBAL                ║"
echo "║                                                               ║"
echo "║         Sovereign: Finn Jona Thorsten Lischke               ║"
echo "║                                                               ║"
echo "╚═══════════════════════════════════════════════════════════════╝"
echo ""

# Kill existing processes
pkill -9 -f "server.py" 2>/dev/null
pkill -9 -f "worm.py" 2>/dev/null
pkill -9 -f "bootstrap.py" 2>/dev/null
sleep 2

# Ensure logs directory
mkdir -p logs

# Start the worm engine
echo "[+] Starting DNA Worm Engine..."
nohup python3 worm.py > logs/worm.log 2>&1 &
WORM_PID=$!
echo $WORM_PID > worm.pid
sleep 2

# Start the server
echo "[+] Starting Absolute Server..."
nohup python3 server.py > logs/server.log 2>&1 &
SERVER_PID=$!
echo $SERVER_PID > server.pid
sleep 3

# Verify
check_port() {
    python3 -c "import socket; s=socket.socket(); s.settimeout(2); r=s.connect_ex(('127.0.0.1',$PORT)); s.close(); exit(r)" 2>/dev/null
    return $?
}

if check_port; then
    echo ""
    echo "✅ THISISMYLIVE v5.0 IS RUNNING!"
    echo ""
    echo "═══════════════════════════════════════════════════"
    echo "  LOCAL:    http://localhost:$PORT"
    echo "  AUTH:     finn / [PROTECTED]"
    echo "  WORM PID: $WORM_PID"
    echo "  SRV PID:  $SERVER_PID"
    echo "═══════════════════════════════════════════════════"
    echo ""
    echo "  API Endpoints:"
    echo "    • GET /api/status         → Full system status"
    echo "    • GET /api/worm/status     → Worm DNA status"
    echo "    • GET /api/worm/evolve     → Trigger evolution"
    echo "    • GET /api/worm/recognize  → Sovereign recognition"
    echo "    • GET /api/worm/replicate  → Create offspring"
    echo "    • GET /api/arsenal         → Arsenal stats"
    echo "    • GET /api/orpp            → ORPP protocol status"
    echo ""
    echo "  To stop:   ./stop.sh"
    echo "  Status:    ./status.sh"
    echo "  Tunnel:    ./tunnel.sh"
    echo ""
else
    echo "⚠️  Server may need more time..."
    echo "    Check: tail -f logs/server.log"
fi
