#!/bin/bash
# THISISMYLIVE v5.0 — PERMANENT TUNNEL
# Auto-reconnecting tunnel with failover
# ================================================

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

PORT="${THISISMYLIVE_PORT:-58133}"
LOG_FILE="logs/tunnel-permanent.log"
URL_FILE="tunnel.url"

mkdir -p logs

log() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] $1" | tee -a $LOG_FILE
}

log "Starting permanent tunnel..."

while true; do
    # Check if tunnel is already running
    if [ -f tunnel.pid ] && kill -0 $(cat tunnel.pid) 2>/dev/null; then
        sleep 30
        continue
    fi

    # Start new tunnel
    log "Creating new tunnel..."
    nohup npx localtunnel --port $PORT > logs/tunnel-temp.log 2>&1 &
    PID=$!
    echo $PID > tunnel.pid

    sleep 5

    # Extract and save URL
    URL=$(grep -oP 'https://[^\s]+\.loca\.lt' logs/tunnel-temp.log | head -1)
    if [ -n "$URL" ]; then
        echo $URL > $URL_FILE
        log "✅ Tunnel active: $URL"
    else
        log "⚠️  Tunnel URL not found, retrying..."
        kill $PID 2>/dev/null
        rm -f tunnel.pid
    fi

    # Wait and check
    sleep 30
done
