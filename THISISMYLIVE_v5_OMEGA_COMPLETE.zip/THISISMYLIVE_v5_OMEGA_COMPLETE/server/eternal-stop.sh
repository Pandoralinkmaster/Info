#!/bin/bash
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

echo "[+] Stopping THISISMYLIVE v5.0..."
pkill -9 -f "bootstrap.py" 2>/dev/null
pkill -9 -f "server.py" 2>/dev/null
rm -f bootstrap.pid server.pid tunnel.pid
echo "✅ All services stopped"
