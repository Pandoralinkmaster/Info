#!/bin/bash
# THISISMYLIVE v5.0 — WATCHDOG SCRIPT
# Monitors and auto-heals the system
# ================================================

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

PORT="${THISISMYLIVE_PORT:-58133}"
LOG_FILE="logs/watchdog.log"

mkdir -p logs

log() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] $1" | tee -a $LOG_FILE
}

log "Watchdog started — monitoring THISISMYLIVE v5.0"

while true; do
    # Check server
    python3 -c "import socket; s=socket.socket(); s.settimeout(2); r=s.connect_ex(('127.0.0.1',$PORT)); s.close(); exit(r)" 2>/dev/null
    if [ $? -ne 0 ]; then
        log "⚠️  Server down — restarting..."
        ./start.sh > /dev/null 2>&1
        log "✅ Server restarted"
    fi

    # Check worm
    if [ -f worm.pid ] && ! kill -0 $(cat worm.pid) 2>/dev/null; then
        log "⚠️  Worm down — restarting..."
        nohup python3 worm.py > logs/worm.log 2>&1 &
        echo $! > worm.pid
        log "✅ Worm restarted"
    fi

    # Check disk space
    DISK_USAGE=$(df -h . | tail -1 | awk '{print $5}' | sed 's/%//')
    if [ "$DISK_USAGE" -gt 90 ]; then
        log "⚠️  Disk usage critical: ${DISK_USAGE}% — cleaning logs..."
        find logs -name "*.log" -mtime +7 -delete 2>/dev/null
        log "✅ Old logs cleaned"
    fi

    sleep 60
done
