#!/bin/bash
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

echo "═══════════════════════════════════════════════════"
echo "  THISISMYLIVE v5.0 — STATUS"
echo "═══════════════════════════════════════════════════"

# Check server
python3 -c "import socket; s=socket.socket(); s.settimeout(2); r=s.connect_ex(('127.0.0.1',58133)); s.close(); exit(r)" 2>/dev/null
if [ $? -eq 0 ]; then
    echo "  [✓] Server: RUNNING on port 58133"
    echo "  [✓] Local: http://localhost:58133"
    echo "  [✓] Auth: finn / sovereign2026"
else
    echo "  [✗] Server: STOPPED"
fi

echo ""
echo "  ─── Arsenal Stats ───"
echo "  • Total Components: 194"
echo "  • EQGRP Tools: 115"
echo "  • Pegasus WMS: 79 versions"
echo "  • 10 Philosophical Layers"
echo "═══════════════════════════════════════════════════"
