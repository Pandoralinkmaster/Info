#!/bin/bash
# THISISMYLIVE v5.0 — BOOTSTRAP SCRIPT
# Universal startup for any environment
# ================================================

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

echo "[+] Bootstrapping THISISMYLIVE v5.0..."

# Check Python
if ! command -v python3 &> /dev/null; then
    echo "⚠️  Python3 not found. Attempting installation..."
    apt-get update && apt-get install -y python3 2>/dev/null ||     yum install -y python3 2>/dev/null ||     brew install python3 2>/dev/null ||     echo "Please install Python3 manually"
fi

# Check dependencies
python3 -c "import http.server, socketserver, base64, json, os, threading, time, hashlib, random" 2>/dev/null
if [ $? -ne 0 ]; then
    echo "⚠️  Missing Python modules detected"
fi

# Create necessary directories
mkdir -p logs
mkdir -p ~/.cache/thisismylive

# Set environment
export THISISMYLIVE_PASS="${THISISMYLIVE_PASS:-sovereign2026}"
export THISISMYLIVE_PORT="${THISISMYLIVE_PORT:-58133}"

# Start everything
./start.sh

echo ""
echo "✅ Bootstrap complete — THISISMYLIVE v5.0 is alive"
