import os
import hashlib
import random

def quantum_collapse(file_path, output_dir, num_fragments=1000):
    """
    Zerlegt eine Datei in Mikro-Fragmente und generiert eine Rekonstruktionsmatrix.
    """
    if not os.path.exists(output_dir):
        os.makedirs(output_dir)
    
    file_name = os.path.basename(file_path)
    with open(file_path, 'rb') as f:
        data = f.read()
    
    total_size = len(data)
    fragment_size = max(1, total_size // num_fragments)
    
    matrix = []
    
    for i in range(num_fragments):
        start = i * fragment_size
        end = start + fragment_size if i < num_fragments - 1 else total_size
        fragment_data = data[start:end]
        
        frag_id = hashlib.sha256(f"{i}-{random.random()}".encode()).hexdigest()[:12]
        frag_path = os.path.join(output_dir, f"frag_{frag_id}.bin")
        
        with open(frag_path, 'wb') as f_frag:
            f_frag.write(fragment_data)
        
        matrix.append({
            "order": i,
            "fragment_id": frag_id,
            "hash": hashlib.sha256(fragment_data).hexdigest()
        })
    
    # Rekonstruktionsmatrix speichern
    matrix_path = os.path.join(output_dir, "reconstruction_matrix.txt")
    with open(matrix_path, 'w') as f_mat:
        for entry in matrix:
            f_mat.write(f"{entry['order']}|{entry['fragment_id']}|{entry['hash']}\n")
            
    print(f"Quanten-Kollaps abgeschlossen: {num_fragments} Fragmente in {output_dir} erstellt.")

if __name__ == "__main__":
    # Dummy-Datei für die Singularität erstellen
    base_file = "singularity_core.dat"
    with open(base_file, "wb") as f:
        f.write(os.urandom(1024 * 10)) # 10KB Zufallsdaten als Kern
    
    quantum_collapse(base_file, "quantum_fragments", num_fragments=100)
