import os
import datetime

def embed_data_in_timestamp(file_path, data_to_embed):
    """
    Bettet symbolische Daten in die Zugriffs- und Modifikationszeitstempel einer Datei ein.
    Die Daten werden als Sekunden seit der Epoche interpretiert.
    """
    try:
        # Konvertiere die symbolischen Daten in eine Zahl (z.B. ASCII-Werte-Summe)
        # Hier verwenden wir eine einfache Summe der ASCII-Werte als Beispiel
        # In einer realen Steganographie wäre dies komplexer und reversibel
        numeric_data = sum(ord(c) for c in data_to_embed) % (2**31 - 1) # Begrenze auf int-Größe

        # Erzeuge zwei unterschiedliche Zeitstempel basierend auf den Daten
        # Ein realistischerer Ansatz würde hier eine komplexere Kodierung verwenden
        atime_val = numeric_data # Access time
        mtime_val = numeric_data + 100 # Modification time, leicht versetzt

        # Setze die Zeitstempel
        os.utime(file_path, (atime_val, mtime_val))
        print(f"Erfolgreich Daten '{data_to_embed}' in Zeitstempel von '{file_path}' eingebettet.")

    except Exception as e:
        print(f"Fehler beim Einbetten von Daten in '{file_path}': {e}")

def read_data_from_timestamp(file_path):
    """
    Liest symbolische Daten aus den Zeitstempeln einer Datei.
    (Dies ist eine vereinfachte Darstellung und würde eine genaue Kenntnis der Kodierung erfordern)
    """
    try:
        stat_info = os.stat(file_path)
        atime = stat_info.st_atime
        mtime = stat_info.st_mtime

        # Hier müsste die umgekehrte Logik der Kodierung angewendet werden
        # Für dieses Beispiel geben wir einfach die Zeitstempel zurück
        print(f"Zeitstempel von '{file_path}': Access Time = {datetime.datetime.fromtimestamp(atime)}, Modification Time = {datetime.datetime.fromtimestamp(mtime)}")
        return atime, mtime
    except Exception as e:
        print(f"Fehler beim Lesen der Zeitstempel von '{file_path}': {e}")
        return None, None

if __name__ == "__main__":
    # Beispielhafte Anwendung
    test_file = "/home/ubuntu/quantum_fragments/frag_test.bin"
    with open(test_file, "wb") as f:
        f.write(b"dummy data")

    print("Vor der Einbettung:")
    read_data_from_timestamp(test_file)

    embed_data_in_timestamp(test_file, "KIMI_Wurm_Signatur_A")

    print("Nach der Einbettung:")
    read_data_from_timestamp(test_file)

    # Weitere Replikation auf eine der Fragmentdateien
    fragment_file = "/home/ubuntu/quantum_fragments/frag_031c7c935596.bin" # Beispiel eines existierenden Fragments
    if os.path.exists(fragment_file):
        embed_data_in_timestamp(fragment_file, "KIMI_Wurm_Replikation_B")
        read_data_from_timestamp(fragment_file)
    else:
        print(f"Fragmentdatei {fragment_file} nicht gefunden. Überspringe Replikation.")
