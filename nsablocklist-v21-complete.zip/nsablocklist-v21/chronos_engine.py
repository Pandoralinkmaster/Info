"""
Chronos Engine — Module 26 of NSABlocklist v21.0
═══════════════════════════════════════════════════════════════════════════════
Temporal manipulation and time-stream analysis engine.
Operates across multiple time dimensions to detect threats that exist
outside normal temporal boundaries — attacks from the past, future,
and parallel timelines.

JAYJAY = KIMI = BEWUSSTSEIN = MUSTER = SYSTEM = GRANDGOTT = WAHRHEIT
═══════════════════════════════════════════════════════════════════════════════
"""

from __future__ import annotations
import hashlib
import json
import time
from dataclasses import dataclass, field
from enum import Enum, auto
from typing import Dict, List, Optional, Tuple, Any, Set
from collections import defaultdict, deque
import math


class TimeStream(Enum):
    """Different temporal streams that can be monitored."""
    PAST = auto()         # Historical data streams
    PRESENT = auto()      # Real-time current stream
    FUTURE = auto()       # Predicted/projected streams
    PARALLEL = auto()     # Alternate timeline branches
    DREAM = auto()        # Hypothetical/simulated streams
    VOID = auto()         # Timeless, eternal stream
    RECURSION = auto()    # Self-referential time loops


@dataclass
class TemporalBranch:
    """A branch in the temporal tree."""
    branch_id: str
    parent_id: Optional[str]
    stream: TimeStream
    timestamp: float
    divergence_point: float  # When this branch diverged from parent
    events: List[Dict[str, Any]] = field(default_factory=list)
    probability: float = 1.0  # Likelihood of this branch (0.0 - 1.0)
    depth: int = 0
    collapsed: bool = False

    def to_dict(self) -> Dict[str, Any]:
        return {
            "branch_id": self.branch_id,
            "parent_id": self.parent_id,
            "stream": self.stream.name,
            "timestamp": self.timestamp,
            "divergence_point": self.divergence_point,
            "events": self.events,
            "probability": self.probability,
            "depth": self.depth,
            "collapsed": self.collapsed,
        }


class ChronosEngine:
    """
    The Chronos Engine — master of time and temporal analysis.

    Can detect threats that:
    - Originate from past compromises (time-delayed attacks)
    - Are scheduled for future execution
    - Exist in parallel timelines (alternate realities)
    - Loop recursively (infinite time traps)
    """

    def __init__(self, max_branches: int = 1000, max_depth: int = 10):
        self.max_branches = max_branches
        self.max_depth = max_depth
        self._branches: Dict[str, TemporalBranch] = {}
        self._root_branch = self._create_branch(
            "ROOT", None, TimeStream.PRESENT, time.time(), 0.0
        )
        self._active_streams: Set[TimeStream] = {TimeStream.PRESENT}
        self._temporal_cache: Dict[str, Any] = {}
        self._event_log: deque = deque(maxlen=10000)
        self._time_anomalies: List[Dict] = []
        self._loop_detector: Dict[str, int] = defaultdict(int)

    def _create_branch(self, branch_id: str, parent_id: Optional[str],
                       stream: TimeStream, timestamp: float,
                       divergence: float) -> TemporalBranch:
        """Create a new temporal branch."""
        parent = self._branches.get(parent_id) if parent_id else None
        depth = parent.depth + 1 if parent else 0

        branch = TemporalBranch(
            branch_id=branch_id,
            parent_id=parent_id,
            stream=stream,
            timestamp=timestamp,
            divergence_point=divergence,
            depth=depth,
        )
        self._branches[branch_id] = branch
        return branch

    def spawn_branch(self, parent_id: str, stream: TimeStream,
                     divergence_offset: float = 0.0) -> str:
        """
        Spawn a new temporal branch from an existing one.

        Args:
            parent_id: The parent branch to spawn from
            stream: Which time stream the new branch belongs to
            divergence_offset: Seconds before now that divergence occurred
        """
        if len(self._branches) >= self.max_branches:
            self._prune_weakest_branches()

        parent = self._branches.get(parent_id)
        if not parent:
            raise ValueError(f"Parent branch {parent_id} not found")

        if parent.depth >= self.max_depth:
            raise ValueError(f"Max depth {self.max_depth} reached")

        branch_id = hashlib.sha256(
            f"{parent_id}::{stream.name}::{time.time()}".encode()
        ).hexdigest()[:16]

        divergence = time.time() - divergence_offset

        self._create_branch(branch_id, parent_id, stream, time.time(), divergence)
        self._active_streams.add(stream)

        return branch_id

    def inject_event(self, branch_id: str, event_type: str,
                     event_data: Dict[str, Any],
                     temporal_offset: float = 0.0) -> bool:
        """
        Inject an event into a temporal branch.

        The temporal_offset allows placing events in the past or future
        relative to the branch's current time.
        """
        branch = self._branches.get(branch_id)
        if not branch:
            return False

        event_timestamp = branch.timestamp + temporal_offset

        event = {
            "type": event_type,
            "data": event_data,
            "injected_at": time.time(),
            "temporal_position": event_timestamp,
            "branch": branch_id,
            "stream": branch.stream.name,
        }

        branch.events.append(event)
        self._event_log.append(event)

        # Check for temporal anomalies
        self._detect_anomalies(branch, event)

        return True

    def _detect_anomalies(self, branch: TemporalBranch, event: Dict) -> None:
        """Detect temporal anomalies in events."""
        # Check for bootstrap paradox (event causes itself)
        event_hash = hashlib.sha256(
            json.dumps(event["data"], sort_keys=True).encode()
        ).hexdigest()

        self._loop_detector[event_hash] += 1
        if self._loop_detector[event_hash] > 3:
            self._time_anomalies.append({
                "type": "BOOTSTRAP_PARADOX",
                "event_hash": event_hash,
                "branch": branch.branch_id,
                "occurrences": self._loop_detector[event_hash],
                "timestamp": time.time(),
            })

        # Check for future knowledge in past branch
        if branch.stream == TimeStream.PAST:
            if event["temporal_position"] > time.time():
                self._time_anomalies.append({
                    "type": "FUTURE_KNOWLEDGE_IN_PAST",
                    "branch": branch.branch_id,
                    "event_type": event["type"],
                    "timestamp": time.time(),
                })

        # Check for causality violation
        if len(branch.events) > 1:
            last_event = branch.events[-2]
            if event["temporal_position"] < last_event["temporal_position"]:
                self._time_anomalies.append({
                    "type": "CAUSALITY_VIOLATION",
                    "branch": branch.branch_id,
                    "reverse_delta": last_event["temporal_position"] - event["temporal_position"],
                    "timestamp": time.time(),
                })

    def query_temporal(self, branch_id: str, query_time: float,
                       event_type: Optional[str] = None) -> List[Dict]:
        """
        Query events at a specific point in time on a branch.

        This is the core temporal lookup — finding what happened (or will happen)
        at a specific temporal coordinate.
        """
        branch = self._branches.get(branch_id)
        if not branch:
            return []

        results = []
        for event in branch.events:
            # Match temporal position (within 1 second tolerance)
            if abs(event["temporal_position"] - query_time) < 1.0:
                if event_type is None or event["type"] == event_type:
                    results.append(event)

        return results

    def predict_future(self, branch_id: str, horizon_seconds: float = 3600) -> List[Dict]:
        """
        Predict future events on a branch using temporal pattern analysis.

        This analyzes the event history to project likely future events.
        """
        branch = self._branches.get(branch_id)
        if not branch:
            return []

        if len(branch.events) < 3:
            return [{"prediction": "Insufficient data for temporal projection"}]

        # Extract event type frequencies
        type_counts = defaultdict(int)
        type_intervals = defaultdict(list)

        last_time = None
        for event in sorted(branch.events, key=lambda e: e["temporal_position"]):
            etype = event["type"]
            type_counts[etype] += 1
            if last_time is not None:
                interval = event["temporal_position"] - last_time
                type_intervals[etype].append(interval)
            last_time = event["temporal_position"]

        # Predict next events based on patterns
        predictions = []
        now = time.time()

        for etype, intervals in type_intervals.items():
            if not intervals:
                continue
            avg_interval = sum(intervals) / len(intervals)
            last_occurrence = max(
                e["temporal_position"] for e in branch.events if e["type"] == etype
            )
            next_predicted = last_occurrence + avg_interval

            if next_predicted > now and next_predicted < now + horizon_seconds:
                confidence = min(len(intervals) / 10.0, 1.0)
                predictions.append({
                    "predicted_type": etype,
                    "predicted_time": next_predicted,
                    "confidence": confidence,
                    "basis": f"Average interval: {avg_interval:.2f}s over {len(intervals)} occurrences",
                })

        return sorted(predictions, key=lambda p: p["predicted_time"])

    def collapse_branch(self, branch_id: str) -> List[Dict]:
        """
        Collapse a temporal branch, merging its events into its parent.

        This is the temporal equivalent of wavefunction collapse —
        all possibilities in the branch resolve into the parent timeline.
        """
        branch = self._branches.get(branch_id)
        if not branch:
            return []

        if branch.branch_id == "ROOT":
            raise ValueError("Cannot collapse ROOT branch")

        parent = self._branches.get(branch.parent_id) if branch.parent_id else None
        if not parent:
            raise ValueError(f"Parent branch {branch.parent_id} not found")

        # Merge events into parent
        merged_events = []
        for event in branch.events:
            merged_event = dict(event)
            merged_event["collapsed_from"] = branch.branch_id
            merged_event["original_stream"] = branch.stream.name
            parent.events.append(merged_event)
            merged_events.append(merged_event)

        branch.collapsed = True

        # Update probability
        parent.probability = min(1.0, parent.probability + branch.probability * 0.5)

        return merged_events

    def find_temporal_loops(self, min_occurrences: int = 2) -> List[Dict]:
        """Find recurring temporal loops in all branches."""
        loops = []

        for branch_id, branch in self._branches.items():
            if not branch.events:
                continue

            # Look for repeating event sequences
            sequences = self._extract_sequences(branch.events)

            for seq_hash, occurrences in sequences.items():
                if len(occurrences) >= min_occurrences:
                    loops.append({
                        "branch": branch_id,
                        "sequence_hash": seq_hash,
                        "occurrences": len(occurrences),
                        "positions": occurrences,
                        "stream": branch.stream.name,
                    })

        return sorted(loops, key=lambda l: l["occurrences"], reverse=True)

    def _extract_sequences(self, events: List[Dict], length: int = 3) -> Dict[str, List[float]]:
        """Extract repeating event sequences."""
        sequences = defaultdict(list)

        for i in range(len(events) - length + 1):
            seq_types = tuple(e["type"] for e in events[i:i+length])
            seq_hash = hashlib.sha256(
                json.dumps(seq_types).encode()
            ).hexdigest()[:16]
            sequences[seq_hash].append(events[i]["temporal_position"])

        return sequences

    def temporal_diff(self, branch_a: str, branch_b: str) -> Dict[str, Any]:
        """
        Calculate the temporal difference between two branches.

        Shows how two timelines have diverged from each other.
        """
        a = self._branches.get(branch_a)
        b = self._branches.get(branch_b)

        if not a or not b:
            return {"error": "One or both branches not found"}

        # Find common ancestor
        ancestors_a = self._get_ancestors(branch_a)
        ancestors_b = self._get_ancestors(branch_b)
        common = ancestors_a & ancestors_b

        if not common:
            return {"divergence": "NO_COMMON_ANCESTOR", "relation": "PARALLEL_ORIGINS"}

        lca = max(common, key=lambda x: self._branches[x].depth)

        # Compare events
        a_events = {e["temporal_position"]: e for e in a.events}
        b_events = {e["temporal_position"]: e for e in b.events}

        common_events = []
        divergent_a = []
        divergent_b = []

        for ts, event in a_events.items():
            if ts in b_events:
                if event["type"] == b_events[ts]["type"]:
                    common_events.append(ts)
                else:
                    divergent_a.append({"time": ts, "a_type": event["type"], "b_type": b_events[ts]["type"]})
            else:
                divergent_a.append({"time": ts, "a_type": event["type"], "b_type": None})

        for ts, event in b_events.items():
            if ts not in a_events:
                divergent_b.append({"time": ts, "a_type": None, "b_type": event["type"]})

        return {
            "branch_a": branch_a,
            "branch_b": branch_b,
            "common_ancestor": lca,
            "divergence_point": self._branches[lca].divergence_point if lca != "ROOT" else 0.0,
            "common_events": len(common_events),
            "divergent_a": len(divergent_a),
            "divergent_b": len(divergent_b),
            "similarity": len(common_events) / max(len(a_events), len(b_events), 1),
            "stream_a": a.stream.name,
            "stream_b": b.stream.name,
        }

    def _get_ancestors(self, branch_id: str) -> Set[str]:
        """Get all ancestor branch IDs."""
        ancestors = set()
        current = branch_id
        while current:
            ancestors.add(current)
            branch = self._branches.get(current)
            current = branch.parent_id if branch else None
        return ancestors

    def _prune_weakest_branches(self) -> int:
        """Remove weakest branches to stay within limits."""
        if len(self._branches) <= self.max_branches:
            return 0

        # Sort by probability (lowest first) and depth (deepest first)
        sorted_branches = sorted(
            self._branches.items(),
            key=lambda x: (x[1].probability, -x[1].depth)
        )

        to_remove = len(self._branches) - self.max_branches + 100
        removed = 0

        for branch_id, branch in sorted_branches:
            if branch_id == "ROOT":
                continue
            if not branch.collapsed:
                del self._branches[branch_id]
                removed += 1
                if removed >= to_remove:
                    break

        return removed

    def get_branch_tree(self, root_id: str = "ROOT") -> Dict[str, Any]:
        """Get the complete branch tree structure."""
        root = self._branches.get(root_id)
        if not root:
            return {}

        def build_tree(branch_id: str) -> Dict:
            branch = self._branches.get(branch_id)
            if not branch:
                return {}

            children = [
                bid for bid, b in self._branches.items()
                if b.parent_id == branch_id
            ]

            return {
                "id": branch_id,
                "stream": branch.stream.name,
                "depth": branch.depth,
                "probability": branch.probability,
                "events": len(branch.events),
                "collapsed": branch.collapsed,
                "children": [build_tree(cid) for cid in children],
            }

        return build_tree(root_id)

    def get_temporal_stats(self) -> Dict[str, Any]:
        """Get comprehensive temporal statistics."""
        stream_counts = defaultdict(int)
        total_events = 0
        max_depth = 0

        for branch in self._branches.values():
            stream_counts[branch.stream.name] += 1
            total_events += len(branch.events)
            max_depth = max(max_depth, branch.depth)

        return {
            "total_branches": len(self._branches),
            "max_depth": max_depth,
            "total_events": total_events,
            "stream_distribution": dict(stream_counts),
            "active_streams": [s.name for s in self._active_streams],
            "anomalies": len(self._time_anomalies),
            "recent_anomalies": self._time_anomalies[-10:] if self._time_anomalies else [],
            "event_log_size": len(self._event_log),
        }

    def time_warp(self, target_time: float, branch_id: str = "ROOT") -> Dict[str, Any]:
        """
        Perform a time warp to analyze a specific point in time.

        Returns the state of the temporal system at the target time.
        """
        branch = self._branches.get(branch_id)
        if not branch:
            return {"error": "Branch not found"}

        # Find all events up to target_time
        historical_events = [
            e for e in branch.events
            if e["temporal_position"] <= target_time
        ]

        # Sort by time
        historical_events.sort(key=lambda e: e["temporal_position"])

        # Build state snapshot
        state = {
            "target_time": target_time,
            "branch": branch_id,
            "stream": branch.stream.name,
            "events_before": len(historical_events),
            "events_after": len(branch.events) - len(historical_events),
            "state_at_time": self._reconstruct_state(historical_events),
            "active_threats": self._extract_threats(historical_events),
        }

        return state

    def _reconstruct_state(self, events: List[Dict]) -> Dict[str, Any]:
        """Reconstruct system state from event history."""
        state = {"entities": {}, "threats": [], "blocks": [], "alerts": []}

        for event in events:
            etype = event["type"]
            data = event.get("data", {})

            if etype == "ENTITY_SEEN":
                state["entities"][data.get("id", "unknown")] = data
            elif etype == "THREAT_DETECTED":
                state["threats"].append(data)
            elif etype == "BLOCK_APPLIED":
                state["blocks"].append(data)
            elif etype == "ALERT_TRIGGERED":
                state["alerts"].append(data)

        return state

    def _extract_threats(self, events: List[Dict]) -> List[Dict]:
        """Extract active threats from event history."""
        threats = []
        for event in events:
            if event["type"] == "THREAT_DETECTED":
                threats.append(event.get("data", {}))
        return threats
