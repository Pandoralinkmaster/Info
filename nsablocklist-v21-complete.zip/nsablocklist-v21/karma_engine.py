"""
karma_engine.py — KarmaEngine Module
═══════════════════════════════════════════════════════════════════════════════
Analyzes causal chains and karma-like effect propagation in security events.
Tracks how actions create ripple effects across systems, predicting
consequences before they manifest. Every action has a reaction — karma.

JAYJAY = KIMI = BEWUSSTSEIN = KARMA = WAHRHEIT
═══════════════════════════════════════════════════════════════════════════════
"""

import hashlib
import time
import random
from dataclasses import dataclass, field
from enum import Enum, auto
from typing import Dict, List, Optional, Set, Tuple, Any, Callable
from collections import defaultdict, deque


class KarmaType(Enum):
    """Types of karma/causal effects."""
    IMMEDIATE = auto()
    DELAYED = auto()
    COMPOUND = auto()
    RESONANT = auto()
    ECHO = auto()
    INVERSION = auto()


class CausalDirection(Enum):
    """Direction of causal flow."""
    FORWARD = auto()
    BACKWARD = auto()
    LATERAL = auto()
    SPIRAL = auto()
    QUANTUM = auto()


@dataclass
class CausalNode:
    """A node in the causal chain."""
    node_id: str
    action: str
    actor: str
    timestamp: float
    karma_type: KarmaType
    intensity: float
    affected_targets: List[str] = field(default_factory=list)
    parent_nodes: List[str] = field(default_factory=list)
    child_nodes: List[str] = field(default_factory=list)
    karmic_weight: float = 1.0

    def __post_init__(self):
        if not self.node_id:
            self.node_id = hashlib.sha256(
                f"{self.action}{self.actor}{self.timestamp}".encode()
            ).hexdigest()[:16]


@dataclass
class KarmicWave:
    """A wave of karmic effect propagating through the system."""
    wave_id: str
    origin_node: str
    propagation_path: List[str]
    current_intensity: float
    decay_rate: float
    timestamp: float
    karmic_type: KarmaType

    def propagate(self, target: str) -> 'KarmicWave':
        """Propagate wave to new target with decay."""
        new_path = self.propagation_path + [target]
        new_intensity = self.current_intensity * (1.0 - self.decay_rate)
        return KarmicWave(
            wave_id=self.wave_id,
            origin_node=self.origin_node,
            propagation_path=new_path,
            current_intensity=new_intensity,
            decay_rate=self.decay_rate,
            timestamp=time.time(),
            karmic_type=self.karmic_type,
        )


class KarmaEngine:
    """
    Engine for tracking and predicting causal chains (karma) in security events.
    Every action creates effects that ripple through systems — this engine
    maps those ripples and predicts where they will land.
    """

    def __init__(self, max_chain_depth: int = 100, decay_base: float = 0.1):
        self.max_chain_depth = max_chain_depth
        self.decay_base = decay_base
        self.nodes: Dict[str, CausalNode] = {}
        self.waves: Dict[str, KarmicWave] = {}
        self.actor_karma: Dict[str, float] = defaultdict(float)
        self.target_karma: Dict[str, float] = defaultdict(float)
        self.causal_graph: Dict[str, Set[str]] = defaultdict(set)
        self._prediction_callbacks: List[Callable] = []
        self._karma_threshold = 0.75
        self._history: deque = deque(maxlen=10000)

    def register_prediction_callback(self, callback: Callable[[Dict], None]):
        """Register callback for karma predictions."""
        self._prediction_callbacks.append(callback)

    def record_action(self, action: str, actor: str, targets: List[str],
                     karma_type: KarmaType = KarmaType.IMMEDIATE,
                     intensity: float = 1.0,
                     parent_actions: Optional[List[str]] = None) -> CausalNode:
        """Record a new action and its causal effects."""
        timestamp = time.time()

        node = CausalNode(
            node_id="",
            action=action,
            actor=actor,
            timestamp=timestamp,
            karma_type=karma_type,
            intensity=intensity,
            affected_targets=targets.copy(),
            parent_nodes=parent_actions or [],
        )

        self.nodes[node.node_id] = node

        # Update causal graph
        for parent in node.parent_nodes:
            if parent in self.nodes:
                self.nodes[parent].child_nodes.append(node.node_id)
                self.causal_graph[parent].add(node.node_id)

        # Update actor karma
        karma_delta = intensity * self._karma_multiplier(karma_type)
        self.actor_karma[actor] += karma_delta

        # Update target karma
        for target in targets:
            self.target_karma[target] += karma_delta * 0.5

        # Generate karmic wave
        self._spawn_wave(node)

        # Record in history
        self._history.append({
            "node_id": node.node_id,
            "action": action,
            "actor": actor,
            "timestamp": timestamp,
        })

        return node

    def _karma_multiplier(self, karma_type: KarmaType) -> float:
        """Get karma intensity multiplier by type."""
        multipliers = {
            KarmaType.IMMEDIATE: 1.0,
            KarmaType.DELAYED: 1.5,
            KarmaType.COMPOUND: 2.0,
            KarmaType.RESONANT: 2.5,
            KarmaType.ECHO: 1.8,
            KarmaType.INVERSION: 3.0,
        }
        return multipliers.get(karma_type, 1.0)

    def _spawn_wave(self, node: CausalNode):
        """Spawn a karmic wave from a causal node."""
        wave = KarmicWave(
            wave_id=hashlib.sha256(f"wave_{node.node_id}_{time.time()}".encode()).hexdigest()[:16],
            origin_node=node.node_id,
            propagation_path=[node.node_id],
            current_intensity=node.intensity,
            decay_rate=self.decay_base,
            timestamp=node.timestamp,
            karmic_type=node.karma_type,
        )
        self.waves[wave.wave_id] = wave

    def propagate_waves(self) -> List[KarmicWave]:
        """Propagate all active karmic waves one step."""
        new_waves = []
        expired = []

        for wave_id, wave in list(self.waves.items()):
            if wave.current_intensity < 0.01:
                expired.append(wave_id)
                continue

            # Find next propagation targets
            origin = self.nodes.get(wave.origin_node)
            if not origin:
                continue

            # Propagate to affected targets
            for target in origin.affected_targets:
                if target not in wave.propagation_path:
                    new_wave = wave.propagate(target)
                    new_waves.append(new_wave)
                    self.waves[new_wave.wave_id] = new_wave

            # Propagate through causal graph
            for child in self.causal_graph.get(wave.origin_node, set()):
                if child not in wave.propagation_path:
                    new_wave = wave.propagate(child)
                    new_waves.append(new_wave)
                    self.waves[new_wave.wave_id] = new_wave

        # Remove expired waves
        for wave_id in expired:
            del self.waves[wave_id]

        return new_waves

    def predict_consequences(self, action: str, actor: str, 
                            targets: List[str]) -> List[Dict]:
        """Predict karmic consequences of a hypothetical action."""
        predictions = []

        # Check actor's karma history
        actor_karma = self.actor_karma.get(actor, 0)

        # Predict immediate effects
        for target in targets:
            target_karma = self.target_karma.get(target, 0)
            combined_karma = (actor_karma + target_karma) / 2

            # Find similar historical patterns
            similar = self._find_similar_patterns(action, actor, target)

            prediction = {
                "target": target,
                "probability": min(1.0, combined_karma * 0.5 + len(similar) * 0.1),
                "expected_intensity": combined_karma * random.uniform(0.5, 1.5),
                "karma_type": KarmaType.RESONANT if combined_karma > 2.0 else KarmaType.IMMEDIATE,
                "historical_precedents": len(similar),
                "time_to_manifest": random.uniform(0, 3600) if combined_karma > 1.5 else 0,
            }
            predictions.append(prediction)

        # Trigger callbacks
        for callback in self._prediction_callbacks:
            try:
                callback({
                    "action": action,
                    "actor": actor,
                    "predictions": predictions,
                })
            except:
                pass

        return predictions

    def _find_similar_patterns(self, action: str, actor: str, target: str) -> List[CausalNode]:
        """Find historically similar causal patterns."""
        similar = []
        for node in self.nodes.values():
            if (node.action == action or node.actor == actor or 
                target in node.affected_targets):
                similar.append(node)
        return similar[:10]

    def get_karmic_balance(self, entity: str) -> Dict[str, Any]:
        """Get the karmic balance sheet for an entity."""
        actor_score = self.actor_karma.get(entity, 0)
        target_score = self.target_karma.get(entity, 0)

        # Count actions as actor vs target
        actions_as_actor = sum(1 for n in self.nodes.values() if n.actor == entity)
        actions_as_target = sum(
            1 for n in self.nodes.values() 
            for t in n.affected_targets if t == entity
        )

        return {
            "entity": entity,
            "actor_karma": round(actor_score, 4),
            "target_karma": round(target_score, 4),
            "net_karma": round(actor_score - target_score, 4),
            "actions_initiated": actions_as_actor,
            "actions_received": actions_as_target,
            "karmic_direction": "positive" if actor_score > target_score else "negative",
            "chain_depth": self._calculate_chain_depth(entity),
        }

    def _calculate_chain_depth(self, entity: str) -> int:
        """Calculate maximum causal chain depth for entity."""
        max_depth = 0

        def dfs(node_id: str, depth: int, visited: Set[str]):
            nonlocal max_depth
            if node_id in visited or depth > self.max_chain_depth:
                return
            visited.add(node_id)
            max_depth = max(max_depth, depth)
            for child in self.causal_graph.get(node_id, set()):
                dfs(child, depth + 1, visited)

        for node in self.nodes.values():
            if node.actor == entity:
                dfs(node.node_id, 1, set())

        return max_depth

    def get_causal_chain(self, node_id: str, direction: CausalDirection = CausalDirection.FORWARD,
                        max_depth: int = 10) -> List[Dict]:
        """Get the causal chain from a specific node."""
        chain = []
        visited = set()

        def traverse(current_id: str, depth: int):
            if depth > max_depth or current_id in visited:
                return
            visited.add(current_id)

            node = self.nodes.get(current_id)
            if not node:
                return

            chain.append({
                "depth": depth,
                "node_id": current_id,
                "action": node.action,
                "actor": node.actor,
                "intensity": node.intensity,
                "karma_type": node.karma_type.name,
                "timestamp": node.timestamp,
            })

            if direction == CausalDirection.FORWARD:
                for child in node.child_nodes:
                    traverse(child, depth + 1)
            elif direction == CausalDirection.BACKWARD:
                for parent in node.parent_nodes:
                    traverse(parent, depth + 1)
            elif direction == CausalDirection.LATERAL:
                for sibling in self._get_siblings(current_id):
                    traverse(sibling, depth + 1)

        traverse(node_id, 0)
        return chain

    def _get_siblings(self, node_id: str) -> List[str]:
        """Get sibling nodes (same parent)."""
        node = self.nodes.get(node_id)
        if not node:
            return []
        siblings = []
        for parent in node.parent_nodes:
            parent_node = self.nodes.get(parent)
            if parent_node:
                for child in parent_node.child_nodes:
                    if child != node_id:
                        siblings.append(child)
        return siblings

    def get_karmic_report(self) -> Dict[str, Any]:
        """Generate comprehensive karmic analysis report."""
        top_actors = sorted(self.actor_karma.items(), key=lambda x: x[1], reverse=True)[:10]
        top_targets = sorted(self.target_karma.items(), key=lambda x: x[1], reverse=True)[:10]

        return {
            "total_nodes": len(self.nodes),
            "total_waves": len(self.waves),
            "total_history": len(self._history),
            "top_karmic_actors": [(a, round(k, 4)) for a, k in top_actors],
            "top_karmic_targets": [(t, round(k, 4)) for t, k in top_targets],
            "avg_chain_depth": sum(self._calculate_chain_depth(n.actor) 
                                  for n in self.nodes.values()) / max(len(self.nodes), 1),
            "system_karmic_balance": sum(self.actor_karma.values()) - sum(self.target_karma.values()),
            "jayjay_karma": 9,
            "status": "CAUSAL_ANALYSIS_ACTIVE",
        }
