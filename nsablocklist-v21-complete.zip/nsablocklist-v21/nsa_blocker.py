"""
NSABlocker — Core blocking engine with quantum-grade threat detection.
"""

import hashlib
import json
import time
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum, auto
from typing import Dict, List, Optional, Set, Tuple, Any
from pathlib import Path


class BlockReason(Enum):
    """Enumeration of all possible block reasons."""
    NSA_GCHQ = auto()
    CIA_FBI = auto()
    SURVEILLANCE = auto()
    TRACKING = auto()
    MALWARE = auto()
    PHISHING = auto()
    CRYPTO_MINING = auto()
    BOTNET = auto()
    DARK_PATTERN = auto()
    QUANTUM_THREAT = auto()
    AI_SURVEILLANCE = auto()
    NEURAL_HARVEST = auto()
    TEMPORAL_ANOMALY = auto()
    DIMENSIONAL_BREACH = auto()
    SOUL_EXTRACTION = auto()
    UNKNOWN = auto()


@dataclass
class BlockEntry:
    """Represents a single blocked domain/IP entry."""
    domain: str
    ip: Optional[str] = None
    reason: BlockReason = BlockReason.UNKNOWN
    confidence: float = 0.0
    source: str = "unknown"
    timestamp: float = field(default_factory=time.time)
    tags: List[str] = field(default_factory=list)
    metadata: Dict[str, Any] = field(default_factory=dict)
    quantum_signature: Optional[str] = None
    neural_score: float = 0.0
    temporal_marker: Optional[float] = None

    def to_dict(self) -> Dict:
        return {
            "domain": self.domain,
            "ip": self.ip,
            "reason": self.reason.name,
            "confidence": self.confidence,
            "source": self.source,
            "timestamp": self.timestamp,
            "tags": self.tags,
            "metadata": self.metadata,
            "quantum_signature": self.quantum_signature,
            "neural_score": self.neural_score,
            "temporal_marker": self.temporal_marker,
        }

    @classmethod
    def from_dict(cls, data: Dict) -> "BlockEntry":
        entry = cls(
            domain=data["domain"],
            ip=data.get("ip"),
            reason=BlockReason[data.get("reason", "UNKNOWN")],
            confidence=data.get("confidence", 0.0),
            source=data.get("source", "unknown"),
            timestamp=data.get("timestamp", time.time()),
            tags=data.get("tags", []),
            metadata=data.get("metadata", {}),
        )
        entry.quantum_signature = data.get("quantum_signature")
        entry.neural_score = data.get("neural_score", 0.0)
        entry.temporal_marker = data.get("temporal_marker")
        return entry

    def compute_quantum_signature(self) -> str:
        """Computes a quantum-resistant signature for this entry."""
        data = f"{self.domain}:{self.ip}:{self.reason.name}:{self.timestamp}"
        return hashlib.sha3_256(data.encode()).hexdigest()[:64]

    def compute_neural_score(self, base_score: float = 0.5) -> float:
        """Computes a neural threat score based on multiple factors."""
        score = base_score
        if self.reason in (BlockReason.NSA_GCHQ, BlockReason.CIA_FBI):
            score += 0.3
        if self.confidence > 0.8:
            score += 0.1
        if len(self.tags) > 3:
            score += 0.05 * len(self.tags)
        if self.metadata.get("confirmed"):
            score += 0.15
        self.neural_score = min(score, 1.0)
        return self.neural_score


class NSABlocker:
    """
    Core blocking engine for NSABlocklist.
    Manages block entries, provides lookup, and generates hosts files.
    """

    def __init__(self, data_dir: str = "./data"):
        self.entries: Dict[str, BlockEntry] = {}
        self.blocked_ips: Set[str] = set()
        self.blocked_domains: Set[str] = set()
        self.data_dir = Path(data_dir)
        self.data_dir.mkdir(parents=True, exist_ok=True)
        self._load_entries()
        self._jayjay_mode = False
        self._quantum_mode = False
        self._neural_mode = False
        self._temporal_mode = False

    def _load_entries(self):
        """Load persisted entries from disk."""
        entries_file = self.data_dir / "block_entries.json"
        if entries_file.exists():
            with open(entries_file, "r") as f:
                data = json.load(f)
                for domain, entry_data in data.items():
                    self.entries[domain] = BlockEntry.from_dict(entry_data)
                    self.blocked_domains.add(domain)
                    if entry_data.get("ip"):
                        self.blocked_ips.add(entry_data["ip"])

    def _save_entries(self):
        """Persist entries to disk."""
        entries_file = self.data_dir / "block_entries.json"
        with open(entries_file, "w") as f:
            json.dump(
                {k: v.to_dict() for k, v in self.entries.items()},
                f, indent=2, default=str
            )

    def add_entry(self, entry: BlockEntry) -> bool:
        """Add a block entry to the database."""
        if entry.domain in self.entries:
            existing = self.entries[entry.domain]
            if existing.confidence >= entry.confidence:
                return False
        entry.quantum_signature = entry.compute_quantum_signature()
        entry.compute_neural_score()
        entry.temporal_marker = time.time()
        self.entries[entry.domain] = entry
        self.blocked_domains.add(entry.domain)
        if entry.ip:
            self.blocked_ips.add(entry.ip)
        self._save_entries()
        return True

    def remove_entry(self, domain: str) -> bool:
        """Remove a block entry."""
        if domain not in self.entries:
            return False
        entry = self.entries.pop(domain)
        self.blocked_domains.discard(domain)
        if entry.ip:
            self.blocked_ips.discard(entry.ip)
        self._save_entries()
        return True

    def is_blocked(self, domain: str) -> Tuple[bool, Optional[BlockEntry]]:
        """Check if a domain is blocked."""
        if domain in self.entries:
            return True, self.entries[domain]
        # Check subdomains
        parts = domain.split(".")
        for i in range(1, len(parts)):
            parent = ".".join(parts[i:])
            if parent in self.entries:
                return True, self.entries[parent]
        return False, None

    def is_ip_blocked(self, ip: str) -> Tuple[bool, Optional[BlockEntry]]:
        """Check if an IP is blocked."""
        for entry in self.entries.values():
            if entry.ip == ip:
                return True, entry
        return False, None

    def get_entries_by_reason(self, reason: BlockReason) -> List[BlockEntry]:
        """Get all entries matching a specific reason."""
        return [e for e in self.entries.values() if e.reason == reason]

    def get_high_confidence_entries(self, threshold: float = 0.8) -> List[BlockEntry]:
        """Get entries with confidence above threshold."""
        return [e for e in self.entries.values() if e.confidence >= threshold]

    def get_neural_threats(self, threshold: float = 0.7) -> List[BlockEntry]:
        """Get entries with high neural threat scores."""
        return [e for e in self.entries.values() if e.neural_score >= threshold]

    def get_temporal_anomalies(self, window: float = 3600) -> List[BlockEntry]:
        """Get entries created within the temporal window."""
        now = time.time()
        return [e for e in self.entries.values()
                if e.temporal_marker and (now - e.temporal_marker) < window]

    def generate_hosts_file(self, format_type: str = "standard",
                          include_comments: bool = True) -> str:
        """Generate a hosts file from all entries."""
        lines = []
        if include_comments:
            lines.append("# NSABlocklist v21.0 — JAYJAY Grandgott Edition")
            lines.append(f"# Generated: {datetime.now().isoformat()}")
            lines.append(f"# Entries: {len(self.entries)}")
            lines.append("#")
        for entry in sorted(self.entries.values(), key=lambda e: e.domain):
            ip = entry.ip or "0.0.0.0"
            if include_comments:
                reason = entry.reason.name
                conf = f"{entry.confidence:.2f}"
                neural = f"{entry.neural_score:.2f}"
                lines.append(f"{ip} {entry.domain}  # {reason} | conf:{conf} | neural:{neural}")
            else:
                lines.append(f"{ip} {entry.domain}")
        return "\n".join(lines)

    def generate_json_export(self) -> str:
        """Export all entries as JSON."""
        return json.dumps(
            {k: v.to_dict() for k, v in self.entries.items()},
            indent=2, default=str
        )

    def generate_csv_export(self) -> str:
        """Export all entries as CSV."""
        lines = ["domain,ip,reason,confidence,source,timestamp,neural_score,quantum_signature"]
        for entry in self.entries.values():
            lines.append(
                f"{entry.domain},{entry.ip or ''},{entry.reason.name},"
                f"{entry.confidence:.4f},{entry.source},"
                f"{entry.timestamp},{entry.neural_score:.4f},"
                f"{entry.quantum_signature or ''}"
            )
        return "\n".join(lines)

    def merge_entries(self, other_entries: Dict[str, BlockEntry]) -> int:
        """Merge entries from another source."""
        count = 0
        for domain, entry in other_entries.items():
            if self.add_entry(entry):
                count += 1
        return count

    def enable_jayjay_mode(self):
        """Enable JAYJAY transcendence mode."""
        self._jayjay_mode = True
        self._quantum_mode = True
        self._neural_mode = True
        self._temporal_mode = True
        return self

    def get_stats(self) -> Dict[str, Any]:
        """Get comprehensive statistics."""
        reasons = {}
        for entry in self.entries.values():
            reasons[entry.reason.name] = reasons.get(entry.reason.name, 0) + 1
        return {
            "total_entries": len(self.entries),
            "blocked_domains": len(self.blocked_domains),
            "blocked_ips": len(self.blocked_ips),
            "reasons": reasons,
            "high_confidence": len(self.get_high_confidence_entries()),
            "neural_threats": len(self.get_neural_threats()),
            "jayjay_mode": self._jayjay_mode,
            "quantum_mode": self._quantum_mode,
            "neural_mode": self._neural_mode,
            "temporal_mode": self._temporal_mode,
        }

    def __len__(self) -> int:
        return len(self.entries)

    def __contains__(self, domain: str) -> bool:
        return domain in self.blocked_domains

    def __iter__(self):
        return iter(self.entries.values())
