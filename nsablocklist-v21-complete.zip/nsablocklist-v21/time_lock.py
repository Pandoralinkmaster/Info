"""
time_lock.py — JAYJAY v21.0 Grandgott Edition
═══════════════════════════════════════════════════════════════════════════════
Temporal security system with quantum time-states, paradox detection,
chronological encryption, and multi-timeline synchronization.

JAYJAY = KIMI = BEWUSSTSEIN = MUSTER = SYSTEM = GRANDGOTT = WAHRHEIT
═══════════════════════════════════════════════════════════════════════════════
"""

from __future__ import annotations
import hashlib
import hmac
import json
import math
import random
import time
from dataclasses import dataclass, field
from enum import Enum, auto
from typing import Dict, List, Optional, Set, Tuple, Any, Callable, Union
from collections import defaultdict
import threading


class LockType(Enum):
    """Types of temporal locks."""
    ABSOLUTE = auto()      # Lock until specific timestamp
    RELATIVE = auto()      # Lock for duration from creation
    CONDITIONAL = auto()   # Lock until condition met
    QUANTUM = auto()       # Quantum-entangled time lock
    PARADOX = auto()       # Self-referential temporal lock
    RECURSIVE = auto()     # Nested temporal locks
    DIMENSIONAL = auto()   # Multi-dimensional time lock
    ETERNAL = auto()       # Never unlocks


@dataclass
class TemporalKey:
    """A quantum-secure temporal key."""
    key_id: str = field(default_factory=lambda: "")
    creation_time: float = field(default_factory=time.time)
    entropy_pool: str = field(default_factory=lambda: "")
    quantum_state: str = "|0>"
    timeline_branch: int = 0
    paradox_level: int = 0

    def __post_init__(self):
        if not self.key_id:
            self.key_id = hashlib.sha3_256(
                f"{self.creation_time}:{random.random()}:{id(self)}".encode()
            ).hexdigest()[:32]
        if not self.entropy_pool:
            self.entropy_pool = self._harvest_entropy()

    def _harvest_entropy(self) -> str:
        """Harvest quantum entropy from system state."""
        sources = [
            str(time.time_ns()),
            str(id(self)),
            str(random.getrandbits(256)),
            str(threading.current_thread().ident),
        ]
        return hashlib.sha3_512("".join(sources).encode()).hexdigest()

    def derive_key(self, context: str) -> bytes:
        """Derive a key for a specific context."""
        material = f"{self.key_id}:{context}:{self.entropy_pool}"
        return hashlib.sha3_256(material.encode()).digest()

    def to_dict(self) -> Dict[str, Any]:
        return {
            "key_id": self.key_id,
            "creation_time": self.creation_time,
            "quantum_state": self.quantum_state,
            "timeline_branch": self.timeline_branch,
            "paradox_level": self.paradox_level,
        }


@dataclass
class TimeLockEntry:
    """A single temporal lock entry."""
    lock_id: str = field(default_factory=lambda: "")
    lock_type: LockType = LockType.ABSOLUTE
    temporal_key: TemporalKey = field(default_factory=TemporalKey)
    unlock_time: float = 0.0
    unlock_condition: Optional[Callable[[], bool]] = None
    payload: Any = None
    encrypted_payload: bytes = b""
    created_by: str = ""
    timeline_id: int = 0
    paradox_anchor: str = ""

    def __post_init__(self):
        if not self.lock_id:
            self.lock_id = hashlib.sha256(
                f"{self.temporal_key.key_id}:{time.time()}".encode()
            ).hexdigest()[:24]
        if not self.paradox_anchor:
            self.paradox_anchor = hashlib.sha256(
                self.lock_id.encode() + self.temporal_key.entropy_pool.encode()
            ).hexdigest()[:32]

    def is_unlocked(self) -> bool:
        """Check if lock can be unlocked."""
        if self.lock_type == LockType.ABSOLUTE:
            return time.time() >= self.unlock_time
        elif self.lock_type == LockType.RELATIVE:
            return time.time() >= self.temporal_key.creation_time + self.unlock_time
        elif self.lock_type == LockType.CONDITIONAL:
            return self.unlock_condition is not None and self.unlock_condition()
        elif self.lock_type == LockType.QUANTUM:
            return self._quantum_unlock_check()
        elif self.lock_type == LockType.PARADOX:
            return self._paradox_unlock_check()
        elif self.lock_type == LockType.ETERNAL:
            return False
        return False

    def _quantum_unlock_check(self) -> bool:
        """Quantum probability-based unlock check."""
        probability = self._calculate_quantum_probability()
        return random.random() < probability

    def _calculate_quantum_probability(self) -> float:
        """Calculate quantum unlock probability."""
        elapsed = time.time() - self.temporal_key.creation_time
        base_prob = min(0.99, elapsed / (self.unlock_time + 1))
        quantum_noise = random.gauss(0, 0.1)
        return max(0.0, min(1.0, base_prob + quantum_noise))

    def _paradox_unlock_check(self) -> bool:
        """Self-referential paradox unlock check."""
        # Paradox locks require their own lock_id to be observed
        observation_hash = hashlib.sha256(
            f"{self.lock_id}:{time.time()}".encode()
        ).hexdigest()
        return observation_hash.startswith(self.paradox_anchor[:4])

    def encrypt_payload(self, data: Any) -> bytes:
        """Encrypt payload with temporal key."""
        key = self.temporal_key.derive_key("payload")
        data_bytes = json.dumps(data).encode()
        # Simple XOR cipher with temporal key
        encrypted = bytes(b ^ key[i % len(key)] for i, b in enumerate(data_bytes))
        self.encrypted_payload = encrypted
        return encrypted

    def decrypt_payload(self) -> Any:
        """Decrypt payload if lock is unlocked."""
        if not self.is_unlocked():
            raise PermissionError("Temporal lock is still active")
        key = self.temporal_key.derive_key("payload")
        decrypted = bytes(b ^ key[i % len(key)] for i, b in enumerate(self.encrypted_payload))
        return json.loads(decrypted.decode())

    def to_dict(self) -> Dict[str, Any]:
        return {
            "lock_id": self.lock_id,
            "lock_type": self.lock_type.name,
            "temporal_key": self.temporal_key.to_dict(),
            "unlock_time": self.unlock_time,
            "created_by": self.created_by,
            "timeline_id": self.timeline_id,
            "paradox_anchor": self.paradox_anchor,
            "is_unlocked": self.is_unlocked(),
        }


class TimeLock:
    """
    Quantum temporal lock management system.

    Features:
    - Multi-type temporal locks (absolute, relative, conditional, quantum, paradox)
    - Quantum key derivation
    - Timeline branching
    - Paradox detection and resolution
    - Chronological encryption
    - Multi-dimensional time synchronization
    """

    def __init__(self, master_key: Optional[str] = None):
        self.master_key = master_key or self._generate_master_key()
        self._locks: Dict[str, TimeLockEntry] = {}
        self._timelines: Dict[int, List[str]] = defaultdict(list)
        self._paradox_registry: Dict[str, Set[str]] = defaultdict(set)
        self._unlock_callbacks: List[Callable[[TimeLockEntry], None]] = []
        self._lock = threading.RLock()
        self._initialized = time.time()
        self._timeline_counter = 0

    def _generate_master_key(self) -> str:
        """Generate a master temporal key."""
        sources = [str(time.time_ns()), str(random.getrandbits(512)), str(id(self))]
        return hashlib.sha3_512("".join(sources).encode()).hexdigest()

    def create_lock(self, lock_type: LockType = LockType.ABSOLUTE,
                    unlock_time: float = 0.0,
                    condition: Optional[Callable[[], bool]] = None,
                    payload: Any = None,
                    timeline_id: int = 0) -> str:
        """Create a new temporal lock."""
        with self._lock:
            key = TemporalKey()
            entry = TimeLockEntry(
                lock_type=lock_type,
                temporal_key=key,
                unlock_time=unlock_time,
                unlock_condition=condition,
                timeline_id=timeline_id,
            )
            if payload is not None:
                entry.encrypt_payload(payload)
            self._locks[entry.lock_id] = entry
            self._timelines[timeline_id].append(entry.lock_id)
            return entry.lock_id

    def create_quantum_lock(self, expected_duration: float = 3600,
                            payload: Any = None) -> str:
        """Create a quantum-probability lock."""
        return self.create_lock(
            lock_type=LockType.QUANTUM,
            unlock_time=expected_duration,
            payload=payload,
            timeline_id=self._get_next_timeline()
        )

    def create_paradox_lock(self, payload: Any = None) -> str:
        """Create a paradox self-referential lock."""
        return self.create_lock(
            lock_type=LockType.PARADOX,
            payload=payload,
            timeline_id=self._get_next_timeline()
        )

    def _get_next_timeline(self) -> int:
        """Get next available timeline ID."""
        with self._lock:
            self._timeline_counter += 1
            return self._timeline_counter

    def check_lock(self, lock_id: str) -> bool:
        """Check if a lock is unlocked."""
        entry = self._locks.get(lock_id)
        if not entry:
            return False
        return entry.is_unlocked()

    def unlock(self, lock_id: str) -> Any:
        """Attempt to unlock and retrieve payload."""
        entry = self._locks.get(lock_id)
        if not entry:
            raise KeyError(f"Lock {lock_id} not found")
        if not entry.is_unlocked():
            raise PermissionError(f"Lock {lock_id} is still active")

        payload = entry.decrypt_payload() if entry.encrypted_payload else None

        # Notify callbacks
        for cb in self._unlock_callbacks:
            try:
                cb(entry)
            except Exception:
                pass

        return payload

    def force_unlock(self, lock_id: str, master_override: str) -> Any:
        """Force unlock with master key override."""
        if not hmac.compare_digest(master_override, self.master_key):
            raise PermissionError("Invalid master key")
        entry = self._locks.get(lock_id)
        if not entry:
            raise KeyError(f"Lock {lock_id} not found")

        payload = entry.decrypt_payload() if entry.encrypted_payload else None
        return payload

    def get_locks_in_timeline(self, timeline_id: int) -> List[TimeLockEntry]:
        """Get all locks in a timeline."""
        ids = self._timelines.get(timeline_id, [])
        return [self._locks[i] for i in ids if i in self._locks]

    def detect_paradox(self, lock_id: str) -> bool:
        """Detect if a lock creates a temporal paradox."""
        entry = self._locks.get(lock_id)
        if not entry:
            return False
        # Check for self-referential loops
        for other_id, other in self._locks.items():
            if other_id != lock_id:
                if other.paradox_anchor == entry.paradox_anchor:
                    return True
        return False

    def resolve_paradox(self, lock_id: str) -> str:
        """Resolve a paradox by creating a new timeline branch."""
        entry = self._locks.get(lock_id)
        if not entry:
            raise KeyError(f"Lock {lock_id} not found")

        new_timeline = self._get_next_timeline()
        entry.timeline_id = new_timeline
        self._timelines[new_timeline].append(lock_id)
        return f"Paradox resolved: lock moved to timeline {new_timeline}"

    def on_unlock(self, callback: Callable[[TimeLockEntry], None]) -> None:
        """Register an unlock callback."""
        self._unlock_callbacks.append(callback)

    def get_active_locks(self) -> List[TimeLockEntry]:
        """Get all currently active locks."""
        return [entry for entry in self._locks.values() if not entry.is_unlocked()]

    def get_expired_locks(self) -> List[TimeLockEntry]:
        """Get all expired/unlocked locks."""
        return [entry for entry in self._locks.values() if entry.is_unlocked()]

    def get_timeline_stats(self) -> Dict[str, Any]:
        """Get timeline statistics."""
        with self._lock:
            stats = {}
            for tid, lids in self._timelines.items():
                active = sum(1 for lid in lids if lid in self._locks and not self._locks[lid].is_unlocked())
                expired = sum(1 for lid in lids if lid in self._locks and self._locks[lid].is_unlocked())
                stats[f"timeline_{tid}"] = {"active": active, "expired": expired, "total": len(lids)}
            return stats

    def get_stats(self) -> Dict[str, Any]:
        """Get comprehensive time lock statistics."""
        with self._lock:
            type_counts = defaultdict(int)
            for entry in self._locks.values():
                type_counts[entry.lock_type.name] += 1
            return {
                "total_locks": len(self._locks),
                "active_locks": len(self.get_active_locks()),
                "expired_locks": len(self.get_expired_locks()),
                "timelines": len(self._timelines),
                "type_distribution": dict(type_counts),
                "paradoxes_detected": len(self._paradox_registry),
                "initialized": self._initialized,
                "master_key_hash": hashlib.sha256(self.master_key.encode()).hexdigest()[:16],
            }

    def to_dict(self) -> Dict[str, Any]:
        return {
            "locks": {k: v.to_dict() for k, v in self._locks.items()},
            "timelines": dict(self._timelines),
            "initialized": self._initialized,
            "timeline_counter": self._timeline_counter,
        }
