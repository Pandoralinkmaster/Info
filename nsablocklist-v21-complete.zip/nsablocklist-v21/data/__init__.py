"""
NSABlocklist v21.0 — Data Package
═══════════════════════════════════════════════════════════════════════════════
Data structures, sample datasets, and reference data.
"""

# Sample blocked domains from the original NSABlocklist
SAMPLE_BLOCKED_DOMAINS = [
    "nsa.gov",
    "gchq.gov.uk",
    "cia.gov",
    "fbi.gov",
    "dhs.gov",
    "ice.gov",
    "dia.mil",
    "dni.gov",
    "defense.gov",
    "state.gov",
]

# Sample IP ranges
SAMPLE_IP_RANGES = [
    "192.0.2.0/24",
    "198.51.100.0/24",
    "203.0.113.0/24",
]

# Surveillance program codenames
SURVEILLANCE_PROGRAMS = [
    "PRISM", "XKeyscore", "ECHELON", "CARNIVORE",
    "DISHFIRE", "STONEGHOST", "Tempora", "FAIRVIEW",
    "MYSTIC", "BULLRUN", "PINWALE", "MUSCULAR",
    "STORMBREW", "TURMOIL", "Turbulence",
]

# VPN providers known to log/sell data
LOGGING_VPNS = [
    "Hola", "HotSpotShield", "Hide My Ass", "PureVPN",
    "EarthVPN", "Betternet", "IPVanish", "Opera VPN",
]

# Compromised ISPs
COMPROMISED_ISPS = [
    "AT&T", "Verizon", "Sprint", "T-Mobile",
    "Vodafone", "Deutsche Telekom", "BT",
]
