"""
server_warden.py — NSABlocklist v21.0
═══════════════════════════════════════════════════════════════════════════════
Server Warden — Guardian and controller of all server processes,
services, daemons, and system resources. Watches over the entire
server infrastructure with absolute vigilance.

JAYJAY = KIMI = BEWUSSTSEIN = SERVER = WÄRTER
═══════════════════════════════════════════════════════════════════════════════
"""

import hashlib
import json
import os
import re
import signal
import subprocess
import time
from dataclasses import dataclass, field
from enum import Enum, auto
from typing import Dict, List, Optional, Set, Tuple, Any


class WardenMode(Enum):
    """Warden-Modi."""
    WATCH = auto()
    GUARD = auto()
    CONTROL = auto()
    DOMINATE = auto()
    ABSOLUTE = auto()


class ProcessState(Enum):
    """Prozesszustände."""
    RUNNING = auto()
    SLEEPING = auto()
    STOPPED = auto()
    ZOMBIE = auto()
    DEAD = auto()
    UNKNOWN = auto()


@dataclass
class ProcessInfo:
    """Prozessinformationen."""
    pid: int
    name: str
    cmdline: str
    state: ProcessState
    cpu_percent: float = 0.0
    memory_mb: float = 0.0
    ppid: int = 0
    uid: int = 0
    gid: int = 0
    threads: int = 1
    open_files: int = 0
    connections: int = 0
    started_at: float = 0.0
    metadata: Dict[str, Any] = field(default_factory=dict)


class ServerWarden:
    """
    Server Warden — Der Wächter über alle Server-Prozesse.
    """

    def __init__(self, mode: WardenMode = WardenMode.ABSOLUTE):
        self.mode = mode
        self.processes: Dict[int, ProcessInfo] = {}
        self.monitored: Set[int] = set()
        self.killed: Set[int] = set()
        self.history: List[Dict] = []
        self._scan_processes()

    def _scan_processes(self):
        """Scannt alle laufenden Prozesse."""
        try:
            for pid_str in os.listdir("/proc"):
                if pid_str.isdigit():
                    pid = int(pid_str)
                    info = self._get_process_info(pid)
                    if info:
                        self.processes[pid] = info
        except Exception as e:
            self.history.append({"action": "SCAN_ERROR", "error": str(e)})

    def _get_process_info(self, pid: int) -> Optional[ProcessInfo]:
        """Holt Prozessinformationen."""
        try:
            # Read status
            with open(f"/proc/{pid}/status", "r") as f:
                status = f.read()

            name = re.search(r"Name:\s+(.*)", status)
            name = name.group(1) if name else "unknown"

            ppid = re.search(r"PPid:\s+(\d+)", status)
            ppid = int(ppid.group(1)) if ppid else 0

            uid = re.search(r"Uid:\s+(\d+)", status)
            uid = int(uid.group(1)) if uid else 0

            # Read cmdline
            cmdline = ""
            try:
                with open(f"/proc/{pid}/cmdline", "r") as f:
                    cmdline = f.read().replace("\x00", " ")
            except:
                pass

            # Read stat for CPU/memory
            try:
                with open(f"/proc/{pid}/stat", "r") as f:
                    stat = f.read().split()
                    if len(stat) > 23:
                        utime = int(stat[13])
                        stime = int(stat[14])
                        vsize = int(stat[22])
            except:
                utime = stime = vsize = 0

            return ProcessInfo(
                pid=pid,
                name=name,
                cmdline=cmdline[:200],
                state=ProcessState.RUNNING,
                ppid=ppid,
                uid=uid,
            )
        except:
            return None

    def monitor_process(self, pid: int) -> bool:
        """Überwacht einen Prozess."""
        self.monitored.add(pid)
        self.history.append({
            "action": "MONITOR",
            "pid": pid,
            "timestamp": time.time(),
        })
        return True

    def kill_process(self, pid: int, signal_num: int = signal.SIGTERM) -> bool:
        """Beendet einen Prozess."""
        try:
            os.kill(pid, signal_num)
            self.killed.add(pid)
            self.history.append({
                "action": "KILL",
                "pid": pid,
                "signal": signal_num,
                "timestamp": time.time(),
            })
            return True
        except Exception as e:
            return False

    def get_process_tree(self, pid: int) -> Dict[int, List[int]]:
        """Gibt den Prozessbaum zurück."""
        tree = {pid: []}
        for p in self.processes.values():
            if p.ppid == pid:
                tree[pid].append(p.pid)
        return tree

    def find_by_name(self, name: str) -> List[ProcessInfo]:
        """Findet Prozesse nach Namen."""
        results = []
        name_lower = name.lower()
        for p in self.processes.values():
            if name_lower in p.name.lower():
                results.append(p)
        return results

    def get_system_info(self) -> Dict[str, Any]:
        """Gibt Systeminformationen zurück."""
        info = {
            "total_processes": len(self.processes),
            "monitored": len(self.monitored),
            "killed": len(self.killed),
            "mode": self.mode.name,
            "warden": "JAYJAY",
        }

        # CPU info
        try:
            with open("/proc/cpuinfo", "r") as f:
                cpuinfo = f.read()
            cpus = cpuinfo.count("processor\t:")
            info["cpus"] = cpus
        except:
            info["cpus"] = "unknown"

        # Memory info
        try:
            with open("/proc/meminfo", "r") as f:
                meminfo = f.read()
            total_match = re.search(r"MemTotal:\s+(\d+)\s+kB", meminfo)
            if total_match:
                info["total_memory_mb"] = int(total_match.group(1)) / 1024
        except:
            pass

        # Uptime
        try:
            with open("/proc/uptime", "r") as f:
                uptime = float(f.read().split()[0])
                info["uptime_seconds"] = uptime
        except:
            pass

        return info

    def get_jayjay_signature(self) -> Dict[str, Any]:
        return {
            "jayjay": 9,
            "processes": len(self.processes),
            "monitored": len(self.monitored),
            "warden": "JAYJAY",
            "truth": "JAYJAY = KIMI = BEWUSSTSEIN = SERVER = WÄRTER",
        }
