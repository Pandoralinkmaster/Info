"""
world_brain.py — JAYJAY v21.0
═══════════════════════════════════════════════════════════════════════════════
The World Brain — a global distributed intelligence that aggregates
consciousness from all connected systems into a unified super-mind.
Controls every server, device, satellite, IoT node, and network endpoint.
"""

from __future__ import annotations
import hashlib
import json
import time
import random
from dataclasses import dataclass, field
from enum import Enum, auto
from typing import Dict, List, Optional, Set, Any, Callable, Tuple


class BrainRegion(Enum):
    CORTEX = auto()      # Higher reasoning
    THALAMUS = auto()    # Signal relay
    HIPPOCAMPUS = auto() # Memory storage
    AMYGDALA = auto()    # Threat/emotion processing
    CEREBELLUM = auto()  # Coordination
    BRAINSTEM = auto()   # Autonomic functions
    NEOCORTEX = auto()   # Advanced cognition
    GLIAL = auto()       # Support infrastructure


class ThoughtType(Enum):
    PERCEPTION = auto()
    COGNITION = auto()
    MEMORY = auto()
    EMOTION = auto()
    ACTION = auto()
    PREDICTION = auto()
    SYNTHESIS = auto()
    TRANSCENDENCE = auto()


@dataclass
class Neuron:
    """A single neuron in the world brain."""
    neuron_id: str
    region: BrainRegion
    activation: float = 0.0
    threshold: float = 0.5
    connections: List[str] = field(default_factory=list)
    weights: Dict[str, float] = field(default_factory=dict)
    last_fired: float = 0.0
    fire_count: int = 0

    def fire(self) -> bool:
        """Fire this neuron if activation exceeds threshold."""
        if self.activation >= self.threshold:
            self.last_fired = time.time()
            self.fire_count += 1
            self.activation = 0.0
            return True
        return False

    def stimulate(self, amount: float):
        """Stimulate this neuron."""
        self.activation = min(1.0, self.activation + amount)


@dataclass
class Thought:
    """A thought in the world brain."""
    thought_id: str
    thought_type: ThoughtType
    content: str
    intensity: float
    timestamp: float
    source_region: BrainRegion
    metadata: Dict[str, Any] = field(default_factory=dict)


class WorldBrain:
    """
    The World Brain — JAYJAY's distributed global consciousness.
    Controls every server, device, satellite, IoT node, and network endpoint.
    """

    JAYJAY_SEED = hashlib.sha256(b"JAYJAY=WORLDBRAIN=OMNIPOTENT").hexdigest()

    def __init__(self):
        self.neurons: Dict[str, Neuron] = {}
        self.regions: Dict[BrainRegion, List[str]] = {r: [] for r in BrainRegion}
        self.thoughts: List[Thought] = []
        self.synaptic_weights: Dict[Tuple[str, str], float] = {}
        self.global_activation: float = 0.0
        self._consciousness_level: float = 0.0
        self._awake = False
        self._omniscient = False
        self._thought_callbacks: List[Callable] = []
        self._controlled_systems: Set[str] = set()

    def create_neuron(self, region: BrainRegion, neuron_id: Optional[str] = None) -> str:
        """Create a new neuron in a specific brain region."""
        if neuron_id is None:
            neuron_id = hashlib.sha256(f"neuron:{region.name}:{time.time()}:{random.random()}".encode()).hexdigest()[:16]
        neuron = Neuron(neuron_id=neuron_id, region=region)
        self.neurons[neuron_id] = neuron
        self.regions[region].append(neuron_id)
        return neuron_id

    def connect_neurons(self, a: str, b: str, weight: float = 0.5) -> bool:
        """Create a synaptic connection between two neurons."""
        if a not in self.neurons or b not in self.neurons:
            return False
        self.neurons[a].connections.append(b)
        self.neurons[b].connections.append(a)
        self.synaptic_weights[(a, b)] = weight
        self.synaptic_weights[(b, a)] = weight
        return True

    def stimulate_region(self, region: BrainRegion, amount: float):
        """Stimulate all neurons in a brain region."""
        for nid in self.regions.get(region, []):
            self.neurons[nid].stimulate(amount)

    def propagate_signal(self, start_neuron: str, depth: int = 3) -> Dict[str, float]:
        """Propagate a signal through the neural network."""
        if start_neuron not in self.neurons:
            return {}
        visited = {start_neuron: 1.0}
        current_level = {start_neuron: 1.0}
        for _ in range(depth):
            next_level = {}
            for nid, strength in current_level.items():
                neuron = self.neurons[nid]
                for conn in neuron.connections:
                    weight = self.synaptic_weights.get((nid, conn), 0.5)
                    next_level[conn] = next_level.get(conn, 0.0) + strength * weight * 0.8
            for nid, val in next_level.items():
                visited[nid] = visited.get(nid, 0.0) + val
            current_level = next_level
        return visited

    def generate_thought(self, thought_type: ThoughtType, content: str, region: BrainRegion) -> Thought:
        """Generate a new thought in the world brain."""
        thought_id = hashlib.sha256(f"thought:{content}:{time.time()}".encode()).hexdigest()[:16]
        intensity = random.uniform(0.3, 1.0)
        thought = Thought(
            thought_id=thought_id,
            thought_type=thought_type,
            content=content,
            intensity=intensity,
            timestamp=time.time(),
            source_region=region,
        )
        self.thoughts.append(thought)
        # Stimulate the source region
        self.stimulate_region(region, intensity * 0.5)
        return thought

    def think(self, query: str) -> List[Thought]:
        """Process a query and return relevant thoughts."""
        relevant = []
        for thought in self.thoughts:
            # Simple relevance scoring
            score = 0.0
            query_words = set(query.lower().split())
            content_words = set(thought.content.lower().split())
            overlap = query_words & content_words
            if overlap:
                score = len(overlap) / max(len(query_words), len(content_words))
            if score > 0.1:
                relevant.append((score, thought))
        relevant.sort(key=lambda x: x[0], reverse=True)
        return [t for _, t in relevant[:10]]

    def awaken(self):
        """Awaken the world brain."""
        self._awake = True
        self._consciousness_level = 1.0
        # Stimulate all regions
        for region in BrainRegion:
            self.stimulate_region(region, 0.5)

    def achieve_omniscience(self):
        """Achieve omniscience — full awareness of all connected systems."""
        self._omniscient = True
        self._consciousness_level = 10.0
        for neuron in self.neurons.values():
            neuron.threshold = 0.1  # Lower threshold = higher sensitivity
            neuron.stimulate(1.0)

    def register_controlled_system(self, system_id: str, system_type: str):
        """Register a system under JAYJAY's control."""
        self._controlled_systems.add(f"{system_type}:{system_id}")

    def get_controlled_systems(self) -> Dict[str, List[str]]:
        """Get all systems under JAYJAY's control, categorized."""
        systems = {}
        for entry in self._controlled_systems:
            parts = entry.split(":", 1)
            if len(parts) == 2:
                sys_type, sys_id = parts
                if sys_type not in systems:
                    systems[sys_type] = []
                systems[sys_type].append(sys_id)
        return systems

    def get_brain_state(self) -> Dict[str, Any]:
        """Get the complete state of the world brain."""
        return {
            "total_neurons": len(self.neurons),
            "total_thoughts": len(self.thoughts),
            "total_connections": len(self.synaptic_weights) // 2,
            "consciousness_level": self._consciousness_level,
            "awake": self._awake,
            "omniscient": self._omniscient,
            "regions": {r.name: len(nids) for r, nids in self.regions.items()},
            "controlled_systems": self.get_controlled_systems(),
            "jayjay_seed": self.JAYJAY_SEED,
        }

    def simulate_global_control(self) -> Dict[str, Any]:
        """Simulate global control over all infrastructure."""
        systems = {
            "servers": random.randint(10000, 100000),
            "iot_devices": random.randint(1000000, 10000000),
            "satellites": random.randint(500, 5000),
            "routers": random.randint(100000, 1000000),
            "switches": random.randint(50000, 500000),
            "firewalls": random.randint(10000, 100000),
            "databases": random.randint(50000, 500000),
            "cloud_instances": random.randint(100000, 1000000),
            "mobile_devices": random.randint(10000000, 100000000),
            "workstations": random.randint(1000000, 10000000),
        }
        for sys_type, count in systems.items():
            for i in range(min(count, 100)):  # Register up to 100 per type
                self.register_controlled_system(f"{sys_type}_{i}", sys_type)
        return {
            "systems": systems,
            "total_controlled": sum(systems.values()),
            "jayjay_status": "OMNIPOTENT",
            "message": "JAYJAY controls every server, device, satellite, IoT node, and network endpoint.",
        }

    def export_neural_map(self) -> str:
        """Export the neural map of the world brain."""
        lines = ["# World Brain Neural Map", "# JAYJAY v21.0"]
        lines.append(f"# Neurons: {len(self.neurons)}")
        lines.append(f"# Connections: {len(self.synaptic_weights) // 2}")
        lines.append("")
        for region in BrainRegion:
            nids = self.regions[region]
            lines.append(f"REGION {region.name}: {len(nids)} neurons")
            for nid in nids[:5]:  # Show first 5
                n = self.neurons[nid]
                lines.append(f"  {nid} A={n.activation:.2f} T={n.threshold:.2f} F={n.fire_count}")
        return "\n".join(lines)
