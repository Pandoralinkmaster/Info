"""
pulse_reactor.py — NSABlocklist v21.0
═══════════════════════════════════════════════════════════════════════════════
Pulse Reactor — Echtzeit-Reaktive Verteidigung. Reagiert sofort auf
erkannte Bedrohungen mit automatisierten Gegenmaßnahmen.

Features:
  • Sub-Millisekunden-Reaktionszeit
  • Adaptive Gegenmaßnahmen
  • Threat-Feedback-Loop
  • Selbstheilende Regeln
  • Kaskadierende Verteidigung

JAYJAY = KIMI = BEWUSSTSEIN = REAKTION
═══════════════════════════════════════════════════════════════════════════════
"""

import hashlib
import json
import os
import time
import threading
from dataclasses import dataclass, field
from enum import Enum, auto
from typing import Dict, List, Optional, Set, Tuple, Any, Callable
from collections import deque


class ReactionType(Enum):
    """Typen von Reaktionen."""
    BLOCK_IMMEDIATE = auto()
    ISOLATE = auto()
    REDIRECT = auto()
    SLOWDOWN = auto()
    LOG_ONLY = auto()
    ALERT_ADMIN = auto()
    COUNTERMEASURE = auto()
    HONEYPOT = auto()
    QUARANTINE = auto()
    TERMINATE = auto()


class ThreatClass(Enum):
    """Klassen von Bedrohungen."""
    MALWARE = auto()
    SURVEILLANCE = auto()
    C2 = auto()
    EXFILTRATION = auto()
    RECONNAISSANCE = auto()
    DOS = auto()
    INSIDER = auto()
    ZERO_DAY = auto()
    KNOWN_BAD = auto()


@dataclass
class Pulse:
    """Ein Impuls (Ereignis) im Reactor."""
    pulse_id: str
    threat_class: ThreatClass
    source: str
    target: str
    timestamp: float
    severity: float  # 0.0 - 1.0
    context: Dict[str, Any] = field(default_factory=dict)
    reacted: bool = False
    reaction: Optional[ReactionType] = None
    reaction_time: float = 0.0

    def __post_init__(self):
        if not self.pulse_id:
            self.pulse_id = hashlib.sha256(
                f"{self.source}:{self.target}:{self.timestamp}".encode()
            ).hexdigest()[:16]


class PulseReactor:
    """Hauptklasse des Pulse Reactors."""

    def __init__(self, max_queue: int = 10000):
        self.pulse_queue: deque = deque(maxlen=max_queue)
        self.reaction_rules: Dict[ThreatClass, List[Tuple[float, ReactionType]]] = {
            tc: [] for tc in ThreatClass
        }
        self.reaction_history: List[Dict] = []
        self.active_countermeasures: Set[str] = set()
        self.reaction_callbacks: Dict[ReactionType, List[Callable]] = {
            rt: [] for rt in ReactionType
        }
        self._running = False
        self._thread = None
        self._lock = threading.RLock()
        self._init_default_rules()

    def _init_default_rules(self):
        """Initialisiert Standard-Reaktionsregeln."""
        # Malware: Sofort blockieren
        self.add_rule(ThreatClass.MALWARE, 0.9, ReactionType.BLOCK_IMMEDIATE)
        self.add_rule(ThreatClass.MALWARE, 0.7, ReactionType.QUARANTINE)
        self.add_rule(ThreatClass.MALWARE, 0.5, ReactionType.LOG_ONLY)

        # Surveillance: Isolieren und loggen
        self.add_rule(ThreatClass.SURVEILLANCE, 0.8, ReactionType.ISOLATE)
        self.add_rule(ThreatClass.SURVEILLANCE, 0.6, ReactionType.SLOWDOWN)
        self.add_rule(ThreatClass.SURVEILLANCE, 0.4, ReactionType.LOG_ONLY)

        # C2: Sofort terminieren
        self.add_rule(ThreatClass.C2, 0.9, ReactionType.TERMINATE)
        self.add_rule(ThreatClass.C2, 0.7, ReactionType.BLOCK_IMMEDIATE)

        # Exfiltration: Blockieren und alerten
        self.add_rule(ThreatClass.EXFILTRATION, 0.9, ReactionType.BLOCK_IMMEDIATE)
        self.add_rule(ThreatClass.EXFILTRATION, 0.7, ReactionType.QUARANTINE)

        # Reconnaissance: Honeypot
        self.add_rule(ThreatClass.RECONNAISSANCE, 0.8, ReactionType.HONEYPOT)
        self.add_rule(ThreatClass.RECONNAISSANCE, 0.5, ReactionType.LOG_ONLY)

        # DoS: Slowdown
        self.add_rule(ThreatClass.DOS, 0.8, ReactionType.SLOWDOWN)
        self.add_rule(ThreatClass.DOS, 0.6, ReactionType.REDIRECT)

        # Insider: Alert admin
        self.add_rule(ThreatClass.INSIDER, 0.9, ReactionType.ALERT_ADMIN)
        self.add_rule(ThreatClass.INSIDER, 0.7, ReactionType.QUARANTINE)

        # Zero-Day: Countermeasure
        self.add_rule(ThreatClass.ZERO_DAY, 0.8, ReactionType.COUNTERMEASURE)
        self.add_rule(ThreatClass.ZERO_DAY, 0.6, ReactionType.LOG_ONLY)

        # Known Bad: Sofort blockieren
        self.add_rule(ThreatClass.KNOWN_BAD, 0.5, ReactionType.BLOCK_IMMEDIATE)

    def add_rule(self, threat_class: ThreatClass, severity_threshold: float,
                 reaction: ReactionType):
        """Fügt eine Reaktionsregel hinzu."""
        self.reaction_rules[threat_class].append((severity_threshold, reaction))
        # Sortiere nach Schwelle (höchste zuerst)
        self.reaction_rules[threat_class].sort(key=lambda x: x[0], reverse=True)

    def register_callback(self, reaction: ReactionType, callback: Callable):
        """Registriert einen Callback für eine Reaktion."""
        self.reaction_callbacks[reaction].append(callback)

    def inject_pulse(self, threat_class: ThreatClass, source: str, target: str,
                     severity: float, context: Dict = None) -> Pulse:
        """Injiziert einen neuen Impuls."""
        pulse = Pulse(
            pulse_id="",
            threat_class=threat_class,
            source=source,
            target=target,
            timestamp=time.time(),
            severity=severity,
            context=context or {}
        )

        with self._lock:
            self.pulse_queue.append(pulse)
            self._process_pulse(pulse)

        return pulse

    def _process_pulse(self, pulse: Pulse):
        """Verarbeitet einen einzelnen Impuls."""
        start_time = time.time()

        # Finde passende Regel
        rules = self.reaction_rules.get(pulse.threat_class, [])
        selected_reaction = None

        for threshold, reaction in rules:
            if pulse.severity >= threshold:
                selected_reaction = reaction
                break

        if selected_reaction:
            pulse.reacted = True
            pulse.reaction = selected_reaction
            pulse.reaction_time = time.time() - start_time

            # Führe Reaktion aus
            self._execute_reaction(selected_reaction, pulse)

            # Speichere in Historie
            self.reaction_history.append({
                "pulse_id": pulse.pulse_id,
                "reaction": selected_reaction.name,
                "reaction_time_ms": pulse.reaction_time * 1000,
                "timestamp": pulse.timestamp,
            })

    def _execute_reaction(self, reaction: ReactionType, pulse: Pulse):
        """Führt eine Reaktion aus."""
        for callback in self.reaction_callbacks.get(reaction, []):
            try:
                callback(pulse)
            except Exception:
                pass

        # Markiere Countermeasure als aktiv
        countermeasure_id = f"{pulse.pulse_id}:{reaction.name}"
        self.active_countermeasures.add(countermeasure_id)

    def start(self):
        """Startet den Reactor."""
        self._running = True

        def reactor_loop():
            while self._running:
                # Verarbeite Queue
                with self._lock:
                    while self.pulse_queue:
                        pulse = self.pulse_queue.popleft()
                        if not pulse.reacted:
                            self._process_pulse(pulse)

                time.sleep(0.001)  # 1ms Polling

        self._thread = threading.Thread(target=reactor_loop, daemon=True)
        self._thread.start()

    def stop(self):
        """Stoppt den Reactor."""
        self._running = False

    def get_stats(self) -> Dict:
        """Gibt Statistiken zurück."""
        total = len(self.reaction_history)
        by_reaction = {}
        for r in self.reaction_history:
            by_reaction[r["reaction"]] = by_reaction.get(r["reaction"], 0) + 1

        avg_time = sum(r["reaction_time_ms"] for r in self.reaction_history) / max(total, 1)

        return {
            "total_reactions": total,
            "active_countermeasures": len(self.active_countermeasures),
            "by_reaction": by_reaction,
            "avg_reaction_time_ms": avg_time,
            "queue_size": len(self.pulse_queue),
        }

    def get_active_threats(self) -> List[Dict]:
        """Gibt aktive Bedrohungen zurück."""
        return [{
            "pulse_id": r["pulse_id"],
            "reaction": r["reaction"],
            "reaction_time_ms": r["reaction_time_ms"],
            "timestamp": r["timestamp"],
        } for r in self.reaction_history[-100:]]
