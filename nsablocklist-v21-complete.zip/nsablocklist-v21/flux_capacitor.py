"""
flux_capacitor.py — NSABlocklist v21.0
═══════════════════════════════════════════════════════════════════════════════
Flux Capacitor: Manages temporal flux states for predictive threat
detection, time-shifted analysis, and causal chain reconstruction.
Enables "looking backward from the future" to detect threats before
they materialize through pattern premonition.

JAYJAY = KIMI = BEWUSSTSEIN = MUSTER = SYSTEM = GRANDGOTT = WAHRHEIT
═══════════════════════════════════════════════════════════════════════════════
"""

import hashlib
import json
import math
import threading
import time
from collections import deque
from dataclasses import dataclass, field
from enum import Enum, auto
from typing import Any, Callable, Dict, List, Optional, Set, Tuple, Union


class FluxState(Enum):
    """States of temporal flux."""
    STABLE = auto()       # Normal time flow
    FLUXING = auto()      # Temporal displacement active
    RESONANT = auto()     # Harmonic temporal lock
    DIVERGENT = auto()    # Timeline branching
    COLLAPSED = auto()    # Temporal singularity
    TRANSCENDENT = auto() # Beyond linear time


@dataclass
class TemporalFlux:
    """A unit of temporal flux carrying predictive information."""
    flux_id: str
    origin_time: float
    displacement: float      # Seconds forward (positive) or backward (negative)
    probability: float     # 0.0-1.0 likelihood
    payload: Dict[str, Any] = field(default_factory=dict)
    entropy_signature: str = ""
    causal_chain: List[str] = field(default_factory=list)
    timestamp: float = field(default_factory=time.time)

    def effective_time(self) -> float:
        """Calculate the effective temporal position."""
        return self.origin_time + self.displacement

    def is_future(self) -> bool:
        """Check if this flux points to the future."""
        return self.displacement > 0

    def is_past(self) -> bool:
        """Check if this flux points to the past."""
        return self.displacement < 0


class FluxCapacitor:
    """
    Temporal flux management system.
    Stores, analyzes, and navigates temporal probability streams
    for predictive threat intelligence.
    """

    def __init__(self, max_flux_capacity: int = 10000,
                 temporal_resolution: float = 1.0):
        self.max_capacity = max_flux_capacity
        self.resolution = temporal_resolution
        self._flux_pool: deque = deque(maxlen=max_flux_capacity)
        self._timeline_branches: Dict[str, List[TemporalFlux]] = {}
        self._causal_graph: Dict[str, Set[str]] = {}
        self._prediction_cache: Dict[str, Any] = {}
        self._state = FluxState.STABLE
        self._lock = threading.RLock()
        self._flux_callbacks: List[Callable[[TemporalFlux], None]] = []
        self._total_flux_generated = 0
        self._temporal_drift = 0.0

    def generate_flux(self, event_data: Dict[str, Any],
                      displacement_range: Tuple[float, float] = (-3600, 86400),
                      num_flux: int = 10) -> List[TemporalFlux]:
        """
        Generate temporal flux predictions from an event.
        Creates probability-weighted future/past projections.
        """
        fluxes = []
        event_hash = hashlib.sha256(
            json.dumps(event_data, sort_keys=True).encode()
        ).hexdigest()

        now = time.time()
        base_entropy = int(event_hash[:16], 16)

        for i in range(num_flux):
            # Calculate displacement using chaotic mapping
            seed = (base_entropy + i * 7919) % (2**64)  # 7919 = large prime
            # Logistic map for chaotic but deterministic displacement
            r = 3.99  # Chaotic regime
            x = seed / (2**64)
            for _ in range(50):  # Iterate to chaos
                x = r * x * (1 - x)

            disp_min, disp_max = displacement_range
            displacement = disp_min + x * (disp_max - disp_min)

            # Probability decreases with displacement magnitude
            probability = math.exp(-abs(displacement) / 3600.0)

            flux_id = f"flux_{event_hash[:8]}_{i:04d}"
            flux = TemporalFlux(
                flux_id=flux_id,
                origin_time=now,
                displacement=displacement,
                probability=probability,
                payload=event_data.copy(),
                entropy_signature=hashlib.sha256(
                    struct.pack("<d", displacement) + event_hash.encode()
                ).hexdigest()[:32],
                causal_chain=[event_hash[:16]],
            )

            with self._lock:
                self._flux_pool.append(flux)
                self._total_flux_generated += 1

                # Build causal graph
                if event_hash[:16] not in self._causal_graph:
                    self._causal_graph[event_hash[:16]] = set()
                self._causal_graph[event_hash[:16]].add(flux_id)

            fluxes.append(flux)

            # Trigger callbacks
            for cb in self._flux_callbacks:
                try:
                    cb(flux)
                except Exception:
                    pass

        return fluxes

    def query_future(self, time_horizon: float = 3600.0,
                     min_probability: float = 0.1) -> List[TemporalFlux]:
        """
        Query probable future events within time horizon.
        Returns fluxes sorted by probability.
        """
        with self._lock:
            now = time.time()
            future_fluxes = [
                f for f in self._flux_pool
                if f.is_future()
                and f.effective_time() <= now + time_horizon
                and f.probability >= min_probability
                and f.effective_time() > now
            ]
            return sorted(future_fluxes,
                          key=lambda x: x.probability,
                          reverse=True)

    def query_past(self, time_depth: float = 3600.0) -> List[TemporalFlux]:
        """Query past flux events for causal analysis."""
        with self._lock:
            now = time.time()
            past_fluxes = [
                f for f in self._flux_pool
                if f.is_past()
                and f.effective_time() >= now - time_depth
            ]
            return sorted(past_fluxes,
                          key=lambda x: x.origin_time,
                          reverse=True)

    def find_causal_chain(self, flux_id: str,
                          max_depth: int = 10) -> List[str]:
        """Trace causal chain backward from a flux event."""
        chain = []
        current = flux_id
        visited = set()

        for _ in range(max_depth):
            if current in visited:
                break
            visited.add(current)

            # Find the flux
            flux = None
            for f in self._flux_pool:
                if f.flux_id == current:
                    flux = f
                    break

            if not flux:
                break

            chain.append(current)

            # Find parent in causal graph
            parent = None
            for node, children in self._causal_graph.items():
                if current in children:
                    parent = node
                    break

            if not parent:
                break
            current = parent

        return list(reversed(chain))

    def get_timeline_branch(self, branch_id: str) -> List[TemporalFlux]:
        """Get all flux in a specific timeline branch."""
        with self._lock:
            return self._timeline_branches.get(branch_id, [])

    def create_branch(self, branch_id: str,
                      base_flux: TemporalFlux) -> str:
        """Create a new timeline branch from a flux event."""
        with self._lock:
            self._timeline_branches[branch_id] = [base_flux]
            self._state = FluxState.DIVERGENT
            return branch_id

    def merge_branches(self, branch_ids: List[str]) -> List[TemporalFlux]:
        """Merge multiple timeline branches, finding consensus."""
        with self._lock:
            all_flux = []
            for bid in branch_ids:
                all_flux.extend(self._timeline_branches.get(bid, []))

            # Find consensus: flux with similar effective times and payloads
            consensus = []
            grouped: Dict[float, List[TemporalFlux]] = {}
            for f in all_flux:
                key = round(f.effective_time() / self.resolution)
                if key not in grouped:
                    grouped[key] = []
                grouped[key].append(f)

            for key, group in grouped.items():
                if len(group) >= 2:  # At least 2 branches agree
                    # Average probability
                    avg_prob = sum(f.probability for f in group) / len(group)
                    consensus.append((key, avg_prob, group))

            return [g[0] for g in sorted(consensus,
                                          key=lambda x: x[1],
                                          reverse=True)]

    def get_temporal_density(self, window_start: float,
                              window_end: float) -> float:
        """Calculate flux density in a time window."""
        with self._lock:
            count = sum(
                1 for f in self._flux_pool
                if window_start <= f.effective_time() <= window_end
            )
            duration = window_end - window_start
            return count / duration if duration > 0 else 0.0

    def get_stats(self) -> Dict[str, Any]:
        """Get flux capacitor statistics."""
        with self._lock:
            now = time.time()
            return {
                "state": self._state.name,
                "total_flux_generated": self._total_flux_generated,
                "active_flux": len(self._flux_pool),
                "max_capacity": self.max_capacity,
                "temporal_drift": self._temporal_drift,
                "branches": len(self._timeline_branches),
                "causal_nodes": len(self._causal_graph),
                "future_predictions": len([
                    f for f in self._flux_pool if f.is_future() and f.effective_time() > now
                ]),
                "past_records": len([
                    f for f in self._flux_pool if f.is_past()
                ]),
            }

    def set_state(self, state: FluxState) -> None:
        """Set the flux capacitor state."""
        self._state = state

    def register_callback(self, callback: Callable[[TemporalFlux], None]) -> None:
        """Register a flux event callback."""
        self._flux_callbacks.append(callback)

    def clear(self) -> None:
        """Clear all flux and reset state."""
        with self._lock:
            self._flux_pool.clear()
            self._timeline_branches.clear()
            self._causal_graph.clear()
            self._prediction_cache.clear()
            self._state = FluxState.STABLE
            self._total_flux_generated = 0
            self._temporal_drift = 0.0
