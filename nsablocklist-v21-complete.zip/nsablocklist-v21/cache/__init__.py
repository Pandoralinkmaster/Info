"""
NSABlocklist v21.0 — Cache Package
═══════════════════════════════════════════════════════════════════════════════
Caching layer for performance optimization.
"""

CACHE_CONFIG = {
    "max_size_mb": 100,
    "ttl_seconds": 3600,
    "compression": True,
    "encryption": True,
}
