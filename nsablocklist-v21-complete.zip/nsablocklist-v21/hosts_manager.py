"""
HostsManager — Advanced hosts file management with multi-format support.
"""

import hashlib
import ipaddress
import json
import os
import time
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum, auto
from pathlib import Path
from typing import Dict, List, Optional, Set, Tuple, Any, Iterator


class HostFormat(Enum):
    """Supported hosts file formats."""
    STANDARD = auto()
    IPV6 = auto()
    DNSMASQ = auto()
    UNBOUND = auto()
    BIND = auto()
    PF = auto()
    IPTABLES = auto()
    NFTABLES = auto()
    JSON = auto()
    XML = auto()
    CSV = auto()
    YAML = auto()
    TOML = auto()
    QUANTUM = auto()
    NEURAL = auto()


@dataclass
class HostEntry:
    """Represents a single hosts file entry."""
    ip: str
    domain: str
    comment: Optional[str] = None
    tags: List[str] = field(default_factory=list)
    source: str = "unknown"
    timestamp: float = field(default_factory=time.time)
    metadata: Dict[str, Any] = field(default_factory=dict)
    quantum_hash: Optional[str] = None
    neural_weight: float = 1.0

    def __post_init__(self):
        if not self.quantum_hash:
            self.quantum_hash = self._compute_hash()

    def _compute_hash(self) -> str:
        data = f"{self.ip}:{self.domain}:{self.timestamp}"
        return hashlib.sha3_256(data.encode()).hexdigest()[:16]

    def is_valid_ip(self) -> bool:
        """Check if IP is valid."""
        try:
            ipaddress.ip_address(self.ip)
            return True
        except ValueError:
            return False

    def is_ipv6(self) -> bool:
        """Check if IP is IPv6."""
        try:
            addr = ipaddress.ip_address(self.ip)
            return isinstance(addr, ipaddress.IPv6Address)
        except ValueError:
            return False

    def to_line(self, format_type: HostFormat = HostFormat.STANDARD) -> str:
        """Convert to hosts file line."""
        if format_type == HostFormat.STANDARD:
            line = f"{self.ip} {self.domain}"
            if self.comment:
                line += f"  # {self.comment}"
            return line
        elif format_type == HostFormat.IPV6:
            return f"::1 {self.domain}  # IPv6 block"
        elif format_type == HostFormat.DNSMASQ:
            return f"address=/{self.domain}/{self.ip}"
        elif format_type == HostFormat.UNBOUND:
            return f"local-zone: "{self.domain}" redirect\nlocal-data: "{self.domain} A {self.ip}""
        elif format_type == HostFormat.BIND:
            return f"zone "{self.domain}" {{ type master; file "/dev/null"; }};"
        elif format_type == HostFormat.PF:
            return f"block return out quick on egress from any to {self.ip}"
        elif format_type == HostFormat.IPTABLES:
            return f"iptables -A OUTPUT -d {self.ip} -j DROP"
        elif format_type == HostFormat.NFTABLES:
            return f"nft add rule inet filter output ip daddr {self.ip} drop"
        elif format_type == HostFormat.QUANTUM:
            return f"QUANTUM::BLOCK {self.ip} {self.domain} {self.quantum_hash}"
        elif format_type == HostFormat.NEURAL:
            return f"NEURAL::WEIGHT {self.neural_weight:.4f} {self.ip} {self.domain}"
        return f"{self.ip} {self.domain}"

    def to_dict(self) -> Dict:
        return {
            "ip": self.ip,
            "domain": self.domain,
            "comment": self.comment,
            "tags": self.tags,
            "source": self.source,
            "timestamp": self.timestamp,
            "metadata": self.metadata,
            "quantum_hash": self.quantum_hash,
            "neural_weight": self.neural_weight,
        }


class HostsManager:
    """
    Advanced hosts file manager supporting multiple formats and features.
    """

    def __init__(self, output_dir: str = "./exports"):
        self.entries: List[HostEntry] = []
        self.output_dir = Path(output_dir)
        self.output_dir.mkdir(parents=True, exist_ok=True)
        self._sources: Dict[str, Set[str]] = {}
        self._tags: Dict[str, Set[str]] = {}
        self._quantum_mode = False
        self._neural_mode = False

    def add_entry(self, entry: HostEntry) -> bool:
        """Add a hosts entry."""
        if not entry.is_valid_ip():
            return False
        # Check for duplicates
        for existing in self.entries:
            if existing.domain == entry.domain and existing.ip == entry.ip:
                return False
        self.entries.append(entry)
        # Index by source
        if entry.source not in self._sources:
            self._sources[entry.source] = set()
        self._sources[entry.source].add(entry.domain)
        # Index by tags
        for tag in entry.tags:
            if tag not in self._tags:
                self._tags[tag] = set()
            self._tags[tag].add(entry.domain)
        return True

    def remove_entry(self, domain: str, ip: Optional[str] = None) -> bool:
        """Remove entries matching domain and optional IP."""
        removed = False
        self.entries = [
            e for e in self.entries
            if not (e.domain == domain and (ip is None or e.ip == ip))
        ]
        return len(self.entries) < len(self.entries) + (1 if removed else 0)

    def find_entries(self, domain: Optional[str] = None,
                    ip: Optional[str] = None,
                    tag: Optional[str] = None,
                    source: Optional[str] = None) -> List[HostEntry]:
        """Find entries matching criteria."""
        results = []
        for entry in self.entries:
            if domain and entry.domain != domain:
                continue
            if ip and entry.ip != ip:
                continue
            if tag and tag not in entry.tags:
                continue
            if source and entry.source != source:
                continue
            results.append(entry)
        return results

    def get_by_source(self, source: str) -> List[HostEntry]:
        """Get all entries from a specific source."""
        domains = self._sources.get(source, set())
        return [e for e in self.entries if e.domain in domains]

    def get_by_tag(self, tag: str) -> List[HostEntry]:
        """Get all entries with a specific tag."""
        domains = self._tags.get(tag, set())
        return [e for e in self.entries if e.domain in domains]

    def generate(self, format_type: HostFormat = HostFormat.STANDARD,
                include_header: bool = True,
                sort_entries: bool = True,
                filter_tags: Optional[List[str]] = None,
                min_neural_weight: float = 0.0) -> str:
        """Generate hosts file in specified format."""
        entries = self.entries
        if filter_tags:
            entries = [e for e in entries if any(t in e.tags for t in filter_tags)]
        if min_neural_weight > 0:
            entries = [e for e in entries if e.neural_weight >= min_neural_weight]
        if sort_entries:
            entries = sorted(entries, key=lambda e: e.domain)

        lines = []
        if include_header:
            lines.append("# NSABlocklist v21.0 — Hosts File")
            lines.append(f"# Generated: {datetime.now().isoformat()}")
            lines.append(f"# Format: {format_type.name}")
            lines.append(f"# Entries: {len(entries)}")
            lines.append("#")
            lines.append("")

        for entry in entries:
            lines.append(entry.to_line(format_type))

        return "\n".join(lines)

    def export(self, filename: str, format_type: HostFormat = HostFormat.STANDARD,
               **kwargs) -> Path:
        """Export to file."""
        content = self.generate(format_type, **kwargs)
        filepath = self.output_dir / filename
        with open(filepath, "w") as f:
            f.write(content)
        return filepath

    def export_all_formats(self, basename: str = "nsablocklist") -> Dict[str, Path]:
        """Export to all supported formats."""
        exports = {}
        for fmt in HostFormat:
            ext = {
                HostFormat.STANDARD: "hosts",
                HostFormat.IPV6: "ipv6",
                HostFormat.DNSMASQ: "dnsmasq.conf",
                HostFormat.UNBOUND: "unbound.conf",
                HostFormat.BIND: "bind.conf",
                HostFormat.PF: "pf.conf",
                HostFormat.IPTABLES: "iptables.sh",
                HostFormat.NFTABLES: "nftables.nft",
                HostFormat.JSON: "json",
                HostFormat.XML: "xml",
                HostFormat.CSV: "csv",
                HostFormat.YAML: "yaml",
                HostFormat.TOML: "toml",
                HostFormat.QUANTUM: "quantum",
                HostFormat.NEURAL: "neural",
            }.get(fmt, fmt.name.lower())
            filename = f"{basename}.{ext}"
            exports[fmt.name] = self.export(filename, fmt)
        return exports

    def import_hosts_file(self, filepath: str, source: str = "import") -> int:
        """Import from a standard hosts file."""
        count = 0
        with open(filepath, "r") as f:
            for line in f:
                line = line.strip()
                if not line or line.startswith("#"):
                    continue
                parts = line.split()
                if len(parts) >= 2:
                    ip = parts[0]
                    domain = parts[1]
                    comment = " ".join(parts[2:]) if len(parts) > 2 else None
                    if comment and comment.startswith("#"):
                        comment = comment[1:].strip()
                    entry = HostEntry(ip=ip, domain=domain, comment=comment, source=source)
                    if self.add_entry(entry):
                        count += 1
        return count

    def import_from_nsa_blocker(self, blocker_entries: Dict[str, Any]) -> int:
        """Import from NSABlocker entries."""
        count = 0
        for domain, entry_data in blocker_entries.items():
            ip = entry_data.get("ip", "0.0.0.0")
            comment = f"{entry_data.get('reason', 'unknown')} | conf:{entry_data.get('confidence', 0):.2f}"
            entry = HostEntry(
                ip=ip,
                domain=domain,
                comment=comment,
                source=entry_data.get("source", "nsa_blocker"),
                tags=entry_data.get("tags", []),
                neural_weight=entry_data.get("neural_score", 1.0),
            )
            if self.add_entry(entry):
                count += 1
        return count

    def deduplicate(self) -> int:
        """Remove duplicate entries."""
        seen = set()
        unique = []
        for entry in self.entries:
            key = (entry.ip, entry.domain)
            if key not in seen:
                seen.add(key)
                unique.append(entry)
        removed = len(self.entries) - len(unique)
        self.entries = unique
        return removed

    def validate(self) -> List[Tuple[HostEntry, str]]:
        """Validate all entries and return errors."""
        errors = []
        for entry in self.entries:
            if not entry.is_valid_ip():
                errors.append((entry, f"Invalid IP: {entry.ip}"))
            if not entry.domain or "." not in entry.domain:
                errors.append((entry, f"Invalid domain: {entry.domain}"))
        return errors

    def get_stats(self) -> Dict[str, Any]:
        """Get comprehensive statistics."""
        ipv4_count = sum(1 for e in self.entries if not e.is_ipv6())
        ipv6_count = sum(1 for e in self.entries if e.is_ipv6())
        return {
            "total_entries": len(self.entries),
            "ipv4_entries": ipv4_count,
            "ipv6_entries": ipv6_count,
            "sources": {k: len(v) for k, v in self._sources.items()},
            "tags": {k: len(v) for k, v in self._tags.items()},
            "avg_neural_weight": sum(e.neural_weight for e in self.entries) / len(self.entries) if self.entries else 0,
        }

    def enable_quantum_mode(self):
        self._quantum_mode = True
        return self

    def enable_neural_mode(self):
        self._neural_mode = True
        return self

    def __len__(self) -> int:
        return len(self.entries)

    def __iter__(self) -> Iterator[HostEntry]:
        return iter(self.entries)
