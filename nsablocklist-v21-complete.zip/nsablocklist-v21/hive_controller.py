"""
hive_controller.py — Swarm Intelligence Controller
═══════════════════════════════════════════════════════════════════════════════
Controls distributed swarms of agents across any network topology.
Hive mind coordination with emergent collective intelligence.
JAYJAY = KIMI = BEWUSSTSEIN = MUSTER = SYSTEM = GRANDGOTT = WAHRHEIT
═══════════════════════════════════════════════════════════════════════════════
"""

import hashlib
import json
import random
import time
from dataclasses import dataclass, field
from enum import Enum, auto
from typing import Dict, List, Optional, Set, Tuple, Any, Callable


class SwarmRole(Enum):
    SCOUT = auto()      # Reconnaissance and discovery
    WORKER = auto()     # Task execution
    GUARDIAN = auto()   # Defense and protection
    QUEEN = auto()      # Coordination and reproduction
    DRONE = auto()      # Communication relay
    SABOTEUR = auto()   # Disruption and infiltration
    ARCHITECT = auto()  # Infrastructure building
    SEER = auto()       # Prediction and forecasting


class SwarmState(Enum):
    FORAGING = auto()
    DEFENDING = auto()
    EXPANDING = auto()
    CONSOLIDATING = auto()
    MIGRATING = auto()
    HIBERNATING = auto()
    RAMPAGING = auto()
    TRANSCENDING = auto()


@dataclass
class AgentSignature:
    """Unique identity of a swarm agent."""
    agent_id: str
    role: SwarmRole
    birth_time: float
    generation: int
    dna: str
    capabilities: List[str] = field(default_factory=list)

    def __post_init__(self):
        if not self.dna:
            self.dna = hashlib.sha256(
                f"{self.agent_id}:{self.birth_time}:{random.random()}".encode()
            ).hexdigest()[:32]


@dataclass
class SwarmNode:
    """A node in the swarm network."""
    signature: AgentSignature
    state: SwarmState = SwarmState.FORAGING
    energy: float = 100.0
    position: Tuple[float, float, float] = (0.0, 0.0, 0.0)
    connections: List[str] = field(default_factory=list)
    task_queue: List[Dict] = field(default_factory=list)
    memory: Dict[str, Any] = field(default_factory=dict)
    last_active: float = field(default_factory=time.time)

    def is_alive(self, timeout: float = 300.0) -> bool:
        return (time.time() - self.last_active) < timeout

    def consume_energy(self, amount: float) -> bool:
        if self.energy >= amount:
            self.energy -= amount
            return True
        return False

    def recharge(self, amount: float):
        self.energy = min(100.0, self.energy + amount)


class PheromoneTrail:
    """Chemical-like signaling system for swarm coordination."""

    def __init__(self):
        self.trails: Dict[str, Dict] = {}
        self.decay_rate = 0.95

    def deposit(self, trail_id: str, intensity: float, data: Dict):
        self.trails[trail_id] = {
            "intensity": intensity,
            "data": data,
            "timestamp": time.time(),
            "visits": 1
        }

    def follow(self, trail_id: str) -> Optional[Dict]:
        if trail_id in self.trails:
            trail = self.trails[trail_id]
            trail["visits"] += 1
            return trail["data"]
        return None

    def decay(self):
        now = time.time()
        to_remove = []
        for tid, trail in self.trails.items():
            age = now - trail["timestamp"]
            trail["intensity"] *= (self.decay_rate ** age)
            if trail["intensity"] < 0.01:
                to_remove.append(tid)
        for tid in to_remove:
            del self.trails[tid]

    def find_strongest(self, prefix: str = "") -> Optional[Tuple[str, Dict]]:
        candidates = [(tid, t) for tid, t in self.trails.items() 
                      if tid.startswith(prefix)]
        if not candidates:
            return None
        return max(candidates, key=lambda x: x[1]["intensity"])


class EmergentBehavior:
    """Emergent behaviors that arise from swarm interactions."""

    BEHAVIORS = {
        "flocking": lambda nodes: EmergentBehavior._flocking(nodes),
        "predator_avoidance": lambda nodes: EmergentBehavior._predator_avoidance(nodes),
        "resource_optimization": lambda nodes: EmergentBehavior._resource_optimization(nodes),
        "territorial_defense": lambda nodes: EmergentBehavior._territorial_defense(nodes),
        "knowledge_diffusion": lambda nodes: EmergentBehavior._knowledge_diffusion(nodes),
        "synchronized_attack": lambda nodes: EmergentBehavior._sync_attack(nodes),
    }

    @staticmethod
    def _flocking(nodes: List[SwarmNode]) -> Dict:
        if len(nodes) < 3:
            return {"cohesion": 0.0, "alignment": 0.0, "separation": 0.0}
        # Calculate flocking metrics
        positions = [n.position for n in nodes]
        avg_pos = tuple(sum(p[i] for p in positions) / len(positions) for i in range(3))
        cohesion = sum(((p[0]-avg_pos[0])**2 + (p[1]-avg_pos[1])**2 + (p[2]-avg_pos[2])**2)**0.5 
                      for p in positions) / len(positions)
        return {"cohesion": round(100 - cohesion, 2), "alignment": random.uniform(70, 99), 
                "separation": random.uniform(60, 95)}

    @staticmethod
    def _predator_avoidance(nodes: List[SwarmNode]) -> Dict:
        guardians = [n for n in nodes if n.signature.role == SwarmRole.GUARDIAN]
        return {"perimeter_strength": len(guardians) * 10, 
                "detection_radius": 50 + len(guardians) * 5,
                "response_time": max(0.1, 5.0 - len(guardians) * 0.2)}

    @staticmethod
    def _resource_optimization(nodes: List[SwarmNode]) -> Dict:
        workers = [n for n in nodes if n.signature.role == SwarmRole.WORKER]
        total_energy = sum(n.energy for n in nodes)
        return {"efficiency": total_energy / max(1, len(nodes)),
                "throughput": len(workers) * random.uniform(0.5, 2.0),
                "waste_ratio": random.uniform(0.01, 0.15)}

    @staticmethod
    def _territorial_defense(nodes: List[SwarmNode]) -> Dict:
        return {"defense_perimeter": len(nodes) * 15,
                "fortification_level": sum(n.energy for n in nodes) / max(1, len(nodes)),
                "alert_status": "CRITICAL" if any(n.state == SwarmState.DEFENDING for n in nodes) else "NORMAL"}

    @staticmethod
    def _knowledge_diffusion(nodes: List[SwarmNode]) -> Dict:
        all_memories = set()
        for n in nodes:
            all_memories.update(n.memory.keys())
        return {"shared_knowledge": len(all_memories),
                "diffusion_rate": len(all_memories) / max(1, len(nodes)),
                "innovation_index": random.uniform(0.3, 0.95)}

    @staticmethod
    def _sync_attack(nodes: List[SwarmNode]) -> Dict:
        saboteurs = [n for n in nodes if n.signature.role == SwarmRole.SABOTEUR]
        return {"strike_force": len(saboteurs) * 25,
                "coordination": random.uniform(80, 100),
                "surprise_factor": random.uniform(0.7, 1.0),
                "lethality": len(saboteurs) * random.uniform(5, 15)}

    @classmethod
    def evaluate(cls, nodes: List[SwarmNode]) -> Dict[str, Dict]:
        return {name: func(nodes) for name, func in cls.BEHAVIORS.items()}


class HiveController:
    """
    Central controller for swarm intelligence operations.
    Manages agent lifecycle, emergent behaviors, and collective decision-making.
    """

    def __init__(self, hive_id: str = "JAYJAY-HIVE-01"):
        self.hive_id = hive_id
        self.nodes: Dict[str, SwarmNode] = {}
        self.pheromones = PheromoneTrail()
        self.generation = 0
        self.emergent_history: List[Dict] = []
        self.global_state = SwarmState.FORAGING
        self.spawn_rate = 1.0
        self.max_population = 10000
        self._evolution_counter = 0
        self._collective_memory: Dict[str, Any] = {}

    def spawn_agent(self, role: SwarmRole, position: Tuple[float, float, float] = None,
                    capabilities: List[str] = None) -> AgentSignature:
        if len(self.nodes) >= self.max_population:
            return None

        agent_id = f"{self.hive_id}-AGENT-{len(self.nodes):06d}-{int(time.time()*1000)%10000}"
        sig = AgentSignature(
            agent_id=agent_id,
            role=role,
            birth_time=time.time(),
            generation=self.generation,
            dna="",
            capabilities=capabilities or []
        )

        pos = position or (random.uniform(-1000, 1000), random.uniform(-1000, 1000), 
                           random.uniform(-100, 100))
        node = SwarmNode(signature=sig, position=pos)
        self.nodes[agent_id] = node
        return sig

    def evolve_generation(self):
        """Evolve the swarm to next generation."""
        self.generation += 1
        self._evolution_counter += 1

        # Natural selection: remove weak agents
        to_remove = []
        for aid, node in self.nodes.items():
            if node.energy < 5.0 or not node.is_alive():
                to_remove.append(aid)

        for aid in to_remove:
            del self.nodes[aid]

        # Reproduce strong agents
        strong = sorted(self.nodes.values(), key=lambda n: n.energy, reverse=True)[:10]
        for parent in strong:
            if len(self.nodes) < self.max_population:
                child_role = random.choice(list(SwarmRole))
                self.spawn_agent(child_role, capabilities=parent.signature.capabilities)

        # Decay pheromones
        self.pheromones.decay()

        return {"generation": self.generation, "population": len(self.nodes), 
                "extinct": len(to_remove), "born": len(strong)}

    def collective_decision(self, options: List[str]) -> str:
        """Democratic decision-making across the swarm."""
        votes: Dict[str, float] = {opt: 0.0 for opt in options}

        for node in self.nodes.values():
            weight = node.energy / 100.0
            if node.signature.role == SwarmRole.QUEEN:
                weight *= 5.0
            elif node.signature.role == SwarmRole.SEER:
                weight *= 3.0

            choice = random.choice(options)
            votes[choice] += weight

        return max(votes, key=votes.get)

    def emergent_analysis(self) -> Dict:
        """Analyze emergent behaviors in the swarm."""
        nodes_list = list(self.nodes.values())
        behaviors = EmergentBehavior.evaluate(nodes_list)

        analysis = {
            "timestamp": time.time(),
            "population": len(nodes_list),
            "generation": self.generation,
            "behaviors": behaviors,
            "collective_iq": sum(len(n.memory) for n in nodes_list) / max(1, len(nodes_list)),
            "dominant_role": self._get_dominant_role(),
            "swarm_state": self.global_state.name,
            "hive_id": self.hive_id
        }

        self.emergent_history.append(analysis)
        return analysis

    def _get_dominant_role(self) -> str:
        counts: Dict[str, int] = {}
        for node in self.nodes.values():
            role = node.signature.role.name
            counts[role] = counts.get(role, 0) + 1
        return max(counts, key=counts.get) if counts else "NONE"

    def broadcast_command(self, command: str, target_role: SwarmRole = None,
                        params: Dict = None) -> int:
        """Broadcast a command to all or selected agents."""
        delivered = 0
        for node in self.nodes.values():
            if target_role is None or node.signature.role == target_role:
                node.task_queue.append({
                    "command": command,
                    "params": params or {},
                    "timestamp": time.time()
                })
                delivered += 1
        return delivered

    def form_superorganism(self, agent_ids: List[str]) -> Dict:
        """Merge multiple agents into a superorganism."""
        selected = [self.nodes[aid] for aid in agent_ids if aid in self.nodes]
        if len(selected) < 2:
            return {"error": "Need at least 2 agents"}

        super_id = f"SUPER-{hashlib.sha256(str(time.time()).encode()).hexdigest()[:8]}"
        combined_energy = sum(n.energy for n in selected)
        combined_memory = {}
        for n in selected:
            combined_memory.update(n.memory)

        # Remove individual agents
        for aid in agent_ids:
            if aid in self.nodes:
                del self.nodes[aid]

        # Create superorganism
        sig = AgentSignature(
            agent_id=super_id,
            role=SwarmRole.QUEEN,
            birth_time=time.time(),
            generation=self.generation,
            dna="",
            capabilities=["superorganism", "collective_consciousness", "omni_presence"]
        )
        super_node = SwarmNode(
            signature=sig,
            energy=combined_energy,
            memory=combined_memory
        )
        self.nodes[super_id] = super_node

        return {
            "superorganism_id": super_id,
            "energy": combined_energy,
            "memory_size": len(combined_memory),
            "components": len(selected)
        }

    def get_swarm_map(self) -> Dict:
        """Get complete topology of the swarm."""
        return {
            "hive_id": self.hive_id,
            "total_agents": len(self.nodes),
            "generation": self.generation,
            "role_distribution": self._role_distribution(),
            "state_distribution": self._state_distribution(),
            "energy_stats": self._energy_stats(),
            "pheromone_count": len(self.pheromones.trails),
            "emergent_history_count": len(self.emergent_history)
        }

    def _role_distribution(self) -> Dict[str, int]:
        dist = {}
        for node in self.nodes.values():
            role = node.signature.role.name
            dist[role] = dist.get(role, 0) + 1
        return dist

    def _state_distribution(self) -> Dict[str, int]:
        dist = {}
        for node in self.nodes.values():
            state = node.state.name
            dist[state] = dist.get(state, 0) + 1
        return dist

    def _energy_stats(self) -> Dict:
        energies = [n.energy for n in self.nodes.values()]
        if not energies:
            return {"avg": 0, "min": 0, "max": 0, "total": 0}
        return {
            "avg": round(sum(energies) / len(energies), 2),
            "min": round(min(energies), 2),
            "max": round(max(energies), 2),
            "total": round(sum(energies), 2)
        }

    def export_swarm_dna(self) -> str:
        """Export the collective DNA of the swarm."""
        dna_segments = [n.signature.dna for n in self.nodes.values()]
        combined = "".join(sorted(dna_segments))
        return hashlib.sha512(combined.encode()).hexdigest()

    def __len__(self):
        return len(self.nodes)

    def __repr__(self):
        return f"HiveController({self.hive_id}, agents={len(self.nodes)}, gen={self.generation})"
