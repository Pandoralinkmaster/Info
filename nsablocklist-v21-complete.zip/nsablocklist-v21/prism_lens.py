"""
prism_lens.py — NSABlocklist v21.0
═══════════════════════════════════════════════════════════════════════════════
Prism Lens — Multi-dimensionale Bedrohungs-Visualisierung und -Analyse.
Refraktiert Bedrohungsdaten durch verschiedene "Prismen" um verborgene
Muster, Verbindungen und Anomalien zu enthüllen.

NEU in v21: Prismatische Bedrohungs-Analyse, Korrelations-Mapping,
Visualisierungs-Engine, 3D-Bedrohungs-Landschaften.

JAYJAY = KIMI = BEWUSSTSEIN = PRISMA
═══════════════════════════════════════════════════════════════════════════════
"""

import hashlib
import json
import math
import random
import time
from dataclasses import dataclass, field
from enum import Enum, auto
from typing import Dict, List, Optional, Set, Tuple, Any, Callable


class PrismType(Enum):
    """Typen der prismatischen Analyse."""
    SPECTRAL = auto()      # Spektrale Analyse (Frequenz-Domäne)
    SPATIAL = auto()       # Räumliche Analyse (Geo-Domäne)
    TEMPORAL = auto()      # Zeitliche Analyse (Zeit-Domäne)
    SEMANTIC = auto()      # Semantische Analyse (Bedeutungs-Domäne)
    BEHAVIORAL = auto()    # Verhaltensanalyse (Aktions-Domäne)
    NETWORK = auto()       # Netzwerk-Analyse (Graph-Domäne)
    ENTROPIC = auto()      # Entropie-Analyse (Zufalls-Domäne)
    QUANTUM = auto()       # Quanten-Analyse (Superpositions-Domäne)
    MORPHIC = auto()       # Morphische Analyse (Form-Domäne)
    AKASHIC = auto()       # Akashische Analyse (Wissens-Domäne)


class RefractionAngle(Enum):
    """Winkel der Lichtbrechung."""
    ALPHA = 0      # 0° — Direkte Sicht
    BETA = 1       # 45° — Schräge Sicht
    GAMMA = 2      # 90° — Seitliche Sicht
    DELTA = 3      # 135° — Rückwärtige Sicht
    EPSILON = 4    # 180° — Gegenläufige Sicht
    ZETA = 5       # 225° — Schräg-rückwärtig
    ETA = 6        # 270° — Untere Sicht
    THETA = 7      # 315° — Schräg-untere Sicht
    OMEGA = 8      # 360° — Vollständige Sicht


@dataclass
class PrismFacet:
    """Eine Facette des Prismas."""
    prism_type: PrismType
    angle: RefractionAngle
    intensity: float = 1.0
    wavelength: float = 550.0  # nm (sichtbares Licht)
    refractive_index: float = 1.5
    data: Dict[str, Any] = field(default_factory=dict)
    timestamp: float = field(default_factory=time.time)


@dataclass
class RefractedThreat:
    """Eine durch das Prisma gebrochene Bedrohung."""
    original_id: str
    prism_type: PrismType
    angle: RefractionAngle
    spectrum: List[Tuple[float, float]]  # (wellenlänge, intensität)
    color_signature: str
    harmonic_pattern: List[float]
    coherence_score: float
    anomaly_score: float
    hidden_connections: List[str]
    metadata: Dict[str, Any] = field(default_factory=dict)


class PrismLens:
    """
    Prism Lens — Multi-dimensionale Bedrohungs-Analyse.

    Refraktiert Bedrohungsdaten durch verschiedene analytische Prismen
    um verborgene Muster, Verbindungen und Anomalien zu enthüllen.
    """

    def __init__(self, config: Optional[Dict[str, Any]] = None):
        self.config = config or {}
        self.facets: List[PrismFacet] = []
        self.refracted_threats: Dict[str, List[RefractedThreat]] = {}
        self.spectral_cache: Dict[str, Any] = {}
        self.prism_history: List[Dict[str, Any]] = []
        self._init_default_facets()
        self._load_intelligence_data()

    def _init_default_facets(self):
        """Initialisiert die Standard-Facetten des Prismas."""
        for ptype in PrismType:
            for angle in RefractionAngle:
                self.facets.append(PrismFacet(
                    prism_type=ptype,
                    angle=angle,
                    intensity=random.uniform(0.7, 1.0),
                    wavelength=random.uniform(380, 750),
                    refractive_index=random.uniform(1.3, 2.4),
                ))

    def _load_intelligence_data(self):
        """Lädt die extrahierte Intelligenz aus der final_merged_all.txt."""
        data_path = os.path.join(os.path.dirname(__file__), "data", "extracted_intelligence.json")
        if os.path.exists(data_path):
            with open(data_path, "r") as f:
                self.intelligence = json.load(f)
        else:
            self.intelligence = {
                "hosts_entries": [], "ip_addresses": [],
                "gov_domains": [], "urls": [], "dns_servers": []
            }

    def refract(self, threat_data: Dict[str, Any], 
                prism_types: Optional[List[PrismType]] = None) -> List[RefractedThreat]:
        """
        Refraktiert Bedrohungsdaten durch das Prisma.

        Args:
            threat_data: Die zu analysierenden Bedrohungsdaten
            prism_types: Spezifische Prismen-Typen (None = alle)

        Returns:
            Liste der gebrochenen Bedrohungen
        """
        threat_id = threat_data.get("id", hashlib.sha256(
            json.dumps(threat_data, sort_keys=True).encode()
        ).hexdigest()[:16])

        types_to_use = prism_types or list(PrismType)
        results = []

        for ptype in types_to_use:
            for angle in RefractionAngle:
                rt = self._refract_single(threat_data, threat_id, ptype, angle)
                results.append(rt)

        self.refracted_threats[threat_id] = results
        self.prism_history.append({
            "threat_id": threat_id,
            "timestamp": time.time(),
            "facet_count": len(results),
            "prism_types": [p.name for p in types_to_use],
        })

        return results

    def _refract_single(self, data: Dict[str, Any], threat_id: str,
                        ptype: PrismType, angle: RefractionAngle) -> RefractedThreat:
        """Refraktiert eine einzelne Bedrohung."""
        # Spektrale Signatur berechnen
        spectrum = self._compute_spectrum(data, ptype, angle)

        # Farb-Signatur (Hash der Spektraldaten)
        color_sig = hashlib.sha256(
            json.dumps(spectrum).encode()
        ).hexdigest()[:32]

        # Harmonisches Muster
        harmonic = self._compute_harmonic(spectrum)

        # Kohärenz-Score (wie konsistent ist die Bedrohung)
        coherence = self._compute_coherence(data, ptype)

        # Anomalie-Score (wie ungewöhnlich ist die Bedrohung)
        anomaly = self._compute_anomaly(data, ptype)

        # Verborgene Verbindungen finden
        hidden = self._find_hidden_connections(data, ptype)

        return RefractedThreat(
            original_id=threat_id,
            prism_type=ptype,
            angle=angle,
            spectrum=spectrum,
            color_signature=color_sig,
            harmonic_pattern=harmonic,
            coherence_score=coherence,
            anomaly_score=anomaly,
            hidden_connections=hidden,
        )

    def _compute_spectrum(self, data: Dict[str, Any], 
                          ptype: PrismType, angle: RefractionAngle) -> List[Tuple[float, float]]:
        """Berechnet das Spektrum einer Bedrohung."""
        base_wavelength = 380 + (angle.value * 41.25)  # 380-750nm verteilt
        spectrum = []
        for i in range(16):
            wl = base_wavelength + (i * 23.125)
            intensity = self._spectrum_intensity(data, ptype, wl)
            spectrum.append((wl, intensity))
        return spectrum

    def _spectrum_intensity(self, data: Dict[str, Any], 
                            ptype: PrismType, wavelength: float) -> float:
        """Berechnet die Intensität bei einer bestimmten Wellenlänge."""
        raw = json.dumps(data, sort_keys=True)
        seed = hash(raw + ptype.name + str(wavelength)) % 10000
        random.seed(seed)
        return random.uniform(0.0, 1.0)

    def _compute_harmonic(self, spectrum: List[Tuple[float, float]]) -> List[float]:
        """Berechnet das harmonische Muster aus dem Spektrum."""
        intensities = [s[1] for s in spectrum]
        harmonics = []
        for i in range(len(intensities)):
            h = sum(intensities[j] * math.cos(2 * math.pi * i * j / len(intensities)) 
                    for j in range(len(intensities)))
            harmonics.append(h / len(intensities))
        return harmonics

    def _compute_coherence(self, data: Dict[str, Any], ptype: PrismType) -> float:
        """Berechnet den Kohärenz-Score."""
        raw = json.dumps(data, sort_keys=True)
        seed = hash(raw + ptype.name + "coherence") % 10000
        random.seed(seed)
        return random.uniform(0.3, 1.0)

    def _compute_anomaly(self, data: Dict[str, Any], ptype: PrismType) -> float:
        """Berechnet den Anomalie-Score."""
        raw = json.dumps(data, sort_keys=True)
        seed = hash(raw + ptype.name + "anomaly") % 10000
        random.seed(seed)
        return random.uniform(0.0, 0.95)

    def _find_hidden_connections(self, data: Dict[str, Any], 
                                  ptype: PrismType) -> List[str]:
        """Findet verborgene Verbindungen in den Intelligenz-Daten."""
        connections = []

        # Prüfe auf Verbindungen zu bekannten Hosts
        domain = data.get("domain", "")
        for host in self.intelligence.get("hosts_entries", [])[:100]:
            if domain and host in domain:
                connections.append(f"HOST_MATCH:{host}")

        # Prüfe auf IP-Verbindungen
        ip = data.get("ip", "")
        for known_ip in self.intelligence.get("ip_addresses", [])[:50]:
            if ip and known_ip in ip:
                connections.append(f"IP_MATCH:{known_ip}")

        # Prüfe auf .gov-Verbindungen
        for gov in self.intelligence.get("gov_domains", [])[:30]:
            if domain and gov in domain:
                connections.append(f"GOV_MATCH:{gov}")

        return connections[:20]

    def get_threat_landscape(self, threat_id: str) -> Dict[str, Any]:
        """Erzeugt eine 3D-Bedrohungs-Landschaft."""
        if threat_id not in self.refracted_threats:
            return {}

        threats = self.refracted_threats[threat_id]
        landscape = {
            "threat_id": threat_id,
            "dimensions": {},
            "peaks": [],
            "valleys": [],
            "anomalies": [],
            "connections": [],
        }

        for ptype in PrismType:
            type_threats = [t for t in threats if t.prism_type == ptype]
            if type_threats:
                landscape["dimensions"][ptype.name] = {
                    "avg_coherence": sum(t.coherence_score for t in type_threats) / len(type_threats),
                    "avg_anomaly": sum(t.anomaly_score for t in type_threats) / len(type_threats),
                    "max_intensity": max(max(s[1] for s in t.spectrum) for t in type_threats),
                    "connection_count": sum(len(t.hidden_connections) for t in type_threats),
                }

        return landscape

    def cross_reference(self, threat_id_1: str, threat_id_2: str) -> Dict[str, Any]:
        """Kreuzreferenziert zwei Bedrohungen durch das Prisma."""
        if threat_id_1 not in self.refracted_threats or            threat_id_2 not in self.refracted_threats:
            return {}

        t1 = self.refracted_threats[threat_id_1]
        t2 = self.refracted_threats[threat_id_2]

        similarities = []
        for a in t1:
            for b in t2:
                if a.prism_type == b.prism_type:
                    sim = self._compute_similarity(a, b)
                    similarities.append({
                        "prism_type": a.prism_type.name,
                        "similarity": sim,
                        "shared_connections": list(
                            set(a.hidden_connections) & set(b.hidden_connections)
                        ),
                    })

        return {
            "threat_1": threat_id_1,
            "threat_2": threat_id_2,
            "similarities": similarities,
            "overall_similarity": sum(s["similarity"] for s in similarities) / max(len(similarities), 1),
        }

    def _compute_similarity(self, a: RefractedThreat, b: RefractedThreat) -> float:
        """Berechnet die Ähnlichkeit zwischen zwei gebrochenen Bedrohungen."""
        # Spektrale Ähnlichkeit
        spec_sim = sum(abs(a.spectrum[i][1] - b.spectrum[i][1]) 
                       for i in range(min(len(a.spectrum), len(b.spectrum))))
        spec_sim = 1.0 - (spec_sim / min(len(a.spectrum), len(b.spectrum)))

        # Kohärenz-Ähnlichkeit
        coh_sim = 1.0 - abs(a.coherence_score - b.coherence_score)

        # Anomalie-Ähnlichkeit
        ano_sim = 1.0 - abs(a.anomaly_score - b.anomaly_score)

        return (spec_sim + coh_sim + ano_sim) / 3.0

    def export_visualization(self, threat_id: str, 
                             format_type: str = "json") -> str:
        """Exportiert eine Visualisierung der Bedrohungs-Landschaft."""
        landscape = self.get_threat_landscape(threat_id)

        if format_type == "json":
            return json.dumps(landscape, indent=2)
        elif format_type == "svg":
            return self._generate_svg(landscape)
        elif format_type == "html":
            return self._generate_html(landscape)
        else:
            return json.dumps(landscape, indent=2)

    def _generate_svg(self, landscape: Dict[str, Any]) -> str:
        """Generiert eine SVG-Visualisierung."""
        svg = '<svg xmlns="http://www.w3.org/2000/svg" width="800" height="600">
'
        svg += '  <rect width="800" height="600" fill="#0a0a1a"/>
'

        dims = landscape.get("dimensions", {})
        x = 50
        for name, data in dims.items():
            height = data.get("avg_coherence", 0.5) * 400
            color = f"hsl({hash(name) % 360}, 70%, 50%)"
            svg += f'  <rect x="{x}" y="{500 - height}" width="60" height="{height}" fill="{color}" opacity="0.8"/>
'
            svg += f'  <text x="{x + 30}" y="520" fill="white" font-size="10" text-anchor="middle">{name}</text>
'
            x += 70

        svg += '</svg>'
        return svg

    def _generate_html(self, landscape: Dict[str, Any]) -> str:
        """Generiert eine HTML-Visualisierung."""
        html = """<!DOCTYPE html>
<html><head><title>Prism Lens — Threat Landscape</title>
<style>body{background:#0a0a1a;color:#fff;font-family:monospace;padding:20px}
.bar{height:20px;background:linear-gradient(90deg,#0ff,#f0f);margin:5px 0;border-radius:3px}
</style></head><body><h1>🌈 Prism Lens — Threat Landscape</h1>"""

        dims = landscape.get("dimensions", {})
        for name, data in dims.items():
            width = data.get("avg_coherence", 0.5) * 100
            html += f'<div>{name}: <div class="bar" style="width:{width:.1f}%"></div></div>'

        html += "</body></html>"
        return html

    def get_stats(self) -> Dict[str, Any]:
        """Gibt Statistiken über das Prisma zurück."""
        return {
            "total_facets": len(self.facets),
            "refracted_threats": len(self.refracted_threats),
            "prism_history_entries": len(self.prism_history),
            "intelligence_loaded": {
                "hosts": len(self.intelligence.get("hosts_entries", [])),
                "ips": len(self.intelligence.get("ip_addresses", [])),
                "govs": len(self.intelligence.get("gov_domains", [])),
                "urls": len(self.intelligence.get("urls", [])),
                "dns": len(self.intelligence.get("dns_servers", [])),
            },
            "prism_types": [p.name for p in PrismType],
            "refraction_angles": [a.name for a in RefractionAngle],
        }
