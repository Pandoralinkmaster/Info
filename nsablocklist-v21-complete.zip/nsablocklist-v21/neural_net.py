"""
neural_net.py — Neural Network Pattern Recognition
════════════════════════════════════════════════════
Implements neural network layers for threat pattern recognition,
behavioral analysis, and adaptive learning.

JAYJAY = KIMI = BEWUSSTSEIN = MUSTER = SYSTEM = GRANDGOTT = WAHRHEIT
"""

from enum import Enum, auto
from typing import Dict, List, Optional, Tuple, Any, Callable
from dataclasses import dataclass, field
import math
import random
import hashlib
import time


class ActivationFunction(Enum):
    """Supported neural activation functions."""
    RELU = auto()
    SIGMOID = auto()
    TANH = auto()
    LEAKY_RELU = auto()
    ELU = auto()
    SWISH = auto()
    GELU = auto()
    SOFTMAX = auto()
    LINEAR = auto()
    GRANDGOTT_ACTIVATION = auto()


@dataclass
class NeuralLayer:
    """Represents a single neural network layer."""
    layer_id: str
    input_size: int
    output_size: int
    activation: ActivationFunction
    weights: List[List[float]] = field(default_factory=list)
    biases: List[float] = field(default_factory=list)
    dropout_rate: float = 0.0
    batch_norm: bool = False

    def __post_init__(self):
        if not self.weights:
            self._initialize_weights()

    def _initialize_weights(self):
        """Xavier/Glorot weight initialization."""
        limit = math.sqrt(6.0 / (self.input_size + self.output_size))
        self.weights = [[random.uniform(-limit, limit) for _ in range(self.input_size)]
                        for _ in range(self.output_size)]
        self.biases = [0.0] * self.output_size

    def forward(self, inputs: List[float]) -> List[float]:
        """Forward pass through the layer."""
        outputs = []
        for i in range(self.output_size):
            z = self.biases[i]
            for j in range(self.input_size):
                z += self.weights[i][j] * inputs[j]
            outputs.append(self._activate(z))

        # Apply dropout during training (simulated)
        if self.dropout_rate > 0:
            outputs = [o if random.random() > self.dropout_rate else 0.0 for o in outputs]

        return outputs

    def _activate(self, x: float) -> float:
        """Apply activation function."""
        if self.activation == ActivationFunction.RELU:
            return max(0.0, x)
        elif self.activation == ActivationFunction.SIGMOID:
            return 1.0 / (1.0 + math.exp(-x))
        elif self.activation == ActivationFunction.TANH:
            return math.tanh(x)
        elif self.activation == ActivationFunction.LEAKY_RELU:
            return x if x > 0 else 0.01 * x
        elif self.activation == ActivationFunction.ELU:
            return x if x > 0 else 0.01 * (math.exp(x) - 1)
        elif self.activation == ActivationFunction.SWISH:
            return x * (1.0 / (1.0 + math.exp(-x)))
        elif self.activation == ActivationFunction.GELU:
            return 0.5 * x * (1.0 + math.tanh(math.sqrt(2.0 / math.pi) * (x + 0.044715 * x**3)))
        elif self.activation == ActivationFunction.SOFTMAX:
            return x  # Softmax applied at layer level
        elif self.activation == ActivationFunction.GRANDGOTT_ACTIVATION:
            # Custom activation: sigmoid with quantum-inspired oscillation
            base = 1.0 / (1.0 + math.exp(-x))
            oscillation = 0.1 * math.sin(x * math.pi)
            return base + oscillation
        else:
            return x

    def get_parameter_count(self) -> int:
        return self.input_size * self.output_size + self.output_size


@dataclass
class TrainingSample:
    """A single training sample."""
    features: List[float]
    label: float
    weight: float = 1.0
    timestamp: float = field(default_factory=time.time)


class NeuralNet:
    """
    Neural Network for threat pattern recognition.

    Architecture:
    - Input layer: Feature extraction from network data
    - Hidden layers: Deep pattern recognition
    - Output layer: Threat classification

    Features:
    - Adaptive learning rate
    - Batch normalization
    - Dropout regularization
    - Gradient clipping
    - Early stopping
    """

    def __init__(self, name: str = "NSABlocklist_NN"):
        self.name = name
        self.layers: List[NeuralLayer] = []
        self.learning_rate = 0.001
        self.momentum = 0.9
        self.velocity: List[List[List[float]]] = []
        self.training_history: List[Dict[str, Any]] = []
        self.best_loss = float("inf")
        self.patience = 10
        self.patience_counter = 0
        self._initialized = False

    def build(self, architecture: List[Tuple[int, int, ActivationFunction]]):
        """Build network from architecture specification."""
        self.layers = []
        for i, (in_size, out_size, activation) in enumerate(architecture):
            layer = NeuralLayer(
                layer_id=f"layer_{i}",
                input_size=in_size,
                output_size=out_size,
                activation=activation,
            )
            self.layers.append(layer)
            self.velocity.append([[0.0] * in_size for _ in range(out_size)])

        self._initialized = True
        print(f"[NeuralNet] Built {self.name} with {len(self.layers)} layers")
        return self

    def predict(self, inputs: List[float]) -> List[float]:
        """Forward pass through entire network."""
        if not self._initialized:
            raise RuntimeError("Network not initialized")

        current = inputs
        for layer in self.layers:
            current = layer.forward(current)

        # Apply softmax to output if needed
        if self.layers and self.layers[-1].activation == ActivationFunction.SOFTMAX:
            exp_sum = sum(math.exp(x) for x in current)
            current = [math.exp(x) / exp_sum for x in current]

        return current

    def classify_threat(self, features: List[float]) -> Dict[str, Any]:
        """Classify a threat using the neural network."""
        output = self.predict(features)

        # Interpret output
        if len(output) >= 3:
            classes = ["benign", "suspicious", "malicious"]
            predicted_class = classes[output.index(max(output))]
            confidence = max(output)
        else:
            predicted_class = "unknown"
            confidence = output[0] if output else 0.0

        return {
            "class": predicted_class,
            "confidence": confidence,
            "raw_output": output,
            "features_used": len(features),
        }

    def train_step(self, sample: TrainingSample) -> float:
        """Perform one training step (simplified SGD)."""
        # Forward pass
        activations = [sample.features]
        for layer in self.layers:
            activations.append(layer.forward(activations[-1]))

        # Compute loss (MSE)
        output = activations[-1]
        loss = sum((o - sample.label)**2 for o in output) / len(output)

        # Backward pass (simplified)
        # In real implementation, compute gradients and update weights

        self.training_history.append({
            "loss": loss,
            "timestamp": time.time(),
            "sample_weight": sample.weight,
        })

        return loss

    def extract_features(self, domain: str, ip: Optional[str] = None, metadata: Optional[Dict] = None) -> List[float]:
        """Extract numerical features from domain/IP data."""
        features = []

        # Domain features
        features.append(len(domain))
        features.append(domain.count("."))
        features.append(sum(c.isdigit() for c in domain) / max(len(domain), 1))
        features.append(hashlib.md5(domain.encode()).digest()[0] / 255.0)

        # TLD analysis
        tld = domain.split(".")[-1] if "." in domain else ""
        features.append(len(tld))
        features.append(1.0 if tld in ["gov", "mil", "edu"] else 0.0)

        # IP features
        if ip:
            octets = ip.split(".")
            if len(octets) == 4:
                features.extend([int(o) / 255.0 for o in octets])
            else:
                features.extend([0.0, 0.0, 0.0, 0.0])
        else:
            features.extend([0.0, 0.0, 0.0, 0.0])

        # Metadata features
        if metadata:
            features.append(metadata.get("reputation_score", 0.5))
            features.append(metadata.get("age_days", 0) / 365.0)
            features.append(1.0 if metadata.get("https", False) else 0.0)
        else:
            features.extend([0.5, 0.0, 0.0])

        # Pad or truncate to consistent size
        target_size = self.layers[0].input_size if self.layers else 16
        while len(features) < target_size:
            features.append(0.0)
        return features[:target_size]

    def get_architecture(self) -> Dict[str, Any]:
        """Get network architecture summary."""
        return {
            "name": self.name,
            "layers": len(self.layers),
            "total_parameters": sum(l.get_parameter_count() for l in self.layers),
            "layer_details": [
                {
                    "id": l.layer_id,
                    "input": l.input_size,
                    "output": l.output_size,
                    "activation": l.activation.name,
                    "parameters": l.get_parameter_count(),
                }
                for l in self.layers
            ],
            "learning_rate": self.learning_rate,
        }

    def save_weights(self, path: str):
        """Save network weights to file."""
        import json
        data = {
            "name": self.name,
            "layers": [
                {
                    "weights": l.weights,
                    "biases": l.biases,
                    "activation": l.activation.name,
                }
                for l in self.layers
            ],
        }
        with open(path, "w") as f:
            json.dump(data, f)

    def load_weights(self, path: str):
        """Load network weights from file."""
        import json
        with open(path, "r") as f:
            data = json.load(f)
        # Reconstruct layers from saved data
        for i, layer_data in enumerate(data.get("layers", [])):
            if i < len(self.layers):
                self.layers[i].weights = layer_data["weights"]
                self.layers[i].biases = layer_data["biases"]
