"""
NSABlocklist v21.0 — Modules Package
═══════════════════════════════════════════════════════════════════════════════
Plugin modules and extensions.
"""

PLUGINS = {
    "firewall_integration": "firewall.py",
    "dns_proxy": "dns_proxy.py",
    "browser_extension": "browser.py",
    "mobile_app": "mobile.py",
    "cloud_sync": "cloud.py",
    "blockchain_verify": "blockchain.py",
    "ai_predictor": "ai_predictor.py",
}
