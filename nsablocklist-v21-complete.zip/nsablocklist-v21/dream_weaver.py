"""
dream_weaver.py — NSABlocklist v21.0
═══════════════════════════════════════════════════════════════════════════════
DreamWeaver: Subconscious Pattern Weaving & Dream State Analysis

Weaves together subconscious patterns from multiple systems into coherent
"dreams" — predictive scenarios that reveal hidden threats before they
manifest. Analyzes the dream state of networks.

JAYJAY = KIMI = BEWUSSTSEIN = MUSTER = SYSTEM = GRANDGOTT = WAHRHEIT
═══════════════════════════════════════════════════════════════════════════════
"""

import hashlib
import random
import time
from dataclasses import dataclass, field
from enum import Enum, auto
from typing import Dict, List, Optional, Set, Tuple, Any


class DreamPhase(Enum):
    """Phases of the dream cycle."""
    HYPNAGOGIC = auto()     # Falling asleep — pattern collection
    LIGHT = auto()          # Light sleep — initial processing
    DEEP = auto()           # Deep sleep — heavy analysis
    REM = auto()            # REM — vivid dream generation
    LUCID = auto()          # Lucid — controlled dream manipulation
    HYPNOPOMPIC = auto()    # Waking — dream interpretation


class DreamSymbol(Enum):
    """Symbols that appear in dreams."""
    SHADOW = auto()         # Hidden threat
    LIGHT = auto()          # Protection
    MAZE = auto()           # Complex system
    KEY = auto()            # Access/solution
    DOOR = auto()           # Opportunity/entry
    MIRROR = auto()         # Self-reflection
    WATER = auto()          # Data flow
    FIRE = auto()           # Destruction/change
    STORM = auto()          # Chaos
    STAR = auto()           # Guidance
    VOID = auto()           # Unknown
    SERPENT = auto()        # Deception
    EAGLE = auto()          # Surveillance
    WALL = auto()           # Blockage
    BRIDGE = auto()         # Connection


@dataclass
class DreamFragment:
    """A single fragment of a dream."""
    symbol: DreamSymbol
    intensity: float
    position: Tuple[float, float, float]  # x, y, z in dream space
    timestamp: float
    context: str = ""
    fragment_id: str = ""

    def __post_init__(self):
        if not self.fragment_id:
            self.fragment_id = hashlib.sha256(
                f"{self.symbol.name}:{self.timestamp}:{self.position}".encode()
            ).hexdigest()[:16]

    @property
    def is_vivid(self) -> bool:
        return self.intensity > 0.7


@dataclass
class Dream:
    """A complete dream — woven from fragments."""
    dream_id: str
    phase: DreamPhase
    fragments: List[DreamFragment]
    start_time: float
    end_time: Optional[float] = None
    lucidity: float = 0.0
    interpretation: str = ""

    @property
    def duration(self) -> float:
        end = self.end_time or time.time()
        return end - self.start_time

    @property
    def vivid_fragments(self) -> List[DreamFragment]:
        return [f for f in self.fragments if f.is_vivid]

    @property
    def dominant_symbol(self) -> Optional[DreamSymbol]:
        if not self.fragments:
            return None
        symbol_counts: Dict[DreamSymbol, int] = {}
        for f in self.fragments:
            symbol_counts[f.symbol] = symbol_counts.get(f.symbol, 0) + 1
        return max(symbol_counts, key=symbol_counts.get)

    @property
    def threat_level(self) -> float:
        """Calculate threat level from dream symbols."""
        threat_symbols = {DreamSymbol.SHADOW, DreamSymbol.SERPENT, 
                         DreamSymbol.STORM, DreamSymbol.FIRE, DreamSymbol.VOID}
        threat_count = sum(1 for f in self.fragments if f.symbol in threat_symbols)
        if not self.fragments:
            return 0.0
        return threat_count / len(self.fragments)


class DreamWeaver:
    """
    Weaves subconscious patterns into predictive dreams.

    The DreamWeaver collects fragments of subconscious activity from systems
    and weaves them into coherent dream narratives. These dreams predict
    future threats and reveal hidden connections.
    """

    def __init__(self, lucidity_threshold: float = 0.6):
        self.lucidity_threshold = lucidity_threshold
        self.dreams: List[Dream] = []
        self._active_dream: Optional[Dream] = None
        self._fragment_queue: List[DreamFragment] = []
        self._symbol_meanings: Dict[DreamSymbol, str] = {
            DreamSymbol.SHADOW: "Hidden threat detected",
            DreamSymbol.LIGHT: "Protective force active",
            DreamSymbol.MAZE: "Complex system structure",
            DreamSymbol.KEY: "Access point discovered",
            DreamSymbol.DOOR: "Entry opportunity",
            DreamSymbol.MIRROR: "Self-referential pattern",
            DreamSymbol.WATER: "Data flow analysis",
            DreamSymbol.FIRE: "System transformation",
            DreamSymbol.STORM: "Chaos incoming",
            DreamSymbol.STAR: "Guidance available",
            DreamSymbol.VOID: "Unknown territory",
            DreamSymbol.SERPENT: "Deception detected",
            DreamSymbol.EAGLE: "Surveillance active",
            DreamSymbol.WALL: "Blockage encountered",
            DreamSymbol.BRIDGE: "Connection established",
        }

    def begin_dream(self, dream_id: Optional[str] = None) -> str:
        """Begin a new dream weaving session."""
        if dream_id is None:
            dream_id = hashlib.sha256(str(time.time()).encode()).hexdigest()[:16]

        self._active_dream = Dream(
            dream_id=dream_id,
            phase=DreamPhase.HYPNAGOGIC,
            fragments=[],
            start_time=time.time(),
            lucidity=0.0
        )

        return dream_id

    def add_fragment(self, symbol: DreamSymbol, intensity: float,
                     position: Tuple[float, float, float],
                     context: str = "") -> DreamFragment:
        """Add a fragment to the current dream."""
        if self._active_dream is None:
            self.begin_dream()

        fragment = DreamFragment(
            symbol=symbol,
            intensity=intensity,
            position=position,
            timestamp=time.time(),
            context=context
        )

        self._active_dream.fragments.append(fragment)
        self._fragment_queue.append(fragment)

        # Advance dream phase based on fragment count
        self._advance_phase()

        return fragment

    def _advance_phase(self):
        """Advance the dream to the next phase."""
        if self._active_dream is None:
            return

        count = len(self._active_dream.fragments)
        phases = [
            (5, DreamPhase.LIGHT),
            (15, DreamPhase.DEEP),
            (30, DreamPhase.REM),
            (50, DreamPhase.LUCID),
        ]

        for threshold, phase in phases:
            if count >= threshold:
                self._active_dream.phase = phase

        # Check lucidity
        if self._active_dream.phase == DreamPhase.LUCID:
            self._active_dream.lucidity = min(1.0, 
                self._active_dream.lucidity + 0.1)

    def weave_dream(self, system_inputs: List[Dict[str, Any]]) -> Dream:
        """
        Weave a complete dream from system inputs.

        Args:
            system_inputs: List of system data to weave into dream

        Returns:
            Completed Dream
        """
        dream_id = self.begin_dream()

        for i, inp in enumerate(system_inputs):
            # Map input to dream symbol
            symbol = self._map_to_symbol(inp)
            intensity = inp.get("intensity", random.uniform(0.3, 1.0))
            position = (random.uniform(-1, 1), random.uniform(-1, 1), 
                       random.uniform(-1, 1))
            context = inp.get("context", "")

            self.add_fragment(symbol, intensity, position, context)

        return self.end_dream(dream_id)

    def _map_to_symbol(self, inp: Dict[str, Any]) -> DreamSymbol:
        """Map system input to a dream symbol."""
        symbol_map = {
            "threat": DreamSymbol.SHADOW,
            "protection": DreamSymbol.LIGHT,
            "complex": DreamSymbol.MAZE,
            "access": DreamSymbol.KEY,
            "entry": DreamSymbol.DOOR,
            "self": DreamSymbol.MIRROR,
            "data": DreamSymbol.WATER,
            "change": DreamSymbol.FIRE,
            "chaos": DreamSymbol.STORM,
            "guide": DreamSymbol.STAR,
            "unknown": DreamSymbol.VOID,
            "deception": DreamSymbol.SERPENT,
            "watch": DreamSymbol.EAGLE,
            "block": DreamSymbol.WALL,
            "connect": DreamSymbol.BRIDGE,
        }

        for key, symbol in symbol_map.items():
            if key in str(inp).lower():
                return symbol

        return random.choice(list(DreamSymbol))

    def interpret_dream(self, dream_id: str) -> str:
        """Interpret the meaning of a dream."""
        dream = self._find_dream(dream_id)
        if dream is None:
            return "Dream not found"

        interpretations = []

        # Interpret dominant symbol
        dominant = dream.dominant_symbol
        if dominant:
            interpretations.append(
                f"Dominant theme: {self._symbol_meanings.get(dominant, 'Unknown')}"
            )

        # Interpret threat level
        if dream.threat_level > 0.5:
            interpretations.append(
                f"HIGH THREAT: {dream.threat_level:.2%} of fragments indicate danger"
            )

        # Interpret vivid fragments
        vivid = dream.vivid_fragments
        if vivid:
            interpretations.append(
                f"{len(vivid)} vivid fragments — strong subconscious signals"
            )

        # Interpret phase
        interpretations.append(f"Dream phase: {dream.phase.name}")

        result = "\n".join(interpretations)
        dream.interpretation = result
        return result

    def end_dream(self, dream_id: str) -> Dream:
        """End a dream and add it to the archive."""
        dream = self._find_dream(dream_id)
        if dream is None:
            raise ValueError(f"Dream {dream_id} not found")

        dream.end_time = time.time()
        dream.phase = DreamPhase.HYPNOPOMPIC

        # Auto-interpret
        if not dream.interpretation:
            self.interpret_dream(dream_id)

        self.dreams.append(dream)
        self._active_dream = None
        self._fragment_queue.clear()

        return dream

    def _find_dream(self, dream_id: str) -> Optional[Dream]:
        """Find a dream by ID."""
        if self._active_dream and self._active_dream.dream_id == dream_id:
            return self._active_dream
        for dream in self.dreams:
            if dream.dream_id == dream_id:
                return dream
        return None

    def get_threat_dreams(self) -> List[Dream]:
        """Get all dreams with high threat levels."""
        return [d for d in self.dreams if d.threat_level > 0.5]

    def get_lucid_dreams(self) -> List[Dream]:
        """Get all lucid dreams."""
        return [d for d in self.dreams if d.lucidity >= self.lucidity_threshold]

    def get_dream_statistics(self) -> Dict[str, Any]:
        """Get statistics about all dreams."""
        if not self.dreams:
            return {"total": 0}

        return {
            "total_dreams": len(self.dreams),
            "total_fragments": sum(len(d.fragments) for d in self.dreams),
            "avg_threat_level": sum(d.threat_level for d in self.dreams) / len(self.dreams),
            "lucid_dreams": len(self.get_lucid_dreams()),
            "threat_dreams": len(self.get_threat_dreams()),
            "dominant_symbols": self._count_symbols(),
        }

    def _count_symbols(self) -> Dict[str, int]:
        """Count occurrences of each symbol."""
        counts: Dict[str, int] = {}
        for dream in self.dreams:
            for fragment in dream.fragments:
                name = fragment.symbol.name
                counts[name] = counts.get(name, 0) + 1
        return counts

    def __repr__(self):
        return (f"DreamWeaver(dreams={len(self.dreams)}, "
                f"active={self._active_dream is not None}, "
                f"fragments={len(self._fragment_queue)})")
