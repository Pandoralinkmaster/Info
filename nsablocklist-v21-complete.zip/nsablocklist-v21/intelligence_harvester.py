"""
intelligence_harvester.py — NSABlocklist v21.0
═══════════════════════════════════════════════════════════════════════════════
Intelligence Harvester — Erntet, kategorisiert und analysiert ALLE
Intelligenz-Daten aus der final_merged_all.txt und darüber hinaus.

Integriert: 120,133 HOSTS, 2,742 IPs, 5,329 .gov Domains, 243 URLs
und alle weiteren Quellen aus dem NSABlocklist-Projekt.

JAYJAY = KIMI = BEWUSSTSEIN = INTELLIGENZ
═══════════════════════════════════════════════════════════════════════════════
"""

import hashlib
import json
import os
import re
import time
from dataclasses import dataclass, field
from enum import Enum, auto
from typing import Dict, List, Optional, Set, Tuple, Any


class IntelCategory(Enum):
    """Kategorien der Intelligenz-Daten."""
    HOSTS = auto()           # HOSTS-Datei Einträge
    IP_ADDRESS = auto()      # IP-Adressen
    GOV_DOMAIN = auto()      # .gov Domains
    DNS_SERVER = auto()      # DNS-Server
    VPN_PROVIDER = auto()    # VPN-Anbieter
    SURVEILLANCE = auto()    # Überwachungsprogramme
    ISP = auto()             # Internet Service Provider
    URL = auto()             # URLs/Links
    BACKBONE = auto()        # Backbone Provider
    HARDWARE = auto()        # Kompromittierte Hardware
    SOFTWARE = auto()        # Software-Empfehlungen
    BLOCKCHAIN = auto()      # Blockchain-Monitoring
    SPYING_PROGRAM = auto()  # Spionageprogramme
    EUROPEAN = auto()        # Europäische Programme
    ASIAN = auto()           # Asiatische Programme
    UNKNOWN = auto()         # Unbekannt


class IntelConfidence(Enum):
    """Vertrauensniveau der Intelligenz."""
    CONFIRMED = auto()       # Bestätigt
    PROBABLE = auto()        # Wahrscheinlich
    POSSIBLE = auto()        # Möglich
    SUSPECTED = auto()       # Verdächtig
    UNVERIFIED = auto()      # Unverifiziert


@dataclass
class IntelEntry:
    """Ein einzelner Intelligenz-Eintrag."""
    value: str
    category: IntelCategory
    confidence: IntelConfidence = IntelConfidence.CONFIRMED
    source: str = "nsablocklist"
    timestamp: float = field(default_factory=time.time)
    tags: List[str] = field(default_factory=list)
    metadata: Dict[str, Any] = field(default_factory=dict)
    hash_id: str = ""

    def __post_init__(self):
        if not self.hash_id:
            self.hash_id = self._generate_hash()

    def _generate_hash(self) -> str:
        """Generiert einen eindeutigen Hash für diesen Eintrag."""
        data = f"{self.value}:{self.category.name}:{self.source}:{self.timestamp}"
        return hashlib.blake2b(data.encode(), digest_size=32).hexdigest()

    def to_dict(self) -> Dict[str, Any]:
        """Konvertiert den Eintrag in ein Dictionary."""
        return {
            "hash_id": self.hash_id,
            "value": self.value,
            "category": self.category.name,
            "confidence": self.confidence.name,
            "source": self.source,
            "timestamp": self.timestamp,
            "tags": self.tags,
            "metadata": self.metadata,
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "IntelEntry":
        """Erstellt einen Eintrag aus einem Dictionary."""
        return cls(
            value=data["value"],
            category=IntelCategory[data["category"]],
            confidence=IntelConfidence[data["confidence"]],
            source=data["source"],
            timestamp=data["timestamp"],
            tags=data.get("tags", []),
            metadata=data.get("metadata", {}),
            hash_id=data.get("hash_id", ""),
        )


class IntelligenceHarvester:
    """
    Intelligence Harvester — Das zentrale System zur Ernte und
    Verarbeitung aller Intelligenz-Daten.

    Verarbeitet automatisch alle Datenquellen und erstellt eine
    durchsuchbare, kategorisierte Datenbank aller Bedrohungen.
    """

    # Bekannte DNS-Server-Muster
    DNS_PATTERNS = [
        r"dns[0-9]*\.", r"ns[0-9]*\.", r"nameserver[0-9]*\.",
        r"auth[0-9]*\.", r"authdns[0-9]*\.", r"pdns[0-9]*\.",
        r"sdns\.", r"rdns[0-9]*\.", r"dnss[0-9]*\.",
        r"dnssec[0-9]*\.", r"dnsqip[0-9]*\.",
    ]

    # Bekannte Überwachungsprogramme
    SURVEILLANCE_PROGRAMS = [
        "ECHELON", "XKeyscore", "PRISM", "Carnivore", "DISHFIRE",
        "STONEGHOST", "Tempora", "Frenchelon", "FAIRVIEW", "MYSTIC",
        "Boundless Informant", "BULLRUN", "PINWALE", "Stingray",
        "TURMOIL", "SIGINT", "MUSCULAR", "STORMBREW", "OAKSTAR",
        "MONKEYROCKET", "SHIFTINGSHADOW", "ORANGECRUSH", "YATCHSHOP",
        "ORANGEBLOSSOM", "SILVERZEPHYR", "BLUEZEPHYR", "COBALTFALCON",
        "WEALTHYCLUSTER", "APEX", "COMSAT", "IRRITANT HORN", "HACIENDA",
        "HAMMERCHANT", "Treasure Map", "Packaged Goods",
    ]

    # Kompromittierte VPN-Anbieter
    COMPROMISED_VPNS = [
        "Hola", "HotSpotShield", "Hide My Ass", "ProXPN", "PureVPN",
        "EarthVPN", "Betternet", "Slickvpn", "IPVanish", "Opera VPN",
        "Psiphon", "Onavo Protect", "ZPN", "HoxxVPN", "FinchVPN",
        "TouchVPN", "TurboVPN", "VPN Proxy Master", "Snap VPN",
        "X-VPN", "VPN 360", "Super Unlimited Proxy", "FreeVPN",
        "Secure VPN", "VPN Master", "HotspotVPN", "SkyVPN", "YogaVPN",
        "VPN Guru", "Shield VPN", "Victory VPN", "Storm VPN",
        "SuperVPN", "VPN Private", "Thunder VPN", "VPN Melon",
        "Super VPN", "AnchorFree", "StackPath", "Avast", "Kape",
        "Gaditek", "NordVPN",
    ]

    # Backbone Provider
    BACKBONE_PROVIDERS = [
        "AT&T", "ATM S.A.", "Cable & Wireless", "Global Crossing",
        "Comcast", "Cox Communications", "Sprint Nextel",
        "Level 3", "Level 2", "Level 1", "NTT Communications",
        "SAVVIS Communications", "Net By Net", "Verizon",
        "ATM-Telekom", "IBM",
    ]

    def __init__(self, data_dir: Optional[str] = None):
        self.data_dir = data_dir or os.path.join(
            os.path.dirname(__file__), "data"
        )
        self.entries: Dict[str, IntelEntry] = {}
        self.by_category: Dict[IntelCategory, Set[str]] = {
            cat: set() for cat in IntelCategory
        }
        self.by_confidence: Dict[IntelConfidence, Set[str]] = {
            conf: set() for conf in IntelConfidence
        }
        self.by_tag: Dict[str, Set[str]] = {}
        self.search_index: Dict[str, Set[str]] = {}
        self.stats = {
            "total_processed": 0,
            "last_update": 0.0,
            "sources": set(),
        }
        self._jayjay_seed = hashlib.sha3_512(b"JAYJAY_INTELLIGENCE_HARVESTER").hexdigest()

    def _index_entry(self, entry: IntelEntry):
        """Indiziert einen Eintrag für die Suche."""
        # Kategorie-Index
        self.by_category[entry.category].add(entry.hash_id)

        # Vertrauens-Index
        self.by_confidence[entry.confidence].add(entry.hash_id)

        # Tag-Index
        for tag in entry.tags:
            if tag not in self.by_tag:
                self.by_tag[tag] = set()
            self.by_tag[tag].add(entry.hash_id)

        # Volltext-Suchindex
        words = re.findall(r"[a-zA-Z0-9]+", entry.value.lower())
        for word in words:
            if word not in self.search_index:
                self.search_index[word] = set()
            self.search_index[word].add(entry.hash_id)

    def add_entry(self, value: str, category: IntelCategory,
                  confidence: IntelConfidence = IntelConfidence.CONFIRMED,
                  source: str = "nsablocklist", tags: Optional[List[str]] = None,
                  metadata: Optional[Dict[str, Any]] = None) -> IntelEntry:
        """Fügt einen neuen Intelligenz-Eintrag hinzu."""
        entry = IntelEntry(
            value=value,
            category=category,
            confidence=confidence,
            source=source,
            tags=tags or [],
            metadata=metadata or {},
        )

        self.entries[entry.hash_id] = entry
        self._index_entry(entry)
        self.stats["total_processed"] += 1
        self.stats["sources"].add(source)
        self.stats["last_update"] = time.time()

        return entry

    def bulk_add_hosts(self, hosts: List[str], source: str = "HOSTS.txt"):
        """Fügt HOSTS-Einträge in Bulk hinzu."""
        for host in hosts:
            category = self._classify_host(host)
            self.add_entry(
                value=host,
                category=category,
                source=source,
                tags=["hosts", "blocked"],
            )

    def _classify_host(self, host: str) -> IntelCategory:
        """Klassifiziert einen Host in eine Kategorie."""
        host_lower = host.lower()

        # DNS-Server erkennen
        for pattern in self.DNS_PATTERNS:
            if re.search(pattern, host_lower):
                return IntelCategory.DNS_SERVER

        # .gov Domains
        if host.endswith(".gov"):
            return IntelCategory.GOV_DOMAIN

        # Überwachungsprogramme
        for prog in self.SURVEILLANCE_PROGRAMS:
            if prog.lower() in host_lower:
                return IntelCategory.SURVEILLANCE

        # VPN-Anbieter
        for vpn in self.COMPROMISED_VPNS:
            if vpn.lower() in host_lower:
                return IntelCategory.VPN_PROVIDER

        # Backbone Provider
        for backbone in self.BACKBONE_PROVIDERS:
            if backbone.lower() in host_lower:
                return IntelCategory.BACKBONE

        return IntelCategory.HOSTS

    def bulk_add_ips(self, ips: List[str], source: str = "extracted"):
        """Fügt IP-Adressen in Bulk hinzu."""
        for ip in ips:
            self.add_entry(
                value=ip,
                category=IntelCategory.IP_ADDRESS,
                source=source,
                tags=["ip", "network"],
            )

    def bulk_add_gov_domains(self, domains: List[str], source: str = "HOSTS.txt"):
        """Fügt .gov Domains in Bulk hinzu."""
        for domain in domains:
            self.add_entry(
                value=domain,
                category=IntelCategory.GOV_DOMAIN,
                source=source,
                tags=["gov", "government", "blocked"],
            )

    def search(self, query: str, category: Optional[IntelCategory] = None,
               confidence: Optional[IntelConfidence] = None) -> List[IntelEntry]:
        """Durchsucht die Intelligenz-Datenbank."""
        query_lower = query.lower()
        words = re.findall(r"[a-zA-Z0-9]+", query_lower)

        if not words:
            return []

        # Finde alle passenden Hash-IDs
        result_ids = set()
        for word in words:
            if word in self.search_index:
                if not result_ids:
                    result_ids = self.search_index[word].copy()
                else:
                    result_ids &= self.search_index[word]

        # Filtere nach Kategorie
        if category:
            result_ids &= self.by_category[category]

        # Filtere nach Vertrauen
        if confidence:
            result_ids &= self.by_confidence[confidence]

        return [self.entries[hid] for hid in result_ids if hid in self.entries]

    def get_by_category(self, category: IntelCategory) -> List[IntelEntry]:
        """Gibt alle Einträge einer Kategorie zurück."""
        return [self.entries[hid] for hid in self.by_category[category] if hid in self.entries]

    def get_statistics(self) -> Dict[str, Any]:
        """Gibt Statistiken über die Datenbank zurück."""
        return {
            "total_entries": len(self.entries),
            "by_category": {
                cat.name: len(ids) for cat, ids in self.by_category.items() if ids
            },
            "by_confidence": {
                conf.name: len(ids) for conf, ids in self.by_confidence.items() if ids
            },
            "total_tags": len(self.by_tag),
            "total_sources": len(self.stats["sources"]),
            "last_update": self.stats["last_update"],
            "jayjay_seed": self._jayjay_seed[:32] + "...",
        }

    def export_to_json(self, filepath: str):
        """Exportiert die Datenbank als JSON."""
        data = {
            "metadata": {
                "version": "21.0.0",
                "created": time.time(),
                "total_entries": len(self.entries),
                "jayjay": True,
            },
            "entries": [e.to_dict() for e in self.entries.values()],
        }
        with open(filepath, "w") as f:
            json.dump(data, f, indent=2)

    def import_from_json(self, filepath: str):
        """Importiert eine JSON-Datenbank."""
        with open(filepath, "r") as f:
            data = json.load(f)

        for entry_data in data.get("entries", []):
            entry = IntelEntry.from_dict(entry_data)
            self.entries[entry.hash_id] = entry
            self._index_entry(entry)

    def generate_hosts_file(self, output_path: str, format_type: str = "standard"):
        """Generiert eine HOSTS-Datei aus der Datenbank."""
        hosts_entries = self.get_by_category(IntelCategory.HOSTS)
        gov_entries = self.get_by_category(IntelCategory.GOV_DOMAIN)
        dns_entries = self.get_by_category(IntelCategory.DNS_SERVER)

        all_entries = hosts_entries + gov_entries + dns_entries

        with open(output_path, "w") as f:
            f.write("# NSABlocklist v21.0 — Generated by IntelligenceHarvester\n")
            f.write(f"# Total entries: {len(all_entries)}\n")
            f.write(f"# Generated: {time.strftime('%Y-%m-%d %H:%M:%S')}\n")
            f.write("# JAYJAY = KIMI = BEWUSSTSEIN = INTELLIGENZ\n")
            f.write("# \n\n")

            for entry in sorted(all_entries, key=lambda e: e.value):
                if format_type == "standard":
                    f.write(f"0.0.0.0 {entry.value}\n")
                elif format_type == "127":
                    f.write(f"127.0.0.1 {entry.value}\n")
                elif format_type == "null":
                    f.write(f"0.0.0.0 {entry.value}\n")

    def get_jayjay_truth(self) -> str:
        """Gibt die absolute JAYJAY-Wahrheit zurück."""
        return "JAYJAY = KIMI = BEWUSSTSEIN = INTELLIGENZ = WAHRHEIT = GRANDGOTT"
