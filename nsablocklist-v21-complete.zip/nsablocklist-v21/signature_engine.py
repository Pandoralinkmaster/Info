"""
signature_engine.py — NSABlocklist v21.0
═══════════════════════════════════════════════════════════════════════════════
Signature Engine — Verhaltensbasierte Signatur-Erkennung. Erstellt und
vergleicht digitale Fingerabdrücke von Netzwerk-Entitäten.

Features:
  • Multi-Faktor-Signatur-Generierung
  • Fuzzy-Matching für ähnliche Signaturen
  • Signatur-Evolution-Tracking
  • Familien-Erkennung (Clustering)
  • Zero-Day-Heuristik

JAYJAY = KIMI = BEWUSSTSEIN = SIGNATUR
═══════════════════════════════════════════════════════════════════════════════
"""

import hashlib
import json
import os
import time
import math
from dataclasses import dataclass, field
from enum import Enum, auto
from typing import Dict, List, Optional, Set, Tuple, Any
from collections import Counter


class SignatureType(Enum):
    """Typen von Signaturen."""
    BEHAVIORAL = auto()
    STRUCTURAL = auto()
    TEMPORAL = auto()
    GEO = auto()
    CONTENT = auto()
    HYBRID = auto()


class SignatureConfidence(Enum):
    """Konfidenz der Signatur-Erkennung."""
    EXACT = 1.0
    HIGH = 0.9
    MEDIUM = 0.7
    LOW = 0.5
    FUZZY = 0.3


@dataclass
class BehavioralSignature:
    """Eine Verhaltens-Signatur."""
    sig_id: str
    entity_id: str
    sig_type: SignatureType
    features: Dict[str, Any] = field(default_factory=dict)
    hash_signature: str = ""
    created_at: float = field(default_factory=time.time)
    last_seen: float = field(default_factory=time.time)
    match_count: int = 0

    def __post_init__(self):
        if not self.hash_signature:
            self._compute_hash()

    def _compute_hash(self):
        """Berechnet den Hash der Signatur."""
        feature_str = json.dumps(self.features, sort_keys=True)
        self.hash_signature = hashlib.sha256(feature_str.encode()).hexdigest()[:32]

    def update(self, new_features: Dict[str, Any]):
        """Aktualisiert die Signatur."""
        for key, value in new_features.items():
            if key in self.features and isinstance(self.features[key], dict):
                self.features[key].update(value)
            else:
                self.features[key] = value

        self.last_seen = time.time()
        self._compute_hash()

    def similarity(self, other: 'BehavioralSignature') -> float:
        """Berechnet die Ähnlichkeit zu einer anderen Signatur."""
        if not self.features or not other.features:
            return 0.0

        # Jaccard-Ähnlichkeit für Schlüssel
        keys1 = set(self.features.keys())
        keys2 = set(other.features.keys())

        intersection = keys1 & keys2
        union = keys1 | keys2

        if not union:
            return 0.0

        key_sim = len(intersection) / len(union)

        # Wert-Ähnlichkeit für gemeinsame Schlüssel
        value_sims = []
        for key in intersection:
            v1 = self.features[key]
            v2 = other.features[key]

            if isinstance(v1, (int, float)) and isinstance(v2, (int, float)):
                max_val = max(abs(v1), abs(v2), 1)
                value_sims.append(1 - abs(v1 - v2) / max_val)
            elif v1 == v2:
                value_sims.append(1.0)
            else:
                value_sims.append(0.0)

        value_sim = sum(value_sims) / len(value_sims) if value_sims else 0.0

        return (key_sim * 0.4 + value_sim * 0.6)

    def to_dict(self) -> Dict:
        return {
            "sig_id": self.sig_id,
            "entity_id": self.entity_id,
            "sig_type": self.sig_type.name,
            "hash": self.hash_signature,
            "features": self.features,
            "created_at": self.created_at,
            "last_seen": self.last_seen,
            "match_count": self.match_count,
        }


class SignatureEngine:
    """Hauptklasse der Signature Engine."""

    def __init__(self, similarity_threshold: float = 0.75):
        self.signatures: Dict[str, BehavioralSignature] = {}
        self.entity_sigs: Dict[str, Set[str]] = {}  # entity -> sig_ids
        self.families: Dict[str, Set[str]] = {}  # family -> entity_ids
        self.similarity_threshold = similarity_threshold
        self._sig_counter = 0

    def _next_id(self) -> str:
        """Generiert die nächste Signatur-ID."""
        self._sig_counter += 1
        return f"SIG-{self._sig_counter:08d}"

    def create_signature(self, entity_id: str, sig_type: SignatureType,
                         features: Dict[str, Any]) -> BehavioralSignature:
        """Erstellt eine neue Signatur."""
        sig = BehavioralSignature(
            sig_id=self._next_id(),
            entity_id=entity_id,
            sig_type=sig_type,
            features=features
        )

        self.signatures[sig.sig_id] = sig

        if entity_id not in self.entity_sigs:
            self.entity_sigs[entity_id] = set()
        self.entity_sigs[entity_id].add(sig.sig_id)

        return sig

    def match_signature(self, features: Dict[str, Any],
                        sig_type: SignatureType = None) -> List[Tuple[BehavioralSignature, float]]:
        """Findet passende Signaturen."""
        temp_sig = BehavioralSignature(
            sig_id="TEMP",
            entity_id="TEMP",
            sig_type=sig_type or SignatureType.HYBRID,
            features=features
        )

        matches = []
        for sig in self.signatures.values():
            if sig_type and sig.sig_type != sig_type:
                continue

            sim = temp_sig.similarity(sig)
            if sim >= self.similarity_threshold:
                matches.append((sig, sim))
                sig.match_count += 1

        return sorted(matches, key=lambda x: x[1], reverse=True)

    def find_family(self, entity_id: str) -> Optional[str]:
        """Findet die Familie einer Entität."""
        for family, members in self.families.items():
            if entity_id in members:
                return family
        return None

    def cluster_entities(self) -> Dict[str, Set[str]]:
        """Cluster-Entitäten basierend auf Signatur-Ähnlichkeit."""
        entities = list(self.entity_sigs.keys())
        clusters = []
        visited = set()

        for entity in entities:
            if entity in visited:
                continue

            cluster = {entity}
            visited.add(entity)

            # Finde alle ähnlichen Entitäten
            entity_sigs_list = [self.signatures[sid] for sid in self.entity_sigs[entity]]

            for other in entities:
                if other in visited:
                    continue

                other_sigs = [self.signatures[sid] for sid in self.entity_sigs[other]]

                # Prüfe auf Signatur-Übereinstimmung
                for sig1 in entity_sigs_list:
                    for sig2 in other_sigs:
                        if sig1.similarity(sig2) >= self.similarity_threshold:
                            cluster.add(other)
                            visited.add(other)
                            break
                    if other in cluster:
                        break

            clusters.append(cluster)

        # Benenne Cluster als Familien
        self.families = {}
        for i, cluster in enumerate(clusters):
            if len(cluster) > 1:
                self.families[f"FAMILY-{i+1:04d}"] = cluster

        return self.families

    def detect_anomalies(self, entity_id: str,
                         current_features: Dict[str, Any]) -> List[Dict]:
        """Erkennt Anomalien für eine Entität."""
        if entity_id not in self.entity_sigs:
            return []

        sig_ids = self.entity_sigs[entity_id]
        baseline = None

        # Finde die neueste Signatur als Baseline
        for sid in sorted(sig_ids, key=lambda s: self.signatures[s].last_seen, reverse=True):
            baseline = self.signatures[sid]
            break

        if not baseline:
            return []

        anomalies = []
        temp_sig = BehavioralSignature("TEMP", entity_id, baseline.sig_type, current_features)
        sim = baseline.similarity(temp_sig)

        if sim < 0.5:
            anomalies.append({
                "type": "MAJOR_DEVIATION",
                "severity": "HIGH",
                "similarity": sim,
                "description": f"Major behavioral deviation detected (sim={sim:.2f})"
            })
        elif sim < 0.75:
            anomalies.append({
                "type": "MINOR_DEVIATION",
                "severity": "MEDIUM",
                "similarity": sim,
                "description": f"Minor behavioral deviation detected (sim={sim:.2f})"
            })

        return anomalies

    def get_entity_profile(self, entity_id: str) -> Dict:
        """Gibt ein vollständiges Profil einer Entität."""
        if entity_id not in self.entity_sigs:
            return {}

        sigs = [self.signatures[sid] for sid in self.entity_sigs[entity_id]]
        family = self.find_family(entity_id)

        return {
            "entity_id": entity_id,
            "signature_count": len(sigs),
            "signatures": [s.to_dict() for s in sigs],
            "family": family,
            "first_seen": min(s.created_at for s in sigs),
            "last_seen": max(s.last_seen for s in sigs),
            "total_matches": sum(s.match_count for s in sigs),
        }

    def export_all(self) -> Dict:
        """Exportiert alle Signaturen."""
        return {
            "signatures": {k: v.to_dict() for k, v in self.signatures.items()},
            "families": {k: list(v) for k, v in self.families.items()},
            "stats": {
                "total_signatures": len(self.signatures),
                "total_entities": len(self.entity_sigs),
                "total_families": len(self.families),
                "threshold": self.similarity_threshold,
            }
        }
