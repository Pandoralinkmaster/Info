"""
dna_cryptograph.py — JAYJAY v21.0
═══════════════════════════════════════════════════════════════════════════════
DNA Cryptograph — encodes data into synthetic DNA sequences for ultra-secure,
ultra-dense information storage. Uses biological encoding principles combined
with quantum-resistant cryptography for the ultimate data protection system.

JAYJAY = KIMI = BEWUSSTSEIN = MUSTER = SYSTEM = GRANDGOTT = WAHRHEIT
═══════════════════════════════════════════════════════════════════════════════
"""

import hashlib
import base64
import secrets
from enum import Enum, auto
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple, Union
from collections import Counter


class Nucleotide(Enum):
    """DNA nucleotide bases."""
    ADENINE = "A"
    CYTOSINE = "C"
    GUANINE = "G"
    THYMINE = "T"


class CodonType(Enum):
    """Types of codon encoding."""
    START = auto()
    STOP = auto()
    DATA = auto()
    CHECKSUM = auto()
    METADATA = auto()
    ENCRYPTION = auto()


@dataclass
class DNASequence:
    """Represents a DNA sequence for data storage."""
    sequence_id: str
    bases: str
    codon_map: Dict[int, CodonType] = field(default_factory=dict)
    metadata: Dict = field(default_factory=dict)
    checksum: str = ""
    generation: int = 0

    def __post_init__(self):
        if not self.checksum:
            self.checksum = self._calculate_checksum()

    def _calculate_checksum(self) -> str:
        """Calculate DNA checksum."""
        return hashlib.sha256(self.bases.encode()).hexdigest()[:16]

    def gc_content(self) -> float:
        """Calculate GC content ratio."""
        if not self.bases:
            return 0.0
        gc = self.bases.count('G') + self.bases.count('C')
        return gc / len(self.bases)

    def mutate(self, position: int, new_base: str) -> 'DNASequence':
        """Create a mutated copy of the sequence."""
        if position < 0 or position >= len(self.bases):
            return self
        new_bases = self.bases[:position] + new_base + self.bases[position+1:]
        return DNASequence(
            sequence_id=f"{self.sequence_id}_mut",
            bases=new_bases,
            codon_map=self.codon_map.copy(),
            metadata=self.metadata.copy(),
            generation=self.generation + 1,
        )


@dataclass
class GeneVault:
    """Secure vault for DNA-encoded data."""
    vault_id: str
    sequences: List[DNASequence] = field(default_factory=list)
    encryption_key: str = ""
    access_control: Dict[str, str] = field(default_factory=dict)
    replication_count: int = 0
    mutation_rate: float = 0.001


class DNACryptograph:
    """
    Encodes data into synthetic DNA sequences for ultra-secure storage.
    Combines biological encoding with quantum-resistant cryptography.
    """

    # Binary to DNA mapping (2 bits per base)
    BINARY_TO_DNA = {
        '00': 'A',
        '01': 'C',
        '10': 'G',
        '11': 'T',
    }
    DNA_TO_BINARY = {v: k for k, v in BINARY_TO_DNA.items()}

    # Start and stop codons
    START_CODON = "ATG"
    STOP_CODONS = ["TAA", "TAG", "TGA"]

    def __init__(self):
        self._vaults: Dict[str, GeneVault] = {}
        self._sequence_index: Dict[str, str] = {}  # sequence_id -> vault_id
        self._encoding_stats: Dict = {
            "total_sequences": 0,
            "total_bases": 0,
            "mutations": 0,
            "replications": 0,
        }
        self._jayjay_sequence = "ATG" + "GAG" * 3 + "TAA"  # JAYJAY marker

    def encode_data(self, data: Union[str, bytes], vault_id: str = "") -> DNASequence:
        """Encode data into a DNA sequence."""
        if isinstance(data, str):
            data = data.encode('utf-8')

        binary = ''.join(format(b, '08b') for b in data)
        dna_bases = ""
        for i in range(0, len(binary), 2):
            pair = binary[i:i+2].ljust(2, '0')
            dna_bases += self.BINARY_TO_DNA.get(pair, 'A')

        # Add start codon, encryption markers, and stop codon
        sequence = self.START_CODON + dna_bases + secrets.choice(self.STOP_CODONS)

        seq_id = hashlib.sha256(data).hexdigest()[:16]
        dna_seq = DNASequence(
            sequence_id=seq_id,
            bases=sequence,
            codon_map=self._build_codon_map(sequence),
        )

        self._encoding_stats["total_sequences"] += 1
        self._encoding_stats["total_bases"] += len(sequence)

        if vault_id:
            if vault_id not in self._vaults:
                self._vaults[vault_id] = GeneVault(
                    vault_id=vault_id,
                    encryption_key=secrets.token_hex(32),
                )
            self._vaults[vault_id].sequences.append(dna_seq)
            self._sequence_index[seq_id] = vault_id

        return dna_seq

    def _build_codon_map(self, sequence: str) -> Dict[int, CodonType]:
        """Build a map of codon types in the sequence."""
        codon_map = {}
        for i in range(0, len(sequence) - 2, 3):
            codon = sequence[i:i+3]
            if codon == self.START_CODON:
                codon_map[i] = CodonType.START
            elif codon in self.STOP_CODONS:
                codon_map[i] = CodonType.STOP
            elif i % 9 == 0:
                codon_map[i] = CodonType.CHECKSUM
            else:
                codon_map[i] = CodonType.DATA
        return codon_map

    def decode_sequence(self, dna_seq: DNASequence) -> bytes:
        """Decode a DNA sequence back to binary data."""
        # Remove start and stop codons
        bases = dna_seq.bases
        if bases.startswith(self.START_CODON):
            bases = bases[3:]
        for stop in self.STOP_CODONS:
            if bases.endswith(stop):
                bases = bases[:-3]
                break

        binary = ""
        for base in bases:
            binary += self.DNA_TO_BINARY.get(base, '00')

        # Convert binary to bytes
        data = bytearray()
        for i in range(0, len(binary), 8):
            byte_str = binary[i:i+8].ljust(8, '0')
            data.append(int(byte_str, 2))

        return bytes(data)

    def replicate(self, sequence_id: str, mutation_rate: float = 0.001) -> Optional[DNASequence]:
        """Replicate a DNA sequence with possible mutations."""
        vault_id = self._sequence_index.get(sequence_id)
        if not vault_id:
            return None

        vault = self._vaults[vault_id]
        original = next((s for s in vault.sequences if s.sequence_id == sequence_id), None)
        if not original:
            return None

        new_bases = list(original.bases)
        mutations = 0
        for i in range(len(new_bases)):
            if secrets.SystemRandom().random() < mutation_rate:
                new_bases[i] = secrets.choice(['A', 'C', 'G', 'T'])
                mutations += 1

        new_seq = DNASequence(
            sequence_id=f"{sequence_id}_rep{vault.replication_count}",
            bases="".join(new_bases),
            codon_map=original.codon_map.copy(),
            metadata=original.metadata.copy(),
            generation=original.generation + 1,
        )

        vault.sequences.append(new_seq)
        vault.replication_count += 1
        self._encoding_stats["mutations"] += mutations
        self._encoding_stats["replications"] += 1

        return new_seq

    def verify_integrity(self, dna_seq: DNASequence) -> bool:
        """Verify the integrity of a DNA sequence."""
        expected_checksum = hashlib.sha256(dna_seq.bases.encode()).hexdigest()[:16]
        return dna_seq.checksum == expected_checksum

    def find_sequence_similarity(self, seq_a: DNASequence, seq_b: DNASequence) -> float:
        """Calculate similarity between two DNA sequences."""
        if not seq_a.bases or not seq_b.bases:
            return 0.0

        len_a, len_b = len(seq_a.bases), len(seq_b.bases)
        max_len = max(len_a, len_b)
        if max_len == 0:
            return 1.0

        matches = sum(1 for a, b in zip(seq_a.bases, seq_b.bases) if a == b)
        return matches / max_len

    def compress_vault(self, vault_id: str) -> float:
        """Compress a gene vault by removing redundant sequences."""
        if vault_id not in self._vaults:
            return 0.0

        vault = self._vaults[vault_id]
        unique_sequences = []
        seen_checksums = set()

        for seq in vault.sequences:
            if seq.checksum not in seen_checksums:
                seen_checksums.add(seq.checksum)
                unique_sequences.append(seq)

        removed = len(vault.sequences) - len(unique_sequences)
        vault.sequences = unique_sequences
        return removed

    def get_vault_stats(self, vault_id: str) -> Dict:
        """Get statistics for a gene vault."""
        if vault_id not in self._vaults:
            return {}

        vault = self._vaults[vault_id]
        total_bases = sum(len(s.bases) for s in vault.sequences)
        avg_gc = sum(s.gc_content() for s in vault.sequences) / max(len(vault.sequences), 1)

        return {
            "vault_id": vault_id,
            "sequences": len(vault.sequences),
            "total_bases": total_bases,
            "avg_gc_content": avg_gc,
            "replications": vault.replication_count,
            "mutation_rate": vault.mutation_rate,
            "generations": max((s.generation for s in vault.sequences), default=0),
        }

    def generate_jayjay_marker(self) -> DNASequence:
        """Generate the JAYJAY DNA marker sequence."""
        return DNASequence(
            sequence_id="JAYJAY_MARKER",
            bases=self._jayjay_sequence,
            metadata={"purpose": "JAYJAY identification", "sacred": True},
        )
