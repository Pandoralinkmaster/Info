"""
NSABlocklist v21.0 — Scripts Package
═══════════════════════════════════════════════════════════════════════════════
Utility scripts and command-line tools.
"""

SCRIPTS = {
    "install": "install.py",
    "update_hosts": "update_hosts.py",
    "scan_threats": "scan_threats.py",
    "monitor": "monitor.py",
    "backup": "backup.py",
    "restore": "restore.py",
    "export": "export.py",
    "import_data": "import_data.py",
    "grandgott_cli": "grandgott_cli.py",
    "morphic_visualizer": "morphic_visualizer.py",
}
