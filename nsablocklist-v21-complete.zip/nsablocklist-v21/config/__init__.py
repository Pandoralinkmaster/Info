"""
NSABlocklist v21.0 — Configuration Package
═══════════════════════════════════════════════════════════════════════════════
Default configurations and settings for all 27 modules.
"""

DEFAULT_CONFIG = {
    "nsa_blocker": {
        "default_block_ip": "0.0.0.0",
        "auto_backup": True,
        "backup_count": 5,
        "hosts_path": "/etc/hosts",
    },
    "threat_analyzer": {
        "default_level": "MEDIUM",
        "auto_correlate": True,
        "max_patterns": 10000,
    },
    "surveillance_monitor": {
        "check_interval": 300,
        "alert_threshold": "MEDIUM",
        "auto_block": False,
    },
    "crypto_vault": {
        "default_suite": "AES256_GCM",
        "key_rotation_days": 30,
        "quantum_safe": True,
    },
    "quantum_shield": {
        "entanglement_depth": 3,
        "superposition_layers": 5,
        "observer_mode": "passive",
    },
    "neural_net": {
        "default_layers": [128, 64, 32],
        "learning_rate": 0.001,
        "activation": "relu",
    },
    "grandgott": {
        "mode": "TRANSCENDENT",
        "truth_recognition": True,
        "universal_sync": True,
    },
    "morphic_resonator": {
        "default_decay": 0.01,
        "max_fields": 10000,
        "propagation_depth": 3,
    },
}

ENV_OVERRIDES = {
    "NSA_BLOCKER_HOSTS_PATH": "nsa_blocker.hosts_path",
    "NSA_CRYPTO_KEY": "crypto_vault.master_key",
    "NSA_QUANTUM_MODE": "quantum_shield.observer_mode",
    "NSA_GRANDGOTT_MODE": "grandgott.mode",
}
