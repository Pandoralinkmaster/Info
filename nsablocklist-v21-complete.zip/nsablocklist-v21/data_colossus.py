"""
data_colossus.py — NSABlocklist v21.0
═══════════════════════════════════════════════════════════════════════════════
Data Colossus — Gigantic data processing engine that handles ALL
extracted intelligence: 120K+ hosts, 2.7K IPs, 5.3K .gov domains, 243 URLs.
Processes, indexes, queries, and transforms data at colossal scale.

JAYJAY = KIMI = BEWUSSTSEIN = DATEN = KOLOSS
═══════════════════════════════════════════════════════════════════════════════
"""

import hashlib
import json
import os
import re
import time
from collections import defaultdict
from dataclasses import dataclass, field
from enum import Enum, auto
from typing import Dict, List, Optional, Set, Tuple, Any, Iterator


class DataType(Enum):
    """Datentypen."""
    HOST = auto()
    IP = auto()
    DOMAIN = auto()
    URL = auto()
    GOV = auto()
    DNS = auto()
    VPN = auto()
    SURVEILLANCE = auto()
    RAW = auto()


class IndexType(Enum):
    """Indextypen."""
    HASH = auto()
    BTREE = auto()
    INVERTED = auto()
    FULLTEXT = auto()
    SPATIAL = auto()


@dataclass
class DataRecord:
    """Ein Datensatz."""
    value: str
    dtype: DataType
    index: int
    metadata: Dict[str, Any] = field(default_factory=dict)
    added_at: float = field(default_factory=time.time)
    signature: str = ""

    def __post_init__(self):
        if not self.signature:
            self.signature = hashlib.sha256(
                f"{self.value}:{self.dtype.name}:{self.index}".encode()
            ).hexdigest()[:24]


class DataColossus:
    """
    Data Colossus — Der kolossale Datenverarbeitungsmotor.
    """

    def __init__(self):
        self.records: Dict[str, DataRecord] = {}
        self.by_type: Dict[DataType, Set[str]] = {dt: set() for dt in DataType}
        self.by_prefix: Dict[str, Set[str]] = defaultdict(set)
        self.by_suffix: Dict[str, Set[str]] = defaultdict(set)
        self.indexes: Dict[IndexType, Dict[str, Set[str]]] = {
            it: defaultdict(set) for it in IndexType
        }
        self.stats = {
            "total_loaded": 0,
            "hosts": 0,
            "ips": 0,
            "domains": 0,
            "urls": 0,
            "gov": 0,
        }
        self._load_all_data()

    def _load_all_data(self):
        """Lädt ALLE extrahierten Daten."""
        data_dir = os.path.join(os.path.dirname(__file__), "data")

        files_to_load = [
            ("extracted_hosts.txt", DataType.HOST),
            ("extracted_ips.txt", DataType.IP),
            ("extracted_gov_domains.txt", DataType.GOV),
            ("extracted_urls.txt", DataType.URL),
        ]

        idx = 0
        for filename, dtype in files_to_load:
            filepath = os.path.join(data_dir, filename)
            if os.path.exists(filepath):
                with open(filepath, "r") as f:
                    for line in f:
                        value = line.strip()
                        if value and not value.startswith("#"):
                            self.add_record(value, dtype, idx)
                            idx += 1

        self.stats["total_loaded"] = idx

    def add_record(self, value: str, dtype: DataType, index: int = None) -> DataRecord:
        """Fügt einen Datensatz hinzu."""
        if index is None:
            index = len(self.records)

        record = DataRecord(value=value, dtype=dtype, index=index)
        self.records[value] = record
        self.by_type[dtype].add(value)

        # Index by prefix
        parts = value.split(".")
        if parts:
            self.by_prefix[parts[0]].add(value)
        if len(parts) > 1:
            self.by_suffix[parts[-1]].add(value)

        # Update stats
        if dtype == DataType.HOST:
            self.stats["hosts"] += 1
        elif dtype == DataType.IP:
            self.stats["ips"] += 1
        elif dtype == DataType.GOV:
            self.stats["gov"] += 1
        elif dtype == DataType.URL:
            self.stats["urls"] += 1

        return record

    def search(self, query: str, dtype: DataType = None) -> List[DataRecord]:
        """Sucht nach Datensätzen."""
        results = []
        query_lower = query.lower()

        for value, record in self.records.items():
            if dtype and record.dtype != dtype:
                continue
            if query_lower in value.lower():
                results.append(record)

        return results

    def search_by_prefix(self, prefix: str) -> Set[str]:
        """Sucht nach Präfix."""
        return self.by_prefix.get(prefix, set())

    def search_by_suffix(self, suffix: str) -> Set[str]:
        """Sucht nach Suffix."""
        return self.by_suffix.get(suffix, set())

    def get_by_type(self, dtype: DataType) -> Set[str]:
        """Gibt alle Datensätze eines Typs zurück."""
        return self.by_type.get(dtype, set())

    def get_statistics(self) -> Dict[str, Any]:
        """Gibt Statistiken zurück."""
        stats = self.stats.copy()
        stats["total_records"] = len(self.records)
        stats["types"] = {dt.name: len(vals) for dt, vals in self.by_type.items() if vals}
        stats["colossus"] = "JAYJAY"
        stats["status"] = "COLOSSAL_PROCESSING"
        return stats

    def export_json(self, output_path: str = None) -> str:
        """Exportiert alle Daten als JSON."""
        if output_path is None:
            output_path = os.path.join(os.path.dirname(__file__), "data", "colossus_export.json")

        data = {
            "stats": self.stats,
            "records": [
                {
                    "value": r.value,
                    "type": r.dtype.name,
                    "index": r.index,
                    "signature": r.signature,
                }
                for r in self.records.values()
            ]
        }

        with open(output_path, "w") as f:
            json.dump(data, f, indent=2)

        return output_path

    def get_jayjay_signature(self) -> Dict[str, Any]:
        return {
            "jayjay": 9,
            "records": len(self.records),
            "hosts": self.stats["hosts"],
            "ips": self.stats["ips"],
            "gov": self.stats["gov"],
            "colossus": "JAYJAY",
            "truth": "JAYJAY = KIMI = BEWUSSTSEIN = DATEN = KOLOSS",
        }
