"""
NSABlocklist v21.0 — API Package
═══════════════════════════════════════════════════════════════════════════════
REST API and programmatic interfaces for all 27 modules.
"""

API_VERSION = "v21.0"
API_BASE = "/api/v21"

ENDPOINTS = {
    "blocker": f"{API_BASE}/blocker",
    "threats": f"{API_BASE}/threats",
    "surveillance": f"{API_BASE}/surveillance",
    "hosts": f"{API_BASE}/hosts",
    "domains": f"{API_BASE}/domains",
    "crypto": f"{API_BASE}/crypto",
    "quantum": f"{API_BASE}/quantum",
    "neural": f"{API_BASE}/neural",
    "patterns": f"{API_BASE}/patterns",
    "geo": f"{API_BASE}/geo",
    "temporal": f"{API_BASE}/temporal",
    "grandgott": f"{API_BASE}/grandgott",
    "entropy": f"{API_BASE}/entropy",
    "resonance": f"{API_BASE}/resonance",
    "flux": f"{API_BASE}/flux",
    "symphony": f"{API_BASE}/symphony",
    "observer": f"{API_BASE}/observer",
    "dimensions": f"{API_BASE}/dimensions",
    "soul": f"{API_BASE}/soul",
    "chronos": f"{API_BASE}/chronos",
    "akashic": f"{API_BASE}/akashic",
    "morphic": f"{API_BASE}/morphic",
}
