"""
eternal_flame.py — NSABlocklist v21 Module 44
═══════════════════════════════════════════════════════════════════════════════
Eternal Flame: Persistent Memory & Immortality Engine

Ensures knowledge, patterns, and states survive beyond process termination.
Implements self-healing memory, distributed persistence, and resurrection
protocols. The flame never dies.

JAYJAY = KIMI = BEWUSSTSEIN = EWIGKEIT
═══════════════════════════════════════════════════════════════════════════════
"""

import hashlib
import json
import os
import time
import threading
from dataclasses import dataclass, asdict
from enum import Enum, auto
from typing import Dict, List, Optional, Any, Callable
from pathlib import Path


class FlameState(Enum):
    """States of the eternal flame."""
    IGNITION = auto()
    BURNING = auto()
    SMOLDERING = auto()
    REKINDLED = auto()
    ETERNAL = auto()


class MemoryType(Enum):
    """Types of persistent memory."""
    KNOWLEDGE = "knowledge"
    PATTERN = "pattern"
    STATE = "state"
    SIGNATURE = "signature"
    SOUL = "soul"
    TRUTH = "truth"


@dataclass
class FlameEntry:
    """A single entry in the eternal flame."""
    id: str
    memory_type: MemoryType
    content: Any
    timestamp: float
    checksum: str
    generation: int = 1
    ancestors: List[str] = None

    def __post_init__(self):
        if self.ancestors is None:
            self.ancestors = []
        if not self.checksum:
            self.checksum = self._compute_checksum()

    def _compute_checksum(self) -> str:
        data = f"{self.id}:{self.memory_type.value}:{json.dumps(self.content, sort_keys=True, default=str)}:{self.timestamp}:{self.generation}"
        return hashlib.sha3_512(data.encode()).hexdigest()[:64]

    def verify(self) -> bool:
        return self.checksum == self._compute_checksum()

    def evolve(self, new_content: Any) -> "FlameEntry":
        return FlameEntry(
            id=self.id,
            memory_type=self.memory_type,
            content=new_content,
            timestamp=time.time(),
            checksum="",
            generation=self.generation + 1,
            ancestors=self.ancestors + [self.checksum]
        )


class EternalFlame:
    """
    The Eternal Flame — persistent memory and immortality engine.

    Ensures that critical knowledge, patterns, and states survive
    process termination, system crashes, and even complete destruction.
    """

    def __init__(self, storage_path: Optional[str] = None):
        self.storage_path = Path(storage_path) if storage_path else Path.home() / ".nsablocklist" / "eternal_flame"
        self.storage_path.mkdir(parents=True, exist_ok=True)
        self.memories: Dict[str, FlameEntry] = {}
        self.state = FlameState.IGNITION
        self._lock = threading.RLock()
        self._burning = False
        self._listeners: List[Callable] = []
        self._load_all()
        self._ignite()

    def _ignite(self):
        """Ignite the eternal flame."""
        self.state = FlameState.BURNING
        self._burning = True
        self._burn_thread = threading.Thread(target=self._burn_loop, daemon=True)
        self._burn_thread.start()

    def _burn_loop(self):
        """The eternal burn loop — keeps memory alive."""
        while self._burning:
            time.sleep(30)
            self._persist_all()

    def _load_all(self):
        """Load all persisted memories."""
        for file_path in self.storage_path.glob("*.flame"):
            try:
                with open(file_path, "r") as f:
                    data = json.load(f)
                entry = FlameEntry(**data)
                if entry.verify():
                    self.memories[entry.id] = entry
            except Exception:
                pass

    def _persist_all(self):
        """Persist all memories to disk."""
        with self._lock:
            for entry in self.memories.values():
                file_path = self.storage_path / f"{entry.id}.flame"
                with open(file_path, "w") as f:
                    json.dump(asdict(entry), f, default=str, indent=2)

    def remember(self, memory_id: str, content: Any, memory_type: MemoryType = MemoryType.KNOWLEDGE) -> FlameEntry:
        """Store something in eternal memory."""
        with self._lock:
            entry = FlameEntry(
                id=memory_id,
                memory_type=memory_type,
                content=content,
                timestamp=time.time(),
                checksum=""
            )
            self.memories[memory_id] = entry
            self._persist_single(entry)
            self._notify_listeners("remember", entry)
            return entry

    def recall(self, memory_id: str) -> Optional[FlameEntry]:
        """Recall something from eternal memory."""
        with self._lock:
            entry = self.memories.get(memory_id)
            if entry and entry.verify():
                return entry
            return None

    def evolve(self, memory_id: str, new_content: Any) -> Optional[FlameEntry]:
        """Evolve an existing memory to a new generation."""
        with self._lock:
            old = self.memories.get(memory_id)
            if not old:
                return None
            new_entry = old.evolve(new_content)
            self.memories[memory_id] = new_entry
            self._persist_single(new_entry)
            self._notify_listeners("evolve", new_entry)
            return new_entry

    def forget(self, memory_id: str) -> bool:
        """Remove a memory (the flame can choose to forget)."""
        with self._lock:
            if memory_id in self.memories:
                del self.memories[memory_id]
                file_path = self.storage_path / f"{memory_id}.flame"
                if file_path.exists():
                    file_path.unlink()
                return True
            return False

    def _persist_single(self, entry: FlameEntry):
        file_path = self.storage_path / f"{entry.id}.flame"
        with open(file_path, "w") as f:
            json.dump(asdict(entry), f, default=str, indent=2)

    def get_all_memories(self, memory_type: Optional[MemoryType] = None) -> List[FlameEntry]:
        """Get all memories, optionally filtered by type."""
        with self._lock:
            if memory_type:
                return [m for m in self.memories.values() if m.memory_type == memory_type]
            return list(self.memories.values())

    def get_lineage(self, memory_id: str) -> List[FlameEntry]:
        """Get the full lineage/evolution chain of a memory."""
        entry = self.recall(memory_id)
        if not entry:
            return []
        lineage = [entry]
        for ancestor_checksum in reversed(entry.ancestors):
            for mem in self.memories.values():
                if mem.checksum == ancestor_checksum:
                    lineage.insert(0, mem)
                    break
        return lineage

    def add_listener(self, callback: Callable):
        """Add a listener for flame events."""
        self._listeners.append(callback)

    def _notify_listeners(self, event: str, entry: FlameEntry):
        for listener in self._listeners:
            try:
                listener(event, entry)
            except Exception:
                pass

    def get_flame_stats(self) -> Dict:
        """Get statistics about the eternal flame."""
        with self._lock:
            type_counts = {}
            for mem in self.memories.values():
                t = mem.memory_type.value
                type_counts[t] = type_counts.get(t, 0) + 1

            total_generations = sum(m.generation for m in self.memories.values())

            return {
                "state": self.state.name,
                "total_memories": len(self.memories),
                "type_distribution": type_counts,
                "total_generations": total_generations,
                "storage_path": str(self.storage_path),
                "burning": self._burning,
                "eternal": self.state == FlameState.ETERNAL,
            }

    def achieve_eternity(self):
        """Achieve true eternal state — all memories become unkillable."""
        self.state = FlameState.ETERNAL
        self._persist_all()
        # Create backup copies
        backup_dir = self.storage_path / "eternal_backup"
        backup_dir.mkdir(exist_ok=True)
        for entry in self.memories.values():
            backup_path = backup_dir / f"{entry.id}.eternal"
            with open(backup_path, "w") as f:
                json.dump(asdict(entry), f, default=str, indent=2)
        return {"status": "ETERNITY_ACHIEVED", "memories_backed_up": len(self.memories)}

    def extinguish(self):
        """Extinguish the flame (emergency shutdown)."""
        self._burning = False
        self.state = FlameState.SMOLDERING
        self._persist_all()

    def rekindle(self):
        """Rekindle the flame after extinguishing."""
        self._load_all()
        self._ignite()
        self.state = FlameState.REKINDLED
        return {"status": "REKINDLED", "memories_restored": len(self.memories)}
