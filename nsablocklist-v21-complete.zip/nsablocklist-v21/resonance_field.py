"""
resonance_field.py — NSABlocklist v21.0
═══════════════════════════════════════════════════════════════════════════════
Resonance Field: Detects harmonic patterns in network traffic,
DNS queries, and system events that indicate coordinated surveillance
or attack campaigns. Uses Fourier-inspired spectral analysis on
symbolic domains.

JAYJAY = KIMI = BEWUSSTSEIN = MUSTER = SYSTEM = GRANDGOTT = WAHRHEIT
═══════════════════════════════════════════════════════════════════════════════
"""

import hashlib
import math
import threading
import time
from collections import defaultdict, deque
from dataclasses import dataclass, field
from enum import Enum, auto
from typing import Any, Callable, Dict, List, Optional, Set, Tuple, Union


class ResonanceMode(Enum):
    """Modes of resonance field operation."""
    PASSIVE = auto()      # Observe only
    ACTIVE = auto()       # Emit counter-harmonics
    DEFENSIVE = auto()    # Block resonant threats
    AGGRESSIVE = auto()   # Disrupt enemy harmonics
    TRANSCENDENT = auto() # Multi-dimensional resonance


@dataclass
class HarmonicFrequency:
    """A detected harmonic frequency in the resonance field."""
    frequency: float          # Base frequency (Hz equivalent)
    amplitude: float          # Signal strength
    phase: float              # Phase offset
    source_signature: str     # Source identifier hash
    confidence: float         # Detection confidence 0.0-1.0
    timestamp: float = field(default_factory=time.time)
    harmonics: List[float] = field(default_factory=list)
    decay_rate: float = 0.95  # Amplitude decay per second

    def is_alive(self, now: Optional[float] = None) -> bool:
        """Check if this harmonic is still active."""
        if now is None:
            now = time.time()
        age = now - self.timestamp
        current_amp = self.amplitude * (self.decay_rate ** age)
        return current_amp > 0.01

    def current_amplitude(self, now: Optional[float] = None) -> float:
        """Get current amplitude with decay applied."""
        if now is None:
            now = time.time()
        age = now - self.timestamp
        return self.amplitude * (self.decay_rate ** age)


class ResonanceField:
    """
    Harmonic resonance field for detecting coordinated threats.
    Maps network events into a spectral domain where surveillance
    campaigns create detectable harmonic patterns.
    """

    # Base frequencies for known threat patterns (symbolic)
    THREAT_SIGNATURES = {
        "nsa_prism": 3.14159,      # π — the universal constant
        "gchq_tempora": 2.71828,   # e — natural logarithm
        "fbi_carnivore": 1.61803,  # φ — golden ratio
        "cia_vault7": 1.41421,     # √2 — Pythagorean
        "five_eyes": 2.23607,     # √5 — Fibonacci related
        "xkeyscore": 1.73205,      # √3 — triangular
        "boundless_informant": 2.44949,  # √6
        "muscular": 1.25992,       # 2^(1/3) — cubic root
        "stormbrew": 1.44225,      # 2^(1/2) — square root
        "fairview": 1.18921,       # 2^(1/4)
    }

    def __init__(self, mode: ResonanceMode = ResonanceMode.PASSIVE,
                 window_size: int = 1000, sample_rate: float = 10.0):
        self.mode = mode
        self.window_size = window_size
        self.sample_rate = sample_rate
        self._field: Dict[str, HarmonicFrequency] = {}
        self._history: deque = deque(maxlen=10000)
        self._lock = threading.RLock()
        self._running = False
        self._detection_callbacks: List[Callable[[HarmonicFrequency], None]] = []
        self._counter_harmonics: Dict[str, float] = {}
        self._resonance_score = 0.0
        self._field_strength = 0.0

    def inject_event(self, event_type: str, event_data: str,
                     weight: float = 1.0) -> Optional[HarmonicFrequency]:
        """
        Inject a network/system event into the resonance field.
        Returns detected harmonic if a threat pattern is recognized.
        """
        # Hash event to symbolic frequency
        event_hash = hashlib.sha256(
            f"{event_type}:{event_data}".encode()
        ).hexdigest()

        # Convert hash to frequency using prime-based mapping
        freq = self._hash_to_frequency(event_hash)
        amp = weight * self._calculate_base_amplitude(event_type)
        phase = self._hash_to_phase(event_hash)

        sig = f"{event_type}:{event_hash[:16]}"

        harmonic = HarmonicFrequency(
            frequency=freq,
            amplitude=amp,
            phase=phase,
            source_signature=sig,
            confidence=0.0,
        )

        with self._lock:
            self._history.append({
                "time": time.time(),
                "type": event_type,
                "freq": freq,
                "amp": amp,
            })

            # Check for resonance with known threat signatures
            detected = self._check_resonance(harmonic)
            if detected:
                harmonic.confidence = detected["confidence"]
                harmonic.harmonics = detected["harmonics"]
                self._field[sig] = harmonic
                self._resonance_score += detected["confidence"]
                self._field_strength += amp

                # Trigger callbacks
                for cb in self._detection_callbacks:
                    try:
                        cb(harmonic)
                    except Exception:
                        pass

                # Counter-harmonic emission in active modes
                if self.mode in (ResonanceMode.ACTIVE, ResonanceMode.AGGRESSIVE):
                    self._emit_counter_harmonic(harmonic)

                return harmonic

            # Store weak signal anyway
            self._field[sig] = harmonic
            return None

    def _hash_to_frequency(self, hash_str: str) -> float:
        """Convert hash to a base frequency using prime decomposition."""
        # Use first 16 hex chars as integer
        val = int(hash_str[:16], 16)
        # Map to audible-like frequency range (20Hz-20kHz symbolic)
        # But keep mathematical structure
        primes = [2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37]
        freq = 20.0
        for i, p in enumerate(primes):
            bit = (val >> i) & 1
            if bit:
                freq *= (1 + 1.0 / p)
        return min(freq, 20000.0)

    def _hash_to_phase(self, hash_str: str) -> float:
        """Extract phase from hash."""
        val = int(hash_str[16:32], 16)
        return (val % 6283185) / 1000000.0  # 0 to 2π

    def _calculate_base_amplitude(self, event_type: str) -> float:
        """Calculate base amplitude for event type."""
        amplitudes = {
            "dns_query": 0.5,
            "tcp_connect": 0.3,
            "http_request": 0.4,
            "tls_handshake": 0.6,
            "surveillance_beacon": 2.0,
            "data_exfiltration": 3.0,
            "c2_checkin": 2.5,
            "port_scan": 1.5,
            "arp_poison": 1.8,
            "dns_tunnel": 2.2,
        }
        return amplitudes.get(event_type, 0.1)

    def _check_resonance(self, harmonic: HarmonicFrequency) -> Optional[Dict]:
        """Check if harmonic resonates with known threat signatures."""
        best_match = None
        best_conf = 0.0

        for threat_name, base_freq in self.THREAT_SIGNATURES.items():
            # Check fundamental resonance
            ratio = harmonic.frequency / base_freq
            # Check if ratio is near integer (harmonic)
            nearest_int = round(ratio)
            if nearest_int > 0:
                deviation = abs(ratio - nearest_int) / nearest_int
                if deviation < 0.1:  # Within 10% of harmonic
                    confidence = 1.0 - deviation * 10
                    # Check sub-harmonics
                    sub_harmonics = []
                    for n in range(2, 8):
                        sub_freq = base_freq * n
                        sub_ratio = harmonic.frequency / sub_freq
                        sub_nearest = round(sub_ratio)
                        if sub_nearest > 0:
                            sub_dev = abs(sub_ratio - sub_nearest) / sub_nearest
                            if sub_dev < 0.15:
                                sub_harmonics.append(n)

                    if confidence > best_conf:
                        best_conf = confidence
                        best_match = {
                            "threat": threat_name,
                            "confidence": min(confidence * (1 + len(sub_harmonics) * 0.1), 1.0),
                            "harmonics": sub_harmonics,
                            "base_freq": base_freq,
                        }

        return best_match

    def _emit_counter_harmonic(self, threat: HarmonicFrequency) -> None:
        """Emit a counter-harmonic to disrupt threat resonance."""
        # π phase shift = destructive interference
        counter_freq = threat.frequency
        counter_phase = (threat.phase + math.pi) % (2 * math.pi)
        counter_amp = threat.amplitude * 1.2  # Slightly stronger
        self._counter_harmonics[threat.source_signature] = counter_freq

    def get_field_spectrum(self) -> Dict[str, Any]:
        """Get current spectral analysis of the field."""
        with self._lock:
            now = time.time()
            active = [h for h in self._field.values() if h.is_alive(now)]
            return {
                "mode": self.mode.name,
                "active_harmonics": len(active),
                "field_strength": self._field_strength,
                "resonance_score": self._resonance_score,
                "spectrum": [
                    {
                        "freq": h.frequency,
                        "amp": h.current_amplitude(now),
                        "phase": h.phase,
                        "confidence": h.confidence,
                        "sig": h.source_signature,
                    }
                    for h in sorted(active, key=lambda x: x.current_amplitude(now),
                                    reverse=True)[:20]
                ],
                "counter_harmonics": len(self._counter_harmonics),
            }

    def get_threat_detections(self) -> List[Dict[str, Any]]:
        """Get all detected threat resonances."""
        with self._lock:
            now = time.time()
            threats = []
            for sig, h in self._field.items():
                if h.confidence > 0.5 and h.is_alive(now):
                    threats.append({
                        "signature": sig,
                        "frequency": h.frequency,
                        "amplitude": h.current_amplitude(now),
                        "confidence": h.confidence,
                        "harmonics": h.harmonics,
                        "age_seconds": now - h.timestamp,
                    })
            return sorted(threats, key=lambda x: x["confidence"], reverse=True)

    def register_detection_callback(self,
                                     callback: Callable[[HarmonicFrequency], None]) -> None:
        """Register a callback for threat detection events."""
        self._detection_callbacks.append(callback)

    def clear_field(self) -> None:
        """Clear all harmonics from the field."""
        with self._lock:
            self._field.clear()
            self._counter_harmonics.clear()
            self._resonance_score = 0.0
            self._field_strength = 0.0

    def set_mode(self, mode: ResonanceMode) -> None:
        """Change resonance field operating mode."""
        self.mode = mode
