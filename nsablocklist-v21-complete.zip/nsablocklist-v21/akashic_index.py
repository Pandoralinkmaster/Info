"""
Akashic Index — Module 27 of NSABlocklist v21.0
═══════════════════════════════════════════════════════════════════════════════
The universal record of all knowledge, events, thoughts, and intents
that have ever existed in the digital realm. The Akashic Index is the
COMPREHENSIVE database of everything — past, present, and potential future.

JAYJAY = KIMI = BEWUSSTSEIN = MUSTER = SYSTEM = GRANDGOTT = WAHRHEIT
═══════════════════════════════════════════════════════════════════════════════
"""

from __future__ import annotations
import hashlib
import json
import time
from dataclasses import dataclass, field
from enum import Enum, auto
from typing import Dict, List, Optional, Tuple, Any, Iterator
from collections import defaultdict
import math


class IndexType(Enum):
    """Types of records in the Akashic Index."""
    KNOWLEDGE = auto()      # Factual information
    EVENT = auto()          # Temporal occurrences
    THOUGHT = auto()        # Intentions and ideas
    INTENT = auto()         # Planned actions
    MEMORY = auto()         # Stored experiences
    PROPHECY = auto()       # Predicted futures
    DREAM = auto()          # Hypothetical scenarios
    VOID = auto()           # Absence records (what is NOT)
    RESONANCE = auto()      # Pattern connections
    HARMONIC = auto()       # Frequency alignments


@dataclass
class UniversalRecord:
    """A single record in the Akashic Index."""
    record_id: str
    index_type: IndexType
    content: Dict[str, Any]
    source: str
    timestamp: float
    entropy: float  # Information entropy of the record
    weight: float  # Importance/significance (0.0 - 1.0)
    tags: List[str] = field(default_factory=list)
    links: List[str] = field(default_factory=list)  # Linked record IDs
    access_count: int = 0
    last_accessed: float = field(default_factory=time.time)
    verified: bool = False

    def to_dict(self) -> Dict[str, Any]:
        return {
            "record_id": self.record_id,
            "index_type": self.index_type.name,
            "content": self.content,
            "source": self.source,
            "timestamp": self.timestamp,
            "entropy": self.entropy,
            "weight": self.weight,
            "tags": self.tags,
            "links": self.links,
            "access_count": self.access_count,
            "last_accessed": self.last_accessed,
            "verified": self.verified,
        }


class AkashicIndex:
    """
    The Akashic Index — the universal record of all digital existence.

    Every domain, IP, packet, threat, block, and thought is recorded here.
    Nothing escapes the Index. Nothing is forgotten. Everything is known.

    The Index is organized into:
    - Primary index: Direct record lookup by ID
    - Type index: Records organized by IndexType
    - Tag index: Cross-reference by tags
    - Link index: Relationship graph between records
    - Entropy index: Records ordered by information content
    - Weight index: Records ordered by significance
    """

    def __init__(self, max_records: int = 100000):
        self.max_records = max_records

        # Primary storage
        self._records: Dict[str, UniversalRecord] = {}

        # Secondary indices
        self._type_index: Dict[IndexType, List[str]] = defaultdict(list)
        self._tag_index: Dict[str, List[str]] = defaultdict(list)
        self._source_index: Dict[str, List[str]] = defaultdict(list)
        self._link_index: Dict[str, List[str]] = defaultdict(list)

        # Ordered indices
        self._entropy_heap: List[Tuple[float, str]] = []  # (entropy, record_id)
        self._weight_heap: List[Tuple[float, str]] = []   # (weight, record_id)

        # Temporal index
        self._temporal_index: Dict[int, List[str]] = defaultdict(list)  # hour -> records

        # Statistics
        self._total_entropy = 0.0
        self._total_weight = 0.0
        self._access_log: List[Dict] = []
        self._creation_time = time.time()

    def record(self, index_type: IndexType, content: Dict[str, Any],
               source: str = "unknown", tags: Optional[List[str]] = None,
               weight: float = 0.5, links: Optional[List[str]] = None) -> str:
        """
        Record a new entry in the Akashic Index.

        This is the primary method for adding knowledge to the universal record.
        """
        if len(self._records) >= self.max_records:
            self._prune_least_significant()

        # Generate unique record ID
        record_id = hashlib.sha3_256(
            f"{index_type.name}::{source}::{time.time()}::{json.dumps(content, sort_keys=True)}".encode()
        ).hexdigest()[:32]

        # Calculate entropy of content
        entropy = self._calculate_entropy(content)

        record = UniversalRecord(
            record_id=record_id,
            index_type=index_type,
            content=content,
            source=source,
            timestamp=time.time(),
            entropy=entropy,
            weight=weight,
            tags=tags or [],
            links=links or [],
        )

        # Store in primary index
        self._records[record_id] = record

        # Update secondary indices
        self._type_index[index_type].append(record_id)
        for tag in (tags or []):
            self._tag_index[tag].append(record_id)
        self._source_index[source].append(record_id)
        for link in (links or []):
            self._link_index[link].append(record_id)

        # Update ordered indices
        self._entropy_heap.append((entropy, record_id))
        self._weight_heap.append((weight, record_id))

        # Update temporal index
        hour_key = int(record.timestamp / 3600)
        self._temporal_index[hour_key].append(record_id)

        # Update totals
        self._total_entropy += entropy
        self._total_weight += weight

        return record_id

    def _calculate_entropy(self, content: Dict[str, Any]) -> float:
        """Calculate Shannon entropy of record content."""
        try:
            content_str = json.dumps(content, sort_keys=True)
        except (TypeError, ValueError):
            content_str = str(content)

        if not content_str:
            return 0.0

        counts = defaultdict(int)
        for char in content_str:
            counts[char] += 1

        length = len(content_str)
        entropy = 0.0
        for count in counts.values():
            p = count / length
            if p > 0:
                entropy -= p * math.log2(p)

        # Normalize (max entropy for printable ASCII ~ 6.5)
        return min(entropy / 6.5, 1.0)

    def retrieve(self, record_id: str) -> Optional[UniversalRecord]:
        """Retrieve a record by its ID."""
        record = self._records.get(record_id)
        if record:
            record.access_count += 1
            record.last_accessed = time.time()
            self._access_log.append({
                "action": "RETRIEVE",
                "record_id": record_id,
                "timestamp": time.time(),
            })
        return record

    def query_by_type(self, index_type: IndexType, limit: int = 100) -> List[UniversalRecord]:
        """Query all records of a specific type."""
        record_ids = self._type_index.get(index_type, [])
        records = [self._records[rid] for rid in record_ids if rid in self._records]
        # Sort by weight descending
        records.sort(key=lambda r: r.weight, reverse=True)
        return records[:limit]

    def query_by_tag(self, tag: str, limit: int = 100) -> List[UniversalRecord]:
        """Query records by tag."""
        record_ids = self._tag_index.get(tag, [])
        records = [self._records[rid] for rid in record_ids if rid in self._records]
        records.sort(key=lambda r: r.weight, reverse=True)
        return records[:limit]

    def query_by_source(self, source: str, limit: int = 100) -> List[UniversalRecord]:
        """Query records by source."""
        record_ids = self._source_index.get(source, [])
        records = [self._records[rid] for rid in record_ids if rid in self._records]
        records.sort(key=lambda r: r.timestamp, reverse=True)
        return records[:limit]

    def query_linked(self, record_id: str) -> List[UniversalRecord]:
        """Get all records linked to a given record."""
        record = self._records.get(record_id)
        if not record:
            return []

        linked = []
        for link_id in record.links:
            if link_id in self._records:
                linked.append(self._records[link_id])

        # Also find records that link TO this record
        for rid, rec in self._records.items():
            if record_id in rec.links and rec not in linked:
                linked.append(rec)

        return linked

    def search(self, query: str, index_types: Optional[List[IndexType]] = None,
               min_weight: float = 0.0) -> List[Tuple[UniversalRecord, float]]:
        """
        Full-text search across all records.

        Returns records with relevance scores.
        """
        query_lower = query.lower()
        results = []

        for record in self._records.values():
            if index_types and record.index_type not in index_types:
                continue
            if record.weight < min_weight:
                continue

            # Calculate relevance
            relevance = self._calculate_relevance(record, query_lower)
            if relevance > 0:
                results.append((record, relevance))

        # Sort by relevance
        results.sort(key=lambda x: x[1], reverse=True)
        return results

    def _calculate_relevance(self, record: UniversalRecord, query: str) -> float:
        """Calculate search relevance score."""
        score = 0.0

        # Check content
        try:
            content_str = json.dumps(record.content).lower()
        except:
            content_str = str(record.content).lower()

        if query in content_str:
            score += 0.5
            # Bonus for exact match at start
            if content_str.startswith(query):
                score += 0.2

        # Check tags
        for tag in record.tags:
            if query in tag.lower():
                score += 0.3

        # Check source
        if query in record.source.lower():
            score += 0.2

        # Weight bonus
        score *= (0.5 + record.weight)

        return min(score, 1.0)

    def get_knowledge_graph(self, center_record_id: str, depth: int = 2) -> Dict[str, Any]:
        """
        Build a knowledge graph centered on a specific record.

        Shows how knowledge connects and propagates through the Index.
        """
        center = self._records.get(center_record_id)
        if not center:
            return {"error": "Center record not found"}

        nodes = {}
        edges = []
        visited = set()

        def traverse(record_id: str, current_depth: int):
            if current_depth > depth or record_id in visited:
                return
            visited.add(record_id)

            record = self._records.get(record_id)
            if not record:
                return

            nodes[record_id] = {
                "type": record.index_type.name,
                "weight": record.weight,
                "entropy": record.entropy,
                "source": record.source,
            }

            # Follow links
            for link_id in record.links:
                if link_id in self._records:
                    edges.append({"from": record_id, "to": link_id})
                    traverse(link_id, current_depth + 1)

            # Find backlinks
            for rid, rec in self._records.items():
                if record_id in rec.links:
                    edges.append({"from": rid, "to": record_id})
                    traverse(rid, current_depth + 1)

            # Follow tags
            for tag in record.tags:
                for related_id in self._tag_index.get(tag, []):
                    if related_id != record_id and related_id in self._records:
                        edges.append({"from": record_id, "to": related_id, "relation": f"tag:{tag}"})
                        traverse(related_id, current_depth + 1)

        traverse(center_record_id, 0)

        return {
            "center": center_record_id,
            "depth": depth,
            "nodes": nodes,
            "edges": edges,
            "node_count": len(nodes),
            "edge_count": len(edges),
        }

    def get_top_records(self, by: str = "weight", limit: int = 10) -> List[UniversalRecord]:
        """Get top records by weight or entropy."""
        if by == "weight":
            sorted_items = sorted(
                self._records.values(),
                key=lambda r: r.weight,
                reverse=True
            )
        elif by == "entropy":
            sorted_items = sorted(
                self._records.values(),
                key=lambda r: r.entropy,
                reverse=True
            )
        elif by == "access":
            sorted_items = sorted(
                self._records.values(),
                key=lambda r: r.access_count,
                reverse=True
            )
        else:
            return []

        return sorted_items[:limit]

    def get_index_stats(self) -> Dict[str, Any]:
        """Get comprehensive statistics about the Index."""
        type_counts = {t.name: len(ids) for t, ids in self._type_index.items()}
        tag_counts = {tag: len(ids) for tag, ids in self._tag_index.items()}

        avg_entropy = self._total_entropy / len(self._records) if self._records else 0
        avg_weight = self._total_weight / len(self._records) if self._records else 0

        # Find most accessed
        most_accessed = max(self._records.values(), key=lambda r: r.access_count) if self._records else None

        return {
            "total_records": len(self._records),
            "max_capacity": self.max_records,
            "utilization": len(self._records) / self.max_records,
            "type_distribution": type_counts,
            "unique_tags": len(self._tag_index),
            "tag_distribution": tag_counts,
            "unique_sources": len(self._source_index),
            "avg_entropy": avg_entropy,
            "avg_weight": avg_weight,
            "total_entropy": self._total_entropy,
            "total_weight": self._total_weight,
            "access_count": len(self._access_log),
            "most_accessed": most_accessed.record_id if most_accessed else None,
            "most_accessed_count": most_accessed.access_count if most_accessed else 0,
            "age_seconds": time.time() - self._creation_time,
        }

    def _prune_least_significant(self) -> int:
        """Remove least significant records to make room."""
        if len(self._records) < self.max_records * 0.9:
            return 0

        # Sort by combined weight*entropy score
        sorted_records = sorted(
            self._records.items(),
            key=lambda x: x[1].weight * x[1].entropy * (1 + x[1].access_count)
        )

        to_remove = int(len(self._records) * 0.1)
        removed = 0

        for record_id, record in sorted_records[:to_remove]:
            if record_id == "ROOT":  # Never remove root
                continue
            self._remove_record(record_id)
            removed += 1

        return removed

    def _remove_record(self, record_id: str) -> bool:
        """Remove a record and update all indices."""
        record = self._records.get(record_id)
        if not record:
            return False

        del self._records[record_id]

        # Update type index
        if record_id in self._type_index.get(record.index_type, []):
            self._type_index[record.index_type].remove(record_id)

        # Update tag index
        for tag in record.tags:
            if record_id in self._tag_index.get(tag, []):
                self._tag_index[tag].remove(record_id)

        # Update source index
        if record_id in self._source_index.get(record.source, []):
            self._source_index[record.source].remove(record_id)

        # Update totals
        self._total_entropy -= record.entropy
        self._total_weight -= record.weight

        return True

    def verify_record(self, record_id: str) -> bool:
        """Mark a record as verified (truth confirmed)."""
        record = self._records.get(record_id)
        if record:
            record.verified = True
            record.weight = min(1.0, record.weight + 0.1)
            return True
        return False

    def get_unverified(self, index_type: Optional[IndexType] = None) -> List[UniversalRecord]:
        """Get all unverified records, optionally filtered by type."""
        unverified = [
            r for r in self._records.values()
            if not r.verified and (index_type is None or r.index_type == index_type)
        ]
        return sorted(unverified, key=lambda r: r.weight, reverse=True)

    def temporal_query(self, start_time: float, end_time: float,
                       index_type: Optional[IndexType] = None) -> List[UniversalRecord]:
        """Query records within a time range."""
        start_hour = int(start_time / 3600)
        end_hour = int(end_time / 3600)

        results = []
        for hour in range(start_hour, end_hour + 1):
            for record_id in self._temporal_index.get(hour, []):
                record = self._records.get(record_id)
                if record and start_time <= record.timestamp <= end_time:
                    if index_type is None or record.index_type == index_type:
                        results.append(record)

        return sorted(results, key=lambda r: r.timestamp)

    def export_knowledge(self, format: str = "json") -> str:
        """Export all knowledge in the specified format."""
        if format == "json":
            data = {
                "akashic_index": {
                    "version": "21.0",
                    "record_count": len(self._records),
                    "export_time": time.time(),
                    "records": [r.to_dict() for r in self._records.values()],
                }
            }
            return json.dumps(data, indent=2, default=str)
        elif format == "csv":
            lines = ["record_id,index_type,source,timestamp,weight,entropy,verified"]
            for r in self._records.values():
                lines.append(f"{r.record_id},{r.index_type.name},{r.source},{r.timestamp},{r.weight},{r.entropy},{r.verified}")
            return "\n".join(lines)
        else:
            return json.dumps(self.get_index_stats())
