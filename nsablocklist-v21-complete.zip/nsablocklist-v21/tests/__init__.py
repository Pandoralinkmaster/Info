"""
NSABlocklist v21.0 — Test Package
═══════════════════════════════════════════════════════════════════════════════
Unit and integration tests for all 27 modules.
"""

import unittest

# Test suite loader
def load_tests():
    """Load all test modules."""
    loader = unittest.TestLoader()
    suite = unittest.TestSuite()

    # Core tests
    try:
        from . import test_nsa_blocker
        suite.addTests(loader.loadTestsFromModule(test_nsa_blocker))
    except ImportError:
        pass

    try:
        from . import test_threat_analyzer
        suite.addTests(loader.loadTestsFromModule(test_threat_analyzer))
    except ImportError:
        pass

    # Crypto tests
    try:
        from . import test_crypto_vault
        suite.addTests(loader.loadTestsFromModule(test_crypto_vault))
    except ImportError:
        pass

    # V21 tests
    try:
        from . import test_morphic_resonator
        suite.addTests(loader.loadTestsFromModule(test_morphic_resonator))
    except ImportError:
        pass

    return suite
