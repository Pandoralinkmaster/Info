"""
NSABlocklist v21.0 — Exports Package
═══════════════════════════════════════════════════════════════════════════════
Export formats and data serialization.
"""

EXPORT_FORMATS = {
    "hosts": ".txt",
    "json": ".json",
    "xml": ".xml",
    "csv": ".csv",
    "yaml": ".yaml",
    "sqlite": ".db",
    "protobuf": ".pb",
    "binary": ".bin",
}
