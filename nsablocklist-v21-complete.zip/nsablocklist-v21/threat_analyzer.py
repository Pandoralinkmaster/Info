"""
ThreatAnalyzer — Advanced threat detection with neural scoring and pattern recognition.
"""

import hashlib
import json
import math
import random
import time
from dataclasses import dataclass, field
from enum import Enum, auto
from typing import Dict, List, Optional, Set, Tuple, Any, Callable


class ThreatLevel(Enum):
    """Threat severity levels."""
    NONE = 0
    LOW = 1
    MEDIUM = 2
    HIGH = 3
    CRITICAL = 4
    EXTREME = 5
    QUANTUM = 6
    OMEGA = 7


@dataclass
class ThreatPattern:
    """Represents a detected threat pattern."""
    name: str
    signature: str
    level: ThreatLevel
    indicators: List[str] = field(default_factory=list)
    weight: float = 1.0
    frequency: int = 0
    first_seen: float = field(default_factory=time.time)
    last_seen: float = field(default_factory=time.time)
    evolution_count: int = 0
    neural_fingerprint: Optional[str] = None

    def evolve(self, new_indicators: List[str]):
        """Evolve the pattern with new indicators."""
        self.indicators.extend(new_indicators)
        self.indicators = list(set(self.indicators))
        self.frequency += 1
        self.last_seen = time.time()
        self.evolution_count += 1
        self.neural_fingerprint = self._compute_fingerprint()

    def _compute_fingerprint(self) -> str:
        data = f"{self.name}:{self.signature}:{self.frequency}:{self.evolution_count}"
        return hashlib.sha3_256(data.encode()).hexdigest()[:32]


@dataclass
class ThreatScore:
    """Composite threat score with multiple dimensions."""
    base_score: float = 0.0
    neural_score: float = 0.0
    quantum_score: float = 0.0
    temporal_score: float = 0.0
    behavioral_score: float = 0.0
    entropy_score: float = 0.0
    reputation_score: float = 0.0

    @property
    def composite(self) -> float:
        """Compute weighted composite score."""
        weights = {
            "base": 0.15, "neural": 0.20, "quantum": 0.15,
            "temporal": 0.10, "behavioral": 0.15, "entropy": 0.10, "reputation": 0.15
        }
        total = (
            self.base_score * weights["base"] +
            self.neural_score * weights["neural"] +
            self.quantum_score * weights["quantum"] +
            self.temporal_score * weights["temporal"] +
            self.behavioral_score * weights["behavioral"] +
            self.entropy_score * weights["entropy"] +
            self.reputation_score * weights["reputation"]
        )
        return min(total, 1.0)

    @property
    def level(self) -> ThreatLevel:
        """Map composite score to threat level."""
        c = self.composite
        if c >= 0.95: return ThreatLevel.OMEGA
        if c >= 0.85: return ThreatLevel.QUANTUM
        if c >= 0.70: return ThreatLevel.EXTREME
        if c >= 0.55: return ThreatLevel.CRITICAL
        if c >= 0.40: return ThreatLevel.HIGH
        if c >= 0.25: return ThreatLevel.MEDIUM
        if c >= 0.10: return ThreatLevel.LOW
        return ThreatLevel.NONE

    def to_dict(self) -> Dict:
        return {
            "base_score": self.base_score,
            "neural_score": self.neural_score,
            "quantum_score": self.quantum_score,
            "temporal_score": self.temporal_score,
            "behavioral_score": self.behavioral_score,
            "entropy_score": self.entropy_score,
            "reputation_score": self.reputation_score,
            "composite": self.composite,
            "level": self.level.name,
        }


class ThreatAnalyzer:
    """
    Advanced threat analysis engine with multi-dimensional scoring.
    """

    # Known threat signatures
    SIGNATURES = {
        "nsa_prism": ["prism", "xkeyscore", "upstream", "fairview", "blarney"],
        "nsa_tempora": ["tempora", "mastering", "optical", "fiber", "gchq"],
        "nsa_echelon": ["echelon", "five_eyes", "signals", "intercept"],
        "cia_vault7": ["vault7", "umbrage", "marble", "grasshopper", "hive"],
        "fbi_carnivore": ["carnivore", "dcs1000", "magic_lantern", "keystroke"],
        "surveillance_dpi": ["dpi", "deep_packet", "inspection", "traffic_analysis"],
        "tracking_fingerprint": ["canvas", "webgl", "audio", "font", "fingerprint"],
        "botnet_c2": ["command_control", "c2", "botnet", "zombie", "ddos"],
        "crypto_mining": ["coinhive", "cryptojacking", "miner", "monero", "xmr"],
        "quantum_attack": ["quantum", "shor", "grover", "post_quantum", "qkd"],
    }

    def __init__(self):
        self.patterns: Dict[str, ThreatPattern] = {}
        self.scores: Dict[str, ThreatScore] = {}
        self.history: List[Dict] = []
        self.callbacks: List[Callable] = []
        self._neural_weights = self._init_neural_weights()
        self._quantum_seed = random.getrandbits(256)

    def _init_neural_weights(self) -> Dict[str, float]:
        """Initialize neural network weights."""
        return {
            "signature_match": 0.35,
            "behavioral_deviation": 0.25,
            "entropy_anomaly": 0.15,
            "reputation_decay": 0.10,
            "temporal_pattern": 0.15,
        }

    def analyze_domain(self, domain: str, context: Optional[Dict] = None) -> ThreatScore:
        """Analyze a domain for threats."""
        score = ThreatScore()
        domain_lower = domain.lower()

        # Signature matching
        matched_signatures = []
        for sig_name, keywords in self.SIGNATURES.items():
            for kw in keywords:
                if kw in domain_lower:
                    matched_signatures.append(sig_name)
                    break
        score.base_score = min(len(matched_signatures) * 0.2, 1.0)

        # Neural analysis
        score.neural_score = self._neural_analysis(domain, matched_signatures)

        # Quantum analysis
        score.quantum_score = self._quantum_analysis(domain)

        # Temporal analysis
        score.temporal_score = self._temporal_analysis(domain, context)

        # Behavioral analysis
        score.behavioral_score = self._behavioral_analysis(domain, context)

        # Entropy analysis
        score.entropy_score = self._entropy_analysis(domain)

        # Reputation analysis
        score.reputation_score = self._reputation_analysis(domain)

        self.scores[domain] = score
        self.history.append({
            "domain": domain,
            "timestamp": time.time(),
            "score": score.to_dict(),
            "context": context,
        })
        return score

    def _neural_analysis(self, domain: str, signatures: List[str]) -> float:
        """Neural network-style analysis of domain."""
        score = 0.0
        if signatures:
            score += len(signatures) * 0.15
        # Character pattern analysis
        if any(c.isdigit() for c in domain):
            score += 0.05
        if len(domain) > 30:
            score += 0.05
        if domain.count("-") > 3:
            score += 0.05
        # TLD analysis
        suspicious_tlds = [".tk", ".ml", ".ga", ".cf", ".top", ".xyz", ".club", ".work"]
        if any(domain.endswith(tld) for tld in suspicious_tlds):
            score += 0.1
        return min(score, 1.0)

    def _quantum_analysis(self, domain: str) -> float:
        """Quantum-inspired analysis using hash-based randomness."""
        h = hashlib.sha3_256(domain.encode()).digest()
        # Use quantum seed to influence analysis
        seed = int.from_bytes(h, "big") ^ self._quantum_seed
        random.seed(seed)
        score = random.random() * 0.3
        # Check for quantum-resistant indicators
        if "quantum" in domain.lower() or "qkd" in domain.lower():
            score += 0.4
        random.seed()  # Reset
        return min(score, 1.0)

    def _temporal_analysis(self, domain: str, context: Optional[Dict]) -> float:
        """Analyze temporal patterns."""
        score = 0.0
        if context and "first_seen" in context:
            age = time.time() - context["first_seen"]
            if age < 86400:  # Less than 1 day
                score += 0.2
            elif age < 604800:  # Less than 1 week
                score += 0.1
        if context and "activity_pattern" in context:
            pattern = context["activity_pattern"]
            if pattern in ["sudden_spike", "irregular", "automated"]:
                score += 0.15
        return min(score, 1.0)

    def _behavioral_analysis(self, domain: str, context: Optional[Dict]) -> float:
        """Analyze behavioral patterns."""
        score = 0.0
        if context:
            if context.get("redirects", 0) > 3:
                score += 0.1
            if context.get("cookies", 0) > 20:
                score += 0.05
            if context.get("third_party_requests", 0) > 10:
                score += 0.1
            if context.get("fingerprinting_attempts", 0) > 0:
                score += 0.2
        return min(score, 1.0)

    def _entropy_analysis(self, domain: str) -> float:
        """Calculate Shannon entropy of domain."""
        if not domain:
            return 0.0
        freq = {}
        for c in domain:
            freq[c] = freq.get(c, 0) + 1
        length = len(domain)
        entropy = 0.0
        for count in freq.values():
            p = count / length
            entropy -= p * math.log2(p)
        # Normalize: max entropy for domain chars is ~log2(37) ≈ 5.2
        normalized = min(entropy / 5.2, 1.0)
        # High entropy can indicate DGA (Domain Generation Algorithm)
        if normalized > 0.7:
            return normalized * 0.8
        return normalized * 0.2

    def _reputation_analysis(self, domain: str) -> float:
        """Analyze domain reputation."""
        score = 0.0
        # Check for known bad patterns
        bad_patterns = ["free", "click", "win", "prize", "gift", "bonus", "cash"]
        for bp in bad_patterns:
            if bp in domain.lower():
                score += 0.05
        # Check for typosquatting indicators
        popular_domains = ["google", "facebook", "amazon", "apple", "microsoft", "bank"]
        for pd in popular_domains:
            if pd in domain.lower() and not domain.endswith(f".{pd}.com"):
                score += 0.1
        return min(score, 1.0)

    def detect_pattern(self, name: str, indicators: List[str]) -> ThreatPattern:
        """Detect or evolve a threat pattern."""
        if name in self.patterns:
            pattern = self.patterns[name]
            pattern.evolve(indicators)
        else:
            signature = hashlib.sha3_256(
                ":".join(sorted(indicators)).encode()
            ).hexdigest()[:16]
            pattern = ThreatPattern(
                name=name,
                signature=signature,
                level=ThreatLevel.MEDIUM,
                indicators=indicators,
            )
            self.patterns[name] = pattern
        return pattern

    def get_threat_report(self, domain: str) -> Optional[Dict]:
        """Get detailed threat report for a domain."""
        if domain not in self.scores:
            return None
        score = self.scores[domain]
        return {
            "domain": domain,
            "score": score.to_dict(),
            "level": score.level.name,
            "recommendation": self._get_recommendation(score.level),
            "patterns": [p.name for p in self.patterns.values()
                        if any(i in domain for i in p.indicators)],
        }

    def _get_recommendation(self, level: ThreatLevel) -> str:
        """Get recommendation based on threat level."""
        recommendations = {
            ThreatLevel.NONE: "No action needed.",
            ThreatLevel.LOW: "Monitor domain activity.",
            ThreatLevel.MEDIUM: "Add to watchlist, enable logging.",
            ThreatLevel.HIGH: "Block domain, investigate connections.",
            ThreatLevel.CRITICAL: "Immediate block, alert security team.",
            ThreatLevel.EXTREME: "Emergency lockdown, preserve evidence.",
            ThreatLevel.QUANTUM: "Quantum containment protocol activated.",
            ThreatLevel.OMEGA: "OMEGA protocol — total system isolation.",
        }
        return recommendations.get(level, "Unknown — manual review required.")

    def register_callback(self, callback: Callable):
        """Register a callback for threat alerts."""
        self.callbacks.append(callback)

    def alert(self, domain: str, score: ThreatScore):
        """Trigger alert callbacks."""
        for cb in self.callbacks:
            try:
                cb(domain, score)
            except Exception:
                pass

    def get_global_stats(self) -> Dict:
        """Get global threat statistics."""
        if not self.scores:
            return {}
        composites = [s.composite for s in self.scores.values()]
        levels = [s.level for s in self.scores.values()]
        return {
            "total_analyzed": len(self.scores),
            "avg_score": sum(composites) / len(composites),
            "max_score": max(composites),
            "min_score": min(composites),
            "level_distribution": {
                level.name: levels.count(level) for level in set(levels)
            },
            "patterns_detected": len(self.patterns),
            "history_entries": len(self.history),
        }
