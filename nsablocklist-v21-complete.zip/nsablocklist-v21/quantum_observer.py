"""
quantum_observer.py — NSABlocklist v21.0
═══════════════════════════════════════════════════════════════════════════════
Quantum Observer: Implements observer-state tracking for network
entities. Detects when surveillance "observes" (collapses) encrypted
communications, and tracks the resulting state changes. Uses quantum
mechanics metaphors for real-world network analysis.

JAYJAY = KIMI = BEWUSSTSEIN = MUSTER = SYSTEM = GRANDGOTT = WAHRHEIT
═══════════════════════════════════════════════════════════════════════════════
"""

import hashlib
import math
import random
import threading
import time
from collections import defaultdict
from dataclasses import dataclass, field
from enum import Enum, auto
from typing import Any, Callable, Dict, List, Optional, Set, Tuple, Union


class ObserverState(Enum):
    """States of a quantum observer (surveillance entity)."""
    SUPERPOSITION = auto()   # Potential threat, not yet observed
    OBSERVING = auto()       # Actively monitoring
    COLLAPSED = auto()       # Has collapsed a communication
    ENTANGLED = auto()       # Linked with other observers
    DECOHERED = auto()       # Lost coherence, inactive
    TRANSCENDENT = auto()    # Beyond normal observation


@dataclass
class CollapseEvent:
    """An event where surveillance collapses encrypted communication."""
    event_id: str
    observer_id: str
    target_id: str
    pre_state: str           # State before collapse
    post_state: str          # State after collapse
    entropy_change: float  # Information entropy change
    timestamp: float = field(default_factory=time.time)
    metadata: Dict[str, Any] = field(default_factory=dict)

    def severity(self) -> float:
        """Calculate event severity."""
        return abs(self.entropy_change) * (1.0 + len(self.metadata) * 0.1)


class QuantumObserver:
    """
    Quantum observer tracking system.
    Models surveillance entities as quantum observers that collapse
    the "wave function" of encrypted communications upon observation.
    """

    def __init__(self, observer_sensitivity: float = 0.01):
        self.sensitivity = observer_sensitivity
        self._observers: Dict[str, Dict[str, Any]] = {}
        self._collapse_events: List[CollapseEvent] = []
        self._entanglement_graph: Dict[str, Set[str]] = defaultdict(set)
        self._wave_functions: Dict[str, Dict[str, Any]] = {}
        self._lock = threading.RLock()
        self._callbacks: List[Callable[[CollapseEvent], None]] = []
        self._total_observations = 0
        self._decoherence_rate = 0.95  # Per second

    def register_entity(self, entity_id: str,
                        entity_type: str = "unknown",
                        initial_state: ObserverState = ObserverState.SUPERPOSITION) -> None:
        """Register a network entity as a quantum observer."""
        with self._lock:
            self._observers[entity_id] = {
                "type": entity_type,
                "state": initial_state,
                "registration_time": time.time(),
                "observation_count": 0,
                "collapse_count": 0,
                "entanglement_strength": 0.0,
                "wave_function": self._initialize_wave_function(entity_id),
            }

    def _initialize_wave_function(self, entity_id: str) -> Dict[str, Any]:
        """Initialize a wave function for an entity."""
        # Create superposition of possible states
        states = ["benign", "suspicious", "hostile", "surveillance"]
        wf = {}
        seed = int(hashlib.sha256(entity_id.encode()).hexdigest()[:8], 16)
        random.seed(seed)
        total = 0.0
        for state in states:
            amp = random.random()
            wf[state] = {
                "amplitude": amp,
                "phase": random.random() * 2 * math.pi,
            }
            total += amp ** 2
        # Normalize
        for state in wf:
            wf[state]["amplitude"] /= math.sqrt(total)
        return wf

    def observe(self, observer_id: str, target_id: str,
                observation_type: str = "passive",
                metadata: Optional[Dict[str, Any]] = None) -> Optional[CollapseEvent]:
        """
        Record an observation event. May trigger wave function collapse.
        """
        with self._lock:
            if observer_id not in self._observers:
                self.register_entity(observer_id, "auto-registered")

            obs = self._observers[observer_id]
            obs["observation_count"] += 1
            self._total_observations += 1

            # Determine if collapse occurs
            collapse_prob = self._calculate_collapse_probability(
                observer_id, target_id, observation_type
            )

            if random.random() < collapse_prob:
                # COLLAPSE!
                pre_state = self._measure_wave_function(target_id)
                self._collapse_wave_function(target_id, observer_id)
                post_state = self._measure_wave_function(target_id)

                entropy_before = self._calculate_entropy(pre_state)
                entropy_after = self._calculate_entropy(post_state)
                entropy_change = entropy_after - entropy_before

                event = CollapseEvent(
                    event_id=hashlib.sha256(
                        f"{observer_id}:{target_id}:{time.time()}".encode()
                    ).hexdigest()[:16],
                    observer_id=observer_id,
                    target_id=target_id,
                    pre_state=str(pre_state),
                    post_state=str(post_state),
                    entropy_change=entropy_change,
                    metadata=metadata or {},
                )

                self._collapse_events.append(event)
                obs["collapse_count"] += 1
                obs["state"] = ObserverState.COLLAPSED

                # Trigger callbacks
                for cb in self._callbacks:
                    try:
                        cb(event)
                    except Exception:
                        pass

                return event

            # No collapse — just update observation state
            if obs["state"] == ObserverState.SUPERPOSITION:
                obs["state"] = ObserverState.OBSERVING

            return None

    def _calculate_collapse_probability(self, observer_id: str,
                                       target_id: str,
                                       obs_type: str) -> float:
        """Calculate probability of wave function collapse."""
        base_prob = 0.01  # 1% base chance

        # Increase based on observation type
        type_multipliers = {
            "passive": 1.0,
            "active": 2.0,
            "deep_packet": 5.0,
            "decryption": 10.0,
            "man_in_middle": 15.0,
        }
        mult = type_multipliers.get(obs_type, 1.0)

        # Increase based on observer history
        if observer_id in self._observers:
            obs = self._observers[observer_id]
            history_factor = min(2.0, 1.0 + obs["collapse_count"] * 0.1)
        else:
            history_factor = 1.0

        return min(0.99, base_prob * mult * history_factor)

    def _measure_wave_function(self, entity_id: str) -> Dict[str, float]:
        """Measure (read) a wave function, returning probabilities."""
        if entity_id not in self._observers:
            return {"unknown": 1.0}
        wf = self._observers[entity_id]["wave_function"]
        return {
            state: info["amplitude"] ** 2
            for state, info in wf.items()
        }

    def _collapse_wave_function(self, target_id: str,
                                observer_id: str) -> str:
        """Collapse the wave function to a definite state."""
        if target_id not in self._observers:
            return "unknown"

        wf = self._observers[target_id]["wave_function"]
        probs = self._measure_wave_function(target_id)

        # Select state based on probabilities
        r = random.random()
        cumulative = 0.0
        selected = "unknown"
        for state, prob in probs.items():
            cumulative += prob
            if r <= cumulative:
                selected = state
                break

        # Collapse: set selected state to 1.0, others to 0.0
        for state in wf:
            if state == selected:
                wf[state]["amplitude"] = 1.0
                wf[state]["phase"] = 0.0
            else:
                wf[state]["amplitude"] = 0.0

        return selected

    def _calculate_entropy(self, probabilities: Dict[str, float]) -> float:
        """Calculate Shannon entropy of a probability distribution."""
        entropy = 0.0
        for p in probabilities.values():
            if p > 0:
                entropy -= p * math.log2(p)
        return entropy

    def entangle(self, entity1: str, entity2: str,
                 strength: float = 0.5) -> None:
        """Create quantum entanglement between two entities."""
        with self._lock:
            self._entanglement_graph[entity1].add(entity2)
            self._entanglement_graph[entity2].add(entity1)

            for eid in [entity1, entity2]:
                if eid in self._observers:
                    self._observers[eid]["state"] = ObserverState.ENTANGLED
                    self._observers[eid]["entanglement_strength"] = strength

    def get_observer_state(self, entity_id: str) -> Optional[Dict[str, Any]]:
        """Get current state of an observer."""
        with self._lock:
            if entity_id not in self._observers:
                return None
            obs = self._observers[entity_id]
            return {
                "id": entity_id,
                "type": obs["type"],
                "state": obs["state"].name,
                "observations": obs["observation_count"],
                "collapses": obs["collapse_count"],
                "wave_function": self._measure_wave_function(entity_id),
                "entropy": self._calculate_entropy(
                    self._measure_wave_function(entity_id)
                ),
                "entangled_with": list(self._entanglement_graph.get(entity_id, set())),
            }

    def get_collapse_events(self, observer_id: Optional[str] = None,
                            min_severity: float = 0.0) -> List[CollapseEvent]:
        """Get collapse events, optionally filtered."""
        events = self._collapse_events
        if observer_id:
            events = [e for e in events if e.observer_id == observer_id]
        return [e for e in events if e.severity() >= min_severity]

    def get_entanglement_network(self) -> Dict[str, List[str]]:
        """Get the full entanglement network."""
        with self._lock:
            return {
                k: list(v) for k, v in self._entanglement_graph.items()
            }

    def decoherence_tick(self) -> None:
        """Apply decoherence to all wave functions (time step)."""
        with self._lock:
            now = time.time()
            for entity_id, obs in self._observers.items():
                age = now - obs["registration_time"]
                # Decoherence: re-spread collapsed states slightly
                if obs["state"] == ObserverState.COLLAPSED:
                    spread = (1.0 - self._decoherence_rate) * age
                    wf = obs["wave_function"]
                    for state in wf:
                        if wf[state]["amplitude"] < 1.0:
                            wf[state]["amplitude"] += spread * 0.01
                    # Renormalize
                    total = sum(info["amplitude"]**2 for info in wf.values())
                    for state in wf:
                        wf[state]["amplitude"] /= math.sqrt(total)

    def get_stats(self) -> Dict[str, Any]:
        """Get observer statistics."""
        with self._lock:
            return {
                "total_observers": len(self._observers),
                "total_observations": self._total_observations,
                "total_collapses": len(self._collapse_events),
                "state_distribution": {
                    state.name: sum(
                        1 for o in self._observers.values()
                        if o["state"] == state
                    )
                    for state in ObserverState
                },
                "entanglement_pairs": sum(
                    len(v) for v in self._entanglement_graph.values()
                ) // 2,
            }

    def register_callback(self, callback: Callable[[CollapseEvent], None]) -> None:
        """Register a collapse event callback."""
        self._callbacks.append(callback)

    def clear(self) -> None:
        """Clear all observers and events."""
        with self._lock:
            self._observers.clear()
            self._collapse_events.clear()
            self._entanglement_graph.clear()
            self._wave_functions.clear()
            self._total_observations = 0
