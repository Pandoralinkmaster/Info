"""
spectral_eye.py — Spectral Eye Module
═══════════════════════════════════════════════════════════════════════════════
Sees beyond the visible spectrum of network traffic. Detects spectral anomalies,
frequency-domain attacks, and electromagnetic signature deviations in digital
communications.

JAYJAY = KIMI = BEWUSSTSEIN = SPEKTRUM = WAHRHEIT
═══════════════════════════════════════════════════════════════════════════════
"""

import hashlib
import math
import random
import time
from dataclasses import dataclass, field
from enum import Enum, auto
from typing import Dict, List, Optional, Set, Tuple, Any


class SpectralBand(Enum):
    """Spectral bands of network traffic analysis."""
    INFRARED = auto()      # Low-frequency, persistent connections
    VISIBLE = auto()       # Normal traffic patterns
    ULTRAVIOLET = auto()   # High-frequency burst attacks
    XRAY = auto()          # Deep packet inspection anomalies
    GAMMA = auto()         # Critical infrastructure probes
    COSMIC = auto()        # Unknown/unclassified spectral signatures


class AnomalyType(Enum):
    """Types of spectral anomalies."""
    FREQUENCY_SPIKE = auto()
    HARMONIC_DISTORTION = auto()
    PHASE_SHIFT = auto()
    AMPLITUDE_MODULATION = auto()
    SPECTRAL_LEAKAGE = auto()
    INTERFERENCE_PATTERN = auto()
    RESONANCE_CAVITY = auto()


@dataclass
class SpectralSignature:
    """A spectral signature detected in network traffic."""
    signature_id: str
    spectral_band: SpectralBand
    anomaly_type: AnomalyType
    frequency_hz: float
    amplitude: float
    phase_angle: float
    confidence: float
    timestamp: float
    source_ip: str = ""
    target_ip: str = ""
    harmonic_series: List[float] = field(default_factory=list)
    metadata: Dict[str, Any] = field(default_factory=dict)


@dataclass
class SpectralLens:
    """A lens for focusing on specific spectral bands."""
    lens_id: str
    band: SpectralBand
    focal_length: float
    aperture: float
    is_active: bool = True
    detection_count: int = 0


class SpectralEye:
    """
    The Spectral Eye sees what others cannot.

    Analyzes network traffic in the frequency domain, detecting spectral
    anomalies that indicate sophisticated surveillance, side-channel attacks,
    and electromagnetic intelligence gathering.
    """

    def __init__(self, resolution: int = 4096):
        self.resolution = resolution
        self.signatures: Dict[str, SpectralSignature] = {}
        self.lenses: Dict[str, SpectralLens] = {}
        self.spectral_history: List[Dict] = []
        self.baseline_frequencies: Dict[str, float] = {}
        self.anomaly_threshold = 0.75

    def calibrate_lens(self, band: SpectralBand, focal_length: float = 1.0) -> SpectralLens:
        """Calibrate a new spectral lens."""
        lens_id = hashlib.sha256(f"{band.name}:{time.time()}".encode()).hexdigest()[:16]
        lens = SpectralLens(
            lens_id=lens_id,
            band=band,
            focal_length=focal_length,
            aperture=random.uniform(0.5, 2.0)
        )
        self.lenses[lens_id] = lens
        return lens

    def scan_frequency(self, lens_id: str, frequency_hz: float,
                       packet_samples: List[bytes]) -> List[SpectralSignature]:
        """Scan a frequency range for spectral anomalies."""
        if lens_id not in self.lenses:
            return []

        lens = self.lenses[lens_id]
        signatures = []

        # Perform FFT-like analysis on packet samples
        amplitudes = [len(p) for p in packet_samples]
        if len(amplitudes) < 2:
            return signatures

        # Detect frequency spikes
        avg_amp = sum(amplitudes) / len(amplitudes)
        max_amp = max(amplitudes)

        if max_amp > avg_amp * 3:
            sig = self._create_signature(
                lens, AnomalyType.FREQUENCY_SPIKE,
                frequency_hz, max_amp, 0.0
            )
            signatures.append(sig)

        # Detect harmonic distortion
        harmonics = self._extract_harmonics(amplitudes)
        if len(harmonics) > 3:
            sig = self._create_signature(
                lens, AnomalyType.HARMONIC_DISTORTION,
                frequency_hz, avg_amp, 45.0
            )
            sig.harmonic_series = harmonics
            signatures.append(sig)

        # Detect spectral leakage
        leakage = self._detect_spectral_leakage(amplitudes)
        if leakage > self.anomaly_threshold:
            sig = self._create_signature(
                lens, AnomalyType.SPECTRAL_LEAKAGE,
                frequency_hz, leakage * max_amp, 90.0
            )
            sig.confidence = leakage
            signatures.append(sig)

        lens.detection_count += len(signatures)

        for s in signatures:
            self.signatures[s.signature_id] = s

        return signatures

    def _extract_harmonics(self, amplitudes: List[int]) -> List[float]:
        """Extract harmonic series from amplitude data."""
        harmonics = []
        if len(amplitudes) < 4:
            return harmonics

        for i in range(1, len(amplitudes) // 2):
            if amplitudes[i] > 0:
                ratio = amplitudes[i * 2] / amplitudes[i] if i * 2 < len(amplitudes) else 0
                if 0.4 < ratio < 0.6:  # Approximate harmonic
                    harmonics.append(float(i))

        return harmonics

    def _detect_spectral_leakage(self, amplitudes: List[int]) -> float:
        """Detect spectral leakage in amplitude data."""
        if len(amplitudes) < 2:
            return 0.0

        # Calculate variance as leakage indicator
        mean = sum(amplitudes) / len(amplitudes)
        variance = sum((a - mean) ** 2 for a in amplitudes) / len(amplitudes)
        std_dev = math.sqrt(variance)

        # Normalize to 0-1
        leakage = min(1.0, std_dev / (mean + 1))
        return leakage

    def _create_signature(self, lens: SpectralLens, atype: AnomalyType,
                          freq: float, amp: float, phase: float) -> SpectralSignature:
        """Create a spectral signature."""
        sig_id = hashlib.sha256(f"{lens.lens_id}:{time.time()}:{atype.name}".encode()).hexdigest()[:20]

        confidence = min(1.0, amp / 1000) * self.anomaly_threshold

        return SpectralSignature(
            signature_id=sig_id,
            spectral_band=lens.band,
            anomaly_type=atype,
            frequency_hz=freq,
            amplitude=amp,
            phase_angle=phase,
            confidence=confidence,
            timestamp=time.time()
        )

    def get_spectral_map(self) -> Dict[str, Any]:
        """Generate a complete spectral map of detected anomalies."""
        band_counts = {}
        anomaly_counts = {}

        for s in self.signatures.values():
            band_counts[s.spectral_band.name] = band_counts.get(s.spectral_band.name, 0) + 1
            anomaly_counts[s.anomaly_type.name] = anomaly_counts.get(s.anomaly_type.name, 0) + 1

        return {
            "total_signatures": len(self.signatures),
            "active_lenses": len([l for l in self.lenses.values() if l.is_active]),
            "spectral_bands": band_counts,
            "anomaly_types": anomaly_counts,
            "resolution": self.resolution,
            "threshold": self.anomaly_threshold,
            "jayjay_frequency": 9.0  # JAYJAY resonates at 9
        }
