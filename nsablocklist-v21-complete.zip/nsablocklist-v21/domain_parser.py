"""
DomainParser — Advanced domain parsing with TLD extraction, subdomain analysis,
and quantum-grade domain fingerprinting.
"""

import hashlib
import ipaddress
import json
import re
import tldextract
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Set, Tuple, Any


@dataclass
class TLDInfo:
    """Information about a top-level domain."""
    tld: str
    category: str  # generic, country, sponsored, infrastructure, test
    iana_manager: Optional[str] = None
    registration_restrictions: Optional[str] = None
    known_abuse_score: float = 0.0
    surveillance_risk: float = 0.0


@dataclass
class ParsedDomain:
    """Comprehensive parsed domain information."""
    raw: str
    subdomain: Optional[str] = None
    domain: str = ""
    suffix: str = ""
    is_ip: bool = False
    ip_address: Optional[str] = None
    is_ipv6: bool = False
    is_private: bool = False
    is_loopback: bool = False
    is_multicast: bool = False
    depth: int = 0
    labels: List[str] = field(default_factory=list)
    label_count: int = 0
    entropy: float = 0.0
    dga_score: float = 0.0
    quantum_fingerprint: Optional[str] = None
    neural_profile: Optional[Dict] = None
    temporal_signature: Optional[str] = None
    dimensional_anchor: Optional[str] = None

    def __post_init__(self):
        if not self.quantum_fingerprint:
            self.quantum_fingerprint = self._compute_quantum_fingerprint()
        if not self.temporal_signature:
            self.temporal_signature = self._compute_temporal_signature()

    def _compute_quantum_fingerprint(self) -> str:
        data = f"{self.raw}:{self.domain}:{self.suffix}"
        return hashlib.sha3_256(data.encode()).hexdigest()[:32]

    def _compute_temporal_signature(self) -> str:
        import time
        data = f"{self.raw}:{time.time()}"
        return hashlib.sha3_256(data.encode()).hexdigest()[:16]

    @property
    def registered_domain(self) -> str:
        """Get the registered domain (domain + suffix)."""
        if self.domain and self.suffix:
            return f"{self.domain}.{self.suffix}"
        return self.raw

    @property
    def fqdn(self) -> str:
        """Get fully qualified domain name."""
        if self.subdomain and self.registered_domain:
            return f"{self.subdomain}.{self.registered_domain}"
        return self.registered_domain

    def to_dict(self) -> Dict:
        return {
            "raw": self.raw,
            "subdomain": self.subdomain,
            "domain": self.domain,
            "suffix": self.suffix,
            "registered_domain": self.registered_domain,
            "fqdn": self.fqdn,
            "is_ip": self.is_ip,
            "ip_address": self.ip_address,
            "is_ipv6": self.is_ipv6,
            "is_private": self.is_private,
            "is_loopback": self.is_loopback,
            "is_multicast": self.is_multicast,
            "depth": self.depth,
            "labels": self.labels,
            "label_count": self.label_count,
            "entropy": self.entropy,
            "dga_score": self.dga_score,
            "quantum_fingerprint": self.quantum_fingerprint,
            "neural_profile": self.neural_profile,
            "temporal_signature": self.temporal_signature,
            "dimensional_anchor": self.dimensional_anchor,
        }


class DomainParser:
    """
    Advanced domain parser with TLD extraction, entropy analysis, and DGA detection.
    """

    # Known high-risk TLDs
    HIGH_RISK_TLDS = {
        ".tk", ".ml", ".ga", ".cf", ".top", ".xyz", ".club", ".work",
        ".click", ".download", ".link", ".men", ".date", ".racing",
        ".loan", ".party", ".review", ".trade", ".win", ".bid",
        ".country", ".gdn", ".kim", ".mom", ".xin", ".jetzt",
    }

    # Surveillance-related TLDs
    SURVEILLANCE_TLDS = {
        ".gov", ".mil", ".int", ".edu",  # Government/military
    }

    # DGA pattern indicators
    DGA_PATTERNS = [
        r"^[a-z0-9]{20,40}\.[a-z]{2,6}$",  # Long random string
        r"^[a-z0-9]{10,20}-[a-z0-9]{10,20}\.",  # Hyphenated random
        r"^(?:[a-z]{2}[0-9]{2}){3,}\.",  # Alternating pattern
        r"^[a-z]{1,3}[0-9]{1,3}[a-z]{1,3}[0-9]{1,3}\.",  # Short alternating
    ]

    def __init__(self):
        self._cache: Dict[str, ParsedDomain] = {}
        self._tld_cache: Dict[str, TLDInfo] = {}
        self._quantum_mode = False
        self._neural_mode = False

    def parse(self, domain: str) -> ParsedDomain:
        """Parse a domain string into structured information."""
        if domain in self._cache:
            return self._cache[domain]

        parsed = ParsedDomain(raw=domain)

        # Check if it's an IP address
        try:
            addr = ipaddress.ip_address(domain)
            parsed.is_ip = True
            parsed.ip_address = str(addr)
            parsed.is_ipv6 = isinstance(addr, ipaddress.IPv6Address)
            parsed.is_private = addr.is_private
            parsed.is_loopback = addr.is_loopback
            parsed.is_multicast = addr.is_multicast
            self._cache[domain] = parsed
            return parsed
        except ValueError:
            pass

        # Use tldextract for proper parsing
        extracted = tldextract.extract(domain)
        parsed.subdomain = extracted.subdomain or None
        parsed.domain = extracted.domain
        parsed.suffix = extracted.suffix
        parsed.labels = domain.split(".")
        parsed.label_count = len(parsed.labels)
        parsed.depth = parsed.label_count - 1 if parsed.suffix else 0

        # Compute entropy
        parsed.entropy = self._compute_entropy(domain)

        # Compute DGA score
        parsed.dga_score = self._compute_dga_score(domain)

        # Build neural profile
        parsed.neural_profile = self._build_neural_profile(parsed)

        # Quantum/dimensional features
        if self._quantum_mode:
            parsed.dimensional_anchor = self._compute_dimensional_anchor(domain)

        self._cache[domain] = parsed
        return parsed

    def _compute_entropy(self, domain: str) -> float:
        """Compute Shannon entropy of domain string."""
        import math
        if not domain:
            return 0.0
        freq = {}
        for c in domain.lower():
            freq[c] = freq.get(c, 0) + 1
        length = len(domain)
        entropy = 0.0
        for count in freq.values():
            p = count / length
            entropy -= p * math.log2(p)
        return entropy

    def _compute_dga_score(self, domain: str) -> float:
        """Compute Domain Generation Algorithm detection score."""
        score = 0.0

        # Check against known DGA patterns
        for pattern in self.DGA_PATTERNS:
            if re.match(pattern, domain, re.IGNORECASE):
                score += 0.3

        # High entropy is suspicious
        entropy = self._compute_entropy(domain)
        if entropy > 4.0:
            score += 0.2
        if entropy > 4.5:
            score += 0.2

        # Check TLD
        for tld in self.HIGH_RISK_TLDS:
            if domain.endswith(tld):
                score += 0.15

        # Length analysis
        main_part = domain.split(".")[0] if "." in domain else domain
        if len(main_part) > 20:
            score += 0.1
        if len(main_part) > 30:
            score += 0.1

        # Character distribution
        digits = sum(1 for c in main_part if c.isdigit())
        if digits / len(main_part) > 0.3 if main_part else 0:
            score += 0.1

        return min(score, 1.0)

    def _build_neural_profile(self, parsed: ParsedDomain) -> Dict:
        """Build a neural analysis profile for the domain."""
        profile = {
            "length_score": min(len(parsed.raw) / 50, 1.0),
            "depth_score": min(parsed.depth / 5, 1.0),
            "entropy_score": min(parsed.entropy / 5.0, 1.0),
            "dga_risk": parsed.dga_score,
            "tld_risk": 0.0,
            "subdomain_complexity": 0.0,
        }

        # TLD risk
        if parsed.suffix:
            for tld in self.HIGH_RISK_TLDS:
                if parsed.suffix in tld:
                    profile["tld_risk"] = 0.7
                    break
            for tld in self.SURVEILLANCE_TLDS:
                if parsed.suffix in tld:
                    profile["tld_risk"] = 0.5
                    break

        # Subdomain complexity
        if parsed.subdomain:
            sub_parts = parsed.subdomain.split(".")
            profile["subdomain_complexity"] = min(len(sub_parts) / 5, 1.0)

        # Overall neural score
        profile["overall_score"] = (
            profile["dga_risk"] * 0.4 +
            profile["tld_risk"] * 0.2 +
            profile["entropy_score"] * 0.2 +
            profile["subdomain_complexity"] * 0.1 +
            profile["length_score"] * 0.1
        )

        return profile

    def _compute_dimensional_anchor(self, domain: str) -> str:
        """Compute a dimensional anchor for quantum mode."""
        import random
        import time
        seed = int(hashlib.sha3_256(domain.encode()).hexdigest(), 16)
        random.seed(seed ^ int(time.time()))
        anchor = f"D{random.randint(1, 11)}-{hashlib.sha3_256(domain.encode()).hexdigest()[:8]}"
        random.seed()
        return anchor

    def get_tld_info(self, tld: str) -> TLDInfo:
        """Get information about a TLD."""
        if tld in self._tld_cache:
            return self._tld_cache[tld]

        info = TLDInfo(tld=tld, category="unknown")

        if tld in (".com", ".net", ".org", ".info", ".biz"):
            info.category = "generic"
        elif tld in (".gov", ".mil", ".edu"):
            info.category = "sponsored"
            info.known_abuse_score = 0.0
            info.surveillance_risk = 0.8
        elif len(tld) == 3 and tld.startswith("."):
            info.category = "country"

        if tld in self.HIGH_RISK_TLDS:
            info.known_abuse_score = 0.7

        self._tld_cache[tld] = info
        return info

    def extract_subdomains(self, domain: str) -> List[str]:
        """Extract all subdomain levels."""
        parsed = self.parse(domain)
        if not parsed.subdomain:
            return []
        parts = parsed.subdomain.split(".")
        subdomains = []
        for i in range(len(parts)):
            sub = ".".join(parts[i:])
            if sub:
                subdomains.append(sub)
        return subdomains

    def is_suspicious(self, domain: str, threshold: float = 0.6) -> Tuple[bool, float]:
        """Check if a domain is suspicious."""
        parsed = self.parse(domain)
        score = parsed.dga_score
        if parsed.neural_profile:
            score = max(score, parsed.neural_profile.get("overall_score", 0))
        return score >= threshold, score

    def find_similar(self, domain: str, candidates: List[str],
                     threshold: float = 0.8) -> List[Tuple[str, float]]:
        """Find similar domains using string similarity."""
        from difflib import SequenceMatcher
        results = []
        for candidate in candidates:
            if candidate == domain:
                continue
            similarity = SequenceMatcher(None, domain, candidate).ratio()
            if similarity >= threshold:
                results.append((candidate, similarity))
        return sorted(results, key=lambda x: x[1], reverse=True)

    def batch_parse(self, domains: List[str]) -> Dict[str, ParsedDomain]:
        """Parse multiple domains efficiently."""
        return {d: self.parse(d) for d in domains}

    def enable_quantum_mode(self):
        self._quantum_mode = True
        return self

    def enable_neural_mode(self):
        self._neural_mode = True
        return self

    def get_cache_stats(self) -> Dict:
        """Get cache statistics."""
        return {
            "domain_cache_size": len(self._cache),
            "tld_cache_size": len(self._tld_cache),
        }
