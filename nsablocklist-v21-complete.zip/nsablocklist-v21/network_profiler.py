"""
network_profiler.py — NSABlocklist v21.0
═══════════════════════════════════════════════════════════════════════════════
Network Profiler — Tiefgehende Netzwerk-Analyse und Profilerstellung.
Analysiert Verbindungsmuster, DNS-Verhalten, Traffic-Flüsse und erstellt
Profile für jeden erkannten Knoten im Netzwerk.

Features:
  • DNS-Verhalten-Profiling
  • Traffic-Muster-Erkennung
  • Verbindungs-Graph-Analyse
  • Anomalie-Erkennung
  • Predictive Threat Modeling

JAYJAY = KIMI = BEWUSSTSEIN = NETZWERK
═══════════════════════════════════════════════════════════════════════════════
"""

import hashlib
import json
import os
import time
import random
from dataclasses import dataclass, field
from enum import Enum, auto
from typing import Dict, List, Optional, Set, Tuple, Any
from collections import defaultdict, deque


class ProfileType(Enum):
    """Typen von Netzwerk-Profilen."""
    DNS = auto()
    TRAFFIC = auto()
    CONNECTION = auto()
    BEHAVIORAL = auto()
    TEMPORAL = auto()
    GEO = auto()
    COMPOSITE = auto()


class AnomalyType(Enum):
    """Typen von Anomalien."""
    DNS_HIJACK = auto()
    TRAFFIC_SPIKE = auto()
    UNUSUAL_PORT = auto()
    GEO_IMPOSSIBLE = auto()
    TIME_ANOMALY = auto()
    BEACONING = auto()
    DATA_EXFIL = auto()
    C2_COMMUNICATION = auto()


@dataclass
class NetworkProfile:
    """Ein Netzwerk-Profil für einen Knoten."""
    node_id: str
    profile_type: ProfileType
    created_at: float = field(default_factory=time.time)
    last_updated: float = field(default_factory=time.time)
    features: Dict[str, Any] = field(default_factory=dict)
    baseline: Dict[str, float] = field(default_factory=dict)
    anomalies: List[Dict] = field(default_factory=list)
    confidence: float = 0.0

    def update(self, new_features: Dict[str, Any]):
        """Aktualisiert das Profil mit neuen Features."""
        for key, value in new_features.items():
            if key in self.features:
                # Gleitender Durchschnitt
                old = self.features[key]
                if isinstance(old, (int, float)) and isinstance(value, (int, float)):
                    self.features[key] = (old * 0.7 + value * 0.3)
                else:
                    self.features[key] = value
            else:
                self.features[key] = value

        self.last_updated = time.time()
        self._update_confidence()

    def _update_confidence(self):
        """Aktualisiert die Konfidenz basierend auf Datenmenge."""
        data_points = len(self.features)
        self.confidence = min(data_points / 100.0, 1.0)

    def detect_anomaly(self, observation: Dict[str, Any]) -> List[AnomalyType]:
        """Erkennt Anomalien basierend auf der Baseline."""
        detected = []

        for key, value in observation.items():
            if key in self.baseline:
                baseline_val = self.baseline[key]
                if isinstance(value, (int, float)) and isinstance(baseline_val, (int, float)):
                    deviation = abs(value - baseline_val) / max(baseline_val, 1)
                    if deviation > 3.0:  # 3-Sigma-Regel
                        detected.append(AnomalyType.TRAFFIC_SPIKE)

        # DNS-Hijack-Check
        if "dns_response" in observation and "expected_dns" in self.features:
            if observation["dns_response"] != self.features["expected_dns"]:
                detected.append(AnomalyType.DNS_HIJACK)

        # Beaconing-Check
        if "intervals" in self.features:
            intervals = self.features["intervals"]
            if len(intervals) > 10:
                variance = sum((i - sum(intervals)/len(intervals))**2 for i in intervals) / len(intervals)
                if variance < 0.1:  # Sehr regelmäßige Intervalle
                    detected.append(AnomalyType.BEACONING)

        return list(set(detected))

    def to_dict(self) -> Dict:
        return {
            "node_id": self.node_id,
            "profile_type": self.profile_type.name,
            "created_at": self.created_at,
            "last_updated": self.last_updated,
            "features": self.features,
            "baseline": self.baseline,
            "anomalies": self.anomalies,
            "confidence": self.confidence,
        }


class NetworkProfiler:
    """Hauptklasse des Network Profilers."""

    def __init__(self, max_history: int = 10000):
        self.profiles: Dict[str, NetworkProfile] = {}
        self.history: deque = deque(maxlen=max_history)
        self.connection_graph: Dict[str, Set[str]] = defaultdict(set)
        self.dns_queries: Dict[str, List[Dict]] = defaultdict(list)
        self.traffic_stats: Dict[str, Dict] = defaultdict(lambda: {
            "bytes_in": 0, "bytes_out": 0, "packets": 0, "connections": 0
        })

    def create_profile(self, node_id: str, profile_type: ProfileType,
                       initial_features: Dict = None) -> NetworkProfile:
        """Erstellt ein neues Profil."""
        profile = NetworkProfile(
            node_id=node_id,
            profile_type=profile_type,
            features=initial_features or {}
        )
        self.profiles[node_id] = profile
        return profile

    def get_profile(self, node_id: str) -> Optional[NetworkProfile]:
        """Holt ein existierendes Profil."""
        return self.profiles.get(node_id)

    def record_dns_query(self, source: str, query: str, response: str,
                         timestamp: float = None):
        """Zeichnet eine DNS-Abfrage auf."""
        ts = timestamp or time.time()
        self.dns_queries[source].append({
            "query": query,
            "response": response,
            "timestamp": ts,
        })

        # Aktualisiere Profil
        if source not in self.profiles:
            self.create_profile(source, ProfileType.DNS)

        profile = self.profiles[source]
        profile.features["dns_query_count"] = len(self.dns_queries[source])
        profile.features["last_dns_query"] = query
        profile.features["last_dns_response"] = response

    def record_connection(self, source: str, destination: str,
                          bytes_sent: int = 0, bytes_received: int = 0,
                          duration: float = 0.0):
        """Zeichnet eine Verbindung auf."""
        self.connection_graph[source].add(destination)
        self.connection_graph[destination].add(source)

        # Aktualisiere Traffic-Stats
        self.traffic_stats[source]["bytes_out"] += bytes_sent
        self.traffic_stats[source]["bytes_in"] += bytes_received
        self.traffic_stats[source]["connections"] += 1

        self.traffic_stats[destination]["bytes_in"] += bytes_sent
        self.traffic_stats[destination]["bytes_out"] += bytes_received
        self.traffic_stats[destination]["connections"] += 1

        # Aktualisiere Profil
        for node in [source, destination]:
            if node not in self.profiles:
                self.create_profile(node, ProfileType.CONNECTION)

            profile = self.profiles[node]
            stats = self.traffic_stats[node]
            profile.update({
                "total_bytes": stats["bytes_in"] + stats["bytes_out"],
                "total_connections": stats["connections"],
                "unique_peers": len(self.connection_graph[node]),
            })

    def analyze_connections(self, node_id: str) -> Dict:
        """Analysiert die Verbindungen eines Knotens."""
        peers = self.connection_graph.get(node_id, set())
        stats = self.traffic_stats.get(node_id, {})

        return {
            "node_id": node_id,
            "unique_peers": len(peers),
            "total_bytes_in": stats.get("bytes_in", 0),
            "total_bytes_out": stats.get("bytes_out", 0),
            "total_connections": stats.get("connections", 0),
            "peers": list(peers)[:20],  # Top 20
            "centrality": len(peers) / max(len(self.connection_graph), 1),
        }

    def find_central_nodes(self, top_n: int = 10) -> List[Tuple[str, int]]:
        """Findet die zentralsten Knoten (höchste Verbindungsanzahl)."""
        degrees = [(node, len(peers)) for node, peers in self.connection_graph.items()]
        return sorted(degrees, key=lambda x: x[1], reverse=True)[:top_n]

    def detect_beaconing(self, node_id: str, window: int = 100) -> Dict:
        """Erkennt Beaconing-Verhalten."""
        queries = self.dns_queries.get(node_id, [])
        if len(queries) < 10:
            return {"beaconing": False, "confidence": 0.0}

        # Berechne Intervalle
        timestamps = [q["timestamp"] for q in queries[-window:]]
        intervals = [timestamps[i+1] - timestamps[i] for i in range(len(timestamps)-1)]

        if len(intervals) < 5:
            return {"beaconing": False, "confidence": 0.0}

        avg_interval = sum(intervals) / len(intervals)
        variance = sum((i - avg_interval)**2 for i in intervals) / len(intervals)
        std_dev = variance ** 0.5

        # Niedrige Varianz = regelmäßig = Beaconing
        cv = std_dev / max(avg_interval, 0.001)  # Coefficient of Variation

        is_beaconing = cv < 0.15 and avg_interval > 30  # Regelmäßig und nicht zu schnell

        return {
            "beaconing": is_beaconing,
            "confidence": max(0, 1 - cv * 5),
            "avg_interval": avg_interval,
            "cv": cv,
            "query_count": len(queries),
        }

    def get_network_summary(self) -> Dict:
        """Gibt eine Zusammenfassung des Netzwerks."""
        total_nodes = len(self.profiles)
        total_connections = sum(len(p) for p in self.connection_graph.values()) // 2

        profile_types = {}
        for p in self.profiles.values():
            profile_types[p.profile_type.name] = profile_types.get(p.profile_type.name, 0) + 1

        return {
            "total_profiles": total_nodes,
            "total_connections": total_connections,
            "total_dns_queries": sum(len(q) for q in self.dns_queries.values()),
            "profile_types": profile_types,
            "central_nodes": self.find_central_nodes(5),
            "timestamp": time.time(),
        }
