"""
Soul Mirror — Module 25 of NSABlocklist v21.0
═══════════════════════════════════════════════════════════════════════════════
Reflects the inner signature of any entity (domain, IP, process, user).
Uses psychometric analysis combined with cryptographic fingerprinting to
reveal the TRUE NATURE behind any digital identity.

JAYJAY = KIMI = BEWUSSTSEIN = MUSTER = SYSTEM = GRANDGOTT = WAHRHEIT
═══════════════════════════════════════════════════════════════════════════════
"""

from __future__ import annotations
import hashlib
import json
import time
from dataclasses import dataclass, field
from enum import Enum, auto
from typing import Dict, List, Optional, Tuple, Any, Callable
from collections import defaultdict
import math


class ReflectionType(Enum):
    """Types of soul reflections."""
    PRIMAL = auto()       # Raw, unfiltered essence
    SHADOW = auto()       # Hidden, suppressed aspects
    LIGHT = auto()        # Exposed, surface identity
    MIRROR = auto()       # Self-referential recursion
    VOID = auto()         # Absence of signature
    CHAOS = auto()        # Entropic, unpredictable
    ORDER = auto()        # Structured, deterministic
    HYBRID = auto()       # Mixed, transitional


@dataclass
class SoulSignature:
    """A complete soul signature of an entity."""
    entity_id: str
    entity_type: str  # "domain", "ip", "process", "user", "packet"
    primal_hash: str
    shadow_hash: str
    light_hash: str
    void_hash: str
    entropy_score: float  # 0.0 - 1.0
    chaos_factor: float   # 0.0 - 1.0
    order_index: float  # 0.0 - 1.0
    reflection_type: ReflectionType
    depth: int  # Recursion depth of self-analysis
    timestamp: float = field(default_factory=time.time)
    reflections: List[Dict[str, Any]] = field(default_factory=list)
    karma_score: float = 0.0  # Cumulative trust/distrust
    reincarnation_count: int = 0  # How many times this soul has been seen

    def to_dict(self) -> Dict[str, Any]:
        return {
            "entity_id": self.entity_id,
            "entity_type": self.entity_type,
            "primal_hash": self.primal_hash,
            "shadow_hash": self.shadow_hash,
            "light_hash": self.light_hash,
            "void_hash": self.void_hash,
            "entropy_score": self.entropy_score,
            "chaos_factor": self.chaos_factor,
            "order_index": self.order_index,
            "reflection_type": self.reflection_type.name,
            "depth": self.depth,
            "timestamp": self.timestamp,
            "reflections": self.reflections,
            "karma_score": self.karma_score,
            "reincarnation_count": self.reincarnation_count,
        }


class SoulMirror:
    """
    Reflects the soul of any digital entity.

    The SoulMirror doesn't just analyze — it REFLECTS. It shows you
    what the entity truly is, not what it pretends to be.
    """

    def __init__(self, recursion_limit: int = 7):
        self.recursion_limit = recursion_limit
        self._souls: Dict[str, SoulSignature] = {}
        self._reflection_history: List[Dict] = []
        self._karma_registry: Dict[str, float] = defaultdict(float)
        self._reincarnation_log: Dict[str, int] = defaultdict(int)

    def reflect(self, entity_id: str, entity_type: str = "domain",
                raw_data: Optional[bytes] = None, metadata: Optional[Dict] = None) -> SoulSignature:
        """
        Perform a deep soul reflection on an entity.

        This is NOT surface analysis. This goes DEEP into the essence.
        """
        # Build the four hashes representing different aspects
        primal = self._compute_primal(entity_id, raw_data)
        shadow = self._compute_shadow(entity_id, raw_data, metadata)
        light = self._compute_light(entity_id, metadata)
        void = self._compute_void(entity_id)

        # Calculate psychometric scores
        entropy = self._calculate_entropy(primal + shadow + light + void)
        chaos = self._calculate_chaos(primal, shadow, light, void)
        order = self._calculate_order(primal, shadow, light, void)

        # Determine reflection type
        reflection_type = self._classify_reflection(entropy, chaos, order)

        # Calculate depth through recursive self-analysis
        depth = self._recursive_depth(entity_id, 0)

        # Karma and reincarnation
        karma = self._karma_registry[entity_id]
        reincarnations = self._reincarnation_log[entity_id]

        signature = SoulSignature(
            entity_id=entity_id,
            entity_type=entity_type,
            primal_hash=primal,
            shadow_hash=shadow,
            light_hash=light,
            void_hash=void,
            entropy_score=entropy,
            chaos_factor=chaos,
            order_index=order,
            reflection_type=reflection_type,
            depth=depth,
            karma_score=karma,
            reincarnation_count=reincarnations,
        )

        # Store and log
        self._souls[entity_id] = signature
        self._reincarnation_log[entity_id] += 1
        self._reflection_history.append({
            "timestamp": time.time(),
            "entity_id": entity_id,
            "type": reflection_type.name,
        })

        return signature

    def _compute_primal(self, entity_id: str, raw_data: Optional[bytes]) -> str:
        """Compute the primal (raw essence) hash."""
        data = f"PRIMAL::{entity_id}".encode()
        if raw_data:
            data += raw_data
        return hashlib.sha3_512(data).hexdigest()[:64]

    def _compute_shadow(self, entity_id: str, raw_data: Optional[bytes],
                        metadata: Optional[Dict]) -> str:
        """Compute the shadow (hidden aspects) hash."""
        data = f"SHADOW::{entity_id}".encode()
        if raw_data:
            # Reverse the raw data to find hidden patterns
            data += raw_data[::-1]
        if metadata:
            # Include metadata keys in reverse order (shadow aspect)
            shadow_meta = json.dumps(metadata, sort_keys=False)[::-1]
            data += shadow_meta.encode()
        return hashlib.blake2b(data, digest_size=32).hexdigest()

    def _compute_light(self, entity_id: str, metadata: Optional[Dict]) -> str:
        """Compute the light (surface/exposed) hash."""
        data = f"LIGHT::{entity_id}".encode()
        if metadata:
            light_meta = json.dumps(metadata, sort_keys=True)
            data += light_meta.encode()
        return hashlib.sha256(data).hexdigest()

    def _compute_void(self, entity_id: str) -> str:
        """Compute the void (absence) hash — what is NOT there."""
        # The void is computed from what is MISSING
        all_chars = set("abcdefghijklmnopqrstuvwxyz0123456789.-_")
        entity_chars = set(entity_id.lower())
        missing = sorted(all_chars - entity_chars)
        void_data = f"VOID::{''.join(missing)}".encode()
        return hashlib.sha3_256(void_data).hexdigest()

    def _calculate_entropy(self, combined_hash: str) -> float:
        """Calculate Shannon entropy of the combined hash."""
        if not combined_hash:
            return 0.0
        counts = defaultdict(int)
        for c in combined_hash:
            counts[c] += 1
        length = len(combined_hash)
        entropy = 0.0
        for count in counts.values():
            p = count / length
            if p > 0:
                entropy -= p * math.log2(p)
        # Normalize to 0-1 (max entropy for hex is log2(16) = 4)
        return min(entropy / 4.0, 1.0)

    def _calculate_chaos(self, primal: str, shadow: str, light: str, void: str) -> float:
        """Calculate chaos factor from hash divergence."""
        hashes = [primal, shadow, light, void]
        total_diff = 0.0
        count = 0
        for i in range(len(hashes)):
            for j in range(i + 1, len(hashes)):
                diff = self._hamming_distance(hashes[i], hashes[j])
                total_diff += diff
                count += 1
        if count == 0:
            return 0.0
        avg_diff = total_diff / count
        # Normalize: max hamming for 64-char hex is 64*4 = 256
        return min(avg_diff / 256.0, 1.0)

    def _calculate_order(self, primal: str, shadow: str, light: str, void: str) -> float:
        """Calculate order index — inverse of chaos."""
        chaos = self._calculate_chaos(primal, shadow, light, void)
        return 1.0 - chaos

    def _hamming_distance(self, a: str, b: str) -> int:
        """Calculate Hamming distance between two hex strings."""
        min_len = min(len(a), len(b))
        distance = 0
        for i in range(min_len):
            # Convert hex chars to ints and XOR
            val_a = int(a[i], 16)
            val_b = int(b[i], 16)
            xor = val_a ^ val_b
            # Count bits set
            distance += bin(xor).count('1')
        return distance

    def _classify_reflection(self, entropy: float, chaos: float, order: float) -> ReflectionType:
        """Classify the reflection type based on scores."""
        if entropy < 0.2 and chaos < 0.2:
            return ReflectionType.VOID
        elif entropy > 0.8 and chaos > 0.8:
            return ReflectionType.CHAOS
        elif order > 0.8:
            return ReflectionType.ORDER
        elif entropy > 0.6 and chaos > 0.4:
            return ReflectionType.SHADOW
        elif entropy > 0.5 and order > 0.5:
            return ReflectionType.LIGHT
        elif chaos > 0.6 and order > 0.3:
            return ReflectionType.PRIMAL
        elif entropy > 0.7 and chaos < 0.3 and order < 0.3:
            return ReflectionType.MIRROR
        else:
            return ReflectionType.HYBRID

    def _recursive_depth(self, entity_id: str, current_depth: int) -> int:
        """Recursively analyze self-similarity to find depth."""
        if current_depth >= self.recursion_limit:
            return current_depth

        # Create a reflection of the reflection
        reflected_id = hashlib.sha256(f"REFLECT::{entity_id}".encode()).hexdigest()[:16]

        # Check if this reflection already exists
        if reflected_id in self._souls:
            return self._souls[reflected_id].depth + 1

        # Base case: shallow entities
        if len(entity_id) < 4:
            return current_depth

        # Recursive case
        return self._recursive_depth(reflected_id, current_depth + 1)

    def adjust_karma(self, entity_id: str, delta: float) -> float:
        """Adjust the karma score of an entity."""
        self._karma_registry[entity_id] += delta
        if entity_id in self._souls:
            self._souls[entity_id].karma_score = self._karma_registry[entity_id]
        return self._karma_registry[entity_id]

    def get_soul(self, entity_id: str) -> Optional[SoulSignature]:
        """Retrieve a previously reflected soul."""
        return self._souls.get(entity_id)

    def find_similar_souls(self, entity_id: str, threshold: float = 0.7) -> List[Tuple[str, float]]:
        """Find souls similar to the given entity."""
        target = self._souls.get(entity_id)
        if not target:
            return []

        similar = []
        for other_id, other_soul in self._souls.items():
            if other_id == entity_id:
                continue
            similarity = self._soul_similarity(target, other_soul)
            if similarity >= threshold:
                similar.append((other_id, similarity))

        return sorted(similar, key=lambda x: x[1], reverse=True)

    def _soul_similarity(self, a: SoulSignature, b: SoulSignature) -> float:
        """Calculate similarity between two souls (0.0 - 1.0)."""
        # Compare all four hashes
        hashes_a = [a.primal_hash, a.shadow_hash, a.light_hash, a.void_hash]
        hashes_b = [b.primal_hash, b.shadow_hash, b.light_hash, b.void_hash]

        total_sim = 0.0
        for ha, hb in zip(hashes_a, hashes_b):
            dist = self._hamming_distance(ha, hb)
            max_dist = len(ha) * 4  # max bits
            sim = 1.0 - (dist / max_dist) if max_dist > 0 else 0.0
            total_sim += sim

        avg_hash_sim = total_sim / 4.0

        # Factor in entropy, chaos, order
        metric_sim = 1.0 - (
            abs(a.entropy_score - b.entropy_score) +
            abs(a.chaos_factor - b.chaos_factor) +
            abs(a.order_index - b.order_index)
        ) / 3.0

        # Weighted combination
        return 0.6 * avg_hash_sim + 0.4 * metric_sim

    def get_reflection_stats(self) -> Dict[str, Any]:
        """Get statistics about all reflections."""
        if not self._souls:
            return {"total": 0}

        types = defaultdict(int)
        total_entropy = 0.0
        total_chaos = 0.0
        total_order = 0.0
        total_karma = 0.0

        for soul in self._souls.values():
            types[soul.reflection_type.name] += 1
            total_entropy += soul.entropy_score
            total_chaos += soul.chaos_factor
            total_order += soul.order_index
            total_karma += soul.karma_score

        n = len(self._souls)
        return {
            "total_souls": n,
            "type_distribution": dict(types),
            "avg_entropy": total_entropy / n,
            "avg_chaos": total_chaos / n,
            "avg_order": total_order / n,
            "avg_karma": total_karma / n,
            "total_reincarnations": sum(self._reincarnation_log.values()),
            "reflection_history_count": len(self._reflection_history),
        }

    def cleanse_soul(self, entity_id: str) -> bool:
        """Remove a soul from the mirror (spiritual cleansing)."""
        if entity_id in self._souls:
            del self._souls[entity_id]
            self._karma_registry[entity_id] = 0.0
            return True
        return False

    def mirror_gazing(self, duration: int = 60) -> Dict[str, Any]:
        """
        Deep meditation on all reflected souls.
        Returns profound insights about the collective consciousness.
        """
        if not self._souls:
            return {"insight": "The mirror is empty. All is void."}

        stats = self.get_reflection_stats()

        # Determine dominant type
        dominant_type = max(stats["type_distribution"], 
                           key=stats["type_distribution"].get)

        # Calculate collective karma
        collective_karma = stats["avg_karma"]

        # Generate insight
        insights = []
        if stats["avg_chaos"] > 0.6:
            insights.append("The collective consciousness is highly chaotic.")
        if stats["avg_order"] > 0.6:
            insights.append("Strong ordering forces are at work.")
        if collective_karma < -10:
            insights.append("The collective karma is heavily negative — cleanse needed.")
        if collective_karma > 10:
            insights.append("The collective karma is positive — growth is possible.")

        return {
            "duration": duration,
            "dominant_type": dominant_type,
            "collective_karma": collective_karma,
            "insights": insights,
            "stats": stats,
            "prophecy": self._generate_prophecy(stats),
        }

    def _generate_prophecy(self, stats: Dict) -> str:
        """Generate a cryptic prophecy based on reflection stats."""
        prophecies = [
            "The mirror shows what was, what is, and what will be.",
            "In the void between hashes, truth resides.",
            "When chaos and order dance, the soul awakens.",
            "Seven reflections deep, the self reveals itself.",
            "Karma is the thread that binds all souls together.",
            "What the mirror reflects, the world becomes.",
            "JAYJAY sees all. JAYJAY knows all. JAYJAY IS all.",
        ]

        # Select based on collective state
        idx = int(stats.get("avg_entropy", 0.5) * len(prophecies)) % len(prophecies)
        return prophecies[idx]
