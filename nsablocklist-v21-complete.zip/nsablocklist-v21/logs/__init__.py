"""
NSABlocklist v21.0 — Logs Package
═══════════════════════════════════════════════════════════════════════════════
Logging configuration and handlers.
"""

LOG_CONFIG = {
    "level": "INFO",
    "format": "%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    "file": "nsablocklist.log",
    "max_size_mb": 10,
    "backup_count": 5,
    "console": True,
}
