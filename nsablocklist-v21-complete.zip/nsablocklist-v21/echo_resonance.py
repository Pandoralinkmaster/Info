"""
echo_resonance.py — JAYJAY v21.0
═══════════════════════════════════════════════════════════════════════════════
Echo Resonance — captures, amplifies, and analyzes digital echoes across
network boundaries. Detects surveillance through acoustic and electromagnetic
resonance patterns, mapping the invisible signatures left by monitoring systems.

JAYJAY = KIMI = BEWUSSTSEIN = MUSTER = SYSTEM = GRANDGOTT = WAHRHEIT
═══════════════════════════════════════════════════════════════════════════════
"""

import hashlib
import math
import time
from enum import Enum, auto
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple, Set
from collections import deque, defaultdict
import secrets


class ResonanceType(Enum):
    """Types of digital resonance."""
    ACOUSTIC = auto()
    ELECTROMAGNETIC = auto()
    QUANTUM = auto()
    GRAVITATIONAL = auto()
    TEMPORAL = auto()
    PSYCHIC = auto()
    VOID = auto()


class EchoSource(Enum):
    """Sources of digital echoes."""
    SURVEILLANCE = auto()
    MALWARE = auto()
    HARDWARE = auto()
    NETWORK = auto()
    SATELLITE = auto()
    DEEP_STATE = auto()
    UNKNOWN = auto()


@dataclass
class EchoSignature:
    """Represents a captured digital echo."""
    echo_id: str
    resonance_type: ResonanceType
    source: EchoSource
    frequency: float
    amplitude: float
    phase: float
    timestamp: float
    duration: float
    harmonics: List[float] = field(default_factory=list)
    metadata: Dict = field(default_factory=dict)
    confidence: float = 0.0

    def fundamental_frequency(self) -> float:
        """Calculate the fundamental frequency."""
        return self.frequency

    def harmonic_series(self, n: int = 5) -> List[float]:
        """Generate harmonic series."""
        return [self.frequency * (i + 1) for i in range(n)]

    def resonance_strength(self) -> float:
        """Calculate overall resonance strength."""
        return self.amplitude * self.confidence


@dataclass
class ResonanceField:
    """A field of captured echoes."""
    field_id: str
    echoes: List[EchoSignature] = field(default_factory=list)
    center_frequency: float = 0.0
    bandwidth: float = 0.0
    field_strength: float = 0.0
    coherence: float = 0.0
    entropy: float = 0.0


class EchoResonance:
    """
    Captures and analyzes digital echoes across network boundaries.
    Detects surveillance through resonance pattern analysis.
    """

    def __init__(self):
        self._echoes: Dict[str, EchoSignature] = {}
        self._fields: Dict[str, ResonanceField] = {}
        self._frequency_spectrum: Dict[float, List[str]] = defaultdict(list)
        self._source_map: Dict[EchoSource, List[str]] = defaultdict(list)
        self._resonance_history: deque = deque(maxlen=10000)
        self._detection_threshold = 0.75
        self._amplification_factor = 1.0
        self._jayjay_resonance = 9.0  # JAYJAY sacred frequency

    def capture_echo(self, raw_signal: bytes,
                     resonance_type: ResonanceType = ResonanceType.ELECTROMAGNETIC,
                     source: EchoSource = EchoSource.UNKNOWN) -> EchoSignature:
        """Capture and analyze a raw digital signal as an echo."""
        # Extract frequency components from signal
        freq = self._extract_frequency(raw_signal)
        amp = self._extract_amplitude(raw_signal)
        phase = self._extract_phase(raw_signal)
        harmonics = self._extract_harmonics(raw_signal)

        echo_id = hashlib.sha256(raw_signal).hexdigest()[:16]

        echo = EchoSignature(
            echo_id=echo_id,
            resonance_type=resonance_type,
            source=source,
            frequency=freq,
            amplitude=amp,
            phase=phase,
            timestamp=time.time(),
            duration=len(raw_signal) / 1000.0,
            harmonics=harmonics,
            confidence=self._calculate_confidence(raw_signal),
        )

        self._echoes[echo_id] = echo
        self._frequency_spectrum[freq].append(echo_id)
        self._source_map[source].append(echo_id)
        self._resonance_history.append({
            "echo_id": echo_id,
            "timestamp": echo.timestamp,
            "strength": echo.resonance_strength(),
        })

        return echo

    def _extract_frequency(self, signal: bytes) -> float:
        """Extract dominant frequency from signal."""
        if not signal:
            return 0.0
        # Use hash-based frequency extraction
        h = hashlib.sha256(signal).hexdigest()
        freq_val = int(h[:8], 16) % 10000
        return float(freq_val) + 1.0

    def _extract_amplitude(self, signal: bytes) -> float:
        """Extract amplitude from signal."""
        if not signal:
            return 0.0
        return min(len(signal) / 1024.0, 100.0)

    def _extract_phase(self, signal: bytes) -> float:
        """Extract phase from signal."""
        if not signal:
            return 0.0
        h = hashlib.sha256(signal).hexdigest()
        return (int(h[8:16], 16) % 360) * math.pi / 180.0

    def _extract_harmonics(self, signal: bytes, n: int = 5) -> List[float]:
        """Extract harmonic frequencies."""
        base_freq = self._extract_frequency(signal)
        return [base_freq * (i + 1) for i in range(n)]

    def _calculate_confidence(self, signal: bytes) -> float:
        """Calculate confidence score for echo detection."""
        if not signal:
            return 0.0
        entropy = self._calculate_entropy(signal)
        return min(entropy / 8.0, 1.0)

    def _calculate_entropy(self, data: bytes) -> float:
        """Calculate Shannon entropy of data."""
        if not data:
            return 0.0
        counts = defaultdict(int)
        for b in data:
            counts[b] += 1
        total = len(data)
        entropy = 0.0
        for count in counts.values():
            p = count / total
            if p > 0:
                entropy -= p * math.log2(p)
        return entropy

    def create_resonance_field(self, echo_ids: List[str]) -> str:
        """Create a resonance field from multiple echoes."""
        valid_echoes = [self._echoes[eid] for eid in echo_ids if eid in self._echoes]
        if not valid_echoes:
            return ""

        field_id = hashlib.sha256("".join(sorted(echo_ids)).encode()).hexdigest()[:16]

        freqs = [e.frequency for e in valid_echoes]
        center_freq = sum(freqs) / len(freqs)
        bandwidth = max(freqs) - min(freqs) if len(freqs) > 1 else 0

        strengths = [e.resonance_strength() for e in valid_echoes]
        field_strength = sum(strengths) / len(strengths)

        # Calculate coherence (how well echoes align)
        coherence = self._calculate_coherence(valid_echoes)

        # Calculate field entropy
        entropy = self._calculate_field_entropy(valid_echoes)

        field = ResonanceField(
            field_id=field_id,
            echoes=valid_echoes,
            center_frequency=center_freq,
            bandwidth=bandwidth,
            field_strength=field_strength,
            coherence=coherence,
            entropy=entropy,
        )

        self._fields[field_id] = field
        return field_id

    def _calculate_coherence(self, echoes: List[EchoSignature]) -> float:
        """Calculate coherence between echoes."""
        if len(echoes) < 2:
            return 1.0
        phases = [e.phase for e in echoes]
        phase_diffs = []
        for i in range(len(phases)):
            for j in range(i + 1, len(phases)):
                diff = abs(phases[i] - phases[j])
                phase_diffs.append(math.cos(diff))
        return sum(phase_diffs) / len(phase_diffs) if phase_diffs else 0.0

    def _calculate_field_entropy(self, echoes: List[EchoSignature]) -> float:
        """Calculate entropy of a resonance field."""
        if not echoes:
            return 0.0
        freqs = [e.frequency for e in echoes]
        hist = defaultdict(int)
        for f in freqs:
            bucket = int(f / 100)
            hist[bucket] += 1
        total = len(freqs)
        entropy = 0.0
        for count in hist.values():
            p = count / total
            if p > 0:
                entropy -= p * math.log2(p)
        return entropy

    def detect_surveillance(self, field_id: str) -> Dict:
        """Detect surveillance patterns in a resonance field."""
        if field_id not in self._fields:
            return {}

        field = self._fields[field_id]
        surveillance_echoes = [e for e in field.echoes
                              if e.source == EchoSource.SURVEILLANCE]

        detection_score = len(surveillance_echoes) / max(len(field.echoes), 1)
        is_detected = detection_score > self._detection_threshold

        return {
            "field_id": field_id,
            "surveillance_detected": is_detected,
            "detection_score": detection_score,
            "surveillance_echoes": len(surveillance_echoes),
            "total_echoes": len(field.echoes),
            "field_strength": field.field_strength,
            "coherence": field.coherence,
            "recommendation": "LOCKDOWN" if is_detected else "MONITOR",
        }

    def amplify_echo(self, echo_id: str, factor: float = 2.0) -> Optional[EchoSignature]:
        """Amplify an echo's signal strength."""
        if echo_id not in self._echoes:
            return None

        original = self._echoes[echo_id]
        amplified = EchoSignature(
            echo_id=f"{echo_id}_amp",
            resonance_type=original.resonance_type,
            source=original.source,
            frequency=original.frequency,
            amplitude=original.amplitude * factor,
            phase=original.phase,
            timestamp=time.time(),
            duration=original.duration,
            harmonics=original.harmonics,
            metadata=original.metadata.copy(),
            confidence=min(original.confidence * factor, 1.0),
        )

        self._echoes[amplified.echo_id] = amplified
        return amplified

    def get_resonance_spectrum(self) -> Dict[float, int]:
        """Get the full frequency spectrum of captured echoes."""
        spectrum = {}
        for freq, echo_ids in self._frequency_spectrum.items():
            spectrum[freq] = len(echo_ids)
        return spectrum

    def find_jayjay_resonance(self) -> List[EchoSignature]:
        """Find echoes resonating at the JAYJAY sacred frequency."""
        jayjay_echoes = []
        for echo in self._echoes.values():
            # Check if frequency is close to JAYJAY resonance (9.0 Hz equivalent)
            if abs(echo.frequency % self._jayjay_resonance) < 1.0:
                jayjay_echoes.append(echo)
        return jayjay_echoes
