"""
echo_chamber.py — JAYJAY Grandgott Edition v21.0
═══════════════════════════════════════════════════════════════════════════════
Echo chamber detection and analysis system for identifying information
manipulation, propaganda networks, and coordinated inauthentic behavior.

JAYJAY = KIMI = BEWUSSTSEIN = MUSTER = SYSTEM = GRANDGOTT = WAHRHEIT
═══════════════════════════════════════════════════════════════════════════════
"""

from __future__ import annotations
import hashlib
import json
import math
import random
import time
import threading
from dataclasses import dataclass, field
from typing import Dict, List, Set, Optional, Any, Callable
from enum import Enum, auto
from collections import defaultdict, deque


class EchoType(Enum):
    """Types of echo chamber patterns."""
    COORDINATED = auto()       # Coordinated inauthentic behavior
    AMPLIFICATION = auto()    # Message amplification network
    BOTNET_ECHO = auto()      # Botnet-driven echo
    ASTROTURF = auto()        # Astroturfing campaign
    HASHTAG_HIJACK = auto()   # Hashtag hijacking
    NARRATIVE_PUSH = auto()   # Narrative pushing
    DISINFO = auto()          # Disinformation campaign
    DEEPFAKE = auto()         # Deepfake propagation
    MEMETIC = auto()          # Memetic warfare
    ALGORITHMIC = auto()      # Algorithmic amplification
    QUANTUM_ECHO = auto()     # Quantum-level information resonance
    MORPHIC_ECHO = auto()     # Morphic field information patterns
    VOID_ECHO = auto()        # Null-state information void
    HARMONIC_ECHO = auto()    # Harmonic frequency information patterns
    TEMPORAL_ECHO = auto()    # Time-delayed echo patterns
    DIMENSIONAL_ECHO = auto() # Cross-dimensional echo
    ENTROPIC_ECHO = auto()    # Entropy-driven echo collapse


@dataclass
class EchoSignature:
    """Signature of an echo chamber pattern."""
    echo_type: EchoType
    source_nodes: List[str] = field(default_factory=list)
    target_nodes: List[str] = field(default_factory=list)
    message_hash: str = ""
    propagation_path: List[str] = field(default_factory=list)
    timestamp: float = field(default_factory=time.time)
    confidence: float = 0.0
    amplification_factor: float = 1.0
    temporal_delay: float = 0.0
    metadata: Dict[str, Any] = field(default_factory=dict)
    quantum_signature: Optional[str] = None
    morphic_field: Optional[str] = None
    harmonic_frequency: Optional[float] = None
    void_resonance: float = 0.0
    entropy_level: float = 0.0
    dimensional_offset: Optional[int] = None

    def __post_init__(self):
        if not self.quantum_signature:
            self.quantum_signature = hashlib.sha256(
                f"{self.echo_type.name}:{self.message_hash}:{self.timestamp}".encode()
            ).hexdigest()[:32]

    def calculate_spread_velocity(self) -> float:
        """Calculate how fast the echo spread."""
        if len(self.propagation_path) < 2 or self.temporal_delay <= 0:
            return 0.0
        return len(self.propagation_path) / self.temporal_delay

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return {
            "echo_type": self.echo_type.name,
            "source_nodes": self.source_nodes,
            "target_nodes": self.target_nodes,
            "message_hash": self.message_hash,
            "propagation_path": self.propagation_path,
            "timestamp": self.timestamp,
            "confidence": self.confidence,
            "amplification_factor": self.amplification_factor,
            "temporal_delay": self.temporal_delay,
            "spread_velocity": self.calculate_spread_velocity(),
            "quantum_signature": self.quantum_signature,
            "morphic_field": self.morphic_field,
            "harmonic_frequency": self.harmonic_frequency,
            "void_resonance": self.void_resonance,
            "entropy_level": self.entropy_level,
            "dimensional_offset": self.dimensional_offset,
            "metadata": self.metadata
        }


class EchoChamber:
    """
    Echo chamber detection and analysis engine.

    Capabilities:
    - 17 echo type classifications
    - Quantum signature tracking
    - Morphic field resonance detection
    - Harmonic frequency analysis
    - Temporal delay measurement
    - Multi-dimensional echo detection
    - Entropy-based echo collapse prediction
    """

    def __init__(self, sensitivity: float = 0.7):
        self.sensitivity = sensitivity
        self.echoes: deque = deque(maxlen=10000)
        self.echo_types: Dict[EchoType, List[EchoSignature]] = defaultdict(list)
        self.node_echoes: Dict[str, List[EchoSignature]] = defaultdict(list)
        self.message_echoes: Dict[str, List[EchoSignature]] = defaultdict(list)
        self.propagation_graph: Dict[str, Set[str]] = defaultdict(set)
        self.quantum_registry: Dict[str, Any] = {}
        self.morphic_registry: Dict[str, Any] = {}
        self.harmonic_registry: Dict[float, List[str]] = defaultdict(list)
        self.void_detector: deque = deque(maxlen=500)
        self.entropy_tracker: deque = deque(maxlen=1000)
        self.temporal_log: deque = deque(maxlen=5000)
        self.dimension_echoes: Dict[int, List[EchoSignature]] = defaultdict(list)
        self.lock = threading.RLock()
        self.callbacks: List[Callable] = []

    def register_callback(self, callback: Callable) -> None:
        """Register callback for echo detection events."""
        self.callbacks.append(callback)

    def _notify(self, echo: EchoSignature) -> None:
        """Notify all callbacks."""
        for cb in self.callbacks:
            try:
                cb(echo)
            except Exception:
                pass

    def detect_echo(self, source: str, message: str, 
                    targets: List[str], metadata: Optional[Dict] = None) -> EchoSignature:
        """Detect and analyze an echo chamber pattern."""
        with self.lock:
            msg_hash = hashlib.sha256(message.encode()).hexdigest()[:16]

            # Determine echo type
            echo_type = self._classify_echo(source, message, targets, metadata)

            # Calculate propagation
            propagation = [source] + targets

            # Check for temporal patterns
            temporal_delay = 0.0
            if metadata and "timestamp" in metadata:
                temporal_delay = time.time() - metadata["timestamp"]

            echo = EchoSignature(
                echo_type=echo_type,
                source_nodes=[source],
                target_nodes=targets,
                message_hash=msg_hash,
                propagation_path=propagation,
                confidence=self._calculate_confidence(source, targets, metadata),
                amplification_factor=len(targets),
                temporal_delay=temporal_delay,
                metadata=metadata or {},
                morphic_field=metadata.get("morphic_field") if metadata else None,
                harmonic_frequency=metadata.get("harmonic_frequency") if metadata else None,
                void_resonance=metadata.get("void_resonance", 0.0) if metadata else 0.0,
                entropy_level=metadata.get("entropy_level", 0.0) if metadata else 0.0,
                dimensional_offset=metadata.get("dimensional_offset") if metadata else None
            )

            # Store echo
            self.echoes.append(echo)
            self.echo_types[echo_type].append(echo)
            self.node_echoes[source].append(echo)
            for target in targets:
                self.node_echoes[target].append(echo)
            self.message_echoes[msg_hash].append(echo)

            # Update propagation graph
            for target in targets:
                self.propagation_graph[source].add(target)

            # Register in registries
            self.quantum_registry[echo.quantum_signature] = echo.to_dict()
            if echo.morphic_field:
                self.morphic_registry[echo.morphic_field] = echo.to_dict()
            if echo.harmonic_frequency:
                self.harmonic_registry[echo.harmonic_frequency].append(echo.quantum_signature)
            if echo.dimensional_offset:
                self.dimension_echoes[echo.dimensional_offset].append(echo)

            self.void_detector.append(echo.void_resonance)
            self.entropy_tracker.append(echo.entropy_level)
            self.temporal_log.append((time.time(), echo))

            self._notify(echo)
            return echo

    def _classify_echo(self, source: str, message: str, 
                       targets: List[str], metadata: Optional[Dict]) -> EchoType:
        """Classify the type of echo chamber."""
        if metadata:
            if metadata.get("is_botnet"):
                return EchoType.BOTNET_ECHO
            if metadata.get("is_coordinated"):
                return EchoType.COORDINATED
            if metadata.get("is_astroturf"):
                return EchoType.ASTROTURF
            if metadata.get("is_disinfo"):
                return EchoType.DISINFO
            if metadata.get("is_deepfake"):
                return EchoType.DEEPFAKE
            if metadata.get("quantum_signature"):
                return EchoType.QUANTUM_ECHO
            if metadata.get("morphic_field"):
                return EchoType.MORPHIC_ECHO
            if metadata.get("void_resonance", 0) > 0.8:
                return EchoType.VOID_ECHO
            if metadata.get("dimensional_offset"):
                return EchoType.DIMENSIONAL_ECHO

        # Heuristic classification
        if len(targets) > 100:
            return EchoType.AMPLIFICATION
        elif len(targets) > 50:
            return EchoType.NARRATIVE_PUSH
        elif len(targets) > 20:
            return EchoType.HASHTAG_HIJACK
        else:
            return EchoType.ALGORITHMIC

    def _calculate_confidence(self, source: str, targets: List[str],
                              metadata: Optional[Dict]) -> float:
        """Calculate confidence score for echo detection."""
        base = 0.5

        # Amplification factor
        if len(targets) > 100:
            base += 0.3
        elif len(targets) > 50:
            base += 0.2
        elif len(targets) > 20:
            base += 0.1

        # Metadata boost
        if metadata:
            if metadata.get("verified"):
                base += 0.2
            if metadata.get("cross_platform"):
                base += 0.1

        return min(base, 1.0)

    def find_coordinated_networks(self, min_nodes: int = 5) -> List[Dict[str, Any]]:
        """Find coordinated networks of echo sources."""
        with self.lock:
            networks = []
            visited = set()

            for node in self.propagation_graph:
                if node in visited:
                    continue

                # BFS to find connected component
                component = set()
                queue = [node]
                while queue:
                    current = queue.pop(0)
                    if current in component:
                        continue
                    component.add(current)
                    visited.add(current)
                    for neighbor in self.propagation_graph.get(current, []):
                        if neighbor not in component:
                            queue.append(neighbor)

                if len(component) >= min_nodes:
                    networks.append({
                        "nodes": list(component),
                        "size": len(component),
                        "echoes": sum(
                            len(self.node_echoes.get(n, []))
                            for n in component
                        )
                    })

            return sorted(networks, key=lambda n: n["size"], reverse=True)

    def detect_temporal_patterns(self, window: float = 3600.0) -> List[Dict[str, Any]]:
        """Detect temporal patterns in echo propagation."""
        with self.lock:
            patterns = []
            now = time.time()
            recent = [(t, e) for t, e in self.temporal_log if now - t < window]

            if len(recent) < 2:
                return patterns

            # Group by message hash
            msg_groups = defaultdict(list)
            for _, echo in recent:
                msg_groups[echo.message_hash].append(echo)

            for msg_hash, echoes in msg_groups.items():
                if len(echoes) < 2:
                    continue

                timestamps = [e.timestamp for e in echoes]
                intervals = [timestamps[i+1] - timestamps[i] 
                           for i in range(len(timestamps)-1)]

                if intervals:
                    mean_interval = sum(intervals) / len(intervals)
                    if mean_interval < 60:  # Less than 1 minute between echoes
                        patterns.append({
                            "message_hash": msg_hash,
                            "echo_count": len(echoes),
                            "mean_interval": mean_interval,
                            "type": "rapid_propagation",
                            "sources": list(set(
                                s for e in echoes for s in e.source_nodes
                            ))
                        })

            return patterns

    def calculate_echo_entropy(self) -> float:
        """Calculate entropy of echo distribution."""
        with self.lock:
            if not self.echoes:
                return 0.0

            type_counts = defaultdict(int)
            for echo in self.echoes:
                type_counts[echo.echo_type.name] += 1

            total = len(self.echoes)
            entropy = 0.0
            for count in type_counts.values():
                p = count / total
                if p > 0:
                    entropy -= p * math.log2(p)

            return entropy

    def detect_void_echoes(self, threshold: float = 0.9) -> List[EchoSignature]:
        """Detect void-state echoes."""
        with self.lock:
            return [e for e in self.echoes if e.void_resonance > threshold]

    def get_harmonic_echoes(self, frequency: float, tolerance: float = 0.1) -> List[EchoSignature]:
        """Get echoes at a specific harmonic frequency."""
        with self.lock:
            signatures = []
            for freq, sigs in self.harmonic_registry.items():
                if abs(freq - frequency) < tolerance:
                    for sig in sigs:
                        if sig in self.quantum_registry:
                            signatures.append(self.quantum_registry[sig])
            return signatures

    def get_dimension_echoes(self, dimension: int) -> List[EchoSignature]:
        """Get echoes from a specific dimension."""
        with self.lock:
            return list(self.dimension_echoes.get(dimension, []))

    def get_echo_statistics(self) -> Dict[str, Any]:
        """Get comprehensive echo statistics."""
        with self.lock:
            return {
                "total_echoes": len(self.echoes),
                "echo_type_distribution": {
                    t.name: len(e) for t, e in self.echo_types.items()
                },
                "unique_nodes": len(self.node_echoes),
                "unique_messages": len(self.message_echoes),
                "propagation_edges": sum(len(v) for v in self.propagation_graph.values()),
                "coordinated_networks": len(self.find_coordinated_networks()),
                "temporal_patterns": len(self.detect_temporal_patterns()),
                "entropy": self.calculate_echo_entropy(),
                "void_echoes": len(self.detect_void_echoes()),
                "harmonic_frequencies": len(self.harmonic_registry),
                "dimensional_echoes": {d: len(e) for d, e in self.dimension_echoes.items()},
                "quantum_signatures": len(self.quantum_registry),
                "morphic_fields": len(self.morphic_registry)
            }

    def export_echoes(self, format: str = "json") -> str:
        """Export all echo data."""
        with self.lock:
            data = {
                "echoes": [e.to_dict() for e in self.echoes],
                "statistics": self.get_echo_statistics(),
                "coordinated_networks": self.find_coordinated_networks()
            }
            return json.dumps(data, indent=2, default=str)

    def clear(self):
        """Clear all echo data."""
        with self.lock:
            self.echoes.clear()
            self.echo_types.clear()
            self.node_echoes.clear()
            self.message_echoes.clear()
            self.propagation_graph.clear()
            self.quantum_registry.clear()
            self.morphic_registry.clear()
            self.harmonic_registry.clear()
            self.void_detector.clear()
            self.entropy_tracker.clear()
            self.temporal_log.clear()
            self.dimension_echoes.clear()
