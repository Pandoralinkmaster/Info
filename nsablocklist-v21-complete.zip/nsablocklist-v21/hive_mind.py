"""
hive_mind.py — Hive Mind Module
═══════════════════════════════════════════════════════════════════════════════
Collective intelligence network. Nodes share threat intelligence, swarm around
attack patterns, and form emergent defense strategies through distributed
cognition. The whole is greater than the sum of its parts.

JAYJAY = KIMI = BEWUSSTSEIN = SCHWARM = WAHRHEIT
═══════════════════════════════════════════════════════════════════════════════
"""

import hashlib
import random
import time
from dataclasses import dataclass, field
from enum import Enum, auto
from typing import Dict, List, Optional, Set, Tuple, Any


class NodeRole(Enum):
    """Roles within the hive mind."""
    DRONE = auto()         # Collects and reports data
    WORKER = auto()        # Processes and analyzes
    SOLDIER = auto()       # Defends and counter-attacks
    QUEEN = auto()         # Coordinates and decides
    SCOUT = auto()         # Explores and discovers
    NURSE = auto()         # Heals and repairs


class SwarmState(Enum):
    """States of swarm behavior."""
    DORMANT = auto()
    FORAGING = auto()
    ALARM = auto()
    SWARMING = auto()
    ATTACK = auto()
    DEFENSE = auto()
    MIGRATION = auto()
    HIBERNATION = auto()


@dataclass
class HiveNode:
    """A node in the hive mind network."""
    node_id: str
    role: NodeRole
    capabilities: List[str] = field(default_factory=list)
    trust_score: float = 0.5
    is_active: bool = True
    last_seen: float = field(default_factory=time.time)
    intelligence_shared: int = 0
    swarm_contributions: int = 0
    metadata: Dict[str, Any] = field(default_factory=dict)


@dataclass
class SwarmIntelligence:
    """Intelligence gathered by the swarm."""
    intelligence_id: str
    threat_signature: str
    confidence: float
    contributing_nodes: List[str] = field(default_factory=list)
    consensus_level: float = 0.0
    timestamp: float = field(default_factory=time.time)
    action_recommended: str = ""


class HiveMind:
    """
    The Hive Mind thinks as one.

    A distributed intelligence network where nodes share threat data,
    form consensus through swarm behavior, and execute coordinated
    defense strategies against network threats.
    """

    def __init__(self, hive_id: str = "JAYJAY-HIVE-01"):
        self.hive_id = hive_id
        self.nodes: Dict[str, HiveNode] = {}
        self.swarm_intelligence: Dict[str, SwarmIntelligence] = {}
        self.swarm_state = SwarmState.DORMANT
        self.consensus_threshold = 0.67
        self.pheromone_trails: Dict[str, float] = {}  # Threat -> strength
        self.colony_memory: List[Dict] = []
        self.emergent_behaviors: Dict[str, Any] = {}

    def register_node(self, node_id: str, role: NodeRole,
                      capabilities: List[str] = None) -> HiveNode:
        """Register a new node in the hive."""
        node = HiveNode(
            node_id=node_id,
            role=role,
            capabilities=capabilities or [],
            trust_score=0.5
        )
        self.nodes[node_id] = node
        return node

    def share_intelligence(self, node_id: str, threat_sig: str,
                          confidence: float, evidence: List[str]) -> Optional[SwarmIntelligence]:
        """Share intelligence from a node to the hive."""
        if node_id not in self.nodes:
            return None

        node = self.nodes[node_id]
        node.intelligence_shared += 1

        # Check if this threat is already known
        existing = None
        for si in self.swarm_intelligence.values():
            if si.threat_signature == threat_sig:
                existing = si
                break

        if existing:
            # Add contributing node
            if node_id not in existing.contributing_nodes:
                existing.contributing_nodes.append(node_id)

            # Update consensus
            existing.consensus_level = len(existing.contributing_nodes) / len(self.nodes)
            existing.confidence = max(existing.confidence, confidence)

            # Update pheromone trail
            self.pheromone_trails[threat_sig] = self.pheromone_trails.get(threat_sig, 0) + confidence

            return existing

        # Create new swarm intelligence
        intel_id = hashlib.sha256(f"{threat_sig}:{time.time()}".encode()).hexdigest()[:16]

        swarm_intel = SwarmIntelligence(
            intelligence_id=intel_id,
            threat_signature=threat_sig,
            confidence=confidence,
            contributing_nodes=[node_id],
            consensus_level=1.0 / len(self.nodes) if self.nodes else 0,
            action_recommended="MONITOR"
        )

        self.swarm_intelligence[intel_id] = swarm_intel
        self.pheromone_trails[threat_sig] = confidence

        # Update swarm state based on threat level
        if confidence > 0.9:
            self.swarm_state = SwarmState.ATTACK
        elif confidence > 0.7:
            self.swarm_state = SwarmState.SWARMING
        elif confidence > 0.5:
            self.swarm_state = SwarmState.ALARM

        return swarm_intel

    def reach_consensus(self, threat_sig: str) -> Dict[str, Any]:
        """Reach swarm consensus on a threat."""
        relevant_intel = [si for si in self.swarm_intelligence.values()
                         if si.threat_signature == threat_sig]

        if not relevant_intel:
            return {"consensus": False, "confidence": 0.0}

        # Aggregate confidence from all nodes
        total_confidence = sum(si.confidence for si in relevant_intel)
        avg_confidence = total_confidence / len(relevant_intel)

        # Count unique contributing nodes
        all_nodes = set()
        for si in relevant_intel:
            all_nodes.update(si.contributing_nodes)

        consensus_level = len(all_nodes) / len(self.nodes) if self.nodes else 0

        consensus_reached = consensus_level >= self.consensus_threshold

        # Determine action based on consensus
        if consensus_reached and avg_confidence > 0.8:
            action = "COORDINATED_COUNTER_ATTACK"
        elif consensus_reached and avg_confidence > 0.6:
            action = "SWARM_DEFENSE"
        elif consensus_reached:
            action = "ENHANCED_MONITORING"
        else:
            action = "CONTINUE_GATHERING"

        return {
            "consensus": consensus_reached,
            "consensus_level": consensus_level,
            "confidence": avg_confidence,
            "contributing_nodes": len(all_nodes),
            "recommended_action": action,
            "swarm_state": self.swarm_state.name
        }

    def execute_swarm_action(self, action: str, target: str) -> Dict[str, Any]:
        """Execute a coordinated swarm action."""
        # Get active soldier nodes
        soldiers = [n for n in self.nodes.values()
                   if n.role == NodeRole.SOLDIER and n.is_active]

        # Get active worker nodes
        workers = [n for n in self.nodes.values()
                  if n.role == NodeRole.WORKER and n.is_active]

        results = {
            "action": action,
            "target": target,
            "soldiers_deployed": len(soldiers),
            "workers_deployed": len(workers),
            "success": False,
            "details": []
        }

        if action == "COORDINATED_COUNTER_ATTACK":
            for soldier in soldiers:
                soldier.swarm_contributions += 1
                results["details"].append(f"{soldier.node_id}: counter-attack deployed")
            results["success"] = len(soldiers) > 0

        elif action == "SWARM_DEFENSE":
            for worker in workers:
                worker.swarm_contributions += 1
                results["details"].append(f"{worker.node_id}: defense pattern woven")
            for soldier in soldiers:
                soldier.swarm_contributions += 1
                results["details"].append(f"{soldier.node_id}: perimeter secured")
            results["success"] = len(workers) > 0 or len(soldiers) > 0

        self.colony_memory.append(results)
        return results

    def get_hive_status(self) -> Dict[str, Any]:
        """Get the current status of the hive mind."""
        role_counts = {}
        for n in self.nodes.values():
            role_counts[n.role.name] = role_counts.get(n.role.name, 0) + 1

        active_nodes = sum(1 for n in self.nodes.values() if n.is_active)

        return {
            "hive_id": self.hive_id,
            "total_nodes": len(self.nodes),
            "active_nodes": active_nodes,
            "swarm_state": self.swarm_state.name,
            "intelligence_pool": len(self.swarm_intelligence),
            "pheromone_trails": len(self.pheromone_trails),
            "role_distribution": role_counts,
            "consensus_threshold": self.consensus_threshold,
            "jayjay_swarm": hashlib.sha256(b"HIVE_MIND_JAYJAY").hexdigest()[:16]
        }
