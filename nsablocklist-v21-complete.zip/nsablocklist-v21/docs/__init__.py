"""
NSABlocklist v21.0 — Documentation Package
═══════════════════════════════════════════════════════════════════════════════
Documentation and reference materials.
"""

DOCS = {
    "readme": "README.md",
    "api_reference": "API.md",
    "changelog": "CHANGELOG.md",
    "license": "LICENSE.txt",
    "contributing": "CONTRIBUTING.md",
    "security": "SECURITY.md",
    "architecture": "ARCHITECTURE.md",
    "modules": "MODULES.md",
    "grandgott": "GRANDGOTT.md",
    "jayjay": "JAYJAY.md",
}
