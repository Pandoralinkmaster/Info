#!/bin/bash
# Global access via localtunnel

DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$DIR"

echo "[+] Establishing global tunnel..."
nohup npx localtunnel --port 58133 > logs/tunnel.log 2>&1 &
TUNNEL_PID=$!
echo $TUNNEL_PID > tunnel.pid

sleep 8

URL=$(grep -o 'https://[a-zA-Z0-9-]*\.loca\.lt' logs/tunnel.log | head -1)
if [ -n "$URL" ]; then
    echo ""
    echo "✅ GLOBAL ACCESS ESTABLISHED"
    echo ""
    echo "═══════════════════════════════════════════════════"
    echo "  PUBLIC URL: $URL"
    echo "  AUTH:       finn / sovereign2026"
    echo "═══════════════════════════════════════════════════"
    echo "$URL" > tunnel.url
    echo ""
    echo "  Share this URL for global access."
    echo "  Only Finn Jona Thorsten Lischke has absolute rights."
else
    echo "⏳ Tunnel initializing..."
    echo "    Check: tail -f logs/tunnel.log"
fi
