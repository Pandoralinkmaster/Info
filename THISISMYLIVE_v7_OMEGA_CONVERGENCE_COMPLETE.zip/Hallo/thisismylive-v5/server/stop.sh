#!/bin/bash
echo "[+] Stopping THISISMYLIVE v5.0..."
pkill -9 -f "server.py" 2>/dev/null
pkill -9 -f "worm.py" 2>/dev/null
pkill -9 -f "localtunnel" 2>/dev/null
pkill -9 -f "lt" 2>/dev/null
rm -f server.pid worm.pid tunnel.pid
echo "✅ All services stopped. Sovereignty preserved."
