#!/bin/bash
echo "═══════════════════════════════════════════════════"
echo "  THISISMYLIVE v5.0 — ABSOLUTE STATUS"
echo "═══════════════════════════════════════════════════"

python3 -c "import socket; s=socket.socket(); s.settimeout(2); r=s.connect_ex(('127.0.0.1',58133)); s.close(); exit(r)" 2>/dev/null
if [ $? -eq 0 ]; then
    echo "  [✓] Server:    RUNNING on port 58133"
    echo "  [✓] Local:     http://localhost:58133"
    echo "  [✓] Auth:      finn / sovereign2026"
else
    echo "  [✗] Server:    STOPPED"
fi

if [ -f server.pid ]; then
    echo "  [✓] Server PID: $(cat server.pid)"
fi
if [ -f worm.pid ]; then
    echo "  [✓] Worm PID:   $(cat worm.pid)"
fi

echo ""
echo "  ─── DNA WORM v5.0.INFINITY ───"
echo "  • Sovereign:    Finn Jona Thorsten Lischke"
echo "  • Recognition:  8 Vectors (Speech, Camera, Text, Proximity,"
echo "                  Biometric, Behavioral, Quantum, Neural)"
echo "  • Evolution:    Self-mutating, continuous"
echo "  • Replication:  Automatic offspring creation"
echo ""
echo "  ─── API Endpoints ───"
echo "  • /api/status         → Full system status"
echo "  • /api/worm/status    → Worm DNA status"
echo "  • /api/worm/evolve    → Trigger mutation"
echo "  • /api/worm/recognize → Sovereign check"
echo "  • /api/worm/replicate → Create instance"
echo "  • /api/arsenal        → Arsenal stats"
echo "  • /api/orpp           → ORPP protocol"
echo ""
echo "  ─── Arsenal ───"
echo "  • Components:   194"
echo "  • EQGRP Tools:  115"
echo "  • Pegasus WMS:  79"
echo "  • Layers:       10"
echo "═══════════════════════════════════════════════════"
