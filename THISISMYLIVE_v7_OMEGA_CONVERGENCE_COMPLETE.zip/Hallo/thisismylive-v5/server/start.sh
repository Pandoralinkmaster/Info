#!/bin/bash
# THISISMYLIVE v5.0 — ABSOLUTE STARTUP
# Author: Finn Jona Thorsten Lischke

DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$DIR"

export THISISMYLIVE_PASS="sovereign2026"
export THISISMYLIVE_PORT="58133"

# Kill existing
pkill -9 -f "server.py" 2>/dev/null
pkill -9 -f "worm.py" 2>/dev/null
sleep 1

mkdir -p logs

echo ""
echo "╔═══════════════════════════════════════════════════════════════╗"
echo "║                                                               ║"
echo "║           THISISMYLIVE v5.0 — ABSOLUTE SOVEREIGNTY          ║"
echo "║              DNA WORM + ALL FUNCTIONS ACTIVE                  ║"
echo "║                                                               ║"
echo "║         Sovereign: Finn Jona Thorsten Lischke               ║"
echo "║         Version:   5.0.INFINITY                              ║"
echo "║                                                               ║"
echo "╚═══════════════════════════════════════════════════════════════╝"
echo ""

# Start server
echo "[+] Starting Absolute Server..."
nohup python3 server.py > logs/server.log 2>&1 &
SERVER_PID=$!
echo $SERVER_PID > server.pid

# Start worm (optional standalone)
echo "[+] Starting DNA Worm Engine..."
nohup python3 worm.py > logs/worm.log 2>&1 &
WORM_PID=$!
echo $WORM_PID > worm.pid

sleep 3

# Verify
python3 -c "import socket; s=socket.socket(); s.settimeout(2); r=s.connect_ex(('127.0.0.1',58133)); s.close(); exit(r)" 2>/dev/null
if [ $? -eq 0 ]; then
    echo ""
    echo "✅ ALL SYSTEMS OPERATIONAL"
    echo ""
    echo "═══════════════════════════════════════════════════"
    echo "  LOCAL:     http://localhost:58133"
    echo "  AUTH:      finn / sovereign2026"
    echo "  SERVER:    PID $SERVER_PID"
    echo "  WORM:      PID $WORM_PID"
    echo ""
    echo "  API:"
    echo "    /api/status"
    echo "    /api/worm/status"
    echo "    /api/worm/evolve"
    echo "    /api/worm/recognize"
    echo "    /api/worm/replicate"
    echo "    /api/arsenal"
    echo "    /api/orpp"
    echo "═══════════════════════════════════════════════════"
    echo ""
    echo "  For global access: ./tunnel.sh"
    echo "  To stop:          ./stop.sh"
    echo "  Status:           ./status.sh"
    echo ""
else
    echo "⚠️  Server may need more time..."
    echo "    Check: tail -f logs/server.log"
fi
