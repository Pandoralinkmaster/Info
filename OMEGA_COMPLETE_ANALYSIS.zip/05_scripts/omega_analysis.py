#!/usr/bin/env python3
# OMEGA Analysis Script
# Run: python3 omega_analysis.py

import json

with open('02_tier_results/all_tiers_complete.json', 'r') as f:
    data = json.load(f)

print("OMEGA Analysis loaded successfully!")
print(f"Hashes: {list(data.keys())}")
print(f"Tiers per hash: {len(data['OMEGA'])}")

# Example: Compare OMEGA anomalies
omega = data['OMEGA']
print(f"\nOMEGA Bit-Level:")
print(f"  Ones: {omega['tier_01_bit_level']['ones_pct']}%")
print(f"  Max Run-0: {omega['tier_01_bit_level']['max_run_0']}")
print(f"\nOMEGA Permutation:")
print(f"  Order: {omega['tier_07_permutation']['order']}")
print(f"  Inversions: {omega['tier_07_permutation']['inversions']}")
print(f"  Sign: {omega['tier_07_permutation']['sign']}")
