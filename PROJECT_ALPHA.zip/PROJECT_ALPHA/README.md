# Project Alpha v7.0

IoT Device Management Platform

## Quick Start

```bash
chmod +x bin/control.sh
./bin/control.sh start
```

## API

- `GET /api/status` — System status
- `GET /api/health` — Health check

## License

MIT
