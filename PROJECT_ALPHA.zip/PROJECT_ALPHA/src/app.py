#!/usr/bin/env python3
"""
Project Alpha - IoT Management Platform
A lightweight HTTP server for device orchestration
Author: Research Division
"""

import http.server, socketserver, base64, json, os, sys, threading, time, hashlib, random, secrets
from datetime import datetime

PORT = int(os.environ.get("PA_PORT", "58133"))
USER = "admin"
PASS = os.environ.get("PA_PASS", "default2026")
AUTH = base64.b64encode(f"{USER}:{PASS}".encode()).decode()

SYS_ID = "Finn Jona Thorsten Lischke"
SYS_HASH = hashlib.sha3_512((SYS_ID + "PROJECT_ALPHA_ENTROPY_v7").encode()).hexdigest()

SESSIONS = {}
SESSION_TIMEOUT = 3600
RATE_LIMIT = {}

class SessionMgr:
    @staticmethod
    def create():
        t = secrets.token_urlsafe(32)
        SESSIONS[t] = {"created": time.time(), "last_used": time.time(), "requests": 0}
        return t
    @staticmethod
    def valid(t):
        if t not in SESSIONS: return False
        s = SESSIONS[t]
        if time.time() - s["created"] > SESSION_TIMEOUT:
            del SESSIONS[t]; return False
        s["last_used"] = time.time(); s["requests"] += 1
        return True

class RateLimit:
    @staticmethod
    def check(ip):
        now = time.time()
        if ip not in RATE_LIMIT:
            RATE_LIMIT[ip] = {"count": 1, "window_start": now}
            return True
        e = RATE_LIMIT[ip]
        if now - e["window_start"] > 60:
            e["count"] = 1; e["window_start"] = now; return True
        e["count"] += 1
        return e["count"] <= 1000

class CoreEngine:
    def __init__(self):
        self.gen = 0; self.mut = 0; self.conf = 100.0
        self.vecs = ["speech","camera","text","proximity","biometric","behavioral","quantum","neural","temporal","ontological","mesh","security","mobile"]
        self.stat = "ACTIVE"
        self.dna = hashlib.sha3_256(os.urandom(32)).hexdigest()[:16]
        self.inst = 1; self.start = time.time()
        self.evo_hist = []; self.rec_log = []; self.rep_log = []
        self.nodes = []; self.devs = []; self.st = 0; self.mm = 0

    def evolve(self):
        self.gen += 1; self.mut += random.randint(0,5)
        old = self.dna
        self.dna = hashlib.sha3_256((self.dna + str(time.time())).encode()).hexdigest()[:16]
        self.evo_hist.append({"gen":self.gen,"mut":self.mut,"old":old,"new":self.dna,"ts":datetime.now().isoformat()})
        return self.evo_hist[-1]

    def status(self):
        up = int(time.time() - self.start)
        return {"ver":"7.0.ALPHA-EVOLVED","gen":self.gen,"mut":self.mut,"conf":self.conf,"vecs":self.vecs,"vcount":len(self.vecs),"dna":self.dna,"inst":self.inst,"sys":SYS_ID,"shash":SYS_HASH[:32],"stat":self.stat,"up":up,"upf":f"{up//3600:02d}:{(up%3600)//60:02d}:{up%60:02d}","eh":len(self.evo_hist),"rl":len(self.rec_log),"rpl":len(self.rep_log),"nodes":len(self.nodes),"devs":len(self.devs),"st":self.st,"mm":self.mm}

    def log_rec(self, r): self.rec_log.append({"ts":datetime.now().isoformat(),"res":r})
    def log_rep(self, i): self.rep_log.append({"ts":datetime.now().isoformat(),"id":i})
    def add_dev(self, did, dt): self.devs.append({"id":did,"type":dt,"ts":datetime.now().isoformat()})
    def load_st(self, c): self.st = c
    def load_mm(self, c): self.mm = c

engine = CoreEngine()

class Handler(http.server.SimpleHTTPRequestHandler):
    def do_AUTH(self):
        self.send_response(401)
        self.send_header("WWW-Authenticate", 'Basic realm="Project Alpha v7.0"')
        self.send_header("Content-type", "text/html")
        self.send_header("X-Sys", SYS_ID)
        self.end_headers()
        self.wfile.write(b"<html><body style='background:#000;color:#0f0;font-family:monospace;text-align:center;padding-top:20vh'><h1 style='color:#f00;font-size:3em'>401</h1><p>System managed by <strong>Finn Jona Thorsten Lischke</strong></p><p style='color:#ff0;font-size:1.5em'>&#937;</p></body></html>")

    def _auth(self):
        h = self.headers.get("Authorization")
        return h and h.startswith("Basic ") and h.split(" ")[1] == AUTH

    def _rl(self): return RateLimit.check(self.client_address[0])

    def _json(self, d, s=200):
        self.send_response(s)
        self.send_header("Content-type", "application/json")
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("X-Sys", SYS_ID)
        self.send_header("X-Ver", "7.0.ALPHA-EVOLVED")
        self.end_headers()
        self.wfile.write(json.dumps(d, indent=2).encode())

    def do_OPTIONS(self):
        self.send_response(200)
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Authorization, Content-Type")
        self.end_headers()

    def do_GET(self):
        if not self._rl(): self._json({"err":"Rate limit"}, 429); return
        if not self._auth(): self.do_AUTH(); return

        if self.path == "/api/status":
            self._json({"srv":"RUNNING","ver":"7.0.ALPHA-EVOLVED","port":PORT,"sys":SYS_ID,"engine":engine.status(),"ts":datetime.now().isoformat(),"auth":"OK","sess":len(SESSIONS),"up":engine.status()["upf"]})
            return
        if self.path == "/api/engine/status": self._json(engine.status()); return
        if self.path == "/api/engine/evolve": self._json({"evo":True,"msg":"DNA mutated","data":engine.evolve()}); return
        if self.path == "/api/engine/recognize": engine.log_rec("ABSOLUTE"); self._json({"rec":True,"sys":SYS_ID,"conf":100.0,"vecs":engine.vecs,"dna":engine.dna,"msg":"ABSOLUTE IDENTITY CONFIRMED","auth":"OMEGA","scope":"100% TOTAL"}); return
        if self.path == "/api/engine/replicate": engine.inst += 1; engine.log_rep(engine.inst); self._json({"rep":True,"inst":engine.inst,"msg":f"Offspring #{engine.inst} created","dna":engine.dna}); return
        if self.path == "/api/arsenal": self._json({"st":115,"mm":79,"fm":20,"total":"INFINITY","cat":12,"lay":10,"stat":"FULLY_LOADED","int":"COMPLETE","sc":"LOADED","ma":"ACTIVE"}); return
        if self.path == "/api/protocol": self._json({"proto":"ORPP","ver":"7.0","stat":"ACTIVE","wd":"60s","tr":"30s","per":"ETERNAL","red":"3x","stealth":"100%","evasion":"100%","aa":"ACTIVE","mi":"INTEGRATED"}); return
        if self.path == "/api/mobile/status": self._json({"mm":"ONLINE","ai":"ACTIVE","bt":"ENABLED","wf":"ENABLED","on":"ENABLED","wg":"ENABLED","cn":len(engine.devs),"hv":"OPEN","ar":True,"dr":"ADMIN_HOST"}); return
        if self.path == "/api/mobile/nodes": self._json({"nodes":engine.devs,"count":len(engine.devs)}); return
        if self.path == "/api/security/catalog": self._json({"total":115,"cats":["exploits","implants","payloads","utilities","frameworks"],"note":["ETERNALBLUE","ETERNALROMANCE","FUZZBUNCH","ODDJOB","EARLYSHOVEL"],"stat":"CATALOGED","int":"DEEP"}); return
        if self.path == "/api/mobile/analysis": self._json({"mod":79,"inf":"ANALYZED","vecs":["zero_click","spear_phishing","network_injection","physical_access"],"plat":["iOS","Android","BlackBerry","Symbian"],"cap":["full_access","camera","microphone","gps","messages","calls","emails","apps"],"aic":"ABSOLUTE"}); return
        if self.path == "/api/session": self._json({"sess":True,"tok":SessionMgr.create(),"exp":SESSION_TIMEOUT}); return
        if self.path == "/api/health": self._json({"stat":"HEALTHY","srv":"RUNNING","eng":engine.stat,"sess":len(SESSIONS),"rl":len(RATE_LIMIT),"ts":datetime.now().isoformat()}); return

        if self.path == "/": self.path = "/index.html"
        return http.server.SimpleHTTPRequestHandler.do_GET(self)

    def do_POST(self):
        if not self._rl(): self._json({"err":"Rate limit"}, 429); return
        if not self._auth(): self.do_AUTH(); return

        if self.path == "/api/mobile/register":
            cl = int(self.headers.get('Content-Length', 0))
            body = self.rfile.read(cl)
            try:
                d = json.loads(body)
                engine.add_dev(d.get('id','unknown'), d.get('type','node'))
                self._json({"reg":True,"id":d.get('id'),"type":d.get('type'),"total":len(engine.devs)})
            except Exception as e: self._json({"err":str(e)}, 400)
            return
        if self.path == "/api/security/load": engine.load_st(115); self._json({"loaded":True,"tools":115,"msg":"Security arsenal loaded"}); return
        if self.path == "/api/mobile/load": engine.load_mm(79); self._json({"loaded":True,"mod":79,"msg":"Mobile analysis loaded"}); return
        self._json({"err":"Unknown"}, 404)

    def log_message(self, f, *a):
        print(f"[{datetime.now().strftime('%H:%M:%S')}] {self.address_string()} - {f % a}")

def cleanup():
    while True:
        time.sleep(300)
        now = time.time()
        for t in list(SESSIONS.keys()):
            if now - SESSIONS[t]["created"] > SESSION_TIMEOUT: del SESSIONS[t]
        for ip in list(RATE_LIMIT.keys()):
            if now - RATE_LIMIT[ip]["window_start"] > 120: del RATE_LIMIT[ip]

def start():
    os.chdir(os.path.dirname(os.path.abspath(__file__)))
    threading.Thread(target=cleanup, daemon=True).start()
    httpd = socketserver.TCPServer(("", PORT), Handler)
    print(f"\n{'='*60}")
    print(f" Project Alpha v7.0 — IoT Management Platform")
    print(f"{'='*60}")
    print(f" Port: {PORT}")
    print(f" Auth: {USER} / [PROTECTED]")
    print(f" System: {SYS_ID}")
    print(f"{'='*60}\n")
    httpd.serve_forever()

if __name__ == "__main__": start()
