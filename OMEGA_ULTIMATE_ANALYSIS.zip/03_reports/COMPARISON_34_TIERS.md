# COMPARISON TABLE: ALL 34 TIERS

## Key Metrics Summary

| Metric | MD5_1 | MD5_2 | MD5_3 | OMEGA |
|--------|-------|-------|-------|-------|
| Hash | 99b7... | 621d... | 7565... | fca5... |
| Sum | 2150 | 1697 | 1923 | 1561 |
| Avg Byte | 134.4 | 106.1 | 120.2 | 97.6 |
| Variance | 3366.25 | 2959.36 | 3148.44 | 5156.25 |
| Ones % | 50.8% | 46.9% | 50.0% | **41.4%** |
| Entropy | 93.5% | 91.1% | 93.9% | 91.1% |
| QS=9 Count | 1 | 0 | 2 | **5** |
| Fibonacci | 0 | 0 | 0 | **4** |
| Primes | 3 | 6 | 6 | 4 |
| Permutation Order | 14 | 14 | 30 | **66** |
| Inversions | 60 | 44 | 58 | **79** |
| Lyapunov Max | 0.698 | 0.702 | 0.700 | **1.386** |
| Carnot Eff. | 91.8% | 94.9% | 97.8% | **100.0%** |
| Gini | 0.312 | 0.353 | 0.340 | **0.482** |
| Consonance | 60.0% | 73.3% | 60.0% | **86.7%** |
| Boomerang | 6 | 8 | 6 | **3** |
| Tensor Entropy | 2.776 | 2.860 | 2.684 | **2.904** |
| Euler Char (T30) | 13 | 17 | 22 | **27** |

## Anomaly Score

| Hash | Anomaly Score |
|------|--------------|
| MD5_1 | 2/34 |
| MD5_2 | 3/34 |
| MD5_3 | 2/34 |
| **OMEGA** | **28/34** |
