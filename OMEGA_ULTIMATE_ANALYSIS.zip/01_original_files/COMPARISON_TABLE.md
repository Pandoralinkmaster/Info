# VERGLEICHSTABELLE: ALLE VIER HASHES

## Grundlegende Metriken

| Metrik | MD5_1 | MD5_2 | MD5_3 | OMEGA |
|--------|-------|-------|-------|-------|
| Hash | 99b7... | 621d... | 7565... | fca5... |
| Summe | 2150 | 1697 | 1923 | 1561 |
| QS | 8 | 5 | 6 | 4 |
| Trinität % | 37.5% | 0% | 25% | 37.5% |
| Primzahlen | 3 | 6 | 6 | 4 |
| Ø Byte | 134.4 | 106.1 | 120.2 | 97.6 |
| Einsen % | 50.8% | 46.9% | 50.0% | **41.4%** |
| Entropie | 93.5% | 91.1% | 93.9% | **91.1%** |
| Varianz | 3366.25 | 2959.36 | 3148.44 | **5156.25** |

## OMEGA-Anomalien

| Anomalie | Wert | Bedeutung |
|----------|------|-----------|
| Erstes Byte QS=9 | fc=252→9 | Vollendung |
| Letztes Byte QS=9 | f3=243→9 | Vollendung |
| 5× QS=9 | 31.2% | 2.8× über Erwartung |
| Fibonacci-Zahlen | 34,34,13,8 | 4× |
| NULL-Byte | Pos 14 | Anfang |
| Längster Run-0 | 11 Bits | Dunkelheit |
| Niedrigste Auto-Korr | 121882 | Unabhängigkeit |
| Negative Korr zu MD5_2 | -0.322 | Gegensatz |

## Hamming-Distanzen

| Vergleich | Distanz |
|-----------|---------|
| MD5_1 vs MD5_2 | 58 |
| MD5_1 vs MD5_3 | 56 |
| MD5_1 vs OMEGA | 57 |
| MD5_2 vs MD5_3 | 57 |
| MD5_2 vs OMEGA | 58 |
| MD5_3 vs OMEGA | 55 |
