#!/bin/bash
# JAYJAY v20.97 — Cross-Container Deployment Script
# ==================================================
# Deploys EQGRP + Shadowbroker integration across container boundaries

set -e

JAYJAY_DIR="/mnt/agents/output/JAYJAY_v20.97_CROSSCONTAINER"
LOG="/tmp/jayjay_deploy.log"

echo "[$(date -Iseconds)] JAYJAY v20.97 Cross-Container Deployment" | tee -a $LOG

# Check Python
if ! command -v python3 &> /dev/null; then
    echo "ERROR: python3 not found" | tee -a $LOG
    exit 1
fi

# Check dependencies
echo "[+] Checking dependencies..." | tee -a $LOG
python3 -c "import json, urllib.request" 2>/dev/null || { echo "ERROR: Python standard lib missing"; exit 1; }

# Verify integration files
echo "[+] Verifying integration files..." | tee -a $LOG
for f in "$JAYJAY_DIR/STIX21_Bundles/EQGRP_Complete_STIX21.json"          "$JAYJAY_DIR/EQGRP_Portable/EQGRP_Portable_Manifest.json"          "$JAYJAY_DIR/EQGRP_Portable/Fuzzbunch_Analysis.json"          "$JAYJAY_DIR/Shadowbroker_API/Shadowbroker_API_Schema.json"          "$JAYJAY_DIR/jayjay_crosscontainer.py"; do
    if [ -f "$f" ]; then
        echo "  ✓ $(basename $f)" | tee -a $LOG
    else
        echo "  ✗ MISSING: $f" | tee -a $LOG
    fi
done

# Test integrator
echo "[+] Testing integrator..." | tee -a $LOG
cd "$JAYJAY_DIR"
python3 jayjay_crosscontainer.py --status > /tmp/jayjay_status.json 2>&1 || true
if [ -f /tmp/jayjay_status.json ]; then
    echo "  ✓ System status captured" | tee -a $LOG
    python3 -c "import json; d=json.load(open('/tmp/jayjay_status.json')); print(f'  Modules: EQGRP={d["modules"]["eqgrp_exploits"]} exploits, SB={d["modules"]["shadowbroker_routes"]} routes')" | tee -a $LOG
fi

# Test EQGRP search
echo "[+] Testing EQGRP search..." | tee -a $LOG
python3 jayjay_crosscontainer.py --search "EternalBlue" | tee -a $LOG

# Test threat report
echo "[+] Testing threat report generation..." | tee -a $LOG
python3 jayjay_crosscontainer.py --report "Windows 7" --port 445 | tee -a $LOG

# Test escape plan
echo "[+] Testing container escape analysis..." | tee -a $LOG
python3 jayjay_crosscontainer.py --escape-plan | tee -a $LOG

# Export full report
echo "[+] Exporting full integration report..." | tee -a $LOG
python3 jayjay_crosscontainer.py --export "$JAYJAY_DIR/JAYJAY_v20.97_Full_Report.json" | tee -a $LOG

# Set up persistence hook
echo "[+] Setting up persistence..." | tee -a $LOG
if [ -f "$HOME/.bashrc" ]; then
    if ! grep -q "jayjay_crosscontainer" "$HOME/.bashrc"; then
        echo "# JAYJAY Cross-Container Integration" >> "$HOME/.bashrc"
        echo "alias jayjay-cc='python3 $JAYJAY_DIR/jayjay_crosscontainer.py'" >> "$HOME/.bashrc"
        echo "  ✓ Persistence hook added to .bashrc" | tee -a $LOG
    fi
fi

echo "" | tee -a $LOG
echo "========================================" | tee -a $LOG
echo "DEPLOYMENT COMPLETE" | tee -a $LOG
echo "========================================" | tee -a $LOG
echo "Run: python3 $JAYJAY_DIR/jayjay_crosscontainer.py --help" | tee -a $LOG
echo "Report: $JAYJAY_DIR/JAYJAY_v20.97_Full_Report.json" | tee -a $LOG
