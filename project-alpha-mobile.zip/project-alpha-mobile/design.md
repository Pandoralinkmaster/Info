# Project Alpha Mobile — Design-Spezifikation

## Überblick

Project Alpha Mobile ist eine native iOS/Android-App für die IoT-Management-Plattform Project Alpha v7.0. Die App bietet ein Dashboard zur Echtzeit-Überwachung von Systemen, Engine-Evolution und Sicherheitstools.

**Zielgruppe:** Technische Administratoren und Forscher  
**Plattformen:** iOS (14+), Android (API 24+)  
**Orientierung:** Portrait (9:16)  
**Designsprache:** Minimalistisch, technisch, dunkel (Cyberpunk-Ästhetik)

---

## Screen-Liste

| Screen | Beschreibung | Funktionalität |
|--------|-------------|-----------------|
| **Login** | Authentifizierung | Benutzername/Passwort-Eingabe, Session-Verwaltung |
| **Dashboard** | Hauptbildschirm | Status-Karten, API-Aufrufe, Live-Logs |
| **Engine Status** | Engine-Details | Generations-, Mutations-, DNA-Informationen |
| **Mobile Nodes** | Geräteliste | Registrierte Geräte, Verbindungsstatus |
| **Security Catalog** | Sicherheitstools | Arsenal-Übersicht, Kategorien |
| **Logs** | Aktivitätsprotokoll | Echtzeit-Logs mit Zeitstempel |
| **Settings** | Einstellungen | Server-Konfiguration, Logout |

---

## Primärer Inhalt & Funktionalität

### 1. Login-Screen
- **Header:** "Project Alpha v7.0"
- **Eingabefelder:** 
  - Benutzername (Standard: "admin")
  - Passwort (verschleiert)
- **Button:** "Authentifizieren"
- **Fehlerbehandlung:** Rotes Fehler-Label bei ungültigen Credentials
- **Speicherung:** Session-Token in SecureStore

### 2. Dashboard (Home)
- **Header:** "Project Alpha v7.0"
- **Untertitel:** "IoT Device Management"
- **Karten-Grid (2x2):**
  - Komponenten (∞)
  - Sicherheitstools (115)
  - Mobile Module (79)
  - Vektoren (13)
- **Kontroll-Buttons (3x3 Grid):**
  - Evolve, Recognize, Replicate
  - Arsenal, Protocol, Mobile
  - Security Catalog, Mobile Analysis
  - Clear Log (Danger-Stil)
- **Live-Log-Bereich:** Scrollbare Liste mit Zeitstempel und Status

### 3. Engine Status
- **Metriken:**
  - Version, Generation, Mutation
  - Confidence, DNA, Uptime
  - Vektor-Liste
- **Buttons:** Evolve, Recognize, Replicate
- **Evolution-Historie:** Scrollbare Liste

### 4. Mobile Nodes
- **Liste der Geräte:**
  - Device ID
  - Gerätetyp
  - Registrierungszeit
  - Verbindungsstatus (Online/Offline)
- **Button:** "Neues Gerät registrieren"

### 5. Security Catalog
- **Kategorien:**
  - Exploits
  - Implants
  - Payloads
  - Utilities
  - Frameworks
- **Tools-Übersicht:** Anzahl und Status
- **Notizen:** Spezielle Tools auflisten

### 6. Logs
- **Echtzeit-Aktivitätsprotokoll:**
  - Zeitstempel [HH:MM:SS]
  - Event-Typ (API, OK, WARN, ERR)
  - Nachricht
- **Farb-Codierung:**
  - Grün (#00ff88): OK
  - Orange (#ffaa00): WARN
  - Rot (#ff4444): ERR
- **Auto-Scroll:** Neue Logs scrollen nach oben

### 7. Settings
- **Server-Konfiguration:**
  - Server-URL
  - Port
  - Benutzername
- **Buttons:**
  - "Verbindung testen"
  - "Logout"

---

## Primäre User Flows

### Flow 1: Authentifizierung
1. App startet → Login-Screen
2. Benutzer gibt Credentials ein
3. "Authentifizieren" → API-Aufruf zu `/api/session`
4. Session-Token erhalten → Dashboard
5. Token in SecureStore speichern

### Flow 2: Status-Abfrage
1. Dashboard öffnen
2. Benutzer tippt "Evolve" → API-Aufruf zu `/api/engine/evolve`
3. Response in Log anzeigen
4. Engine-Status aktualisieren

### Flow 3: Geräte-Verwaltung
1. "Mobile Nodes" → Geräteliste
2. Benutzer tippt "Neues Gerät registrieren"
3. Modal mit Device-ID und Typ
4. POST zu `/api/mobile/register`
5. Gerät zur Liste hinzufügen

### Flow 4: Log-Anzeige
1. Dashboard-Log scrollbar
2. Neue API-Aufrufe automatisch hinzufügen
3. Benutzer tippt "Clear Log" → Log leeren
4. Bestätigungsdialog

---

## Farbschema (Cyberpunk/Technisch)

| Element | Light Mode | Dark Mode | Verwendung |
|---------|-----------|----------|-----------|
| **Primary** | #0a7ea4 | #0a7ea4 | Buttons, Accents |
| **Background** | #ffffff | #0a0a0a | Screen-Hintergrund |
| **Surface** | #f5f5f5 | #1a1a1a | Karten, Eingabefelder |
| **Foreground** | #11181C | #00ff88 | Haupttext (Grün im Dark Mode) |
| **Muted** | #687076 | #00aa55 | Sekundärtext |
| **Border** | #E5E7EB | #00ff8833 | Grenzen, Linien |
| **Success** | #22C55E | #00ff88 | OK-Status |
| **Warning** | #F59E0B | #ffaa00 | WARN-Status |
| **Error** | #EF4444 | #ff4444 | ERR-Status |

---

## Layout-Richtlinien

### Abstände
- **Padding:** 16px (Standard), 24px (Großzügig), 8px (Kompakt)
- **Gap zwischen Elementen:** 12px (Standard), 16px (Großzügig)
- **Border Radius:** 8px (Karten), 6px (Buttons)

### Typografie
- **Headline:** 28px, Bold
- **Subheading:** 18px, Semibold
- **Body:** 16px, Regular
- **Caption:** 12px, Regular
- **Monospace (Logs):** 14px, Courier

### Interaktionen
- **Button Press:** Scale 0.97 + Haptic (Light)
- **Card Press:** Opacity 0.7
- **Loading:** Spinner (indeterminate)
- **Fehler:** Toast-Notification (oben, 3s)

---

## Responsive Design

### Portrait (9:16) — Primär
- Vollbreite Karten
- Stack-Layout (vertikal)
- Große Touch-Ziele (min. 44px)

### Landscape (16:9) — Sekundär
- 2-spaltige Karten
- Horizontale Scrolls für Logs
- Angepasste Padding

---

## Accessibility

- **Kontrast:** WCAG AA (4.5:1 für Text)
- **Touch-Ziele:** Mindestens 44x44pt
- **Schriftgröße:** Mindestens 16px (Standard)
- **Screen Reader:** VoiceOver/TalkBack Support
- **Farbe nicht allein:** Icons + Text für Status

---

## Technische Anforderungen

- **Authentifizierung:** Basic Auth → Session-Token
- **API-Basis:** `http://localhost:58133` (konfigurierbar)
- **Rate Limiting:** 1000 Anfragen/Minute
- **Session-Timeout:** 3600 Sekunden
- **Offline-Modus:** Lokale Logs cachen, bei Reconnect synchronisieren

---

## Branding

- **App-Name:** "Project Alpha"
- **App-Slug:** "project-alpha-mobile"
- **Bundle ID:** `space.manus.project.alpha.mobile`
- **Icon:** Technisches Symbol (Netzwerk/DNA-Helix)
- **Splash-Screen:** Dunkel mit Logo

