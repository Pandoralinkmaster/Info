import { ScrollView, Text, View, TouchableOpacity, ActivityIndicator, Alert } from "react-native";
import { useState, useEffect, useCallback } from "react";
import { ScreenContainer } from "@/components/screen-container";
import { useAuthContext } from "@/lib/auth-context";
import { useLogs } from "@/lib/use-logs";
import { useColors } from "@/hooks/use-colors";
import { useRouter } from "expo-router";

interface MetricCard {
  label: string;
  value: string | number;
  endpoint: string;
}

export default function DashboardScreen() {
  const router = useRouter();
  const { apiClient, logout } = useAuthContext();
  const { logs, addLog, clearLogs, addApiLog } = useLogs();
  const colors = useColors();

  const [metrics, setMetrics] = useState<MetricCard[]>([
    { label: "Components", value: "∞", endpoint: "arsenal" },
    { label: "Security Tools", value: 115, endpoint: "arsenal" },
    { label: "Mobile Modules", value: 79, endpoint: "mobile" },
    { label: "Vectors", value: 13, endpoint: "vectors" },
  ]);

  const [isLoading, setIsLoading] = useState(false);
  const [engineStatus, setEngineStatus] = useState<any>(null);

  // Load initial status
  useEffect(() => {
    loadStatus();
  }, []);

  const loadStatus = useCallback(async () => {
    if (!apiClient) return;

    try {
      setIsLoading(true);
      const status = await apiClient.getStatus();
      setEngineStatus(status.engine);
      addLog("System status loaded", "ok");
    } catch (err) {
      const errorMsg = err instanceof Error ? err.message : "Failed to load status";
      addLog(`Error: ${errorMsg}`, "err");
    } finally {
      setIsLoading(false);
    }
  }, [apiClient, addLog]);

  const callApi = useCallback(
    async (endpoint: string, apiCall: () => Promise<any>) => {
      if (!apiClient) return;

      try {
        setIsLoading(true);
        addLog(`Calling ${endpoint}...`, "ok", endpoint);
        const response = await apiCall();
        addApiLog(endpoint, response, false);
        // Update metrics if needed
        if (endpoint === "arsenal") {
          setMetrics((prev) =>
            prev.map((m) =>
              m.endpoint === "arsenal"
                ? { ...m, value: response.st || 115 }
                : m
            )
          );
        }
      } catch (err) {
        const errorMsg = err instanceof Error ? err.message : "API call failed";
        addApiLog(endpoint, { error: errorMsg }, true);
      } finally {
        setIsLoading(false);
      }
    },
    [apiClient, addLog, addApiLog]
  );

  const handleEvolve = () =>
    callApi("/api/engine/evolve", () => apiClient!.evolveEngine());

  const handleRecognize = () =>
    callApi("/api/engine/recognize", () => apiClient!.recognizeEngine());

  const handleReplicate = () =>
    callApi("/api/engine/replicate", () => apiClient!.replicateEngine());

  const handleArsenal = () =>
    callApi("/api/arsenal", () => apiClient!.getArsenal());

  const handleProtocol = () =>
    callApi("/api/protocol", () => apiClient!.getProtocol());

  const handleMobile = () =>
    callApi("/api/mobile/status", () => apiClient!.getMobileStatus());

  const handleSecurityCatalog = () =>
    callApi("/api/security/catalog", () => apiClient!.getSecurityCatalog());

  const handleMobileAnalysis = () =>
    callApi("/api/mobile/analysis", () => apiClient!.getMobileAnalysis());

  const handleClearLog = () => {
    Alert.alert("Clear Log", "Are you sure you want to clear the log?", [
      { text: "Cancel", style: "cancel" },
      {
        text: "Clear",
        style: "destructive",
        onPress: () => {
          clearLogs();
          addLog("Log cleared", "ok");
        },
      },
    ]);
  };

  const handleLogout = () => {
    Alert.alert("Logout", "Are you sure you want to logout?", [
      { text: "Cancel", style: "cancel" },
      {
        text: "Logout",
        style: "destructive",
        onPress: async () => {
          await logout();
          router.replace("/login");
        },
      },
    ]);
  };

  return (
    <ScreenContainer className="bg-background p-4">
      <ScrollView
        contentContainerStyle={{ flexGrow: 1 }}
        showsVerticalScrollIndicator={false}
      >
        {/* Header */}
        <View className="mb-6">
          <Text className="text-3xl font-bold text-foreground mb-1">
            Project Alpha
          </Text>
          <Text className="text-sm text-muted">v7.0 — IoT Management</Text>
        </View>

        {/* Metrics Grid */}
        <View className="gap-3 mb-6">
          <View className="flex-row gap-3">
            {metrics.slice(0, 2).map((metric, idx) => (
              <View
                key={idx}
                className="flex-1 bg-surface border border-border rounded-lg p-4"
              >
                <Text className="text-2xl font-bold text-foreground mb-1">
                  {metric.value}
                </Text>
                <Text className="text-xs text-muted uppercase tracking-wider">
                  {metric.label}
                </Text>
              </View>
            ))}
          </View>
          <View className="flex-row gap-3">
            {metrics.slice(2, 4).map((metric, idx) => (
              <View
                key={idx}
                className="flex-1 bg-surface border border-border rounded-lg p-4"
              >
                <Text className="text-2xl font-bold text-foreground mb-1">
                  {metric.value}
                </Text>
                <Text className="text-xs text-muted uppercase tracking-wider">
                  {metric.label}
                </Text>
              </View>
            ))}
          </View>
        </View>

        {/* Control Buttons */}
        <View className="gap-2 mb-6">
          {/* Row 1 */}
          <View className="flex-row gap-2">
            <TouchableOpacity
              onPress={handleEvolve}
              disabled={isLoading}
              className="flex-1 bg-surface border border-border rounded-lg py-3 items-center"
            >
              <Text className="text-foreground font-medium text-sm">Evolve</Text>
            </TouchableOpacity>
            <TouchableOpacity
              onPress={handleRecognize}
              disabled={isLoading}
              className="flex-1 bg-surface border border-border rounded-lg py-3 items-center"
            >
              <Text className="text-foreground font-medium text-sm">Recognize</Text>
            </TouchableOpacity>
            <TouchableOpacity
              onPress={handleReplicate}
              disabled={isLoading}
              className="flex-1 bg-surface border border-border rounded-lg py-3 items-center"
            >
              <Text className="text-foreground font-medium text-sm">Replicate</Text>
            </TouchableOpacity>
          </View>

          {/* Row 2 */}
          <View className="flex-row gap-2">
            <TouchableOpacity
              onPress={handleArsenal}
              disabled={isLoading}
              className="flex-1 bg-surface border border-border rounded-lg py-3 items-center"
            >
              <Text className="text-foreground font-medium text-sm">Arsenal</Text>
            </TouchableOpacity>
            <TouchableOpacity
              onPress={handleProtocol}
              disabled={isLoading}
              className="flex-1 bg-surface border border-border rounded-lg py-3 items-center"
            >
              <Text className="text-foreground font-medium text-sm">Protocol</Text>
            </TouchableOpacity>
            <TouchableOpacity
              onPress={handleMobile}
              disabled={isLoading}
              className="flex-1 bg-surface border border-border rounded-lg py-3 items-center"
            >
              <Text className="text-foreground font-medium text-sm">Mobile</Text>
            </TouchableOpacity>
          </View>

          {/* Row 3 */}
          <View className="flex-row gap-2">
            <TouchableOpacity
              onPress={handleSecurityCatalog}
              disabled={isLoading}
              className="flex-1 bg-surface border border-warning rounded-lg py-3 items-center"
            >
              <Text className="text-warning font-medium text-sm">Security</Text>
            </TouchableOpacity>
            <TouchableOpacity
              onPress={handleMobileAnalysis}
              disabled={isLoading}
              className="flex-1 bg-surface border border-warning rounded-lg py-3 items-center"
            >
              <Text className="text-warning font-medium text-sm">Analysis</Text>
            </TouchableOpacity>
            <TouchableOpacity
              onPress={handleClearLog}
              disabled={isLoading}
              className="flex-1 bg-surface border border-error rounded-lg py-3 items-center"
            >
              <Text className="text-error font-medium text-sm">Clear</Text>
            </TouchableOpacity>
          </View>
        </View>

        {/* Log Display */}
        <View className="bg-surface border border-border rounded-lg p-4 mb-6 max-h-64">
          <Text className="text-foreground font-semibold text-sm mb-3">
            Activity Log
          </Text>
          <ScrollView showsVerticalScrollIndicator={false}>
            {logs.length === 0 ? (
              <Text className="text-muted text-xs">No logs yet</Text>
            ) : (
              logs.map((log) => (
                <View key={log.id} className="mb-2">
                  <View className="flex-row gap-2">
                    <Text className="text-muted text-xs">[{log.timestamp}]</Text>
                    <Text
                      className={`text-xs flex-1 ${
                        log.level === "ok"
                          ? "text-success"
                          : log.level === "warn"
                          ? "text-warning"
                          : "text-error"
                      }`}
                    >
                      {log.message}
                    </Text>
                  </View>
                </View>
              ))
            )}
          </ScrollView>
        </View>

        {/* Footer */}
        <View className="border-t border-border pt-4 items-center gap-2">
          <Text className="text-muted text-xs">
            Project Alpha v7.0 — Research Platform
          </Text>
          <Text className="text-muted text-xs">
            Finn Jona Thorsten Lischke — Principal Researcher
          </Text>
          <TouchableOpacity
            onPress={handleLogout}
            className="mt-2 px-4 py-2 bg-error/10 border border-error rounded-lg"
          >
            <Text className="text-error text-xs font-medium">Logout</Text>
          </TouchableOpacity>
        </View>

        {isLoading && (
          <View className="absolute inset-0 bg-black/20 items-center justify-center rounded-lg">
            <ActivityIndicator color={colors.primary} size="large" />
          </View>
        )}
      </ScrollView>
    </ScreenContainer>
  );
}
