import React, { useState } from "react";
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  ScrollView,
  ActivityIndicator,
  Alert,
} from "react-native";
import { useRouter } from "expo-router";
import { ScreenContainer } from "@/components/screen-container";
import { useAuthContext } from "@/lib/auth-context";
import { useColors } from "@/hooks/use-colors";

export default function LoginScreen() {
  const router = useRouter();
  const { login, isLoading, error } = useAuthContext();
  const colors = useColors();

  const [baseURL, setBaseURL] = useState("http://localhost:58133");
  const [username, setUsername] = useState("admin");
  const [password, setPassword] = useState("default2026");
  const [localError, setLocalError] = useState<string | null>(null);

  const handleLogin = async () => {
    setLocalError(null);

    if (!baseURL.trim()) {
      setLocalError("Server URL is required");
      return;
    }

    if (!username.trim()) {
      setLocalError("Username is required");
      return;
    }

    if (!password.trim()) {
      setLocalError("Password is required");
      return;
    }

    try {
      await login(baseURL, username, password);
      router.replace("/(tabs)");
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : "Login failed";
      setLocalError(errorMessage);
      Alert.alert("Login Failed", errorMessage);
    }
  };

  const displayError = localError || error;

  return (
    <ScreenContainer
      className="bg-background"
      containerClassName="bg-background"
    >
      <ScrollView
        contentContainerStyle={{ flexGrow: 1 }}
        className="flex-1"
      >
        <View className="flex-1 justify-center px-6 py-8">
          {/* Header */}
          <View className="items-center mb-12">
            <Text className="text-4xl font-bold text-foreground mb-2">
              Project Alpha
            </Text>
            <Text className="text-base text-muted">v7.0 — IoT Management</Text>
            <Text className="text-sm text-muted mt-2">Authentication</Text>
          </View>

          {/* Error Message */}
          {displayError && (
            <View className="bg-error/10 border border-error rounded-lg p-3 mb-6">
              <Text className="text-error text-sm">{displayError}</Text>
            </View>
          )}

          {/* Form */}
          <View className="gap-4 mb-8">
            {/* Server URL */}
            <View>
              <Text className="text-muted text-sm mb-2 font-medium">
                Server URL
              </Text>
              <TextInput
                className="bg-surface border border-border rounded-lg px-4 py-3 text-foreground"
                placeholderTextColor={colors.muted}
                placeholder="http://localhost:58133"
                value={baseURL}
                onChangeText={setBaseURL}
                editable={!isLoading}
                autoCapitalize="none"
                keyboardType="url"
              />
            </View>

            {/* Username */}
            <View>
              <Text className="text-muted text-sm mb-2 font-medium">
                Username
              </Text>
              <TextInput
                className="bg-surface border border-border rounded-lg px-4 py-3 text-foreground"
                placeholderTextColor={colors.muted}
                placeholder="admin"
                value={username}
                onChangeText={setUsername}
                editable={!isLoading}
                autoCapitalize="none"
              />
            </View>

            {/* Password */}
            <View>
              <Text className="text-muted text-sm mb-2 font-medium">
                Password
              </Text>
              <TextInput
                className="bg-surface border border-border rounded-lg px-4 py-3 text-foreground"
                placeholderTextColor={colors.muted}
                placeholder="••••••••"
                value={password}
                onChangeText={setPassword}
                editable={!isLoading}
                secureTextEntry
              />
            </View>
          </View>

          {/* Login Button */}
          <TouchableOpacity
            onPress={handleLogin}
            disabled={isLoading}
            className={`rounded-lg py-4 items-center justify-center ${
              isLoading ? "opacity-50" : ""
            }`}
            style={{
              backgroundColor: colors.primary,
            }}
          >
            {isLoading ? (
              <ActivityIndicator color={colors.background} size="small" />
            ) : (
              <Text className="text-background font-semibold text-base">
                Authenticate
              </Text>
            )}
          </TouchableOpacity>

          {/* Info Text */}
          <View className="mt-12 pt-8 border-t border-border">
            <Text className="text-muted text-xs text-center leading-relaxed">
              Project Alpha v7.0 — IoT Device Management Platform
            </Text>
            <Text className="text-muted text-xs text-center mt-2">
              Finn Jona Thorsten Lischke — Principal Researcher
            </Text>
          </View>
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}
