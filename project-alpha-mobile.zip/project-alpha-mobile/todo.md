# Project Alpha Mobile — TODO

## Authentifizierung
- [x] Login-Screen implementieren (Benutzername/Passwort)
- [x] Session-Token Verwaltung (SecureStore)
- [x] Authentifizierungs-Hook (useAuth)
- [x] Protected Routes Setup

## Dashboard & UI
- [x] Dashboard-Screen mit Karten-Grid (4 Metriken)
- [x] Kontroll-Buttons (9 Buttons in 3x3 Grid)
- [x] Live-Log-Bereich mit Echtzeit-Updates
- [x] Farbschema anpassen (Cyberpunk/Dunkel)
- [x] Responsive Layout für Portrait/Landscape

## API-Integration
- [x] API-Client Setup (Basis-Auth)
- [x] `/api/status` Endpoint
- [x] `/api/engine/status` Endpoint
- [x] `/api/engine/evolve` Endpoint
- [x] `/api/engine/recognize` Endpoint
- [x] `/api/engine/replicate` Endpoint
- [x] `/api/arsenal` Endpoint
- [x] `/api/protocol` Endpoint
- [x] `/api/mobile/status` Endpoint
- [x] `/api/mobile/nodes` Endpoint
- [x] `/api/security/catalog` Endpoint
- [x] `/api/mobile/analysis` Endpoint
- [x] `/api/session` Endpoint (Session-Erstellung)

## Screens
- [ ] Engine Status Screen
- [ ] Mobile Nodes Screen (Geräteliste)
- [ ] Security Catalog Screen
- [ ] Logs Screen (Detaillierte Ansicht)
- [ ] Settings Screen (Server-Konfiguration)

## Funktionalität
- [x] API-Aufrufe mit Loading-States
- [x] Error-Handling & Toast-Notifications
- [x] Log-Verwaltung (Hinzufügen, Löschen, Scrollen)
- [ ] Geräte-Registrierung (Mobile Nodes)
- [ ] Evolution-Historie anzeigen
- [ ] Rate-Limiting Handling

## Styling & Polish
- [x] NativeWind Tailwind-Integration
- [x] Dark Mode Setup
- [x] Haptic Feedback auf Buttons
- [x] Loading-Spinner
- [x] Fehler-Dialoge
- [x] Bestätigungs-Dialoge

## Branding
- [ ] App-Logo generieren
- [x] App-Name in app.config.ts setzen
- [ ] Splash-Screen anpassen
- [ ] Icon-Mapping in icon-symbol.tsx

## Testing & Qualität
- [ ] End-to-End Login-Flow testen
- [ ] API-Aufrufe validieren
- [ ] Offline-Modus testen
- [ ] Responsive Design testen
- [ ] iOS & Android testen

## Deployment
- [ ] Checkpoint vor Veröffentlichung
- [ ] APK-Build generieren
- [ ] IPA-Build generieren
