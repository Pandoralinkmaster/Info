import { useState, useCallback } from "react";

export type LogLevel = "ok" | "warn" | "err";

export interface LogEntry {
  id: string;
  timestamp: string;
  level: LogLevel;
  message: string;
  endpoint?: string;
}

const MAX_LOGS = 100;

export function useLogs() {
  const [logs, setLogs] = useState<LogEntry[]>([
    {
      id: "init-1",
      timestamp: new Date().toLocaleTimeString("de-DE", {
        hour: "2-digit",
        minute: "2-digit",
        second: "2-digit",
      }),
      level: "ok",
      message: "Project Alpha v7.0 initialized",
    },
    {
      id: "init-2",
      timestamp: new Date().toLocaleTimeString("de-DE", {
        hour: "2-digit",
        minute: "2-digit",
        second: "2-digit",
      }),
      level: "ok",
      message: "System: Finn Jona Thorsten Lischke",
    },
    {
      id: "init-3",
      timestamp: new Date().toLocaleTimeString("de-DE", {
        hour: "2-digit",
        minute: "2-digit",
        second: "2-digit",
      }),
      level: "warn",
      message: "Absolute identity confirmed",
    },
  ]);

  const addLog = useCallback((message: string, level: LogLevel = "ok", endpoint?: string) => {
    const timestamp = new Date().toLocaleTimeString("de-DE", {
      hour: "2-digit",
      minute: "2-digit",
      second: "2-digit",
    });

    const newLog: LogEntry = {
      id: `log-${Date.now()}-${Math.random()}`,
      timestamp,
      level,
      message,
      endpoint,
    };

    setLogs((prevLogs) => {
      const updated = [newLog, ...prevLogs];
      // Keep only the last MAX_LOGS entries
      return updated.slice(0, MAX_LOGS);
    });
  }, []);

  const clearLogs = useCallback(() => {
    setLogs([]);
  }, []);

  const addApiLog = useCallback(
    (endpoint: string, data: any, isError: boolean = false) => {
      const level: LogLevel = isError ? "err" : "ok";
      const message = isError
        ? `[API] ${endpoint} - Error: ${JSON.stringify(data).slice(0, 100)}`
        : `[API] ${endpoint} - ${JSON.stringify(data).slice(0, 100)}`;

      addLog(message, level, endpoint);
    },
    [addLog]
  );

  return {
    logs,
    addLog,
    clearLogs,
    addApiLog,
  };
}
