import React, { createContext, useContext, useState, useEffect, ReactNode } from "react";
import * as SecureStore from "expo-secure-store";
import ProjectAlphaClient, { ApiConfig } from "./api-client";

export interface AuthContextType {
  isAuthenticated: boolean;
  isLoading: boolean;
  error: string | null;
  apiClient: ProjectAlphaClient | null;
  login: (baseURL: string, username: string, password: string) => Promise<void>;
  logout: () => Promise<void>;
  setApiConfig: (config: ApiConfig) => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [apiClient, setApiClient] = useState<ProjectAlphaClient | null>(null);

  // Initialize auth on app start
  useEffect(() => {
    const initializeAuth = async () => {
      try {
        const savedConfig = await SecureStore.getItemAsync("project_alpha_config");
        const savedToken = await SecureStore.getItemAsync("project_alpha_session");

        if (savedConfig && savedToken) {
          const config: ApiConfig = JSON.parse(savedConfig);
          const client = new ProjectAlphaClient(config);
          client.setSessionToken(savedToken);
          setApiClient(client);
          setIsAuthenticated(true);
        }
      } catch (err) {
        console.error("Auth initialization error:", err);
        setError("Failed to restore session");
      } finally {
        setIsLoading(false);
      }
    };

    initializeAuth();
  }, []);

  const login = async (baseURL: string, username: string, password: string) => {
    setIsLoading(true);
    setError(null);

    try {
      const config: ApiConfig = {
        baseURL,
        username,
        password,
      };

      const client = new ProjectAlphaClient(config);
      const sessionResponse = await client.createSession();

      if (sessionResponse.sess) {
        await SecureStore.setItemAsync("project_alpha_config", JSON.stringify(config));
        await SecureStore.setItemAsync("project_alpha_session", sessionResponse.tok);
        setApiClient(client);
        setIsAuthenticated(true);
      } else {
        throw new Error("Session creation failed");
      }
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : "Login failed";
      setError(errorMessage);
      setIsAuthenticated(false);
      throw err;
    } finally {
      setIsLoading(false);
    }
  };

  const logout = async () => {
    try {
      await SecureStore.deleteItemAsync("project_alpha_config");
      await SecureStore.deleteItemAsync("project_alpha_session");
      setApiClient(null);
      setIsAuthenticated(false);
      setError(null);
    } catch (err) {
      console.error("Logout error:", err);
    }
  };

  const setApiConfig = (config: ApiConfig) => {
    if (apiClient) {
      apiClient.setConfig(config);
    }
  };

  return (
    <AuthContext.Provider
      value={{
        isAuthenticated,
        isLoading,
        error,
        apiClient,
        login,
        logout,
        setApiConfig,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}

export function useAuthContext(): AuthContextType {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error("useAuthContext must be used within AuthProvider");
  }
  return context;
}
