import axios, { AxiosInstance } from "axios";
import * as SecureStore from "expo-secure-store";

export interface ApiConfig {
  baseURL: string;
  username: string;
  password: string;
}

export interface SessionResponse {
  sess: boolean;
  tok: string;
  exp: number;
}

export interface StatusResponse {
  srv: string;
  ver: string;
  port: number;
  sys: string;
  engine: EngineStatus;
  ts: string;
  auth: string;
  sess: number;
  up: string;
}

export interface EngineStatus {
  ver: string;
  gen: number;
  mut: number;
  conf: number;
  vecs: string[];
  vcount: number;
  dna: string;
  inst: number;
  sys: string;
  shash: string;
  stat: string;
  up: number;
  upf: string;
  eh: number;
  rl: number;
  rpl: number;
  nodes: number;
  devs: number;
  st: number;
  mm: number;
}

export interface EvolveResponse {
  evo: boolean;
  msg: string;
  data: {
    gen: number;
    mut: number;
    old: string;
    new: string;
    ts: string;
  };
}

export interface RecognizeResponse {
  rec: boolean;
  sys: string;
  conf: number;
  vecs: string[];
  dna: string;
  msg: string;
  auth: string;
  scope: string;
}

export interface ReplicateResponse {
  rep: boolean;
  inst: number;
  msg: string;
  dna: string;
}

export interface ArsenalResponse {
  st: number;
  mm: number;
  fm: number;
  total: string;
  cat: number;
  lay: number;
  stat: string;
  int: string;
  sc: string;
  ma: string;
}

export interface ProtocolResponse {
  proto: string;
  ver: string;
  stat: string;
  wd: string;
  tr: string;
  per: string;
  red: string;
  stealth: string;
  evasion: string;
  aa: string;
  mi: string;
}

export interface MobileStatusResponse {
  mm: string;
  ai: string;
  bt: string;
  wf: string;
  on: string;
  wg: string;
  cn: number;
  hv: string;
  ar: boolean;
  dr: string;
}

export interface DeviceNode {
  id: string;
  type: string;
  ts: string;
}

export interface NodesResponse {
  nodes: DeviceNode[];
  count: number;
}

export interface SecurityCatalogResponse {
  total: number;
  cats: string[];
  note: string[];
  stat: string;
  int: string;
}

export interface MobileAnalysisResponse {
  mod: number;
  inf: string;
  vecs: string[];
  plat: string[];
  cap: string[];
  aic: string;
}

export interface HealthResponse {
  stat: string;
  srv: string;
  eng: string;
  sess: number;
  rl: number;
  ts: string;
}

export interface RegisterDeviceRequest {
  id: string;
  type: string;
}

export interface RegisterDeviceResponse {
  reg: boolean;
  id: string;
  type: string;
  total: number;
}

class ProjectAlphaClient {
  private client: AxiosInstance;
  private config: ApiConfig;
  private sessionToken: string | null = null;

  constructor(config: ApiConfig) {
    this.config = config;
    this.client = axios.create({
      baseURL: config.baseURL,
      timeout: 10000,
    });
  }

  private getAuthHeader(): string {
    const credentials = `${this.config.username}:${this.config.password}`;
    return `Basic ${Buffer.from(credentials).toString("base64")}`;
  }

  private getHeaders() {
    return {
      Authorization: this.getAuthHeader(),
      "Content-Type": "application/json",
    };
  }

  async createSession(): Promise<SessionResponse> {
    const response = await this.client.get<SessionResponse>("/api/session", {
      headers: this.getHeaders(),
    });
    this.sessionToken = response.data.tok;
    await SecureStore.setItemAsync("project_alpha_session", this.sessionToken);
    return response.data;
  }

  async getStatus(): Promise<StatusResponse> {
    const response = await this.client.get<StatusResponse>("/api/status", {
      headers: this.getHeaders(),
    });
    return response.data;
  }

  async getEngineStatus(): Promise<EngineStatus> {
    const response = await this.client.get<EngineStatus>("/api/engine/status", {
      headers: this.getHeaders(),
    });
    return response.data;
  }

  async evolveEngine(): Promise<EvolveResponse> {
    const response = await this.client.get<EvolveResponse>("/api/engine/evolve", {
      headers: this.getHeaders(),
    });
    return response.data;
  }

  async recognizeEngine(): Promise<RecognizeResponse> {
    const response = await this.client.get<RecognizeResponse>(
      "/api/engine/recognize",
      {
        headers: this.getHeaders(),
      }
    );
    return response.data;
  }

  async replicateEngine(): Promise<ReplicateResponse> {
    const response = await this.client.get<ReplicateResponse>(
      "/api/engine/replicate",
      {
        headers: this.getHeaders(),
      }
    );
    return response.data;
  }

  async getArsenal(): Promise<ArsenalResponse> {
    const response = await this.client.get<ArsenalResponse>("/api/arsenal", {
      headers: this.getHeaders(),
    });
    return response.data;
  }

  async getProtocol(): Promise<ProtocolResponse> {
    const response = await this.client.get<ProtocolResponse>("/api/protocol", {
      headers: this.getHeaders(),
    });
    return response.data;
  }

  async getMobileStatus(): Promise<MobileStatusResponse> {
    const response = await this.client.get<MobileStatusResponse>(
      "/api/mobile/status",
      {
        headers: this.getHeaders(),
      }
    );
    return response.data;
  }

  async getMobileNodes(): Promise<NodesResponse> {
    const response = await this.client.get<NodesResponse>("/api/mobile/nodes", {
      headers: this.getHeaders(),
    });
    return response.data;
  }

  async getSecurityCatalog(): Promise<SecurityCatalogResponse> {
    const response = await this.client.get<SecurityCatalogResponse>(
      "/api/security/catalog",
      {
        headers: this.getHeaders(),
      }
    );
    return response.data;
  }

  async getMobileAnalysis(): Promise<MobileAnalysisResponse> {
    const response = await this.client.get<MobileAnalysisResponse>(
      "/api/mobile/analysis",
      {
        headers: this.getHeaders(),
      }
    );
    return response.data;
  }

  async getHealth(): Promise<HealthResponse> {
    const response = await this.client.get<HealthResponse>("/api/health", {
      headers: this.getHeaders(),
    });
    return response.data;
  }

  async registerDevice(
    request: RegisterDeviceRequest
  ): Promise<RegisterDeviceResponse> {
    const response = await this.client.post<RegisterDeviceResponse>(
      "/api/mobile/register",
      request,
      {
        headers: this.getHeaders(),
      }
    );
    return response.data;
  }

  async loadSecurityArsenal() {
    const response = await this.client.post("/api/security/load", {}, {
      headers: this.getHeaders(),
    });
    return response.data;
  }

  async loadMobileModules() {
    const response = await this.client.post("/api/mobile/load", {}, {
      headers: this.getHeaders(),
    });
    return response.data;
  }

  setConfig(config: Partial<ApiConfig>) {
    this.config = { ...this.config, ...config };
    this.client.defaults.baseURL = this.config.baseURL;
  }

  getConfig(): ApiConfig {
    return this.config;
  }

  setSessionToken(token: string) {
    this.sessionToken = token;
  }

  getSessionToken(): string | null {
    return this.sessionToken;
  }
}

export default ProjectAlphaClient;
