/** @type {const} */
const themeColors = {
  primary: { light: '#0a7ea4', dark: '#00ff88' },
  background: { light: '#ffffff', dark: '#0a0a0a' },
  surface: { light: '#f5f5f5', dark: '#1a1a1a' },
  foreground: { light: '#11181C', dark: '#00ff88' },
  muted: { light: '#687076', dark: '#00aa55' },
  border: { light: '#E5E7EB', dark: '#00ff8833' },
  success: { light: '#22C55E', dark: '#00ff88' },
  warning: { light: '#F59E0B', dark: '#ffaa00' },
  error: { light: '#EF4444', dark: '#ff4444' },
};

module.exports = { themeColors };
