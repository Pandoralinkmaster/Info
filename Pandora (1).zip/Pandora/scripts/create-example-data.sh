#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
mkdir -p demo-ssd/Pandora/{database,receipts,products,logs,backups,consent,onion,scan,buildings,csi,chat,security,registry,network,mesh,jayjay}
cp master_config.example.json demo-ssd/Pandora/master_config.json
cp examples/products.example.json demo-ssd/Pandora/products/products.json
cp examples/receipt.example.txt demo-ssd/Pandora/receipts/receipt-demo.txt
echo "Created demo SSD structure in demo-ssd/Pandora"
