#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
if [ ! -x "./gradlew" ]; then
  echo "Gradle wrapper not found. Open the project in Android Studio or install Gradle, then run: gradle :pandora-android:assembleDebug"
  echo "This repository is Gradle-ready but does not bundle wrapper binaries."
  exit 1
fi
./gradlew :pandora-android:assembleDebug
mkdir -p dist
cp pandora-android/build/outputs/apk/debug/pandora-android-debug.apk dist/Pandora.apk
echo "APK copied to dist/Pandora.apk"
