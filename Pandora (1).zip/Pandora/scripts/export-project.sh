#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
OUT="../Pandora.zip"
rm -f "$OUT"
zip -r "$OUT" . -x "**/.gradle/**" "**/build/**" "**/.idea/**"
echo "Created $OUT"
