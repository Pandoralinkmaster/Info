# Pandora Protocol

## Grundregeln

- CEO Host ist Root of Trust.
- Alle Knoten brauchen Registrierung, Token, Rolle und Consent.
- Wenn CEO Host gesperrt ist, werden sensible Endpunkte blockiert.
- Mesh transportiert nur Pandora-Daten.
- Store-and-forward hält nur verschlüsselte Payloads.
- Keine komplette Master-Datenbank auf Client-Geräten.
