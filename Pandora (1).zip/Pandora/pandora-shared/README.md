# pandora-shared

Gemeinsame Modell- und Protokoll-Spezifikation für Pandora.

Die Android-App enthält aktuell die ausführbaren Kotlin-Modelle in `pandora-android/src/main/java/de/pandora/os/model`.
Dieser Ordner dokumentiert, welche Modelle plattformübergreifend gelten.
