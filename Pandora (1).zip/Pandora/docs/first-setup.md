# First Setup

1. CEO Host Mode auswählen.
2. CEO registrieren.
3. M.2 SSD auswählen.
4. Ordnerstruktur, `master_config.json` und `pandora.db` werden erstellt.
