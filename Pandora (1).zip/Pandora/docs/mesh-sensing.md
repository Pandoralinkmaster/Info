# Mesh Sensing

Handys liefern RSSI, WLAN-Scan, BLE-Signalstärke, Bewegungssensoren, Scan-Daten und Simulation. Echte CSI-Rohdaten sind Forschungsmodul.
