# 3D Building Overlay

Pandora verwaltet Gebäude, Etagen, Räume, Zonen, Mesh-Knoten, Signal-Heatmaps, Presence-Heatmaps und Eventpunkte. Erste Version nutzt Demo-Daten und Web/Compose-kompatible Modelle.
