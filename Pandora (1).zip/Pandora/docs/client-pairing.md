# Client Pairing

Clients registrieren sich per Pairing-Code/QR. CEO bestätigt, vergibt Rolle und Token. Ohne aktiven CEO Host sind Daten gesperrt.
