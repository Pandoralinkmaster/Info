# WireGuard

Pandora enthält Peer-Verwaltung, QR-Konzept, Status und Logs. Produktiv kann dies über Android VpnService oder Integration mit einer bestehenden WireGuard-App umgesetzt werden. Keine privaten Schlüssel hardcoden.
