# Security Model

Zero-Trust, Consent-Gate, Host Visibility Gate, Rollen, Tokens, verschlüsselte Datenfelder, Post-Quantum-Interface, Audit-Logs.
