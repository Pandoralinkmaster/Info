# JayJay AI

JayJay ist die KI-Steuerung von Pandora. Sie hört nur auf CEO, verteilt Aufgaben an autorisierte Compute Nodes und teilt keine komplette Datenbank oder geheimen Schlüssel.
