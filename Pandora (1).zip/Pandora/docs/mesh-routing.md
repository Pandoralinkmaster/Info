# Mesh Routing

Android-Handys sind Mesh-Knoten. Transporte: Tor/Onion, BLE, WiFi Direct, WiFi Aware, lokales WLAN, Hotspot, WebSocket, REST-Sync. Mesh ist App-Level und leitet nur Pandora-Daten.
