# Mobile Host Mode

Das Samsung Galaxy S24 Ultra läuft im CEO Host Mode. Der lokale Ktor-Server startet nur nach CEO-Freigabe. Wenn das Gerät gesperrt oder Host deaktiviert ist, sehen Clients nur `access_locked`.
