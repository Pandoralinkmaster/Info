# M.2 SSD via SAF

Pandora nutzt Android Storage Access Framework. Die App öffnet `ACTION_OPEN_DOCUMENT_TREE`; der Nutzer wählt die SSD oder den Pandora-Ordner; Pandora speichert die persistente URI-Berechtigung und erstellt `/Pandora/...`.
