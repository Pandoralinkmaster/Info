# Onion Access

Pandora enthält Onion-Status, Konfiguration und Schnittstellen. Auf Android wird ein externer Tor/Orbot-kompatibler Dienst benötigt, der auf den lokalen Pandora-Port weiterleitet. Zugriff bleibt an Login, Token, Consent und aktiven CEO Host gebunden.
