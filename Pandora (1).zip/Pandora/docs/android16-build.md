# Android 16 Build

Pandora ist auf `compileSdk 36` und `targetSdk 36` vorbereitet. Falls lokale SDKs API 36 noch nicht installiert haben, in Android Studio SDK Manager installieren oder temporär auf verfügbare SDK-Version anpassen.

Build: `./scripts/build-android.sh`.
