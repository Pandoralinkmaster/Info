# Pandora OS CSI Research

Normale Android-Apps bekommen normalerweise keine echten CSI-Rohdaten. Echte CSI-Funktion benötigt privilegierten Systemdienst, kompatiblen WLAN-Chip, Kernel-/Firmware-Zugriff oder ein späteres Pandora OS / Custom-ROM.
