# Replit Agent Prompt

Siehe Hauptnachricht im Chat. Dieses Projekt entspricht der aktuellen Pandora-v1-Spezifikation: Android-only, Samsung Galaxy S24 Ultra als CEO Host, M.2 SSD, Android-Handys als Client/Mesh/Sensing/Compute, JayJay AI.
