package de.pandora.os.overlay

import de.pandora.os.model.Building
import de.pandora.os.model.Floor
import de.pandora.os.model.PresenceHeatmapPoint
import de.pandora.os.model.SignalHeatmapPoint

class BuildingOverlayManager {
    fun demoBuilding(): Building = Building(
        id = "demo-building",
        name = "Pandora Demo Building",
        floors = listOf(Floor("floor-1", "demo-building", "EG", 0), Floor("floor-2", "demo-building", "OG", 1))
    )
    fun demoSignalHeatmap(): List<SignalHeatmapPoint> = listOf(
        SignalHeatmapPoint(0f, 0f, 0f, 0.9f, "wifi"), SignalHeatmapPoint(4f, 2f, 0f, 0.4f, "ble")
    )
    fun demoPresenceHeatmap(): List<PresenceHeatmapPoint> = listOf(
        PresenceHeatmapPoint(2f, 1f, 0f, 0.72f, "mesh-sensing")
    )
}
