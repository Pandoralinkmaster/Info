package de.pandora.os.database

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

class PandoraDatabaseHelper(context: Context) : SQLiteOpenHelper(context, "pandora.db", null, 1) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE IF NOT EXISTS ceo_profile (id TEXT PRIMARY KEY, name TEXT, email TEXT, device_name TEXT, created_at INTEGER)")
        db.execSQL("CREATE TABLE IF NOT EXISTS devices (id TEXT PRIMARY KEY, name TEXT, roles TEXT, status TEXT, token_hash TEXT, last_heartbeat INTEGER)")
        db.execSQL("CREATE TABLE IF NOT EXISTS consent (id TEXT PRIMARY KEY, device_id TEXT, version TEXT, scopes TEXT, active INTEGER, created_at INTEGER, revoked_at INTEGER)")
        db.execSQL("CREATE TABLE IF NOT EXISTS products (id TEXT PRIMARY KEY, name TEXT, description TEXT, price_btc REAL, category TEXT, active INTEGER)")
        db.execSQL("CREATE TABLE IF NOT EXISTS payments (id TEXT PRIMARY KEY, product_id TEXT, amount_btc REAL, address TEXT, status TEXT, tx_id TEXT, created_at INTEGER)")
        db.execSQL("CREATE TABLE IF NOT EXISTS receipts (id TEXT PRIMARY KEY, payment_id TEXT, product_id TEXT, text_path TEXT, created_at INTEGER, signature TEXT)")
        db.execSQL("CREATE TABLE IF NOT EXISTS chat_messages (id TEXT PRIMARY KEY, sender_id TEXT, target_id TEXT, encrypted_body TEXT, created_at INTEGER)")
        db.execSQL("CREATE TABLE IF NOT EXISTS mesh_nodes (id TEXT PRIMARY KEY, role TEXT, transport TEXT, status TEXT, last_seen INTEGER)")
        db.execSQL("CREATE TABLE IF NOT EXISTS mesh_messages (id TEXT PRIMARY KEY, sender_id TEXT, target_id TEXT, ttl INTEGER, encrypted_payload TEXT, created_at INTEGER)")
        db.execSQL("CREATE TABLE IF NOT EXISTS csi_frames (id TEXT PRIMARY KEY, source_id TEXT, source_type TEXT, is_real_csi INTEGER, rssi INTEGER, created_at INTEGER)")
        db.execSQL("CREATE TABLE IF NOT EXISTS buildings (id TEXT PRIMARY KEY, name TEXT)")
        db.execSQL("CREATE TABLE IF NOT EXISTS floors (id TEXT PRIMARY KEY, building_id TEXT, name TEXT, level INTEGER)")
        db.execSQL("CREATE TABLE IF NOT EXISTS rooms (id TEXT PRIMARY KEY, floor_id TEXT, name TEXT)")
        db.execSQL("CREATE TABLE IF NOT EXISTS zones (id TEXT PRIMARY KEY, room_id TEXT, name TEXT)")
        db.execSQL("CREATE TABLE IF NOT EXISTS jayjay_tasks (id TEXT PRIMARY KEY, type TEXT, created_by TEXT, assigned_to TEXT, status TEXT, encrypted_payload TEXT, created_at INTEGER)")
        db.execSQL("CREATE TABLE IF NOT EXISTS compute_nodes (id TEXT PRIMARY KEY, device_id TEXT, status TEXT, battery_pct INTEGER, temperature_c REAL, capabilities TEXT)")
        db.execSQL("CREATE TABLE IF NOT EXISTS audit_log (id INTEGER PRIMARY KEY AUTOINCREMENT, type TEXT, message TEXT, created_at INTEGER)")
    }
    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) = Unit
}
