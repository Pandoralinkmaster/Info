package de.pandora.os.registry

import de.pandora.os.model.DeviceRecord
import de.pandora.os.model.NodeStatus
import de.pandora.os.model.UserRole
import java.util.UUID

class RegistryManager {
    private val devices = mutableListOf<DeviceRecord>()
    fun requestRegistration(name: String): DeviceRecord {
        val device = DeviceRecord(UUID.randomUUID().toString(), name, listOf(UserRole.CUSTOMER), NodeStatus.PENDING)
        devices += device
        return device
    }
    fun authorize(id: String, roles: List<UserRole>) = devices.replaceAll { if (it.id == id) it.copy(status = NodeStatus.AUTHORIZED, roles = roles) else it }
    fun block(id: String) = devices.replaceAll { if (it.id == id) it.copy(status = NodeStatus.BLOCKED) else it }
    fun list(): List<DeviceRecord> = devices
}
