package de.pandora.os.api

import de.pandora.os.security.HostVisibilityGate
import io.ktor.http.*
import io.ktor.serialization.kotlinx.json.*
import io.ktor.server.application.*
import io.ktor.server.cio.*
import io.ktor.server.engine.*
import io.ktor.server.plugins.contentnegotiation.*
import io.ktor.server.response.*
import io.ktor.server.routing.*
import io.ktor.server.websocket.*
import kotlinx.coroutines.isActive
import java.time.Duration

class LocalApiServer(private val hostVisibilityGate: HostVisibilityGate) {
    private var server: ApplicationEngine? = null

    fun start(port: Int = 8080) {
        if (server != null) return
        server = embeddedServer(CIO, port = port, host = "0.0.0.0") {
            install(ContentNegotiation) { json() }
            install(WebSockets) { pingPeriod = Duration.ofSeconds(15) }
            routing {
                get("/health") { call.respond(mapOf("status" to "ok", "name" to "Pandora")) }
                get("/host/visibility") { call.respond(hostVisibilityGate.guardedStatus()) }
                post("/host/unlock") { hostVisibilityGate.unlockWithCeo(); call.respond(mapOf("status" to "active")) }
                post("/host/lock") { hostVisibilityGate.lock(); call.respond(mapOf("status" to "locked")) }

                guardedGet("/products", hostVisibilityGate) { call.respond(mapOf("products" to emptyList<String>())) }
                guardedPost("/products", hostVisibilityGate) { call.respond(HttpStatusCode.Created, mapOf("status" to "created")) }
                guardedPost("/checkout/create", hostVisibilityGate) { call.respond(mapOf("status" to "pending", "bitcoinUri" to "bitcoin:<adresse>?amount=<betrag>&label=<produktname>")) }
                guardedGet("/payments/{id}", hostVisibilityGate) { call.respond(mapOf("status" to "pending")) }
                guardedGet("/receipts", hostVisibilityGate) { call.respond(mapOf("receipts" to emptyList<String>())) }
                guardedGet("/devices", hostVisibilityGate) { call.respond(mapOf("devices" to emptyList<String>())) }
                guardedPost("/devices/register", hostVisibilityGate) { call.respond(mapOf("status" to "pending")) }
                guardedPost("/devices/authorize", hostVisibilityGate) { call.respond(mapOf("status" to "authorized")) }
                guardedGet("/system/status", hostVisibilityGate) { call.respond(mapOf("host" to "Samsung Galaxy S24 Ultra", "mode" to "ceo_mobile_host")) }

                mountStatusRoutes(hostVisibilityGate)
                webSocket("/ws") {
                    while (isActive) {
                        outgoing.send(io.ktor.websocket.Frame.Text("{\"type\":\"heartbeat\",\"hostActive\":${hostVisibilityGate.isActive()}}"))
                        kotlinx.coroutines.delay(5000)
                    }
                }
            }
        }.start(wait = false)
    }

    fun stop() { server?.stop(1000, 2000); server = null }
}

private fun Route.guardedGet(path: String, gate: HostVisibilityGate, body: suspend RoutingContext.() -> Unit) = get(path) {
    if (!gate.isActive()) call.respond(mapOf("status" to "locked", "reason" to "CEO host is not active")) else body()
}
private fun Route.guardedPost(path: String, gate: HostVisibilityGate, body: suspend RoutingContext.() -> Unit) = post(path) {
    if (!gate.isActive()) call.respond(mapOf("status" to "locked", "reason" to "CEO host is not active")) else body()
}

private fun Route.mountStatusRoutes(gate: HostVisibilityGate) {
    val statusEndpoints = listOf("network", "onion", "wireguard", "mesh", "onion-mesh", "scan", "mesh-sensing", "csi", "building", "jayjay", "compute")
    statusEndpoints.forEach { name ->
        guardedGet("/$name/status", gate) { call.respond(mapOf("module" to name, "status" to "enabled", "mode" to "mobile-first")) }
    }
}
