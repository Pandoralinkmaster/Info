package de.pandora.os.network

class NetworkManager {
    fun currentStatus(): Map<String, String> = mapOf("localWifi" to "supported", "mobileHotspot" to "supported", "websocket" to "enabled", "restSync" to "enabled")
}
class OnionManager {
    fun status(): Map<String, String> = mapOf("onion" to "enabled", "note" to "Requires Tor/Orbot or compatible onion service on Android")
}
class WireGuardManager {
    fun status(): Map<String, String> = mapOf("wireguard" to "enabled", "note" to "Use VpnService or external WireGuard app integration")
    fun createPeer(name: String): Map<String, String> = mapOf("peer" to name, "qr" to "wireguard-peer-qr-placeholder")
}
