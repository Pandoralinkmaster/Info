package de.pandora.os.security

import java.security.MessageDigest
import java.util.UUID

class HostVisibilityGate {
    private var active: Boolean = false
    private var lastUnlock: Long = 0L
    private val timeoutMs = 15 * 60 * 1000L

    fun unlockWithCeo(): Boolean { active = true; lastUnlock = System.currentTimeMillis(); return true }
    fun lock() { active = false }
    fun isActive(): Boolean = active && (System.currentTimeMillis() - lastUnlock) < timeoutMs
    fun guardedStatus(): Map<String, String> = if (isActive()) mapOf("status" to "active") else mapOf("status" to "locked", "reason" to "CEO host is not active")
}

class TokenService {
    fun newToken(): String = UUID.randomUUID().toString() + "." + UUID.randomUUID().toString()
    fun hash(value: String): String = MessageDigest.getInstance("SHA-256").digest(value.toByteArray()).joinToString("") { "%02x".format(it) }
}

class ConsentGate {
    fun allowed(consentActive: Boolean, roleAllowed: Boolean, hostActive: Boolean): Boolean = consentActive && roleAllowed && hostActive
}

class PostQuantumSecurityLayer {
    fun describe(): String = "Interface ready for hybrid post-quantum key exchange and encrypted field storage. Replace stubs with vetted ML-KEM/ML-DSA implementation before production."
    fun encryptPlaceholder(payload: String): String = "pq-prepared:" + payload.reversed()
    fun decryptPlaceholder(payload: String): String = payload.removePrefix("pq-prepared:").reversed()
}
