package de.pandora.os.storage

import android.content.Context
import android.net.Uri
import androidx.documentfile.provider.DocumentFile
import org.json.JSONObject

class PandoraSafStorageManager(private val context: Context) {
    companion object {
        val REQUIRED_DIRS = listOf(
            "database", "receipts", "products", "logs", "backups", "consent", "onion",
            "scan", "buildings", "csi", "chat", "security", "registry", "network", "mesh", "jayjay"
        )
    }

    fun persistTreePermission(uri: Uri) {
        context.contentResolver.takePersistableUriPermission(
            uri,
            android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION or android.content.Intent.FLAG_GRANT_WRITE_URI_PERMISSION
        )
        context.getSharedPreferences("pandora", Context.MODE_PRIVATE).edit().putString("ssd_uri", uri.toString()).apply()
    }

    fun getRoot(): DocumentFile? {
        val raw = context.getSharedPreferences("pandora", Context.MODE_PRIVATE).getString("ssd_uri", null) ?: return null
        return DocumentFile.fromTreeUri(context, Uri.parse(raw))
    }

    fun ensurePandoraStructure(): Boolean {
        val root = getRoot() ?: return false
        val pandora = root.findFile("Pandora") ?: root.createDirectory("Pandora") ?: return false
        REQUIRED_DIRS.forEach { dir -> pandora.findFile(dir) ?: pandora.createDirectory(dir) }
        if (pandora.findFile("master_config.json") == null) {
            val file = pandora.createFile("application/json", "master_config.json") ?: return false
            context.contentResolver.openOutputStream(file.uri)?.use { out ->
                out.write(defaultMasterConfig().toString(2).toByteArray())
            }
        }
        return true
    }

    private fun defaultMasterConfig(): JSONObject = JSONObject().apply {
        put("systemName", "Pandora")
        put("systemVersion", "1.0.0")
        put("hostMode", "ceo_mobile_host")
        put("hostDevice", "Samsung Galaxy S24 Ultra")
        put("ceoName", "Finn Jona Lischke")
        put("ceoEmail", "finn.jona.lischke@gmail.com")
        put("storageType", "external_m2_ssd_via_saf")
        put("databasePath", "/Pandora/database/pandora.db")
        put("securityMode", "zero-trust")
        put("postQuantumSecurity", "enabled")
        put("wireGuard", "enabled")
        put("meshRouting", "enabled")
        put("onionAccess", "enabled")
        put("jayJayAI", "enabled")
    }
}
