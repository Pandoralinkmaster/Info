package de.pandora.os.jayjay

import de.pandora.os.model.ComputeNode
import de.pandora.os.model.JayJayTask
import de.pandora.os.model.NodeStatus
import java.util.UUID

class JayJayAI {
    private val tasks = mutableListOf<JayJayTask>()

    fun commandFromCeo(command: String, ceoActive: Boolean): Map<String, String> {
        if (!ceoActive) return mapOf("status" to "rejected", "reason" to "CEO host is not active")
        return mapOf("status" to "accepted", "command" to command)
    }

    fun createTask(type: String, createdBy: String, encryptedPayload: String): JayJayTask {
        val task = JayJayTask(UUID.randomUUID().toString(), type, createdBy, encryptedPayload = encryptedPayload)
        tasks += task
        return task
    }

    fun listTasks(): List<JayJayTask> = tasks
}

class ComputeMeshManager {
    private val nodes = mutableListOf<ComputeNode>()
    fun register(deviceId: String, capabilities: List<String>): ComputeNode {
        val node = ComputeNode(UUID.randomUUID().toString(), deviceId, NodeStatus.PENDING, capabilities = capabilities)
        nodes += node
        return node
    }
    fun authorize(id: String) = nodes.replaceAll { if (it.id == id) it.copy(status = NodeStatus.AUTHORIZED) else it }
    fun list(): List<ComputeNode> = nodes
}
