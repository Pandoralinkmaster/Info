package de.pandora.os.sensing

import de.pandora.os.model.CsiFrame
import java.util.UUID

class MeshSensingManager {
    fun rssiFrame(sourceId: String, rssi: Int): CsiFrame = CsiFrame(UUID.randomUUID().toString(), sourceId, "rssi_sensing_node", false, rssi = rssi)
    fun bleFrame(sourceId: String, rssi: Int): CsiFrame = CsiFrame(UUID.randomUUID().toString(), sourceId, "ble_sensing_node", false, rssi = rssi)
}

class CsiSensingManager {
    fun simulatePresence(sourceId: String): Map<String, Any> = mapOf("sourceId" to sourceId, "type" to "presence", "confidence" to 0.78, "realCsi" to false)
    fun ingest(frame: CsiFrame): Map<String, Any> = mapOf("accepted" to true, "realCsi" to frame.isRealCsi, "sourceType" to frame.sourceType)
}

class RuViewCompatibilityLayer {
    fun normalize(frame: CsiFrame): Map<String, Any?> = mapOf(
        "format" to "ruview-compatible-pandora-frame",
        "source" to frame.sourceType,
        "realCsi" to frame.isRealCsi,
        "rssi" to frame.rssi,
        "timestamp" to frame.createdAt
    )
}
