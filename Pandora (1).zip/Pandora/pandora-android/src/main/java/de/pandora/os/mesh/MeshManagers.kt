package de.pandora.os.mesh

import de.pandora.os.model.MeshMessage
import de.pandora.os.model.MeshNode
import de.pandora.os.model.NodeStatus
import java.util.UUID

class MeshRoutingManager {
    private val nodes = mutableListOf<MeshNode>()
    private val offlineQueue = mutableListOf<MeshMessage>()

    fun registerNode(role: String, transport: List<String>): MeshNode {
        val node = MeshNode(UUID.randomUUID().toString(), role, transport, NodeStatus.PENDING)
        nodes += node
        return node
    }
    fun authorize(id: String) = nodes.replaceAll { if (it.id == id) it.copy(status = NodeStatus.AUTHORIZED) else it }
    fun listNodes(): List<MeshNode> = nodes
    fun queueEncryptedMessage(sender: String, target: String, payload: String): MeshMessage {
        val msg = MeshMessage(UUID.randomUUID().toString(), sender, target, ttl = 7, encryptedPayload = payload)
        offlineQueue += msg
        return msg
    }
}

class OnionMeshRoutingManager {
    fun createRoute(hops: List<String>): Map<String, Any> = mapOf("routeId" to UUID.randomUUID().toString(), "hops" to hops, "mode" to "layered-encryption-prepared")
    fun wrapPayload(payload: String, hops: List<String>): String = hops.reversed().fold(payload) { acc, hop -> "layer($hop:$acc)" }
}
