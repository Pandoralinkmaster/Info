package de.pandora.os.setup

import android.content.Context
import de.pandora.os.database.PandoraDatabaseHelper
import de.pandora.os.model.CeoProfile
import de.pandora.os.model.SetupStatus
import de.pandora.os.storage.PandoraSafStorageManager
import java.util.UUID

class FirstSetupManager(private val context: Context, private val storage: PandoraSafStorageManager) {
    private val prefs = context.getSharedPreferences("pandora_setup", Context.MODE_PRIVATE)

    fun status(): SetupStatus = SetupStatus.valueOf(prefs.getString("status", SetupStatus.NOT_STARTED.name)!!)

    fun registerCeo(name: String = "Finn Jona Lischke", email: String = "finn.jona.lischke@gmail.com"): CeoProfile {
        val profile = CeoProfile(id = UUID.randomUUID().toString(), name = name, email = email)
        prefs.edit()
            .putString("ceo_id", profile.id)
            .putString("ceo_name", profile.name)
            .putString("ceo_email", profile.email)
            .putString("status", SetupStatus.CEO_REGISTERED.name)
            .apply()
        return profile
    }

    fun createDatabase(): Boolean {
        PandoraDatabaseHelper(context).writableDatabase.use { db ->
            db.execSQL("INSERT OR IGNORE INTO audit_log(type,message,created_at) VALUES('setup','database created',strftime('%s','now')*1000)")
        }
        prefs.edit().putString("status", SetupStatus.DATABASE_CREATED.name).apply()
        return true
    }

    fun completeAfterSsdSelected(): Boolean {
        val ok = storage.ensurePandoraStructure()
        if (!ok) return false
        prefs.edit().putString("status", SetupStatus.FOLDERS_CREATED.name).apply()
        createDatabase()
        prefs.edit().putString("status", SetupStatus.SETUP_COMPLETE.name).apply()
        return true
    }
}
