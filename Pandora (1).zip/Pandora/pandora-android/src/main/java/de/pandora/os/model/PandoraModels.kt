package de.pandora.os.model

import kotlinx.serialization.Serializable

@Serializable enum class DeviceMode { CEO_HOST, CLIENT, MESH_NODE, SENSING_NODE, COMPUTE_NODE, RELAY_NODE }
@Serializable enum class UserRole { CEO, ADMIN, CUSTOMER, SERVICE, SCANNER, MESH_NODE, SENSING_NODE, COMPUTE_NODE, RELAY_NODE }
@Serializable enum class SetupStatus { NOT_STARTED, CEO_REGISTERED, SSD_SELECTED, FOLDERS_CREATED, DATABASE_CREATED, MASTER_CONFIG_CREATED, HOST_READY, SETUP_COMPLETE }
@Serializable enum class NodeStatus { PENDING, AUTHORIZED, ACTIVE, BUSY, PAUSED, BLOCKED, OFFLINE, ERROR }

@Serializable data class CeoProfile(
    val id: String,
    val name: String = "Finn Jona Lischke",
    val email: String = "finn.jona.lischke@gmail.com",
    val deviceName: String = "Samsung Galaxy S24 Ultra",
    val createdAt: Long = System.currentTimeMillis()
)

@Serializable data class Product(
    val id: String,
    val name: String,
    val description: String,
    val priceBtc: Double,
    val category: String = "General",
    val active: Boolean = true
)

@Serializable data class Payment(
    val id: String,
    val productId: String,
    val amountBtc: Double,
    val address: String,
    val status: String = "pending",
    val txId: String? = null,
    val createdAt: Long = System.currentTimeMillis()
)

@Serializable data class Receipt(
    val id: String,
    val paymentId: String,
    val productId: String,
    val textPath: String,
    val createdAt: Long = System.currentTimeMillis(),
    val signature: String? = null
)

@Serializable data class DeviceRecord(
    val id: String,
    val name: String,
    val roles: List<UserRole>,
    val status: NodeStatus = NodeStatus.PENDING,
    val tokenHash: String? = null,
    val lastHeartbeat: Long? = null
)

@Serializable data class ConsentGrant(
    val id: String,
    val deviceId: String,
    val version: String,
    val scopes: List<String>,
    val active: Boolean = true,
    val createdAt: Long = System.currentTimeMillis(),
    val revokedAt: Long? = null
)

@Serializable data class SystemStatus(
    val hostActive: Boolean,
    val setupStatus: SetupStatus,
    val storageReady: Boolean,
    val apiReady: Boolean,
    val onionReady: Boolean,
    val wireGuardReady: Boolean,
    val meshReady: Boolean,
    val jayJayReady: Boolean
)

@Serializable data class MeshNode(
    val id: String,
    val role: String,
    val transport: List<String>,
    val status: NodeStatus,
    val lastSeen: Long? = null
)

@Serializable data class MeshMessage(
    val id: String,
    val senderId: String,
    val targetId: String,
    val ttl: Int,
    val encryptedPayload: String,
    val createdAt: Long = System.currentTimeMillis()
)

@Serializable data class CsiFrame(
    val id: String,
    val sourceId: String,
    val sourceType: String,
    val isRealCsi: Boolean,
    val amplitude: List<Double> = emptyList(),
    val phase: List<Double> = emptyList(),
    val rssi: Int? = null,
    val createdAt: Long = System.currentTimeMillis()
)

@Serializable data class Building(
    val id: String,
    val name: String,
    val floors: List<Floor> = emptyList()
)

@Serializable data class Floor(val id: String, val buildingId: String, val name: String, val level: Int)
@Serializable data class Room(val id: String, val floorId: String, val name: String)
@Serializable data class Zone(val id: String, val roomId: String, val name: String)
@Serializable data class SignalHeatmapPoint(val x: Float, val y: Float, val z: Float, val value: Float, val source: String)
@Serializable data class PresenceHeatmapPoint(val x: Float, val y: Float, val z: Float, val confidence: Float, val source: String)

@Serializable data class JayJayTask(
    val id: String,
    val type: String,
    val createdBy: String,
    val assignedTo: String? = null,
    val status: String = "pending",
    val encryptedPayload: String = "",
    val createdAt: Long = System.currentTimeMillis()
)

@Serializable data class ComputeNode(
    val id: String,
    val deviceId: String,
    val status: NodeStatus,
    val batteryPct: Int? = null,
    val temperatureC: Double? = null,
    val capabilities: List<String> = emptyList()
)
