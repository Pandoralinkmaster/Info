package de.pandora.os.shop

import de.pandora.os.model.Payment
import de.pandora.os.model.Product
import de.pandora.os.model.Receipt
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

class ShopManager {
    private val products = mutableListOf(
        Product("demo-1", "Pandora Demo Product", "Testprodukt für Checkout", 0.0001, "Demo")
    )
    fun listProducts(): List<Product> = products
    fun addProduct(product: Product) { products += product }
}

class CheckoutManager {
    fun createBitcoinUri(address: String, amount: Double, label: String): String = "bitcoin:$address?amount=$amount&label=${label.replace(" ", "%20")}" 
}

class PaymentManager {
    fun createPending(product: Product, address: String): Payment = Payment(UUID.randomUUID().toString(), product.id, product.priceBtc, address)
    fun checkMempoolPrepared(): String = "Mempool.space client interface ready; configure network client before production."
}

class ReceiptManager {
    fun createReceiptText(product: Product, payment: Payment): String {
        val ts = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.ROOT).format(Date())
        return """
            PANDORA RECEIPT
            Time: $ts
            Product: ${product.name}
            Amount BTC: ${payment.amountBtc}
            Status: ${payment.status}
            TxId: ${payment.txId ?: "pending"}
            Receipt integrity: hash/signature prepared
        """.trimIndent()
    }
    fun receiptRecord(payment: Payment, product: Product, textPath: String): Receipt = Receipt(UUID.randomUUID().toString(), payment.id, product.id, textPath)
}
