package de.pandora.os

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import de.pandora.os.api.LocalApiServer
import de.pandora.os.security.HostVisibilityGate
import de.pandora.os.setup.FirstSetupManager
import de.pandora.os.storage.PandoraSafStorageManager

class MainActivity : ComponentActivity() {
    private val gate = HostVisibilityGate()
    private val api = LocalApiServer(gate)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val storage = PandoraSafStorageManager(this)
        val setup = FirstSetupManager(this, storage)
        setContent { PandoraApp(storage, setup, gate, api) }
    }
}

@Composable
fun PandoraApp(storage: PandoraSafStorageManager, setup: FirstSetupManager, gate: HostVisibilityGate, api: LocalApiServer) {
    var mode by remember { mutableStateOf("not_selected") }
    var status by remember { mutableStateOf(setup.status().name) }
    var hostActive by remember { mutableStateOf(gate.isActive()) }
    var message by remember { mutableStateOf("Pandora bereit") }

    val treeLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            result.data?.data?.let { uri: Uri ->
                storage.persistTreePermission(uri)
                val ok = setup.completeAfterSsdSelected()
                status = setup.status().name
                message = if (ok) "SSD freigegeben, Pandora-Struktur und Datenbank erstellt" else "SSD konnte nicht eingerichtet werden"
            }
        }
    }

    MaterialTheme {
        Surface(modifier = Modifier.fillMaxSize()) {
            Column(Modifier.padding(20.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("Pandora OS Experience", style = MaterialTheme.typography.headlineMedium)
                Text("Samsung Galaxy S24 Ultra = CEO Host. Andere Android-Handys = Client/Mesh/Sensing/Compute.")
                Text("Setup Status: $status")
                Text("Host Active: $hostActive")
                Text(message)

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = { mode = "CEO_HOST"; setup.registerCeo(); status = setup.status().name }) { Text("CEO Host Mode") }
                    Button(onClick = { mode = "CLIENT" }) { Text("Client Mode") }
                }

                Button(onClick = {
                    val intent = Intent(Intent.ACTION_OPEN_DOCUMENT_TREE).apply {
                        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
                    }
                    treeLauncher.launch(intent)
                }) { Text("M.2 SSD auswählen / freigeben") }

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = { gate.unlockWithCeo(); hostActive = true; api.start(); message = "CEO Host aktiv: API auf Port 8080 gestartet" }) { Text("Host freischalten") }
                    Button(onClick = { gate.lock(); hostActive = false; api.stop(); message = "Host gesperrt: Clients sehen nichts" }) { Text("Host sperren") }
                }

                Divider()
                Text("Enthaltene Module", style = MaterialTheme.typography.titleLarge)
                val modules = listOf(
                    "Admin Dashboard", "Shop", "Checkout", "Pay", "Receipt", "Chat", "Registry", "Consent-Gate", "Security",
                    "Onion", "WireGuard", "Mesh-Routing", "Onion Mesh", "Bluetooth/BLE Mesh", "WiFi Mesh", "Scan",
                    "Mesh Sensing", "CSI/RuView Compatibility", "3D Building Overlay", "JayJay AI", "Compute Mesh", "Simulation"
                )
                modules.forEach { Text("• $it") }

                Divider()
                Text("Hinweis", style = MaterialTheme.typography.titleMedium)
                Text("Dieses Projekt enthält die komplette Modulstruktur und testbare Manager. Hardware-/OS-nahe Funktionen wie Tor, WireGuard, WiFi Direct, BLE Mesh und echte CSI-Daten benötigen reale Geräte, Berechtigungen und Adapterkonfiguration.")
            }
        }
    }
}
