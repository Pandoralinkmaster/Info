# Pandora OS Experience — Android Mobile Swarm v1

Pandora ist ein OS-artiges Android-System mit einer einzigen App: `Pandora.apk`.

**Aktuelle Zielarchitektur:**

- Samsung Galaxy S24 Ultra = CEO Host Mode, Root of Trust, Master-Kontrollgerät.
- M.2 SSD am Samsung Galaxy S24 Ultra = zentrale Master-Datenbank und Dateistruktur.
- Andere Android-Handys = Client Mode, Mesh Node Mode, Sensing Node Mode, Compute Node Mode und Relay Node Mode.
- JayJay AI = KI-Steuerung des verteilten Pandora-Gehirns, hört nur auf CEO.
- Keine iOS-v1, kein ESP32, kein Raspberry Pi, keine PS4, keine externe Pflicht-Cloud.

## Was enthalten ist

Dieses ZIP enthält ein vollständiges Android-Projektgerüst mit echtem Kotlin-Code, Gradle-Konfiguration, Modulen, Datenmodellen, Managern, lokalen Services, Sicherheitslogik, Beispielkonfigurationen, Skripten und Dokumentation.

Einige Funktionen sind wegen Android-/Geräte-Grenzen als **Adapter, Manager, Simulation und konfigurierbare Schnittstellen** umgesetzt:

- Tor/Onion benötigt Tor/Orbot oder einen kompatiblen Onion-Dienst auf dem Gerät.
- WireGuard benötigt Nutzerfreigabe/VpnService oder externe WireGuard-App-Integration.
- WiFi/Bluetooth-Mesh ist als App-Level-Mesh vorbereitet; echte Reichweite hängt von Android-Version, Gerät und Berechtigungen ab.
- CSI/RuView-ähnliche Funktionen nutzen v1 RSSI/BLE/WLAN-Scan/Sensor-Fallback und Simulation. Echte CSI-Rohdaten benötigen privilegierten Systemzugriff oder spätere Pandora-OS-Forschung.

## Build-Ziel

```bash
cd Pandora
./scripts/build-android.sh
```

Ziel: `pandora-android/build/outputs/apk/debug/Pandora.apk`

## Export

```bash
./scripts/export-project.sh
```

Erzeugt `Pandora.zip`.

## Struktur

```text
Pandora/
├── pandora-android/        # Android-App mit CEO Host Mode + Client/Mesh/Sensing/Compute
├── pandora-shared/         # gemeinsame Spezifikation, Modelle und Protokollnotizen
├── docs/                   # komplette Dokumentation
├── scripts/                # Build/Export/Beispieldaten
├── examples/               # Beispielprodukte, Belege, Konfiguration
├── README.md
├── config.example.json
└── master_config.example.json
```

## Erste Einrichtung in der App

1. App starten.
2. `CEO Host Mode` wählen.
3. CEO registrieren.
4. M.2 SSD über Android Storage Access Framework freigeben.
5. Pandora erstellt automatisch `/Pandora/...`, `master_config.json` und `pandora.db`.
6. CEO Host Mode aktivieren.
7. Andere Android-Handys per Pairing-Code/QR registrieren.

## Hauptregel

Wenn CEO Host nicht aktiv ist, sehen andere Geräte nichts.
