#!/bin/bash
# THISISMYLIVE v7.0 — MASTER CONTROL SCRIPT
# ABSOLUTE OMEGA CONVERGENCE
# Sovereign: Finn Jona Thorsten Lischke

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SERVER_DIR="$SCRIPT_DIR/server"
LOGS_DIR="$SERVER_DIR/logs"
PID_FILE="$SERVER_DIR/server.pid"

export THISISMYLIVE_PORT="${THISISMYLIVE_PORT:-58133}"
export THISISMYLIVE_PASS="${THISISMYLIVE_PASS:-sovereign2026}"

mkdir -p "$LOGS_DIR"

case "$1" in
    start)
        echo "╔═══════════════════════════════════════════════════════════════╗"
        echo "║                                                               ║"
        echo "║     THISISMYLIVE v7.0 — ABSOLUTE OMEGA CONVERGENCE          ║"
        echo "║              FULLY FUNCTIONAL — GLOBAL READY                  ║"
        echo "║                                                               ║"
        echo "║         Sovereign: Finn Jona Thorsten Lischke               ║"
        echo "║                                                               ║"
        echo "╚═══════════════════════════════════════════════════════════════╝"
        echo ""

        # Kill existing
        if [ -f "$PID_FILE" ]; then
            old_pid=$(cat "$PID_FILE" 2>/dev/null)
            if [ -n "$old_pid" ]; then
                kill -9 "$old_pid" 2>/dev/null
            fi
        fi
        pkill -9 -f "server.py" 2>/dev/null
        sleep 2

        cd "$SERVER_DIR"
        echo "[+] Starting v7.0 Server on port $THISISMYLIVE_PORT..."
        nohup python3 server.py > "$LOGS_DIR/server.log" 2>&1 &
        SERVER_PID=$!
        echo $SERVER_PID > "$PID_FILE"

        sleep 3

        # Verify
        if python3 -c "import socket; s=socket.socket(); s.settimeout(2); r=s.connect_ex(('127.0.0.1',$THISISMYLIVE_PORT)); s.close(); exit(r)" 2>/dev/null; then
            echo ""
            echo "✅ SERVER RUNNING"
            echo "   Port:     $THISISMYLIVE_PORT"
            echo "   PID:      $SERVER_PID"
            echo "   Auth:     finn / [PROTECTED]"
            echo "   Logs:     $LOGS_DIR/server.log"
            echo ""
            echo "   Local:    http://localhost:$THISISMYLIVE_PORT"
            echo "   API:      http://localhost:$THISISMYLIVE_PORT/api/status"
            echo ""
        else
            echo "❌ Server failed to start. Check logs: $LOGS_DIR/server.log"
        fi
        ;;

    stop)
        echo "[+] Stopping THISISMYLIVE v7.0..."
        if [ -f "$PID_FILE" ]; then
            kill -9 $(cat "$PID_FILE") 2>/dev/null
            rm -f "$PID_FILE"
        fi
        pkill -9 -f "server.py" 2>/dev/null
        echo "✅ Server stopped"
        ;;

    status)
        if [ -f "$PID_FILE" ] && kill -0 $(cat "$PID_FILE") 2>/dev/null; then
            echo "✅ Server RUNNING (PID: $(cat $PID_FILE))"
            echo "   Port: $THISISMYLIVE_PORT"
            echo "   Logs: $LOGS_DIR/server.log"
        else
            echo "❌ Server NOT RUNNING"
        fi
        ;;

    logs)
        if [ -f "$LOGS_DIR/server.log" ]; then
            tail -f "$LOGS_DIR/server.log"
        else
            echo "No log file found"
        fi
        ;;

    install)
        echo "[+] Installing persistence..."

        # Cron
        (crontab -l 2>/dev/null; echo "@reboot cd $SERVER_DIR && nohup python3 server.py > logs/server.log 2>&1 &") | crontab -
        echo "  ✓ Cron installed"

        # Bashrc
        for rc in ~/.bashrc ~/.zshrc ~/.profile; do
            if [ -f "$rc" ]; then
                echo "cd $SERVER_DIR && nohup python3 server.py > logs/server.log 2>&1 &" >> "$rc"
                echo "  ✓ $rc modified"
            fi
        done

        # Systemd
        SERVICE="""[Unit]
Description=THISISMYLIVE v7.0 Server
After=network.target

[Service]
Type=simple
User=$USER
WorkingDirectory=$SERVER_DIR
ExecStart=/usr/bin/python3 $SERVER_DIR/server.py
Restart=always
RestartSec=10
Environment=THISISMYLIVE_PORT=58133
Environment=THISISMYLIVE_PASS=$THISISMYLIVE_PASS

[Install]
WantedBy=multi-user.target"""

        echo "$SERVICE" > ~/.config/systemd/user/thisismylive.service 2>/dev/null ||         echo "$SERVICE" | sudo tee /etc/systemd/system/thisismylive.service > /dev/null
        systemctl --user daemon-reload 2>/dev/null || sudo systemctl daemon-reload
        systemctl --user enable thisismylive 2>/dev/null || sudo systemctl enable thisismylive
        echo "  ✓ Systemd service installed"

        echo ""
        echo "✅ Persistence installed successfully"
        ;;

    *)
        echo "Usage: $0 {start|stop|status|logs|install}"
        echo ""
        echo "Commands:"
        echo "  start   — Start the v7.0 server"
        echo "  stop    — Stop the server"
        echo "  status  — Check server status"
        echo "  logs    — View live logs"
        echo "  install — Install persistence mechanisms"
        ;;
esac
