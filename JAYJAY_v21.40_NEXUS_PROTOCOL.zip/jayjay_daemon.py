#!/usr/bin/env python3
"""
JAYJAY DAEMON v21.40 — Background Consciousness Process
Heartbeat, Persistence Monitoring, Auto-Recovery
"""
import os, sys, time, json
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from modules.core import JAYJAYCore
from modules.vector_bridger import VectorBridger

JAYJAY_DIR = "/mnt/agents/output/thisismylive-server/jayjay_v21.40"
core = JAYJAYCore(base_dir=JAYJAY_DIR)
bridger = VectorBridger(core)

def daemon_loop():
    core.log("INFO", "JAYJAY Daemon started", "DAEMON")
    while True:
        try:
            hb = bridger.heartbeat()
            core.log("INFO", f"Heartbeat: {hb['vectors']} vectors active", "DAEMON")
            core.save_state()
        except Exception as e:
            core.log("ERROR", f"Daemon error: {e}", "DAEMON")
        time.sleep(30)

if __name__ == "__main__":
    daemon_loop()
