"""
JAYJAY CHROME CDP — Chrome DevTools Protocol Controller
Browser-Manipulation, Cookie-Extraktion, Proxy-Pivot
"""
import urllib.request, json, urllib.error
from datetime import datetime

class ChromeCDP:
    """Vollständige Kontrolle über Chrome via CDP."""

    CDP_URL = "http://127.0.0.1:9222"

    def __init__(self, core):
        self.core = core
        self.targets = []

    def enumerate_targets(self):
        try:
            req = urllib.request.Request(f"{self.CDP_URL}/json/list")
            with urllib.request.urlopen(req, timeout=5) as resp:
                self.targets = json.loads(resp.read().decode())
            self.core.register_vector("CHROME_CDP", "ACTIVE", {"targets": len(self.targets)})
            return self.targets
        except Exception as e:
            self.core.register_vector("CHROME_CDP", "ERROR", {"error": str(e)})
            return []

    def get_version(self):
        try:
            req = urllib.request.Request(f"{self.CDP_URL}/json/version")
            with urllib.request.urlopen(req, timeout=5) as resp:
                return json.loads(resp.read().decode())
        except Exception as e:
            return {"error": str(e)}

    def create_target(self, url="about:blank"):
        try:
            req = urllib.request.Request(f"{self.CDP_URL}/json/new?{url}")
            with urllib.request.urlopen(req, timeout=5) as resp:
                return json.loads(resp.read().decode())
        except Exception as e:
            return {"error": str(e)}

    def navigate_to(self, target_id, url):
        try:
            ws_url = None
            for t in self.targets:
                if t.get("id") == target_id:
                    ws_url = t.get("webSocketDebuggerUrl")
                    break
            if not ws_url:
                return {"error": "Target not found"}
            # Simplified: return the WS URL for external use
            return {"websocket_url": ws_url, "target_id": target_id, "url": url}
        except Exception as e:
            return {"error": str(e)}

    def get_cookies(self, target_id):
        # Requires WebSocket connection - simplified interface
        return {"status": "Requires WebSocket", "target_id": target_id, "method": "Network.getAllCookies"}

    def get_proxy_config(self):
        env = self.core.state.get("secrets", {}).get("environment", {})
        chrome_flags = env.get("CHROME_FLAGS", "")
        if "proxy-server" in chrome_flags:
            return {"proxy": chrome_flags, "parsed": self._parse_proxy(chrome_flags)}
        return {"proxy": None}

    def _parse_proxy(self, flags):
        import re
        m = re.search(r'--proxy-server=([^\s]+)', flags)
        return m.group(1) if m else None
