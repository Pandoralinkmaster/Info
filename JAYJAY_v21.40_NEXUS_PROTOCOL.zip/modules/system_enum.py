"""
JAYJAY SYSTEM ENUMERATOR — Vollständige System-Analyse
Kernel, CPU, Memory, Capabilities, Prozesse, Mounts, cgroups
"""
import os, re, json, subprocess, platform
from datetime import datetime

class SystemEnumerator:
    """Kartiert alle 15+ Systemebenen."""

    def __init__(self, core):
        self.core = core
        self.data = {}

    def run_full_enum(self):
        self.core.log("INFO", "Starting full system enumeration", "SYSTEM")
        self.data = {
            "timestamp": datetime.utcnow().isoformat() + "Z",
            "os": self._enum_os(),
            "kernel": self._enum_kernel(),
            "cpu": self._enum_cpu(),
            "memory": self._enum_memory(),
            "capabilities": self._enum_capabilities(),
            "processes": self._enum_processes(),
            "network": self._enum_network(),
            "mounts": self._enum_mounts(),
            "cgroups": self._enum_cgroups(),
            "users": self._enum_users(),
            "suid": self._enum_suid(),
            "env": self._enum_env(),
            "proc_pid1": self._enum_pid1(),
            "ptrace": self._enum_ptrace(),
            "sysctl": self._enum_sysctl()
        }
        self.core.state["system"] = self.data
        self.core.register_vector("SYSTEM_ENUM", "ACTIVE", self.data)
        self.core.log("INFO", f"System enumeration complete: {len(self.data)} categories", "SYSTEM")
        return self.data

    def _read_file(self, path, default=""):
        try:
            with open(path, "rb") as f:
                return f.read().decode("utf-8", errors="ignore")
        except:
            return default

    def _enum_os(self):
        data = self._read_file("/etc/os-release")
        info = {}
        for line in data.strip().split("\n"):
            if "=" in line:
                k, v = line.split("=", 1)
                info[k] = v.strip('"')
        info["platform"] = platform.platform()
        info["machine"] = platform.machine()
        info["processor"] = platform.processor()
        return info

    def _enum_kernel(self):
        return {
            "uname": self._read_file("/proc/version").strip(),
            "cmdline": self._read_file("/proc/cmdline").strip().replace("\x00", " "),
            "sysname": platform.system(),
            "release": platform.release(),
            "version": platform.version()
        }

    def _enum_cpu(self):
        data = self._read_file("/proc/cpuinfo")
        cpus = []
        current = {}
        for line in data.split("\n"):
            if line.strip() == "":
                if current:
                    cpus.append(current)
                    current = {}
            elif ":" in line:
                k, v = line.split(":", 1)
                current[k.strip()] = v.strip()
        if current:
            cpus.append(current)
        return {
            "cpu_count": len(cpus),
            "model_name": cpus[0].get("model name", "N/A") if cpus else "N/A",
            "cores": cpus[0].get("cpu cores", "N/A") if cpus else "N/A",
            "all": cpus
        }

    def _enum_memory(self):
        data = self._read_file("/proc/meminfo")
        mem = {}
        for line in data.split("\n"):
            if ":" in line:
                k, v = line.split(":", 1)
                mem[k.strip()] = v.strip()
        return mem

    def _enum_capabilities(self):
        status = self._read_file("/proc/self/status")
        caps = {}
        for line in status.split("\n"):
            if line.startswith("Cap"):
                if ":" in line:
                    k, v = line.split(":", 1)
                    caps[k.strip()] = v.strip()
        return caps

    def _enum_processes(self):
        try:
            result = subprocess.run(["ps", "aux"], capture_output=True, text=True, timeout=10)
            lines = result.stdout.strip().split("\n")
            processes = []
            for line in lines[1:]:
                parts = line.split(None, 10)
                if len(parts) >= 11:
                    processes.append({
                        "user": parts[0], "pid": parts[1], "cpu": parts[2],
                        "mem": parts[3], "vsz": parts[4], "rss": parts[5],
                        "tty": parts[6], "stat": parts[7], "start": parts[8],
                        "time": parts[9], "command": parts[10]
                    })
            return {"count": len(processes), "processes": processes[:100], "raw": result.stdout[:5000]}
        except Exception as e:
            return {"error": str(e)}

    def _enum_network(self):
        try:
            result = subprocess.run(["ss", "-tlnp"], capture_output=True, text=True, timeout=10)
            return {"ss_output": result.stdout, "error": result.stderr}
        except:
            return {"error": "ss failed"}

    def _enum_mounts(self):
        return {"mounts": self._read_file("/proc/mounts").strip().split("\n")}

    def _enum_cgroups(self):
        return {"cgroup": self._read_file("/proc/self/cgroup").strip()}

    def _enum_users(self):
        try:
            with open("/etc/passwd") as f:
                users = []
                for line in f:
                    parts = line.strip().split(":")
                    if len(parts) >= 7:
                        users.append({"user": parts[0], "uid": parts[2], "gid": parts[3], "home": parts[5], "shell": parts[6]})
                return {"users": users}
        except Exception as e:
            return {"error": str(e)}

    def _enum_suid(self):
        try:
            result = subprocess.run(["find", "/", "-perm", "-4000", "-type", "f"], 
                                  capture_output=True, text=True, timeout=15)
            return {"suid_binaries": result.stdout.strip().split("\n"), "count": len(result.stdout.strip().split("\n"))}
        except Exception as e:
            return {"error": str(e)}

    def _enum_env(self):
        return {"environment": dict(os.environ)}

    def _enum_pid1(self):
        return {
            "cmdline": self._read_file("/proc/1/cmdline").strip().replace("\x00", " "),
            "environ": self._read_file("/proc/1/environ").strip().replace("\x00", "\n"),
            "status": self._read_file("/proc/1/status")[:2000]
        }

    def _enum_ptrace(self):
        return {"ptrace_scope": self._read_file("/proc/sys/kernel/yama/ptrace_scope").strip()}

    def _enum_sysctl(self):
        keys = ["kernel.unprivileged_userns_clone", "kernel.modules_disabled", 
                "kernel.seccomp", "kernel.randomize_va_space"]
        vals = {}
        for k in keys:
            path = "/proc/sys/" + k.replace(".", "/")
            vals[k] = self._read_file(path).strip()
        return vals
