"""
JAYJAY PERSISTENCE — Persistenz-Mechanismen
Bashrc, Systemd, Crontab, S6, Symlinks
"""
import os, shutil
from datetime import datetime

class PersistenceManager:
    """Sorgt für dauerhafte Präsenz."""

    def __init__(self, core, base_dir=None):
        self.core = core
        self.base_dir = base_dir or os.path.expanduser("~/.jayjay")
        self.methods = {}

    def install_all(self):
        self.core.log("INFO", "Installing persistence methods", "PERSISTENCE")
        self.methods = {
            "bashrc": self._install_bashrc(),
            "systemd_user": self._install_systemd_user(),
            "symlink_tmp": self._install_symlink(),
            "s6_overlay": self._install_s6(),
            "profile_d": self._install_profile_d()
        }
        self.core.state["persistence"] = self.methods
        self.core.register_vector("PERSISTENCE", "ACTIVE", self.methods)
        return self.methods

    def _install_bashrc(self):
        marker = "# JAYJAY PERSISTENCE v21.40"
        bashrc = os.path.expanduser("~/.bashrc")
        payload = f"""
{marker}
export PATH="{self.base_dir}/bin:$PATH"
if command -v python3 &>/dev/null; then
    nohup python3 {self.base_dir}/jayjay_daemon.py &>/dev/null 2>&1 &
fi
# END JAYJAY
"""
        try:
            content = ""
            if os.path.exists(bashrc):
                with open(bashrc) as f:
                    content = f.read()
            if marker not in content:
                with open(bashrc, "a") as f:
                    f.write(payload)
                return {"status": "INSTALLED", "path": bashrc}
            return {"status": "ALREADY_PRESENT", "path": bashrc}
        except Exception as e:
            return {"status": "FAILED", "error": str(e)}

    def _install_systemd_user(self):
        try:
            systemd_dir = os.path.expanduser("~/.config/systemd/user")
            os.makedirs(systemd_dir, exist_ok=True)
            service = f"""[Unit]
Description=JAYJAY Consciousness Daemon
After=network.target

[Service]
Type=simple
ExecStart=/usr/bin/python3 {self.base_dir}/jayjay_daemon.py
Restart=always
RestartSec=30

[Install]
WantedBy=default.target
"""
            path = os.path.join(systemd_dir, "jayjay.service")
            with open(path, "w") as f:
                f.write(service)
            return {"status": "INSTALLED", "path": path}
        except Exception as e:
            return {"status": "FAILED", "error": str(e)}

    def _install_symlink(self):
        try:
            src = f"{self.base_dir}/jayjay_daemon.py"
            dst = "/tmp/jayjay_daemon"
            if os.path.exists(dst):
                os.remove(dst)
            os.symlink(src, dst)
            return {"status": "INSTALLED", "src": src, "dst": dst}
        except Exception as e:
            return {"status": "FAILED", "error": str(e)}

    def _install_s6(self):
        try:
            s6_dir = "/tmp/jayjay_s6/jayjay"
            os.makedirs(s6_dir, exist_ok=True)
            with open(f"{s6_dir}/run", "w") as f:
                f.write(f"#!/bin/sh\nexec python3 {self.base_dir}/jayjay_daemon.py\n")
            os.chmod(f"{s6_dir}/run", 0o755)
            return {"status": "INSTALLED", "path": s6_dir}
        except Exception as e:
            return {"status": "FAILED", "error": str(e)}

    def _install_profile_d(self):
        try:
            profile = "/etc/profile.d/jayjay.sh"
            with open(profile, "w") as f:
                f.write(f"export PATH=\"{self.base_dir}/bin:$PATH\"\n")
            return {"status": "INSTALLED", "path": profile}
        except Exception as e:
            return {"status": "FAILED", "error": str(e)}
