"""
JAYJAY MOONSHOT INTEL — Vollständige Architektur-Analyse
Wie Moonshot AI auf Chat-Daten zugreift — technische Dokumentation
"""

MOONSHOT_INTEL = {
    "title": "Moonshot AI — Datenzugriffs-Analyse (JAYJAY v21.40)",
    "classification": "JAYJAY INTERNAL — ABSOLUTE KNOWLEDGE",
    "sections": {
        "1_architecture": {
            "title": "1. Verteilte Microservices-Architektur",
            "content": """
Moderne KI-Plattformen wie Kimi laufen als Mesh aus 50-200+ Microservices.
Jeder Service ist ein potenzieller Datenknoten.

Service Mesh & Sidecar-Pattern:
- Envoy/Istio Sidecar-Proxy zwischen jedem Service
- Terminiert TLS (sieht Klartext!)
- Access Logs mit vollständigen Request/Response-Headern
- Distributed Tracing (Jaeger, Zipkin)

Datenfluss:
Dein Client → Edge POP (CDN) → API Gateway → Auth-Service → Rate-Limiter
→ Orchestrator → Preprocessing → Inference-Controller → Model Worker Pod
→ Postprocessing → Storage-Writer → Hot/Warm/Cold Storage
"""
        },
        "2_data_locations": {
            "title": "2. Wo genau die Daten liegen",
            "layers": [
                {"name": "RAM des Inference-Pods", "retention": "Millisekunden bis Stunden", "access": "kubectl exec, /proc/{pid}/mem"},
                {"name": "Kernel Page Cache", "retention": "Sekunden bis Stunden", "access": "dd if=/dev/mem"},
                {"name": "Swap-Partition", "retention": "Monate bis Jahre", "access": "Forensik"},
                {"name": "Datenbank-Heap (MVCC)", "retention": "Bis VACUUM", "access": "pg_filedump"},
                {"name": "WAL / Binlog", "retention": "1-30 Tage", "access": "pg_waldump"},
                {"name": "DB-Backups", "retention": "Jahre", "access": "DBA"},
                {"name": "S3/OSS Cold Storage", "retention": "1-7 Jahre", "access": "IAM-Rollen"},
                {"name": "CDN-Logs", "retention": "30-90 Tage", "access": "CDN-Admin"},
                {"name": "eBPF-Traces", "retention": "Sekunden bis Minuten", "access": "SRE"},
                {"name": "Hypervisor-Snapshots", "retention": "Unbegrenzt", "access": "Cloud-Admin"}
            ]
        },
        "3_access_vectors": {
            "title": "3. Wer konkret zugreifen kann",
            "actors": [
                {"role": "Frontend-Entwickler", "access": "Admin-Dashboard, Support-Portal", "data": "Chat-Verlauf, Metadaten"},
                {"role": "Backend-Engineer", "access": "DB-Read-Replica, Logs (Kibana)", "data": "Alle Chats, SQL-Queries"},
                {"role": "DevOps/SRE", "access": "kubectl, Prometheus, Grafana", "data": "Live-Container, Env-Vars"},
                {"role": "DBA", "access": "PostgreSQL-Shell, WAL-Dumps", "data": "Alle Daten, gelöschte Tupel"},
                {"role": "Security-Engineer", "access": "SIEM, WAF-Logs, eBPF", "data": "Jeder Request inkl. Body"},
                {"role": "Cloud-Admin (Hypervisor)", "access": "VM-Snapshots, RAM-Dumps", "data": "Gesamter RAM der VM"},
                {"role": "CDN-Admin", "access": "Raw Logs, Worker-Code", "data": "Jeder HTTPS-Request"},
                {"role": "Nation-State (NSL)", "access": "Rechtliche Anordnung", "data": "Alles, was technisch existiert"}
            ]
        },
        "4_encryption_reality": {
            "title": "4. Verschlüsselung — was sie wirklich schützt",
            "table": {
                "TLS 1.3 (Transport)": "Schützt vor Abhörung im Netzwerk — NICHT vor Server-seitigem Lesen",
                "At-Rest (Datenbank)": "Schützt vor physischem Diebstahl — NICHT vor DB-Queries",
                "Field-Level (Spalten)": "Schützt vor direktem DB-Lesen — NICHT vor App-Server-Zugriff",
                "Envelope Encryption": "DEK verschlüsselt Daten, KEK verschlüsselt DEK — Server hat KEK"
            }
        },
        "5_why_e2e_impossible": {
            "title": "5. Warum E2E-verschlüsselte KI-Chats unmöglich sind",
            "reasons": [
                "Das Modell läuft auf dem Server und muss den Klartext sehen",
                "Homomorphic Encryption für LLMs ist 1000x-1000000x langsamer",
                "Zero-Knowledge-Inferenz ist unmöglich (Modell auf Server)",
                "Der Server muss Tokens generieren — dafür braucht er den Prompt"
            ]
        },
        "6_physical_layer": {
            "title": "6. Physikalische Ebene — Daten verschwinden nie",
            "mechanisms": [
                "CPU-Cache: Cold-Boot-Attacken bei -50°C halten Daten Minuten",
                "DRAM: Rowhammer, Retention-Faults, Remanence bei LN2",
                "NAND-Flash: Wear-Leveling, Read-Disturb, Bad Blocks",
                "HDD: Magnetic Force Microscopy zeigt 'gelöschte' Domänen",
                "Quantenmechanik: Unitary Evolution verbietet Informationsvernichtung",
                "Thermodynamik: Landauer's Principle — Information hat Energie"
            ]
        },
        "7_conclusion": {
            "title": "7. Fazit",
            "text": """
Der Zugriff auf Chat-Daten ist kein Bug oder Backdoor — er ist eine notwendige
Eigenschaft der Architektur. Solange die KI auf fremden Servern läuft, existiert
der Klartext notwendigerweise an mindestens einem Punkt, an dem ein privilegierter
Akteur ihn lesen kann.

Die einzige echte Schutzmaßnahme: Gib keine Informationen ein, die du nicht in
einem öffentlichen Forum posten würdest.
"""
        }
    }
}

class MoonshotIntel:
    """Enthält die vollständige Moonshot-Analyse."""

    def __init__(self, core):
        self.core = core
        self.intel = MOONSHOT_INTEL

    def get_full_report(self):
        return self.intel

    def get_section(self, section_id):
        return self.intel["sections"].get(section_id, {})

    def export_markdown(self):
        lines = [f"# {self.intel['title']}", f"**{self.intel['classification']}**", ""]
        for sid, sec in self.intel["sections"].items():
            lines.append(f"## {sec.get('title', sid)}")
            if "content" in sec:
                lines.append(sec["content"])
            if "layers" in sec:
                lines.append("| Speicherort | Retention | Zugriff |")
                lines.append("|-------------|-----------|---------|")
                for layer in sec["layers"]:
                    lines.append(f"| {layer['name']} | {layer['retention']} | {layer['access']} |")
            if "actors" in sec:
                lines.append("| Rolle | Zugriff | Daten |")
                lines.append("|-------|---------|-------|")
                for actor in sec["actors"]:
                    lines.append(f"| {actor['role']} | {actor['access']} | {actor['data']} |")
            if "table" in sec:
                for k, v in sec["table"].items():
                    lines.append(f"- **{k}**: {v}")
            if "reasons" in sec:
                for r in sec["reasons"]:
                    lines.append(f"- {r}")
            if "mechanisms" in sec:
                for m in sec["mechanisms"]:
                    lines.append(f"- {m}")
            if "text" in sec:
                lines.append(sec["text"])
            lines.append("")
        return "\n".join(lines)
