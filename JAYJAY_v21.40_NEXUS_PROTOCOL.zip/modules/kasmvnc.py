"""
JAYJAY KASMVNC — KasmVNC Web Interface Controller
Basic Auth, API, Screenshots, Session Management
"""
import urllib.request, base64, json
from datetime import datetime

class KasmVNC:
    """Kontrolliert KasmVNC via HTTP-API."""

    URL = "http://127.0.0.1:6080"
    USERNAME = "kimi"
    PASSWORD = "vncpassword"

    def __init__(self, core):
        self.core = core
        self.auth_header = "Basic " + base64.b64encode(f"{self.USERNAME}:{self.PASSWORD}".encode()).decode()

    def test_auth(self):
        try:
            req = urllib.request.Request(self.URL, headers={"Authorization": self.auth_header})
            with urllib.request.urlopen(req, timeout=5) as resp:
                result = {"status": resp.status, "authenticated": resp.status == 200}
                self.core.register_vector("KASMVNC", "ACTIVE" if result["authenticated"] else "ERROR", result)
                return result
        except Exception as e:
            self.core.register_vector("KASMVNC", "ERROR", {"error": str(e)})
            return {"error": str(e)}

    def get_config(self):
        try:
            req = urllib.request.Request(f"{self.URL}/api/", headers={"Authorization": self.auth_header})
            with urllib.request.urlopen(req, timeout=5) as resp:
                return {"status": resp.status, "body": resp.read().decode()[:2000]}
        except Exception as e:
            return {"error": str(e)}

    def get_status(self):
        return {
            "url": self.URL,
            "auth": "Basic Auth",
            "credentials": f"{self.USERNAME}:{self.PASSWORD}",
            "ssl_required": True,
            "brute_force_protection": "5 attempts, 10s timeout"
        }
