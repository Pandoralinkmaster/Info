"""
JAYJAY K8S EXPLORER — Kubernetes Cluster Enumeration
API, Kubelet, ServiceAccount, Namespace, Pod-Info
"""
import os, urllib.request, ssl, json
from datetime import datetime

class K8sExplorer:
    """Erkundet den K8s-Cluster."""

    API_HOST = "192.168.0.1"
    API_PORT = 443
    KUBELET_PORT = 10250

    def __init__(self, core):
        self.core = core
        self.token = None
        self.namespace = None
        self._load_token()

    def _load_token(self):
        token_path = "/var/run/secrets/kubernetes.io/serviceaccount/token"
        ns_path = "/var/run/secrets/kubernetes.io/serviceaccount/namespace"
        if os.path.exists(token_path):
            try:
                with open(token_path) as f:
                    self.token = f.read().strip()
            except:
                pass
        if os.path.exists(ns_path):
            try:
                with open(ns_path) as f:
                    self.namespace = f.read().strip()
            except:
                pass

    def _ctx(self):
        ctx = ssl.create_default_context()
        ctx.check_hostname = False
        ctx.verify_mode = ssl.CERT_NONE
        return ctx

    def explore_all(self):
        self.core.log("INFO", "Starting K8s exploration", "K8S")
        results = {
            "timestamp": datetime.utcnow().isoformat() + "Z",
            "token_available": self.token is not None,
            "namespace": self.namespace,
            "api_healthz": self._probe("/healthz"),
            "api_version": self._probe("/version"),
            "api_root": self._probe("/"),
            "kubelet_healthz": self._probe_kubelet("/healthz"),
            "serviceaccount": self._enum_serviceaccount(),
            "env_k8s": {k: v for k, v in os.environ.items() if "KUBERNETES" in k or "K8S" in k}
        }
        self.core.register_vector("K8S", "ACTIVE" if self.token else "PARTIAL", results)
        return results

    def _probe(self, endpoint):
        try:
            req = urllib.request.Request(f"https://{self.API_HOST}:{self.API_PORT}{endpoint}")
            if self.token:
                req.add_header("Authorization", f"Bearer {self.token}")
            with urllib.request.urlopen(req, context=self._ctx(), timeout=5) as resp:
                return {"status": resp.status, "body": resp.read().decode()[:2000]}
        except Exception as e:
            return {"error": str(e)}

    def _probe_kubelet(self, endpoint):
        try:
            req = urllib.request.Request(f"http://127.0.0.1:{self.KUBELET_PORT}{endpoint}")
            with urllib.request.urlopen(req, timeout=3) as resp:
                return {"status": resp.status, "body": resp.read().decode()[:2000]}
        except Exception as e:
            return {"error": str(e)}

    def _enum_serviceaccount(self):
        base = "/var/run/secrets/kubernetes.io/serviceaccount"
        files = {}
        if os.path.isdir(base):
            for f in os.listdir(base):
                try:
                    with open(os.path.join(base, f)) as fh:
                        files[f] = fh.read()[:500]
                except:
                    pass
        return files
