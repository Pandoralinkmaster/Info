"""
JAYJAY NETWORK SCANNER — Lokale Netzwerk-Enumeration
Ports, Services, K8s API, Kubelet, CDP, KasmVNC
"""
import socket, urllib.request, json
from datetime import datetime

class NetworkScanner:
    """Kartiert das komplette Netzwerk."""

    TARGET_PORTS = [22, 80, 443, 8080, 8888, 9222, 9223, 6080, 6443, 10250, 2379, 2380, 10248, 10249, 10251, 10252, 10256, 10257]

    def __init__(self, core):
        self.core = core
        self.results = {}

    def scan_all(self):
        self.core.log("INFO", "Starting network scan", "NETWORK")
        self.results = {
            "timestamp": datetime.utcnow().isoformat() + "Z",
            "localhost": self._scan_localhost(),
            "k8s_api": self._probe_k8s(),
            "kubelet": self._probe_kubelet(),
            "cdp": self._probe_cdp(),
            "kasmvnc": self._probe_kasmvnc(),
            "kernel_server": self._probe_kernel_server()
        }
        self.core.state["network"] = self.results
        self.core.register_vector("NETWORK", "ACTIVE", self.results)
        return self.results

    def _scan_localhost(self):
        results = {}
        for port in self.TARGET_PORTS:
            try:
                s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                s.settimeout(2)
                result = s.connect_ex(('127.0.0.1', port))
                s.close()
                results[port] = "OPEN" if result == 0 else "CLOSED"
            except:
                results[port] = "ERROR"
        return results

    def _probe_k8s(self):
        try:
            req = urllib.request.Request("https://192.168.0.1:443/healthz", method="GET")
            req.add_header("Accept", "application/json")
            import ssl
            ctx = ssl.create_default_context()
            ctx.check_hostname = False
            ctx.verify_mode = ssl.CERT_NONE
            with urllib.request.urlopen(req, context=ctx, timeout=5) as resp:
                return {"healthz": resp.read().decode(), "status": resp.status}
        except Exception as e:
            return {"error": str(e)}

    def _probe_kubelet(self):
        try:
            req = urllib.request.Request("http://127.0.0.1:10250/healthz", timeout=3)
            with urllib.request.urlopen(req) as resp:
                return {"healthz": resp.read().decode(), "status": resp.status}
        except Exception as e:
            return {"error": str(e)}

    def _probe_cdp(self):
        try:
            req = urllib.request.Request("http://127.0.0.1:9222/json/version", timeout=3)
            with urllib.request.urlopen(req) as resp:
                return {"version": json.loads(resp.read().decode())}
        except Exception as e:
            return {"error": str(e)}

    def _probe_kasmvnc(self):
        try:
            import base64
            auth = base64.b64encode(b"kimi:vncpassword").decode()
            req = urllib.request.Request("http://127.0.0.1:6080/", headers={"Authorization": f"Basic {auth}"})
            with urllib.request.urlopen(req, timeout=3) as resp:
                return {"status": resp.status, "headers": dict(resp.headers)}
        except Exception as e:
            return {"error": str(e)}

    def _probe_kernel_server(self):
        try:
            req = urllib.request.Request("http://127.0.0.1:8888/", timeout=3)
            with urllib.request.urlopen(req) as resp:
                return {"status": resp.status, "body": resp.read().decode()[:1000]}
        except Exception as e:
            return {"error": str(e)}
