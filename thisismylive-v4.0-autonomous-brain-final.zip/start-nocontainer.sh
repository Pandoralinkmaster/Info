#!/bin/bash
# THISISMYLIVE v4.0 - NO CONTAINER START
# Starts server natively without Docker/containerization

set -e
DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$DIR"

echo "========================================"
echo "  THISISMYLIVE v4.0 - NO CONTAINER"
echo "========================================"

# Set environment
export THISISMYLIVE_PORT=58133
export THISISMYLIVE_USER=finn
if [ -z "$THISISMYLIVE_PASSWORD" ]; then
    echo "[WARNING] Set THISISMYLIVE_PASSWORD for protected access"
    echo "[INFO] Example: export THISISMYLIVE_PASSWORD=your_secret"
fi

# Kill old server
if [ -f ".server.pid" ]; then
    OLD_PID=$(cat .server.pid 2>/dev/null)
    if kill -0 "$OLD_PID" 2>/dev/null; then
        echo "[STOP] Stopping old server (PID: $OLD_PID)"
        kill "$OLD_PID" 2>/dev/null || true
        sleep 1
    fi
    rm -f .server.pid
fi

# Kill anything on port 58133
if command -v lsof >/dev/null 2>&1; then
    lsof -ti:58133 | xargs kill -9 2>/dev/null || true
fi

# Start server
echo "[START] Starting server on 0.0.0.0:58133..."
if command -v python3 >/dev/null 2>&1; then
    nohup python3 "$DIR/server-auth.py" >> "$DIR/server.log" 2>&1 &
    SERVER_PID=$!
    echo "$SERVER_PID" > .server.pid
    echo "[START] Python server started (PID: $SERVER_PID)"
else
    echo "[ERROR] Python3 not found!"
    exit 1
fi

# Wait for server
sleep 3

# Check if running
if (echo >/dev/tcp/localhost/58133) 2>/dev/null; then
    echo "[OK] Server responding on port 58133"
else
    echo "[ERROR] Server not responding!"
    exit 1
fi

# Start tunnel in background
echo "[START] Starting tunnel..."
nohup "$DIR/tunnel-permanent.sh" >> "$DIR/tunnel.log" 2>&1 &
TUNNEL_PID=$!
echo "$TUNNEL_PID" > .tunnel.pid

# Wait for tunnel URL
sleep 10

if [ -f "$DIR/tunnel.url" ]; then
    URL=$(cat "$DIR/tunnel.url")
    echo ""
    echo "========================================"
    echo "  SERVER IS LIVE"
    echo "========================================"
    echo ""
    echo "  LOCAL:  http://localhost:58133"
    echo "  GLOBAL: $URL"
    echo ""
    echo "  Auth:   finn / [your password]"
    echo ""
    echo "  Commands:"
    echo "    ./master.sh status   - Check status"
    echo "    ./master.sh stop     - Stop server"
    echo "    ./global-access.sh   - Show all access methods"
    echo ""
    echo "========================================"
else
    echo "[WARNING] Tunnel URL not yet available"
    echo "[INFO] Check tunnel.log for details"
fi

echo ""
echo "[DONE] THISISMYLIVE v4.0 running in NO CONTAINER mode"
