#!/usr/bin/env python3
"""
THISISMYLIVE v4.0 - Python HTTP Tunnel
Alternative tunnel using Python + free tunnel services
"""
import urllib.request, urllib.parse, json, time, subprocess, os, sys, threading

PORT = 58133
SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
URL_FILE = os.path.join(SCRIPT_DIR, "tunnel.url")
LOG_FILE = os.path.join(SCRIPT_DIR, "tunnel.log")

def log(msg):
    ts = time.strftime("%Y-%m-%d %H:%M:%S")
    line = f"[{ts}] [PY-TUNNEL] {msg}"
    print(line)
    with open(LOG_FILE, "a") as f:
        f.write(line + "\n")

def try_localtunnel():
    """Try localtunnel via npx or local install"""
    lt_path = os.path.join(SCRIPT_DIR, "node_modules", ".bin", "lt")

    if os.path.exists(lt_path):
        cmd = [lt_path, "--port", str(PORT), "--subdomain", "thisismylive-eternal"]
    elif os.path.exists("/usr/local/bin/lt"):
        cmd = ["lt", "--port", str(PORT), "--subdomain", "thisismylive-eternal"]
    else:
        cmd = ["npx", "localtunnel", "--port", str(PORT), "--subdomain", "thisismylive-eternal"]

    log(f"Trying localtunnel: {' '.join(cmd)}")

    try:
        proc = subprocess.Popen(
            cmd,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            cwd=SCRIPT_DIR
        )

        # Read output for URL
        url = None
        for line in iter(proc.stdout.readline, ''):
            line = line.strip()
            log(f"lt output: {line}")
            if "loca.lt" in line or "localtunnel.me" in line:
                # Extract URL
                import re
                match = re.search(r'https://[^\s]+', line)
                if match:
                    url = match.group(0)
                    break
            if "your url is" in line.lower():
                parts = line.split()
                for p in parts:
                    if p.startswith("http"):
                        url = p
                        break

        if url:
            with open(URL_FILE, "w") as f:
                f.write(url)
            log(f"Tunnel URL: {url}")
            print(f"\n========================================")
            print(f"  GLOBAL URL: {url}")
            print(f"  LOCAL URL:  http://localhost:{PORT}")
            print(f"========================================\n")

            # Keep process running
            proc.wait()
        else:
            log("Could not extract tunnel URL")
            proc.terminate()

    except Exception as e:
        log(f"localtunnel failed: {e}")

def try_serveo():
    """Try serveo.net SSH tunnel"""
    log("Trying serveo.net SSH tunnel...")
    try:
        proc = subprocess.Popen(
            ["ssh", "-o", "StrictHostKeyChecking=no", "-R", f"80:localhost:{PORT}", "serveo.net"],
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True
        )

        url = None
        for line in iter(proc.stdout.readline, ''):
            line = line.strip()
            log(f"serveo: {line}")
            if "Forwarding" in line:
                parts = line.split()
                for p in parts:
                    if "serveo.net" in p:
                        url = f"https://{p}"
                        break

        if url:
            with open(URL_FILE, "w") as f:
                f.write(url)
            log(f"Serveo URL: {url}")
            proc.wait()
        else:
            log("Serveo failed")
            proc.terminate()
    except Exception as e:
        log(f"Serveo failed: {e}")

def try_localhost_run():
    """Try localhost.run SSH tunnel"""
    log("Trying localhost.run SSH tunnel...")
    try:
        proc = subprocess.Popen(
            ["ssh", "-o", "StrictHostKeyChecking=no", "-R", f"80:localhost:{PORT}", "localhost.run"],
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True
        )

        url = None
        for line in iter(proc.stdout.readline, ''):
            line = line.strip()
            log(f"localhost.run: {line}")
            if "localhost.run" in line:
                import re
                match = re.search(r'https://[^\s]+localhost\.run[^\s]*', line)
                if match:
                    url = match.group(0)
                    break

        if url:
            with open(URL_FILE, "w") as f:
                f.write(url)
            log(f"localhost.run URL: {url}")
            proc.wait()
        else:
            log("localhost.run failed")
            proc.terminate()
    except Exception as e:
        log(f"localhost.run failed: {e}")

def main():
    log("Python Tunnel starting...")

    # Try methods in order
    methods = [
        ("localtunnel", try_localtunnel),
        ("serveo", try_serveo),
        ("localhost.run", try_localhost_run),
    ]

    for name, method in methods:
        log(f"Trying {name}...")
        try:
            method()
            log(f"{name} exited, trying next...")
        except Exception as e:
            log(f"{name} error: {e}")

    log("All tunnel methods exhausted")

if __name__ == "__main__":
    main()
