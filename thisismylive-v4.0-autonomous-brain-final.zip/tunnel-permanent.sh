#!/bin/bash
# THISISMYLIVE v4.0 - REAL Tunnel with Auto-Reconnect
# Exposes localhost:58133 to the internet via localtunnel

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PORT=58133
TUNNEL_URL_FILE="$SCRIPT_DIR/tunnel.url"
LOGFILE="$SCRIPT_DIR/tunnel.log"
PIDFILE="$SCRIPT_DIR/.tunnel.pid"

log() { echo "[$(date '+%Y-%m-%d %H:%M:%S')] [TUNNEL] $1" | tee -a "$LOGFILE"; }

# Detect tunnel command
detect_tunnel_cmd() {
    if command -v lt >/dev/null 2>&1; then
        echo "lt"
    elif command -v npx >/dev/null 2>&1; then
        echo "npx localtunnel"
    else
        echo ""
    fi
}

TUNNEL_CMD=$(detect_tunnel_cmd)

if [ -z "$TUNNEL_CMD" ]; then
    log "ERROR: No tunnel command found. Install with: npm install -g localtunnel"
    exit 1
fi

log "Tunnel tool: $TUNNEL_CMD"
log "Starting tunnel on port $PORT..."

# Kill old tunnel
if [ -f "$PIDFILE" ]; then
    OLD_PID=$(cat "$PIDFILE" 2>/dev/null)
    if kill -0 "$OLD_PID" 2>/dev/null; then
        kill "$OLD_PID" 2>/dev/null
        log "Killed old tunnel (PID: $OLD_PID)"
    fi
    rm -f "$PIDFILE"
fi

# Start tunnel in background and capture URL
if [ "$TUNNEL_CMD" = "lt" ]; then
    lt --port "$PORT" --subdomain thisismylive-eternal > "$SCRIPT_DIR/.tunnel_output" 2>&1 &
else
    npx localtunnel --port "$PORT" --subdomain thisismylive-eternal > "$SCRIPT_DIR/.tunnel_output" 2>&1 &
fi

TUNNEL_PID=$!
echo $TUNNEL_PID > "$PIDFILE"
log "Tunnel started (PID: $TUNNEL_PID)"

# Wait and extract URL
sleep 8

if [ -f "$SCRIPT_DIR/.tunnel_output" ]; then
    URL=$(grep -o 'https://[^[:space:]]*loca.lt' "$SCRIPT_DIR/.tunnel_output" 2>/dev/null | head -1)
    if [ -n "$URL" ]; then
        echo "$URL" > "$TUNNEL_URL_FILE"
        log "Tunnel URL: $URL"
        echo "========================================"
        echo "  GLOBAL URL: $URL"
        echo "  LOCAL URL:  http://localhost:$PORT"
        echo "========================================"
    else
        log "Could not extract URL from output"
        cat "$SCRIPT_DIR/.tunnel_output" >> "$LOGFILE"
    fi
fi

# Monitor tunnel
while true; do
    sleep 30
    if ! kill -0 "$TUNNEL_PID" 2>/dev/null; then
        log "Tunnel died. Restarting..."
        rm -f "$PIDFILE"
        exec "$0"  # Restart self
    fi
    # Check if URL still works
    if [ -f "$TUNNEL_URL_FILE" ]; then
        URL=$(cat "$TUNNEL_URL_FILE")
        if command -v curl >/dev/null 2>&1; then
            if ! curl -s --max-time 5 "$URL" > /dev/null 2>&1; then
                log "Tunnel URL not responding. Restarting..."
                kill "$TUNNEL_PID" 2>/dev/null
                rm -f "$PIDFILE"
                exec "$0"
            fi
        fi
    fi
done
