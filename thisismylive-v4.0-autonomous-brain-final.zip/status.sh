#!/bin/bash
# THISISMYLIVE v4.0 - Status Check

echo "==================================="
echo "  THISISMYLIVE v4.0 STATUS CHECK"
echo "==================================="
echo ""

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PORT=58133

# Server PID
if [ -f "$SCRIPT_DIR/.server.pid" ]; then
    PID=$(cat "$SCRIPT_DIR/.server.pid" 2>/dev/null)
    if kill -0 "$PID" 2>/dev/null; then
        echo "✓ Server PID: $PID (RUNNING)"
    else
        echo "✗ Server PID: $PID (DEAD)"
    fi
else
    echo "✗ Server: No PID file"
fi

# Port check
if (echo >/dev/tcp/localhost/$PORT) 2>/dev/null; then
    echo "✓ Port $PORT: OPEN"
else
    echo "✗ Port $PORT: CLOSED"
fi

# Tunnel PID
if [ -f "$SCRIPT_DIR/.tunnel.pid" ]; then
    PID=$(cat "$SCRIPT_DIR/.tunnel.pid" 2>/dev/null)
    if kill -0 "$PID" 2>/dev/null; then
        echo "✓ Tunnel PID: $PID (RUNNING)"
    else
        echo "✗ Tunnel PID: $PID (DEAD)"
    fi
else
    echo "✗ Tunnel: No PID file"
fi

# Tunnel URL
if [ -f "$SCRIPT_DIR/tunnel.url" ]; then
    echo "✓ Global URL: $(cat "$SCRIPT_DIR/tunnel.url")"
else
    echo "✗ Global URL: Not available"
fi

echo ""
echo "Local Access:  http://localhost:$PORT"
echo ""

# System info
echo "System:"
echo "  User: $(whoami) (UID: $(id -u))"
echo "  Host: $(hostname)"
echo "  Date: $(date)"
echo ""
echo "==================================="
