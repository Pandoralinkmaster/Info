#!/bin/bash
# THISISMYLIVE v4.0 - Protected Start
# Requires THISISMYLIVE_PASSWORD environment variable

if [ -z "$THISISMYLIVE_PASSWORD" ] && [ -z "$THISISMYLIVE_PASSWORD_HASH" ]; then
    echo "[ERROR] Set THISISMYLIVE_PASSWORD or THISISMYLIVE_PASSWORD_HASH first!"
    echo "[INFO] Example: export THISISMYLIVE_PASSWORD=your_secret"
    exit 1
fi

DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$DIR"

if command -v python3 >/dev/null 2>&1; then
    nohup python3 server-auth.py > server.log 2>&1 &
    echo $! > .server.pid
elif command -v node >/dev/null 2>&1; then
    nohup node server.js > server.log 2>&1 &
    echo $! > .server.pid
fi

echo "[THISISMYLIVE] Protected server started on port 58133"
echo "[THISISMYLIVE] Auth required for access"
