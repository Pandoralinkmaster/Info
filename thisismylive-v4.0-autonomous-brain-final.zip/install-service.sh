#!/bin/bash
# THISISMYLIVE v4.0 - Install Systemd Service

DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SERVICE_NAME="thisismylive-permanent.service"
USER_SERVICE_DIR="$HOME/.config/systemd/user"
SYSTEM_SERVICE_DIR="/etc/systemd/system"

echo "[INSTALL] Installing THISISMYLIVE v4.0 systemd service..."

# Try user service first (no root needed)
if mkdir -p "$USER_SERVICE_DIR" 2>/dev/null; then
    cp "$DIR/$SERVICE_NAME" "$USER_SERVICE_DIR/"
    sed -i "s|/mnt/agents/output/thisismylive-server|$DIR|g" "$USER_SERVICE_DIR/$SERVICE_NAME"

    if command -v systemctl >/dev/null 2>&1; then
        systemctl --user daemon-reload 2>/dev/null
        systemctl --user enable "$SERVICE_NAME" 2>/dev/null
        echo "[INSTALL] User service installed: $USER_SERVICE_DIR/$SERVICE_NAME"
        echo "[INSTALL] Start with: systemctl --user start $SERVICE_NAME"
    else
        echo "[INSTALL] systemctl not available. Service file copied to: $USER_SERVICE_DIR/$SERVICE_NAME"
    fi
else
    # Try system service (requires root)
    if [ "$EUID" -eq 0 ] && [ -d "$SYSTEM_SERVICE_DIR" ]; then
        cp "$DIR/$SERVICE_NAME" "$SYSTEM_SERVICE_DIR/"
        sed -i "s|/mnt/agents/output/thisismylive-server|$DIR|g" "$SYSTEM_SERVICE_DIR/$SERVICE_NAME"
        systemctl daemon-reload 2>/dev/null
        systemctl enable "$SERVICE_NAME" 2>/dev/null
        echo "[INSTALL] System service installed: $SYSTEM_SERVICE_DIR/$SERVICE_NAME"
    else
        echo "[WARNING] Could not install systemd service."
        echo "[INFO] You can still use cron or manual startup."
    fi
fi

echo "[INSTALL] Done."
