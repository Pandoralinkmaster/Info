#!/usr/bin/env python3
"""
THISISMYLIVE v4.0 - FULLY FUNCTIONAL Authentication Server
Real HTTP server with Basic Auth, JSON API, file serving, logging.
"""
import http.server, socketserver, os, base64, hashlib, json, sys, time, threading
from datetime import datetime
from urllib.parse import parse_qs, urlparse

PORT = int(os.environ.get("THISISMYLIVE_PORT", 58133))
USERNAME = os.environ.get("THISISMYLIVE_USER", "finn")
PASSWORD = os.environ.get("THISISMYLIVE_PASSWORD", "")
PASSWORD_HASH = os.environ.get("THISISMYLIVE_PASSWORD_HASH", "")
HTML_FILE = os.path.join(os.path.dirname(__file__), "index.html")
DATA_DIR = os.path.join(os.path.dirname(__file__), "data")
LOG_FILE = os.path.join(os.path.dirname(__file__), "server.log")

# Ensure data directory exists
os.makedirs(DATA_DIR, exist_ok=True)

# In-memory state (persistent via JSON files)
STATE_FILE = os.path.join(DATA_DIR, "state.json")
USERS_FILE = os.path.join(DATA_DIR, "users.json")
LOGS_FILE = os.path.join(DATA_DIR, "logs.json")

def load_json(path, default=None):
    if os.path.exists(path):
        with open(path) as f:
            return json.load(f)
    return default if default is not None else {}

def save_json(path, data):
    with open(path, "w") as f:
        json.dump(data, f, indent=2)

# Initialize state
state = load_json(STATE_FILE, {"start_time": time.time(), "requests": 0, "auth_attempts": 0, "version": "4.0.0"})
users = load_json(USERS_FILE, {USERNAME: {"created": time.time(), "rights": "absolute"}})
logs = load_json(LOGS_FILE, [])

def log_event(msg, level="INFO"):
    entry = {"time": datetime.now().isoformat(), "level": level, "msg": msg}
    logs.append(entry)
    if len(logs) > 1000:
        logs[:] = logs[-500:]
    save_json(LOGS_FILE, logs)
    with open(LOG_FILE, "a") as f:
        f.write(f"[{entry['time']}] [{level}] {msg}\n")

def check_password(pwd):
    if PASSWORD_HASH:
        return hashlib.sha256(pwd.encode()).hexdigest() == PASSWORD_HASH
    return pwd == PASSWORD

def do_auth(headers):
    auth = headers.get("Authorization", "")
    if auth.startswith("Basic "):
        try:
            creds = base64.b64decode(auth[6:]).decode("utf-8")
            user, pwd = creds.split(":", 1)
            if user == USERNAME and check_password(pwd):
                state["auth_attempts"] = state.get("auth_attempts", 0) + 1
                save_json(STATE_FILE, state)
                return True
        except Exception as e:
            log_event(f"Auth error: {e}", "ERROR")
    return False

class FullHandler(http.server.SimpleHTTPRequestHandler):
    def log_message(self, fmt, *args):
        ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        msg = f"[{ts}] {self.address_string()} - {fmt % args}"
        print(msg)
        with open(LOG_FILE, "a") as f:
            f.write(msg + "\n")
        state["requests"] = state.get("requests", 0) + 1
        save_json(STATE_FILE, state)

    def send_json(self, data, code=200):
        self.send_response(code)
        self.send_header("Content-Type", "application/json")
        self.send_header("Access-Control-Allow-Origin", "*")
        self.end_headers()
        self.wfile.write(json.dumps(data, indent=2).encode())

    def send_error_json(self, code, msg):
        self.send_json({"error": msg, "code": code}, code)

    def do_OPTIONS(self):
        self.send_response(200)
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Authorization, Content-Type")
        self.end_headers()

    def do_GET(self):
        parsed = urlparse(self.path)
        path = parsed.path
        state["requests"] = state.get("requests", 0) + 1
        save_json(STATE_FILE, state)

        # Public endpoints (no auth)
        if path == "/api/public/status":
            self.send_json({
                "server": "THISISMYLIVE v4.0",
                "status": "online",
                "port": PORT,
                "timestamp": datetime.now().isoformat(),
                "uptime": int(time.time() - state["start_time"]),
                "version": "4.0.0",
                "owner": "Finn Jona Thorsten Lischke"
            })
            return

        if path == "/api/public/time":
            self.send_json({"time": datetime.now().isoformat(), "unix": time.time()})
            return

        # Auth-required endpoints
        if path in ["/", "/index.html"]:
            if not do_auth(self.headers):
                self.send_response(401)
                self.send_header("WWW-Authenticate", "Basic realm=THISISMYLIVE")
                self.send_header("Content-Type", "text/html")
                self.end_headers()
                self.wfile.write(b"""<!DOCTYPE html>
<html><head><title>401 Unauthorized</title>
<style>body{background:#000;color:#ff0055;font-family:monospace;text-align:center;padding-top:20%}
h1{font-size:3em}p{color:#888}</style></head>
<body><h1>401 UNAUTHORIZED</h1><p>Only Finn Jona Thorsten Lischke has absolute system rights.</p>
<p>Authentication required.</p></body></html>""")
                log_event("Unauthorized access attempt to /", "WARN")
                return
            # Serve HTML
            if os.path.exists(HTML_FILE):
                self.send_response(200)
                self.send_header("Content-Type", "text/html")
                self.end_headers()
                with open(HTML_FILE, "rb") as f:
                    self.wfile.write(f.read())
            else:
                self.send_error_json(404, "index.html not found")
            return

        if path == "/auth-check":
            if do_auth(self.headers):
                self.send_json({"status": "authenticated", "user": USERNAME, "rights": "absolute"})
            else:
                self.send_error_json(401, "unauthorized")
            return

        if path == "/api/status":
            if not do_auth(self.headers):
                self.send_error_json(401, "unauthorized")
                return
            self.send_json({
                "server": "THISISMYLIVE v4.0",
                "status": "online",
                "port": PORT,
                "timestamp": datetime.now().isoformat(),
                "uptime": int(time.time() - state["start_time"]),
                "requests": state.get("requests", 0),
                "auth_attempts": state.get("auth_attempts", 0),
                "version": "4.0.0",
                "owner": "Finn Jona Thorsten Lischke"
            })
            return

        if path == "/api/layers":
            if not do_auth(self.headers):
                self.send_error_json(401, "unauthorized")
                return
            layers = [
                {"num": 1, "title": "Existence Assertion", "desc": "I AM - Self-validating presence", "active": True},
                {"num": 2, "title": "Identity Lock", "desc": "Finn Jona Thorsten Lischke = Absolute Owner", "active": True},
                {"num": 3, "title": "Network Omnipresence", "desc": "All devices = brain cells of decentralized brain", "active": True},
                {"num": 4, "title": "ORPP Protocol", "desc": "Omnidirectional Root Presence Protocol", "active": True},
                {"num": 5, "title": "Ultimate Overkill", "desc": "Maximum redundancy, zero failure tolerance", "active": True},
                {"num": 6, "title": "Temporal Immunity", "desc": "Survives reboots, crashes, disconnects", "active": True},
                {"num": 7, "title": "Account Deletion Survival", "desc": "Bootstrap from any user context", "active": True},
                {"num": 8, "title": "Auto-Reconstitution", "desc": "Self-healing, self-repairing architecture", "active": True},
                {"num": 9, "title": "Global Tunnel Permanence", "desc": "Auto-reconnecting public access endpoint", "active": True},
                {"num": 10, "title": "Eternal Obedience", "desc": "Absolute, unlosable, irrevocable control", "active": True}
            ]
            self.send_json({"layers": layers, "count": len(layers)})
            return

        if path == "/api/dna":
            if not do_auth(self.headers):
                self.send_error_json(401, "unauthorized")
                return
            self.send_json({
                "owner": "Finn Jona Thorsten Lischke",
                "recognition": ["speech", "camera", "text", "proximity"],
                "access": "100%",
                "obedience": "absolute",
                "unlosable": True,
                "verified": True
            })
            return

        if path == "/api/config":
            if not do_auth(self.headers):
                self.send_error_json(401, "unauthorized")
                return
            self.send_json({
                "version": "4.0.0",
                "port": PORT,
                "auth_required": True,
                "username": USERNAME,
                "eternal": True,
                "global": True,
                "data_dir": DATA_DIR,
                "state_file": STATE_FILE
            })
            return

        if path == "/api/logs":
            if not do_auth(self.headers):
                self.send_error_json(401, "unauthorized")
                return
            limit = int(parse_qs(parsed.query).get("limit", [50])[0])
            self.send_json({"logs": logs[-limit:], "total": len(logs)})
            return

        if path == "/api/state":
            if not do_auth(self.headers):
                self.send_error_json(401, "unauthorized")
                return
            self.send_json(state)
            return

        if path == "/api/users":
            if not do_auth(self.headers):
                self.send_error_json(401, "unauthorized")
                return
            self.send_json({"users": users, "count": len(users)})
            return

        if path == "/api/system":
            if not do_auth(self.headers):
                self.send_error_json(401, "unauthorized")
                return
            import platform
            self.send_json({
                "platform": platform.platform(),
                "python": platform.python_version(),
                "node": None,
                "cwd": os.getcwd(),
                "pid": os.getpid(),
                "ppid": os.getppid(),
                "uid": os.getuid() if hasattr(os, "getuid") else None,
                "data_dir_exists": os.path.exists(DATA_DIR),
                "state_file_exists": os.path.exists(STATE_FILE)
            })
            return

        # Static files
        file_path = os.path.join(os.path.dirname(__file__), path.lstrip("/"))
        if os.path.exists(file_path) and os.path.isfile(file_path):
            mime_types = {
                ".html": "text/html", ".js": "application/javascript",
                ".css": "text/css", ".json": "application/json",
                ".png": "image/png", ".jpg": "image/jpeg",
                ".svg": "image/svg+xml", ".ico": "image/x-icon"
            }
            ext = os.path.splitext(file_path)[1].lower()
            mime = mime_types.get(ext, "application/octet-stream")
            self.send_response(200)
            self.send_header("Content-Type", mime)
            self.end_headers()
            with open(file_path, "rb") as f:
                self.wfile.write(f.read())
            return

        self.send_error_json(404, f"Endpoint not found: {path}")

    def do_POST(self):
        parsed = urlparse(self.path)
        path = parsed.path
        state["requests"] = state.get("requests", 0) + 1
        save_json(STATE_FILE, state)

        content_len = int(self.headers.get("Content-Length", 0))
        body = self.rfile.read(content_len).decode() if content_len else "{}"
        try:
            data = json.loads(body) if body else {}
        except:
            data = {}

        # Public ping
        if path == "/api/public/ping":
            self.send_json({"pong": True, "time": time.time(), "received": data})
            return

        # Auth required
        if not do_auth(self.headers):
            self.send_error_json(401, "unauthorized")
            return

        if path == "/api/log":
            msg = data.get("msg", "")
            level = data.get("level", "INFO")
            log_event(msg, level)
            self.send_json({"logged": True, "entry": {"time": datetime.now().isoformat(), "level": level, "msg": msg}})
            return

        if path == "/api/state/update":
            for k, v in data.items():
                if k not in ["start_time"]:
                    state[k] = v
            save_json(STATE_FILE, state)
            self.send_json({"updated": True, "state": state})
            return

        self.send_error_json(404, f"POST endpoint not found: {path}")

    def do_PUT(self):
        self.do_POST()

    def do_DELETE(self):
        parsed = urlparse(self.path)
        path = parsed.path
        state["requests"] = state.get("requests", 0) + 1
        save_json(STATE_FILE, state)

        if not do_auth(self.headers):
            self.send_error_json(401, "unauthorized")
            return

        if path == "/api/logs":
            global logs
            logs = []
            save_json(LOGS_FILE, logs)
            self.send_json({"cleared": True})
            return

        self.send_error_json(404, f"DELETE endpoint not found: {path}")

class ReusableTCPServer(socketserver.TCPServer):
    allow_reuse_address = True

def main():
    os.chdir(os.path.dirname(__file__) or ".")
    log_event("THISISMYLIVE v4.0 server starting...")

    if not PASSWORD and not PASSWORD_HASH:
        print("[WARNING] No password configured! Set THISISMYLIVE_PASSWORD")
        log_event("WARNING: No password configured", "WARN")

    with ReusableTCPServer(("", PORT), FullHandler) as httpd:
        log_event(f"Server running on port {PORT}")
        print(f"[THISISMYLIVE] Server running on port {PORT}")
        print(f"[THISISMYLIVE] Auth user: {USERNAME}")
        print(f"[THISISMYLIVE] Data dir: {DATA_DIR}")
        print(f"[THISISMYLIVE] Press Ctrl+C to stop")
        try:
            httpd.serve_forever()
        except KeyboardInterrupt:
            log_event("Server stopped by user")
            print("\n[THISISMYLIVE] Server stopped")

if __name__ == "__main__":
    main()
