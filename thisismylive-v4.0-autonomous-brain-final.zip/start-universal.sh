#!/bin/bash
# THISISMYLIVE v4.0 - Universal Start (Python or Node.js)
DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$DIR"

if command -v python3 >/dev/null 2>&1; then
    echo "[THISISMYLIVE] Starting with Python3..."
    nohup python3 server-auth.py > server.log 2>&1 &
    echo $! > .server.pid
elif command -v node >/dev/null 2>&1; then
    echo "[THISISMYLIVE] Starting with Node.js..."
    nohup node server.js > server.log 2>&1 &
    echo $! > .server.pid
else
    echo "[ERROR] No Python3 or Node.js found!"
    exit 1
fi

echo "[THISISMYLIVE] Server started on port 58133"
echo "[THISISMYLIVE] Access: http://localhost:58133"
