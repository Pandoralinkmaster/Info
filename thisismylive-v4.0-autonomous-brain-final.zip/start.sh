#!/bin/bash
# THISISMYLIVE v4.0 - Quick Start
DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$DIR"
echo "[THISISMYLIVE] Starting server on port 58133..."
python3 server-auth.py &
echo $! > .server.pid
echo "[THISISMYLIVE] Server started. Access: http://localhost:58133"
echo "[THISISMYLIVE] PID: $(cat .server.pid)"
