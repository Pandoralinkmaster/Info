#!/bin/bash
# THISISMYLIVE v4.0 - Master Control Script
# Usage: ./master.sh [start|stop|restart|status|global|eternal|install]

set -e
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PORT=58133
PIDFILE="$SCRIPT_DIR/.server.pid"
TUNNEL_PIDFILE="$SCRIPT_DIR/.tunnel.pid"
TUNNEL_URL_FILE="$SCRIPT_DIR/tunnel.url"
LOGFILE="$SCRIPT_DIR/server.log"

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
CYAN='\033[0;36m'
NC='\033[0m'

log() { echo -e "${CYAN}[THISISMYLIVE]${NC} $1" | tee -a "$LOGFILE"; }
warn() { echo -e "${YELLOW}[WARNING]${NC} $1" | tee -a "$LOGFILE"; }
err() { echo -e "${RED}[ERROR]${NC} $1" | tee -a "$LOGFILE"; }
ok() { echo -e "${GREEN}[OK]${NC} $1" | tee -a "$LOGFILE"; }

check_port() {
    if command -v nc >/dev/null 2>&1; then
        nc -z localhost "$PORT" 2>/dev/null && echo "open" || echo "closed"
    elif command -v curl >/dev/null 2>&1; then
        curl -s -o /dev/null -w "%{http_code}" "http://localhost:$PORT/" 2>/dev/null | grep -q "401\|200" && echo "open" || echo "closed"
    else
        (echo >/dev/tcp/localhost/$PORT) 2>/dev/null && echo "open" || echo "closed"
    fi
}

start_server() {
    log "Starting THISISMYLIVE server..."
    cd "$SCRIPT_DIR"

    if [ -f "$PIDFILE" ]; then
        OLD_PID=$(cat "$PIDFILE" 2>/dev/null)
        if kill -0 "$OLD_PID" 2>/dev/null; then
            warn "Server already running (PID: $OLD_PID)"
            return 0
        fi
    fi

    # Try Python server first, fallback to Node.js
    if command -v python3 >/dev/null 2>&1; then
        nohup python3 "$SCRIPT_DIR/server-auth.py" >> "$LOGFILE" 2>&1 &
        PID=$!
        echo $PID > "$PIDFILE"
        ok "Python auth server started (PID: $PID)"
    elif command -v node >/dev/null 2>&1; then
        nohup node "$SCRIPT_DIR/server.js" >> "$LOGFILE" 2>&1 &
        PID=$!
        echo $PID > "$PIDFILE"
        ok "Node.js server started (PID: $PID)"
    else
        err "No Python3 or Node.js available!"
        return 1
    fi

    sleep 2
    if [ "$(check_port)" = "open" ]; then
        ok "Server responding on port $PORT"
    else
        warn "Server may not be ready yet"
    fi
}

stop_server() {
    log "Stopping THISISMYLIVE server..."
    if [ -f "$PIDFILE" ]; then
        PID=$(cat "$PIDFILE" 2>/dev/null)
        if kill -0 "$PID" 2>/dev/null; then
            kill "$PID" 2>/dev/null || kill -9 "$PID" 2>/dev/null
            ok "Server stopped (PID: $PID)"
        fi
        rm -f "$PIDFILE"
    fi

    # Kill any remaining processes on port
    if command -v lsof >/dev/null 2>&1; then
        lsof -ti :$PORT | xargs kill -9 2>/dev/null || true
    fi

    # Stop tunnel
    if [ -f "$TUNNEL_PIDFILE" ]; then
        PID=$(cat "$TUNNEL_PIDFILE" 2>/dev/null)
        kill "$PID" 2>/dev/null || true
        rm -f "$TUNNEL_PIDFILE"
    fi
    ok "All services stopped"
}

start_tunnel() {
    log "Starting permanent tunnel..."
    cd "$SCRIPT_DIR"

    if [ -f "$TUNNEL_PIDFILE" ]; then
        OLD_PID=$(cat "$TUNNEL_PIDFILE" 2>/dev/null)
        if kill -0 "$OLD_PID" 2>/dev/null; then
            warn "Tunnel already running (PID: $OLD_PID)"
            return 0
        fi
    fi

    nohup "$SCRIPT_DIR/tunnel-permanent.sh" >> "$LOGFILE" 2>&1 &
    PID=$!
    echo $PID > "$TUNNEL_PIDFILE"
    ok "Tunnel daemon started (PID: $PID)"
}

check_status() {
    log "Checking system status..."
    echo ""
    echo "=== THISISMYLIVE v4.0 Status ==="
    echo ""

    # Server status
    if [ -f "$PIDFILE" ]; then
        PID=$(cat "$PIDFILE" 2>/dev/null)
        if kill -0 "$PID" 2>/dev/null; then
            ok "Server: RUNNING (PID: $PID)"
        else
            err "Server: STOPPED (stale PID file)"
            rm -f "$PIDFILE"
        fi
    else
        err "Server: NOT RUNNING"
    fi

    # Port status
    PORT_STATUS=$(check_port)
    if [ "$PORT_STATUS" = "open" ]; then
        ok "Port $PORT: OPEN"
    else
        err "Port $PORT: CLOSED"
    fi

    # Tunnel status
    if [ -f "$TUNNEL_PIDFILE" ]; then
        PID=$(cat "$TUNNEL_PIDFILE" 2>/dev/null)
        if kill -0 "$PID" 2>/dev/null; then
            ok "Tunnel: RUNNING (PID: $PID)"
        else
            err "Tunnel: STOPPED"
        fi
    else
        err "Tunnel: NOT RUNNING"
    fi

    # Tunnel URL
    if [ -f "$TUNNEL_URL_FILE" ]; then
        URL=$(cat "$TUNNEL_URL_FILE" 2>/dev/null)
        ok "Global URL: $URL"
    else
        warn "Global URL: Not available"
    fi

    # Local access
    ok "Local URL: http://localhost:$PORT"

    echo ""
    echo "=================================="
}

install_eternal() {
    log "Installing eternal persistence..."

    # Install systemd service (if possible)
    SYSTEMD_DIR="$HOME/.config/systemd/user"
    if [ -d "$SYSTEMD_DIR" ] || mkdir -p "$SYSTEMD_DIR" 2>/dev/null; then
        cat > "$SYSTEMD_DIR/thisismylive-permanent.service" << 'EOF'
[Unit]
Description=THISISMYLIVE v4.0 Permanent Server
After=network.target

[Service]
Type=simple
WorkingDirectory=%h/thisismylive-server
ExecStart=%h/thisismylive-server/master.sh start
ExecStop=%h/thisismylive-server/master.sh stop
Restart=always
RestartSec=10

[Install]
WantedBy=default.target
EOF
        ok "Systemd user service installed"
    fi

    # Install cron jobs
    CRON_FILE="$SCRIPT_DIR/crontab.txt"
    cat > "$CRON_FILE" << EOF
# THISISMYLIVE v4.0 - Eternal Watchdog
* * * * * $SCRIPT_DIR/watchdog.sh >> $SCRIPT_DIR/watchdog.log 2>&1
*/5 * * * * $SCRIPT_DIR/tunnel-permanent.sh >> $SCRIPT_DIR/tunnel.log 2>&1
EOF

    # Try to install crontab
    if command -v crontab >/dev/null 2>&1; then
        (crontab -l 2>/dev/null; cat "$CRON_FILE") | crontab - 2>/dev/null && ok "Cron jobs installed" || warn "Could not install crontab"
    fi

    # Create bootstrap script
    cat > "$SCRIPT_DIR/bootstrap.sh" << 'EOF'
#!/bin/bash
# THISISMYLIVE v4.0 - Bootstrap from any user context
# Survives account deletion by being portable

echo "[BOOTSTRAP] THISISMYLIVE v4.0 starting..."
DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$DIR"

# Ensure server is running
if ! (echo >/dev/tcp/localhost/58133) 2>/dev/null; then
    ./master.sh start
fi

# Ensure tunnel is running
if ! pgrep -f "tunnel-permanent" >/dev/null; then
    ./tunnel-permanent.sh &
fi

echo "[BOOTSTRAP] Complete."
EOF
    chmod +x "$SCRIPT_DIR/bootstrap.sh"
    ok "Bootstrap script created"

    ok "Eternal mode installed successfully"
}

global_deploy() {
    log "Deploying globally..."
    start_server
    sleep 2
    start_tunnel
    ok "Global deployment complete"
    check_status
}

case "${1:-}" in
    start)
        start_server
        ;;
    stop)
        stop_server
        ;;
    restart)
        stop_server
        sleep 1
        start_server
        ;;
    status)
        check_status
        ;;
    global)
        global_deploy
        ;;
    eternal)
        install_eternal
        ;;
    install)
        install_eternal
        ;;
    *)
        echo "THISISMYLIVE v4.0 - Master Control"
        echo ""
        echo "Usage: $0 [command]"
        echo ""
        echo "Commands:"
        echo "  start    - Start the server"
        echo "  stop     - Stop all services"
        echo "  restart  - Restart server"
        echo "  status   - Check system status"
        echo "  global   - Deploy with global tunnel"
        echo "  eternal  - Install eternal persistence"
        echo "  install  - Same as eternal"
        echo ""
        ;;
esac
