// THISISMYLIVE v4.0 - Node.js Authentication Server
const http = require('http');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const PORT = process.env.THISISMYLIVE_PORT || 58133;
const USERNAME = 'finn';
const PASSWORD = process.env.THISISMYLIVE_PASSWORD || '';
const PASSWORD_HASH = process.env.THISISMYLIVE_PASSWORD_HASH || '';

const MIME_TYPES = {
  '.html': 'text/html',
  '.js': 'text/javascript',
  '.css': 'text/css',
  '.json': 'application/json',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.gif': 'image/gif',
  '.svg': 'image/svg+xml',
  '.ico': 'image/x-icon'
};

function checkAuth(req) {
  const auth = req.headers.authorization || '';
  if (!auth.startsWith('Basic ')) return false;
  try {
    const creds = Buffer.from(auth.slice(6), 'base64').toString('utf8');
    const [user, pwd] = creds.split(':');
    if (user !== USERNAME) return false;
    if (PASSWORD_HASH) {
      const hash = crypto.createHash('sha256').update(pwd).digest('hex');
      return hash === PASSWORD_HASH;
    }
    return pwd === PASSWORD;
  } catch (e) { return false; }
}

const server = http.createServer((req, res) => {
  const log = (msg) => console.log(`[${new Date().toISOString()}] ${msg}`);

  if (req.url === '/auth-check') {
    if (checkAuth(req)) {
      res.writeHead(200, {'Content-Type': 'application/json'});
      res.end(JSON.stringify({status: 'authenticated', user: USERNAME, rights: 'absolute'}));
    } else {
      res.writeHead(401, {'WWW-Authenticate': 'Basic realm=THISISMYLIVE', 'Content-Type': 'application/json'});
      res.end(JSON.stringify({status: 'unauthorized', code: 401}));
    }
    return;
  }

  if (req.url === '/' || req.url === '/index.html') {
    if (!checkAuth(req)) {
      res.writeHead(401, {'WWW-Authenticate': 'Basic realm=THISISMYLIVE', 'Content-Type': 'text/html'});
      res.end(`<html><head><title>401 Unauthorized</title></head>
<body style="background:#000;color:#ff0055;font-family:monospace;text-align:center;padding-top:20%">
<h1>401 UNAUTHORIZED</h1><p>Only Finn Jona Thorsten Lischke has absolute system rights.</p></body></html>`);
      return;
    }
  }

  let filePath = path.join(__dirname, req.url === '/' ? 'index.html' : req.url);
  const ext = path.extname(filePath).toLowerCase();
  const contentType = MIME_TYPES[ext] || 'application/octet-stream';

  fs.readFile(filePath, (err, content) => {
    if (err) {
      if (err.code === 'ENOENT') {
        res.writeHead(404, {'Content-Type': 'text/html'});
        res.end('<h1>404 Not Found</h1>');
      } else {
        res.writeHead(500);
        res.end(`Server Error: ${err.code}`);
      }
    } else {
      res.writeHead(200, {'Content-Type': contentType});
      res.end(content, 'utf-8');
    }
  });
});

server.listen(PORT, () => {
  console.log(`[THISISMYLIVE] Node.js server running on port ${PORT}`);
  console.log(`[THISISMYLIVE] Auth user: ${USERNAME}`);
  if (!PASSWORD && !PASSWORD_HASH) {
    console.log('[WARNING] No password configured!');
  }
});
