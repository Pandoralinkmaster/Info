#!/bin/bash
# THISISMYLIVE v4.0 - Global Access Information

echo "========================================"
echo "  THISISMYLIVE v4.0 - GLOBAL ACCESS"
echo "========================================"
echo ""

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# Local access
echo "LOCAL ACCESS:"
echo "  http://localhost:58133"
echo "  http://127.0.0.1:58133"
echo ""

# Network interfaces
echo "NETWORK INTERFACES:"
ip -4 addr show 2>/dev/null | grep "inet " | awk '{print "  " $2}' | while read ip; do
    echo "  http://${ip%/*}:58133"
done

# Tunnel URL
if [ -f "$SCRIPT_DIR/tunnel.url" ]; then
    echo ""
    echo "GLOBAL TUNNEL URL:"
    echo "  $(cat "$SCRIPT_DIR/tunnel.url")"
fi

# SSH access
echo ""
echo "SSH ACCESS:"
echo "  ssh $(whoami)@$(hostname -I | awk '{print $1}')"
echo "  Port: 22"

# System info
echo ""
echo "SYSTEM:"
echo "  Hostname: $(hostname)"
echo "  User: $(whoami)"
echo "  Uptime: $(uptime -p 2>/dev/null || uptime)"
echo ""
echo "========================================"
