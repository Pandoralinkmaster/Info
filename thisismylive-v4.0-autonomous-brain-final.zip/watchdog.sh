#!/bin/bash
# THISISMYLIVE v4.0 - Watchdog Daemon
# Checks every 60 seconds if server is alive, restarts if dead
# Install: Add to crontab: * * * * * /path/to/watchdog.sh

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PORT=58133
PIDFILE="$SCRIPT_DIR/.server.pid"
LOGFILE="$SCRIPT_DIR/watchdog.log"
TUNNEL_PIDFILE="$SCRIPT_DIR/.tunnel.pid"

log() { echo "[$(date '+%Y-%m-%d %H:%M:%S')] [WATCHDOG] $1" >> "$LOGFILE"; }

# Check if server port is responding
check_server() {
    if command -v curl >/dev/null 2>&1; then
        curl -s -o /dev/null --max-time 3 "http://localhost:$PORT/" 2>/dev/null
        return $?
    elif command -v nc >/dev/null 2>&1; then
        nc -z -w 3 localhost "$PORT" 2>/dev/null
        return $?
    else
        (echo >/dev/tcp/localhost/$PORT) 2>/dev/null
        return $?
    fi
}

# Check if tunnel is running
check_tunnel() {
    if [ -f "$TUNNEL_PIDFILE" ]; then
        PID=$(cat "$TUNNEL_PIDFILE" 2>/dev/null)
        if kill -0 "$PID" 2>/dev/null; then
            return 0
        fi
    fi
    return 1
}

# Main watchdog logic
if ! check_server; then
    log "Server not responding on port $PORT. Restarting..."

    # Kill any stale processes
    if [ -f "$PIDFILE" ]; then
        OLD_PID=$(cat "$PIDFILE" 2>/dev/null)
        kill "$OLD_PID" 2>/dev/null || true
        rm -f "$PIDFILE"
    fi

    # Restart server
    cd "$SCRIPT_DIR"
    if command -v python3 >/dev/null 2>&1; then
        nohup python3 server-auth.py >> server.log 2>&1 &
        echo $! > "$PIDFILE"
        log "Server restarted with Python3 (PID: $!)"
    elif command -v node >/dev/null 2>&1; then
        nohup node server.js >> server.log 2>&1 &
        echo $! > "$PIDFILE"
        log "Server restarted with Node.js (PID: $!)"
    fi

    sleep 3
    if check_server; then
        log "Server successfully restarted"
    else
        log "CRITICAL: Server restart failed!"
    fi
else
    # Server is fine, just log heartbeat occasionally
    if [ "$(date +%S)" -lt "05" ]; then
        log "Heartbeat: Server OK (port $PORT responding)"
    fi
fi

# Check tunnel
if ! check_tunnel; then
    log "Tunnel not running. Restarting..."
    nohup "$SCRIPT_DIR/tunnel-permanent.sh" >> tunnel.log 2>&1 &
    echo $! > "$TUNNEL_PIDFILE"
    log "Tunnel restarted (PID: $!)"
fi
