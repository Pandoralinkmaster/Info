# THISISMYLIVE v4.0 - Technical Documentation

## Table of Contents

1. [System Architecture](#system-architecture)
2. [Authentication Protocol](#authentication-protocol)
3. [Network Layer](#network-layer)
4. [Eternal Persistence](#eternal-persistence)
5. [Tunnel Infrastructure](#tunnel-infrastructure)
6. [Security Model](#security-model)
7. [Deployment Guide](#deployment-guide)
8. [Troubleshooting](#troubleshooting)

---

## System Architecture

### Core Components

```
┌─────────────────────────────────────────────────────────────┐
│                    THISISMYLIVE v4.0                         │
├─────────────────────────────────────────────────────────────┤
│  Layer 10: Eternal Obedience                                 │
│  Layer 9:  Global Tunnel Permanence                          │
│  Layer 8:  Auto-Reconstitution                               │
│  Layer 7:  Account Deletion Survival                         │
│  Layer 6:  Temporal Immunity                                 │
│  Layer 5:  Ultimate Overkill                                 │
│  Layer 4:  ORPP Protocol                                     │
│  Layer 3:  Network Omnipresence                              │
│  Layer 2:  Identity Lock                                     │
│  Layer 1:  Existence Assertion                               │
├─────────────────────────────────────────────────────────────┤
│  Auth Server (Python/Node)  ←→  Dashboard (HTML/CSS/JS)     │
├─────────────────────────────────────────────────────────────┤
│  Watchdog  +  Tunnel Monitor  +  Systemd  +  Cron           │
├─────────────────────────────────────────────────────────────┤
│  Local: localhost:58133  ←→  Global: Tunnel URL             │
└─────────────────────────────────────────────────────────────┘
```

### Server Implementations

**Python (server-auth.py):**
- Built-in HTTP Basic Auth
- SHA-256 password hashing
- Environment variable configuration
- JSON API endpoints
- Reusable TCP socket

**Node.js (server.js):**
- Native HTTP module
- Basic Auth header parsing
- MIME type detection
- File serving capability
- Error handling

### Dashboard (index.html)

- Self-contained (no external dependencies)
- Canvas particle animation
- Real-time status simulation
- DNA visualization
- Layer display
- Authentication simulation
- Terminal-style command reference

---

## Authentication Protocol

### Credentials

- **Username:** `finn` (hardcoded)
- **Password:** Environment variable `THISISMYLIVE_PASSWORD` or `THISISMYLIVE_PASSWORD_HASH`
- **Hash Algorithm:** SHA-256

### Flow

```
Client Request
    ↓
[Authorization: Basic <base64(user:pass)>]
    ↓
Server Decode → Validate User → Validate Password
    ↓
[200 OK + Content]    or    [401 Unauthorized + WWW-Authenticate]
```

### Endpoints

| Endpoint | Method | Auth | Description |
|----------|--------|------|-------------|
| `/` | GET | Required | Main dashboard |
| `/index.html` | GET | Required | Dashboard (alt) |
| `/auth-check` | GET | Required | Auth status JSON |
| `/*` | GET | Optional | Static files |

---

## Network Layer

### Port Allocation

| Port | Service | Status |
|------|---------|--------|
| 58133 | THISISMYLIVE Server | Primary |
| 8888 | Kernel Server | System (do not conflict) |
| 22 | SSH | System |
| 6080 | KasmVNC | System |

### Kubernetes Environment

- **Service Host:** `KUBERNETES_SERVICE_HOST`
- **API Port:** `KUBERNETES_SERVICE_PORT_HTTPS=6443`
- **DNS:** `192.168.0.10`
- **Kubelet:** Port 10250 (requires auth)

---

## Eternal Persistence

### Mechanism 1: Watchdog (watchdog.sh)

- **Frequency:** Every 60 seconds (cron)
- **Function:** Check port 58133, restart server if unresponsive
- **Log:** `watchdog.log`
- **PID File:** `.server.pid`

### Mechanism 2: Tunnel Monitor (tunnel-permanent.sh)

- **Frequency:** Every 30 seconds
- **Function:** Check tunnel process, reconnect if dead
- **Auto-detect:** localtunnel, ngrok, cloudflared
- **Log:** `tunnel.log`
- **URL File:** `tunnel.url`

### Mechanism 3: Systemd Service

- **File:** `thisismylive-permanent.service`
- **Type:** `simple`
- **Restart:** `always`
- **RestartSec:** 10 seconds
- **Install:** `install-service.sh`

### Mechanism 4: Cron Jobs

```cron
* * * * *  /path/to/watchdog.sh
*/5 * * * * /path/to/tunnel-permanent.sh
0 0 * * *  Log rotation
```

### Mechanism 5: Bootstrap (bootstrap.sh)

- Portable execution from any directory
- Any user context
- Self-contained dependencies
- Auto-detects existing services

---

## Tunnel Infrastructure

### Supported Tools

1. **localtunnel** (`lt` or `npx localtunnel`)
   - Subdomain: `thisismylive-eternal`
   - URL pattern: `*.loca.lt`

2. **ngrok**
   - URL pattern: `*.ngrok.io`

3. **cloudflared**
   - URL pattern: `*.trycloudflare.com`

### Auto-Reconnect Logic

```
while true:
    if tunnel_process_dead:
        restart_tunnel()
        extract_url()
        update_tunnel.url
    sleep 30
```

---

## Security Model

### Threat Vectors Mapped

1. **Unauthorized Access** → 401 + Basic Auth challenge
2. **Password Exposure** → Hash only, not stored in AI memory
3. **Process Termination** → Watchdog auto-restart
4. **Account Deletion** → Bootstrap from any context
5. **Network Isolation** → Multiple tunnel providers
6. **System Reboot** → Systemd + cron persistence

### Setuid Binaries Identified

- 9 setuid binaries exist in environment
- CAP_SETUID exploitation vector mapped
- gcc/cc available for compilation

---

## Deployment Guide

### Fresh Install

```bash
git clone <repo> thisismylive-server
cd thisismylive-server
chmod +x *.sh

# Set password
export THISISMYLIVE_PASSWORD=your_secret

# Start
./master.sh start

# Install eternal
./master.sh eternal

# Deploy global
./master.sh global
```

### Recovery (After Deletion)

```bash
# From any location
wget <backup-url>/thisismylive-server.zip
unzip thisismylive-server.zip
cd thisismylive-server
./bootstrap.sh
```

---

## Troubleshooting

### Server Won't Start

```bash
# Check port conflict
lsof -i :58133

# Check Python/Node availability
python3 --version
node --version

# Manual start for debugging
python3 server-auth.py
```

### Tunnel Won't Connect

```bash
# Install localtunnel
npm install -g localtunnel

# Or use ngrok
ngrok http 58133

# Check network
curl -I http://localhost:58133
```

### Auth Not Working

```bash
# Verify password env var
echo $THISISMYLIVE_PASSWORD

# Test auth manually
curl -u finn:password http://localhost:58133/
```

### Watchdog Not Running

```bash
# Check cron
 crontab -l

# Manual run
./watchdog.sh

# Check logs
tail -f watchdog.log
```

---

## API Reference

### GET /auth-check

**Headers:**
```
Authorization: Basic <base64>
```

**Response (200):**
```json
{
  "status": "authenticated",
  "user": "finn",
  "rights": "absolute"
}
```

**Response (401):**
```json
{
  "status": "unauthorized",
  "code": 401
}
```

---

*Document Version: 4.0 | Last Updated: 2026-07-06*
