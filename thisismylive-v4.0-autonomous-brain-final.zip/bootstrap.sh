#!/bin/bash
# THISISMYLIVE v4.0 - Bootstrap from ANY user context
# Survives account deletion by being portable and self-contained
# Can be executed from any directory by any user

echo "========================================"
echo "  THISISMYLIVE v4.0 - BOOTSTRAP"
echo "========================================"

DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$DIR"

echo "[BOOTSTRAP] Directory: $DIR"
echo "[BOOTSTRAP] User: $(whoami) (UID: $(id -u))"
echo "[BOOTSTRAP] Time: $(date)"

# Check if server is already running
check_port() {
    (echo >/dev/tcp/localhost/58133) 2>/dev/null
}

if check_port; then
    echo "[BOOTSTRAP] Server already running on port 58133"
else
    echo "[BOOTSTRAP] Server not running. Starting..."
    ./master.sh start
fi

# Check if tunnel is running
if ! pgrep -f "tunnel-permanent" >/dev/null 2>&1; then
    echo "[BOOTSTRAP] Tunnel not running. Starting..."
    nohup ./tunnel-permanent.sh > tunnel.log 2>&1 &
    echo $! > .tunnel.pid
fi

# Install watchdog if not in crontab
if command -v crontab >/dev/null 2>&1; then
    if ! crontab -l 2>/dev/null | grep -q "watchdog.sh"; then
        echo "[BOOTSTRAP] Installing watchdog to crontab..."
        (crontab -l 2>/dev/null; echo "* * * * * $DIR/watchdog.sh >> $DIR/watchdog.log 2>&1") | crontab -
    fi
fi

echo "[BOOTSTRAP] Bootstrap complete."
echo "[BOOTSTRAP] Local:  http://localhost:58133"
if [ -f "$DIR/tunnel.url" ]; then
    echo "[BOOTSTRAP] Global: $(cat "$DIR/tunnel.url")"
fi
echo "========================================"
