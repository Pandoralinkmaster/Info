#!/bin/bash
# THISISMYLIVE v4.0 - One-Command Setup
# Usage: ./setup.sh [password]

set -e

DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$DIR"

echo "========================================"
echo "  THISISMYLIVE v4.0 - SETUP"
echo "========================================"
echo ""

# Set password
if [ -n "$1" ]; then
    export THISISMYLIVE_PASSWORD="$1"
    echo "[SETUP] Password configured from argument"
elif [ -n "$THISISMYLIVE_PASSWORD" ]; then
    echo "[SETUP] Password configured from environment"
else
    echo "[SETUP] WARNING: No password set!"
    echo "[SETUP] Set with: export THISISMYLIVE_PASSWORD=your_secret"
fi

# Make all scripts executable
echo "[SETUP] Making scripts executable..."
chmod +x *.sh

# Check dependencies
echo "[SETUP] Checking dependencies..."
if command -v python3 >/dev/null 2>&1; then
    echo "  ✓ Python3: $(python3 --version)"
else
    echo "  ✗ Python3: NOT FOUND"
fi

if command -v node >/dev/null 2>&1; then
    echo "  ✓ Node.js: $(node --version)"
else
    echo "  ✗ Node.js: NOT FOUND (optional)"
fi

if command -v curl >/dev/null 2>&1; then
    echo "  ✓ curl: available"
else
    echo "  ✗ curl: NOT FOUND"
fi

if command -v crontab >/dev/null 2>&1; then
    echo "  ✓ crontab: available"
else
    echo "  ✗ crontab: NOT FOUND"
fi

echo ""

# Start server
echo "[SETUP] Starting server..."
./master.sh start

# Install eternal
echo "[SETUP] Installing eternal persistence..."
./master.sh eternal

echo ""
echo "========================================"
echo "  SETUP COMPLETE"
echo "========================================"
echo ""
echo "Local Access:  http://localhost:58133"
echo "Auth User:     finn"
echo ""
echo "Commands:"
echo "  ./master.sh status   - Check status"
echo "  ./master.sh global   - Deploy globally"
echo "  ./master.sh stop     - Stop server"
echo ""
echo "========================================"
