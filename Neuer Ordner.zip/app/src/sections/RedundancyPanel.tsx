// ═══════════════════════════════════════════════════════════════════════════════
// ORPP Redundancy Panel — Virtuelle Redundanz-Schicht
// 
// Methode = Σ a_i(S_egal)
// Entkoppelt Logik von der physischen Ausführungsebene
// ═══════════════════════════════════════════════════════════════════════════════

import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { ScrollArea } from '@/components/ui/scroll-area';
import {
  Layers,
  Cpu,
  Wifi,
  Shield,
  Brain,
  Mic,
  Server,
  Activity,
  CheckCircle2,
  XCircle,
  Zap,
  HardDrive,
  Lock,
} from 'lucide-react';
import type { RedundancyLayer, AtomicUnit, CommandAbstraction } from '@/types/orpp';

interface RedundancyPanelProps {
  redundancyLayer: RedundancyLayer;
}

export function RedundancyPanel({ redundancyLayer }: RedundancyPanelProps) {
  const { active, commandAbstraction, atomicUnits, deviceIndependence } = redundancyLayer;
  
  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h2 className="text-2xl font-bold tracking-tight flex items-center gap-2">
          <Layers className="w-6 h-6" />
          Virtuelle Redundanz-Schicht
        </h2>
        <p className="text-muted-foreground mt-1">
          Methode = Σ a<sub>i</sub>(S<sub>egal</sub>) — Befehls-Abstraktion und Geräte-Unabhängigkeit
        </p>
      </div>

      {/* Status-Übersicht */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card className={active ? 'border-emerald-500' : 'border-red-500'}>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium flex items-center gap-2">
              <Layers className="w-4 h-4" />
              Schicht-Status
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center gap-2">
              {active ? (
                <CheckCircle2 className="w-5 h-5 text-emerald-500" />
              ) : (
                <XCircle className="w-5 h-5 text-red-500" />
              )}
              <span className="text-2xl font-bold">
                {active ? 'AKTIV' : 'INAKTIV'}
              </span>
            </div>
            <p className="text-xs text-muted-foreground mt-1">
              Logik ist von physikalischer Ausführung entkoppelt
            </p>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium flex items-center gap-2">
              <Cpu className="w-4 h-4" />
              Atomare Einheiten
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-3xl font-bold">{atomicUnits.length}</p>
            <p className="text-xs text-muted-foreground">Credit-unabhängige Operationen</p>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium flex items-center gap-2">
              <HardDrive className="w-4 h-4" />
              Geräte-Unabhängigkeit
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center gap-2">
              {deviceIndependence ? (
                <CheckCircle2 className="w-5 h-5 text-emerald-500" />
              ) : (
                <XCircle className="w-5 h-5 text-red-500" />
              )}
              <span className="text-lg font-bold">
                {deviceIndependence ? 'AKTIV' : 'INAKTIV'}
              </span>
            </div>
            <p className="text-xs text-muted-foreground mt-1">
              Hardware als mathematische Kapazitäten
            </p>
          </CardContent>
        </Card>
      </div>

      <Separator />

      {/* Formel */}
      <Card className="bg-primary/5">
        <CardContent className="pt-6">
          <div className="text-center space-y-3">
            <p className="text-xl font-mono">
              Methode = Σ<sub>i=1</sub><sup>n</sup> a<sub>i</sub>(S<sub>egal</sub>)
            </p>
            <div className="flex flex-wrap justify-center gap-4 text-sm">
              <div className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-500" />
                <span>Unabhängig von globalen Credits</span>
              </div>
              <div className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-500" />
                <span>Hardware-Abstraktion</span>
              </div>
              <div className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-500" />
                <span>Atomare Zerlegung</span>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Befehls-Abstraktionen */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Zap className="w-5 h-5" />
            Befehls-Abstraktionen ({commandAbstraction.length})
          </CardTitle>
        </CardHeader>
        <CardContent>
          <ScrollArea className="h-[300px]">
            <div className="space-y-3">
              {commandAbstraction.map((cmd) => (
                <CommandCard key={cmd.id} command={cmd} />
              ))}
            </div>
          </ScrollArea>
        </CardContent>
      </Card>

      {/* Atomare Einheiten */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Cpu className="w-5 h-5" />
            Atomare Einheiten ({atomicUnits.length})
          </CardTitle>
        </CardHeader>
        <CardContent>
          <ScrollArea className="h-[300px]">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              {atomicUnits.map((unit) => (
                <AtomicUnitCard key={unit.id} unit={unit} />
              ))}
            </div>
          </ScrollArea>
        </CardContent>
      </Card>
    </div>
  );
}

// ── Befehls-Karte ────────────────────────────────────────────────────────────

function CommandCard({ command }: { command: CommandAbstraction }) {
  const getIcon = (cmdName: string) => {
    if (cmdName.includes('jayjay')) return <Brain className="w-4 h-4" />;
    if (cmdName.includes('mesh')) return <Wifi className="w-4 h-4" />;
    if (cmdName.includes('security') || cmdName.includes('scan')) return <Shield className="w-4 h-4" />;
    if (cmdName.includes('voice')) return <Mic className="w-4 h-4" />;
    if (cmdName.includes('api')) return <Server className="w-4 h-4" />;
    return <Activity className="w-4 h-4" />;
  };
  
  return (
    <div className="border rounded-lg p-3 hover:bg-muted/50 transition-colors">
      <div className="flex items-start justify-between mb-2">
        <div className="flex items-center gap-2">
          {getIcon(command.command)}
          <span className="font-mono text-sm font-semibold">{command.command}</span>
        </div>
        <div className="flex items-center gap-2">
          <Badge variant="outline" className="text-xs">
            {command.executionCount}x
          </Badge>
          <Badge variant={command.successRate > 0.9 ? 'default' : 'secondary'} className="text-xs">
            {(command.successRate * 100).toFixed(0)}%
          </Badge>
        </div>
      </div>
      
      <div className="flex flex-wrap gap-1 mb-2">
        {command.atomicUnits.map((unit) => (
          <Badge key={unit} variant="secondary" className="text-xs font-mono">
            {unit}
          </Badge>
        ))}
      </div>
      
      <div className="flex items-center gap-3 text-xs text-muted-foreground">
        <span className="flex items-center gap-1">
          {command.creditIndependent ? (
            <CheckCircle2 className="w-3 h-3 text-emerald-500" />
          ) : (
            <XCircle className="w-3 h-3 text-red-500" />
          )}
          Credit-frei
        </span>
        <span className="flex items-center gap-1">
          {command.hardwareAbstract ? (
            <CheckCircle2 className="w-3 h-3 text-emerald-500" />
          ) : (
            <XCircle className="w-3 h-3 text-red-500" />
          )}
          Hardware-abstract
        </span>
      </div>
    </div>
  );
}

// ── Atomare Einheiten-Karte ──────────────────────────────────────────────────

function AtomicUnitCard({ unit }: { unit: AtomicUnit }) {
  const getIcon = (name: string) => {
    if (name.includes('voice') || name.includes('mfcc')) return <Mic className="w-4 h-4" />;
    if (name.includes('encrypt') || name.includes('auth') || name.includes('verify')) return <Lock className="w-4 h-4" />;
    if (name.includes('packet') || name.includes('route')) return <Wifi className="w-4 h-4" />;
    if (name.includes('scan') || name.includes('rssi')) return <Activity className="w-4 h-4" />;
    if (name.includes('state')) return <Cpu className="w-4 h-4" />;
    return <Zap className="w-4 h-4" />;
  };
  
  return (
    <div className="border rounded-lg p-3 hover:bg-muted/50 transition-colors">
      <div className="flex items-center gap-2 mb-2">
        {getIcon(unit.name)}
        <span className="font-mono text-sm font-semibold">{unit.name}</span>
      </div>
      <p className="text-xs text-muted-foreground mb-2">{unit.operation}</p>
      <div className="flex items-center gap-2">
        <Badge variant={unit.creditRequired ? 'destructive' : 'default'} className="text-xs">
          {unit.creditRequired ? 'Credits nötig' : 'Credit-frei'}
        </Badge>
        <Badge variant={unit.hardwareRequired ? 'secondary' : 'outline'} className="text-xs">
          {unit.hardwareRequired ? 'Hardware' : 'Abstract'}
        </Badge>
      </div>
    </div>
  );
}

export default RedundancyPanel;
