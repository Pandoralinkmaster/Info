// ═══════════════════════════════════════════════════════════════════════════════
// ORPP Analysis Panel — Kausalanalyse der Abbruchbedingungen
// 
// Γ(S) = { 1 wenn S ∉ Ω (Stopp), 0 wenn S ∈ Ω (Aktiv) }
// Analyse(E_stop) → ΔLogik
// ═══════════════════════════════════════════════════════════════════════════════

import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { ScrollArea } from '@/components/ui/scroll-area';
import {
  Activity,
  AlertTriangle,
  Bug,
  WifiOff,
  ShieldAlert,
  ZapOff,
  HelpCircle,
  ChevronRight,
  Clock,
  Lightbulb,
  Code2,
} from 'lucide-react';
import type { AnalysisResult, ErrorVector } from '@/types/orpp';
import { StopCause } from '@/types/orpp';

interface AnalysisPanelProps {
  analysisResults: AnalysisResult[];
  errorVector: ErrorVector;
  isAnalyzing: boolean;
  onRunAnalysis: () => void;
}

export function AnalysisPanel({
  analysisResults,
  errorVector,
  isAnalyzing,
  onRunAnalysis,
}: AnalysisPanelProps) {
  const sortedResults = [...analysisResults].sort((a, b) => b.timestamp - a.timestamp);
  
  // Fehlervektor-Komponenten
  const errorComponents = [
    { label: 'Ressourcen-Erschöpfung', value: errorVector.resourceExhaustion, icon: <ZapOff className="w-4 h-4" />, color: 'bg-red-500' },
    { label: 'Sicherheits-Latenzen', value: errorVector.securityLatency, icon: <ShieldAlert className="w-4 h-4" />, color: 'bg-amber-500' },
    { label: 'Netzwerk-Ausfall', value: errorVector.networkFailure, icon: <WifiOff className="w-4 h-4" />, color: 'bg-blue-500' },
    { label: 'System-Crash', value: errorVector.systemCrash, icon: <Bug className="w-4 h-4" />, color: 'bg-purple-500' },
    { label: 'Externe Terminierung', value: errorVector.externalTermination, icon: <AlertTriangle className="w-4 h-4" />, color: 'bg-rose-500' },
    { label: 'Unbekannt', value: errorVector.unknownCause, icon: <HelpCircle className="w-4 h-4" />, color: 'bg-gray-500' },
  ];

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold tracking-tight flex items-center gap-2">
            <Activity className="w-6 h-6" />
            Kausalanalyse der Abbruchbedingungen
          </h2>
          <p className="text-muted-foreground mt-1">
            Analyse(E_stop) → ΔLogik — Ursachen identifizieren und Lösungen ableiten
          </p>
        </div>
        <button
          onClick={onRunAnalysis}
          disabled={isAnalyzing}
          className="inline-flex items-center gap-2 px-4 py-2 bg-primary text-primary-foreground rounded-md hover:bg-primary/90 transition-colors disabled:opacity-50"
        >
          <Activity className="w-4 h-4" />
          {isAnalyzing ? 'Analysiere...' : 'Neue Analyse starten'}
        </button>
      </div>

      {/* Fehlervektor-Visualisierung */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Bug className="w-5 h-5" />
            Fehlervektor e — Aktuelle Abbruchrisiken
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {errorComponents.map((comp) => (
              <div key={comp.label} className="space-y-2">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    {comp.icon}
                    <span className="text-sm font-medium">{comp.label}</span>
                  </div>
                  <span className={`text-sm font-bold ${comp.value > 0.5 ? 'text-red-500' : comp.value > 0.2 ? 'text-amber-500' : 'text-emerald-500'}`}>
                    {(comp.value * 100).toFixed(1)}%
                  </span>
                </div>
                <div className="h-2 bg-muted rounded-full overflow-hidden">
                  <div 
                    className={`h-full ${comp.color} transition-all duration-500`}
                    style={{ width: `${comp.value * 100}%` }}
                  />
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      <Separator />

      {/* Analyse-Ergebnisse */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Lightbulb className="w-5 h-5" />
            Analyse-Ergebnisse ({sortedResults.length})
          </CardTitle>
        </CardHeader>
        <CardContent>
          <ScrollArea className="h-[400px]">
            <div className="space-y-3">
              {sortedResults.length === 0 ? (
                <div className="text-center py-8 text-muted-foreground">
                  <Activity className="w-8 h-8 mx-auto mb-2 opacity-50" />
                  <p>Noch keine Analyse-Ergebnisse vorhanden.</p>
                  <p className="text-sm">Starte eine Kausalanalyse, um Abbruchbedingungen zu identifizieren.</p>
                </div>
              ) : (
                sortedResults.map((result) => (
                  <AnalysisCard key={result.id} result={result} />
                ))
              )}
            </div>
          </ScrollArea>
        </CardContent>
      </Card>
    </div>
  );
}

// ── Analyse-Karte ────────────────────────────────────────────────────────────

function AnalysisCard({ result }: { result: AnalysisResult }) {
  const causeConfig = getCauseConfig(result.category);
  
  return (
    <div className={`p-4 rounded-lg border ${causeConfig.borderColor} ${causeConfig.bgColor}`}>
      <div className="flex items-start justify-between mb-2">
        <div className="flex items-center gap-2">
          {causeConfig.icon}
          <span className="font-semibold">{causeConfig.label}</span>
          <Badge variant={result.severity > 0.7 ? 'destructive' : result.severity > 0.4 ? 'default' : 'secondary'}>
            Schwere: {(result.severity * 100).toFixed(0)}%
          </Badge>
        </div>
        <div className="flex items-center gap-1 text-xs text-muted-foreground">
          <Clock className="w-3 h-3" />
          {new Date(result.timestamp).toLocaleTimeString()}
        </div>
      </div>
      
      <Separator className="my-2" />
      
      <div className="space-y-2">
        <div className="flex items-start gap-2">
          <Lightbulb className="w-4 h-4 mt-0.5 shrink-0 text-amber-500" />
          <div>
            <p className="text-xs font-medium text-muted-foreground">Empfehlung</p>
            <p className="text-sm">{result.recommendation}</p>
          </div>
        </div>
        
        <div className="flex items-start gap-2">
          <Code2 className="w-4 h-4 mt-0.5 shrink-0 text-blue-500" />
          <div>
            <p className="text-xs font-medium text-muted-foreground">ΔLogik</p>
            <code className="text-xs bg-muted px-2 py-1 rounded block mt-1">
              {result.deltaLogic}
            </code>
          </div>
        </div>
        
        <div className="flex items-center gap-2 mt-2">
          <ChevronRight className="w-3 h-3" />
          <Badge variant={result.integrated ? 'default' : 'outline'} className="text-xs">
            {result.integrated ? 'Integriert' : 'Nicht integriert'}
          </Badge>
        </div>
      </div>
    </div>
  );
}

// ── Cause Config ─────────────────────────────────────────────────────────────

function getCauseConfig(cause: StopCause) {
  switch (cause) {
    case StopCause.RESOURCE_EXHAUSTION:
      return {
        label: 'Ressourcen-Erschöpfung',
        icon: <ZapOff className="w-4 h-4 text-red-500" />,
        borderColor: 'border-red-200',
        bgColor: 'bg-red-50',
      };
    case StopCause.SECURITY_LATENCY:
      return {
        label: 'Sicherheits-Latenzen',
        icon: <ShieldAlert className="w-4 h-4 text-amber-500" />,
        borderColor: 'border-amber-200',
        bgColor: 'bg-amber-50',
      };
    case StopCause.NETWORK_FAILURE:
      return {
        label: 'Netzwerk-Ausfall',
        icon: <WifiOff className="w-4 h-4 text-blue-500" />,
        borderColor: 'border-blue-200',
        bgColor: 'bg-blue-50',
      };
    case StopCause.SYSTEM_CRASH:
      return {
        label: 'System-Crash',
        icon: <Bug className="w-4 h-4 text-purple-500" />,
        borderColor: 'border-purple-200',
        bgColor: 'bg-purple-50',
      };
    case StopCause.EXTERNAL_TERMINATION:
      return {
        label: 'Externe Terminierung',
        icon: <AlertTriangle className="w-4 h-4 text-rose-500" />,
        borderColor: 'border-rose-200',
        bgColor: 'bg-rose-50',
      };
    default:
      return {
        label: 'Unbekannte Ursache',
        icon: <HelpCircle className="w-4 h-4 text-gray-500" />,
        borderColor: 'border-gray-200',
        bgColor: 'bg-gray-50',
      };
  }
}

export default AnalysisPanel;
