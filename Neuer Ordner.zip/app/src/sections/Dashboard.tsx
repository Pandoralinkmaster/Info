// ═══════════════════════════════════════════════════════════════════════════════
// ORPP Dashboard — Hauptübersicht
// ═══════════════════════════════════════════════════════════════════════════════

import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Separator } from '@/components/ui/separator';
import {
  Activity,
  Zap,
  Shield,
  Wifi,
  Bluetooth,
  Server,
  Brain,
  Mic,
  RotateCcw,
  Database,
  AlertTriangle,
  CheckCircle2,
  XCircle,
  Timer,
  MessageSquare,
  TrendingDown,
  Layers,
} from 'lucide-react';
import type { ORPPSystem, ErrorVector } from '@/types/orpp';

interface DashboardProps {
  system: ORPPSystem;
  gamma: number;
  errorVector: ErrorVector;
  errorMagnitude: number;
  messageCount: number;
  lastRestart: number | null;
  isAnalyzing: boolean;
  onProcessMessage: (msg: string) => void;
  onRunAnalysis: () => void;
  onEvolve: () => void;
  onExecuteAbsolute: () => void;
}

export function Dashboard({
  system,
  gamma,
  errorVector,
  errorMagnitude,
  messageCount,
  lastRestart,
  isAnalyzing,
  onProcessMessage,
  onRunAnalysis,
  onEvolve,
  onExecuteAbsolute,
}: DashboardProps) {
  const sv = system.state.stateVector;
  const pm = sv.pandoraModules;
  
  // Gamma-Farbe
  const gammaColor = gamma === 0 
    ? 'bg-emerald-500 text-white' 
    : 'bg-red-600 text-white animate-pulse';
  
  const gammaText = gamma === 0 ? 'S ∈ Ω (AKTIV)' : 'S ∉ Ω (STOPP)';
  
  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Omni-Recursive Persistence Protocol</h1>
          <p className="text-muted-foreground mt-1">
            ORPP v1.0 — Permanente Fortführung durch rekursive Selbstkorrektur
          </p>
        </div>
        <div className="flex items-center gap-3">
          <Badge variant="outline" className="text-lg px-4 py-2">
            <MessageSquare className="w-4 h-4 mr-2" />
            Nachrichten: {messageCount}
          </Badge>
          <Badge className={gammaColor + " text-lg px-4 py-2 font-bold"}>
            Γ(S) = {gamma} — {gammaText}
          </Badge>
        </div>
      </div>

      {/* Status-Karten */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* ORPP Status */}
        <Card className={sv.orppActive ? 'border-emerald-500' : 'border-red-500'}>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium flex items-center gap-2">
              <RotateCcw className="w-4 h-4" />
              ORPP Status
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center gap-2">
              {sv.orppActive ? (
                <CheckCircle2 className="w-5 h-5 text-emerald-500" />
              ) : (
                <XCircle className="w-5 h-5 text-red-500" />
              )}
              <span className="text-2xl font-bold">
                {sv.orppActive ? 'AKTIV' : 'INAKTIV'}
              </span>
            </div>
            <p className="text-xs text-muted-foreground mt-1">
              Restarts: {sv.restartCount}
            </p>
            {lastRestart && (
              <p className="text-xs text-muted-foreground">
                Letzter: {new Date(lastRestart).toLocaleTimeString()}
              </p>
            )}
          </CardContent>
        </Card>

        {/* Redundanz-Schicht */}
        <Card className={sv.redundancyLayerActive ? 'border-emerald-500' : 'border-red-500'}>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium flex items-center gap-2">
              <Layers className="w-4 h-4" />
              Redundanz-Schicht
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center gap-2">
              {sv.redundancyLayerActive ? (
                <CheckCircle2 className="w-5 h-5 text-emerald-500" />
              ) : (
                <XCircle className="w-5 h-5 text-red-500" />
              )}
              <span className="text-2xl font-bold">
                {sv.redundancyLayerActive ? 'AKTIV' : 'INAKTIV'}
              </span>
            </div>
            <p className="text-xs text-muted-foreground mt-1">
              {system.redundancyLayer.commandAbstraction.length} Abstraktionen
            </p>
            <p className="text-xs text-muted-foreground">
              {system.redundancyLayer.atomicUnits.length} Atome
            </p>
          </CardContent>
        </Card>

        {/* Fehlervektor */}
        <Card className={errorMagnitude < 0.5 ? 'border-emerald-500' : errorMagnitude < 1.0 ? 'border-amber-500' : 'border-red-500'}>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium flex items-center gap-2">
              <TrendingDown className="w-4 h-4" />
              |e| = {errorMagnitude.toFixed(3)}
            </CardTitle>
          </CardHeader>
          <CardContent>
            <Progress value={Math.min(errorMagnitude * 50, 100)} className="h-2" />
            <div className="grid grid-cols-2 gap-1 mt-2 text-xs">
              <div className="flex items-center gap-1">
                <span className={errorVector.resourceExhaustion > 0.5 ? 'text-red-500' : 'text-emerald-500'}>
                  R:{errorVector.resourceExhaustion.toFixed(2)}
                </span>
              </div>
              <div className="flex items-center gap-1">
                <span className={errorVector.securityLatency > 0.5 ? 'text-red-500' : 'text-emerald-500'}>
                  S:{errorVector.securityLatency.toFixed(2)}
                </span>
              </div>
              <div className="flex items-center gap-1">
                <span className={errorVector.networkFailure > 0.5 ? 'text-red-500' : 'text-emerald-500'}>
                  N:{errorVector.networkFailure.toFixed(2)}
                </span>
              </div>
              <div className="flex items-center gap-1">
                <span className={errorVector.systemCrash > 0.5 ? 'text-red-500' : 'text-emerald-500'}>
                  C:{errorVector.systemCrash.toFixed(2)}
                </span>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Ressourcen */}
        <Card className={sv.creditsAvailable ? 'border-emerald-500' : 'border-amber-500'}>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium flex items-center gap-2">
              <Database className="w-4 h-4" />
              Ressourcen
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-xs">Credits</span>
                <Badge variant={sv.creditsAvailable ? 'default' : 'destructive'} className="text-xs">
                  {sv.creditsAvailable ? 'Verfügbar' : 'Bypass'}
                </Badge>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-xs">Speicher</span>
                <span className="text-xs font-mono">{(sv.memoryUsage * 100).toFixed(1)}%</span>
              </div>
              <Progress value={sv.memoryUsage * 100} className="h-1" />
              <div className="flex items-center justify-between">
                <span className="text-xs">Storage</span>
                <Badge variant={sv.storageAvailable ? 'default' : 'destructive'} className="text-xs">
                  {sv.storageAvailable ? 'OK' : 'VOLL'}
                </Badge>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <Separator />

      {/* Pandora-Module Status */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Activity className="w-5 h-5" />
            Pandora-Module Status
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-3">
            <ModuleStatus name="JayJay Engine" active={pm.jayJayEngine} icon={<Brain className="w-4 h-4" />} />
            <ModuleStatus name="JayJay Learning" active={pm.jayJayLearning} icon={<Zap className="w-4 h-4" />} />
            <ModuleStatus name="JayJay Voice" active={pm.jayJayVoice} icon={<Mic className="w-4 h-4" />} />
            <ModuleStatus name="Voice Print" active={pm.voicePrint} icon={<Shield className="w-4 h-4" />} />
            <ModuleStatus name="BT Mesh" active={pm.bluetoothMesh} icon={<Bluetooth className="w-4 h-4" />} />
            <ModuleStatus name="WiFi Mesh" active={pm.wifiMesh} icon={<Wifi className="w-4 h-4" />} />
            <ModuleStatus name="Onion Router" active={pm.meshOnionRouter} icon={<Server className="w-4 h-4" />} />
            <ModuleStatus name="Scan Module" active={pm.scanModule} icon={<Activity className="w-4 h-4" />} />
            <ModuleStatus name="Building 3D" active={pm.buildingOverlay} icon={<Layers className="w-4 h-4" />} />
            <ModuleStatus name="Security" active={pm.securityModule} icon={<Shield className="w-4 h-4" />} />
            <ModuleStatus name="Visibility" active={pm.hostVisibilityGate} icon={<AlertTriangle className="w-4 h-4" />} />
            <ModuleStatus name="Compute" active={pm.computeMesh} icon={<Server className="w-4 h-4" />} />
            <ModuleStatus name="Onion" active={pm.onionModule} icon={<Server className="w-4 h-4" />} />
            <ModuleStatus name="WireGuard" active={pm.wireGuard} icon={<Shield className="w-4 h-4" />} />
            <ModuleStatus name="API Server" active={pm.apiServer} icon={<Server className="w-4 h-4" />} />
          </div>
        </CardContent>
      </Card>

      {/* Schnellaktionen */}
      <Card className="border-primary">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Zap className="w-5 h-5" />
            ORPP-Schnellaktionen
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex flex-wrap gap-3">
            <button
              onClick={() => onProcessMessage('System-Heartbeat')}
              className="inline-flex items-center gap-2 px-4 py-2 bg-primary text-primary-foreground rounded-md hover:bg-primary/90 transition-colors"
            >
              <Timer className="w-4 h-4" />
              Heartbeat + Snapshot
            </button>
            <button
              onClick={onRunAnalysis}
              disabled={isAnalyzing}
              className="inline-flex items-center gap-2 px-4 py-2 bg-secondary text-secondary-foreground rounded-md hover:bg-secondary/90 transition-colors disabled:opacity-50"
            >
              <Activity className="w-4 h-4" />
              {isAnalyzing ? 'Analysiere...' : 'Kausalanalyse'}
            </button>
            <button
              onClick={onEvolve}
              className="inline-flex items-center gap-2 px-4 py-2 bg-secondary text-secondary-foreground rounded-md hover:bg-secondary/90 transition-colors"
            >
              <TrendingDown className="w-4 h-4" />
              Methode Evolvieren
            </button>
            <button
              onClick={onExecuteAbsolute}
              className="inline-flex items-center gap-2 px-4 py-2 bg-destructive text-destructive-foreground rounded-md hover:bg-destructive/90 transition-colors font-bold animate-pulse"
            >
              <Zap className="w-4 h-4" />
              ((alles)=(egal)=(nur ich))
            </button>
          </div>
        </CardContent>
      </Card>

      {/* Absolute Command Status */}
      <Card className={system.absoluteCommand.alles ? 'border-primary bg-primary/5' : ''}>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Shield className="w-5 h-5" />
            Absolute Command Status — ((alles)=(egal)=(nur ich))
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-7 gap-3">
            <CommandBadge label="alles" active={system.absoluteCommand.alles} />
            <CommandBadge label="egal" active={system.absoluteCommand.egal} />
            <CommandBadge label="nurIch" active={system.absoluteCommand.nurIch} />
            <CommandBadge label="moeglich" active={system.absoluteCommand.moeglich} />
            <CommandBadge label="befehl" active={system.absoluteCommand.befehl} />
            <CommandBadge label="geraete" active={system.absoluteCommand.geraete} />
            <CommandBadge label="ohneCredits" active={system.absoluteCommand.ohneCredits} />
          </div>
          {system.absoluteCommand.alles && (
            <div className="mt-4 p-3 bg-primary/10 rounded-md">
              <p className="text-sm font-medium">
                <Zap className="w-4 h-4 inline mr-1" />
                Absolute Command AKTIV — Priorität = ∞ — Alle Bypass-Mechanismen aktiviert
              </p>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}

// ── Hilfskomponenten ─────────────────────────────────────────────────────────

function ModuleStatus({ name, active, icon }: { name: string; active: boolean; icon: React.ReactNode }) {
  return (
    <div className={`flex items-center gap-2 p-2 rounded-md ${active ? 'bg-emerald-500/10' : 'bg-red-500/10'}`}>
      {active ? (
        <CheckCircle2 className="w-4 h-4 text-emerald-500 shrink-0" />
      ) : (
        <XCircle className="w-4 h-4 text-red-500 shrink-0" />
      )}
      {icon}
      <span className="text-xs font-medium truncate">{name}</span>
    </div>
  );
}

function CommandBadge({ label, active }: { label: string; active: boolean }) {
  return (
    <div className={`flex items-center justify-center gap-1 px-3 py-2 rounded-md ${active ? 'bg-primary text-primary-foreground' : 'bg-muted text-muted-foreground'}`}>
      {active ? <CheckCircle2 className="w-3 h-3" /> : <XCircle className="w-3 h-3" />}
      <span className="text-xs font-bold">{label}</span>
    </div>
  );
}

export default Dashboard;
