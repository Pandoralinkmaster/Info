// ═══════════════════════════════════════════════════════════════════════════════
// ORPP Evolution Panel — Methoden-Evolution
// 
// min ∫ |Γ(S)| dt
// M_new = evolutionäre Weiterentwicklung mit Fehlervektor-Minimierung
// ═══════════════════════════════════════════════════════════════════════════════

import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Progress } from '@/components/ui/progress';
import {
  TrendingDown,
  TrendingUp,
  GitBranch,
  Clock,
  CheckCircle2,
  Brain,
} from 'lucide-react';
import type { MethodEvolution, ErrorVector } from '@/types/orpp';

interface EvolutionPanelProps {
  evolutionHistory: MethodEvolution[];
  onEvolve: () => void;
}

export function EvolutionPanel({
  evolutionHistory,
  onEvolve,
}: EvolutionPanelProps) {
  const sorted = [...evolutionHistory].sort((a, b) => b.timestamp - a.timestamp);
  
  // Statistiken
  const totalEvolutions = sorted.length;
  const integratedCount = sorted.filter(e => e.integrated).length;
  const avgImprovement = totalEvolutions > 0
    ? sorted.reduce((sum, e) => sum + e.improvement, 0) / totalEvolutions
    : 0;
  
  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold tracking-tight flex items-center gap-2">
            <Brain className="w-6 h-6" />
            Methoden-Evolution
          </h2>
          <p className="text-muted-foreground mt-1">
            min ∫ |Γ(S)| dt — Fehlervektor-Minimierung durch evolutionäre Methodenentwicklung
          </p>
        </div>
        <button
          onClick={onEvolve}
          className="inline-flex items-center gap-2 px-4 py-2 bg-primary text-primary-foreground rounded-md hover:bg-primary/90 transition-colors"
        >
          <GitBranch className="w-4 h-4" />
          Neue Evolution
        </button>
      </div>

      {/* Statistiken */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium flex items-center gap-2">
              <GitBranch className="w-4 h-4" />
              Evolutionen
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-3xl font-bold">{totalEvolutions}</p>
            <p className="text-xs text-muted-foreground">Methoden-Iterationen</p>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4" />
              Integriert
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-3xl font-bold">{integratedCount}</p>
            <Progress value={totalEvolutions > 0 ? (integratedCount / totalEvolutions) * 100 : 0} className="h-2 mt-2" />
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium flex items-center gap-2">
              {avgImprovement >= 0 ? <TrendingDown className="w-4 h-4 text-emerald-500" /> : <TrendingUp className="w-4 h-4 text-red-500" />}
              Ø Verbesserung
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className={`text-3xl font-bold ${avgImprovement >= 0 ? 'text-emerald-500' : 'text-red-500'}`}>
              {avgImprovement >= 0 ? '-' : '+'}{Math.abs(avgImprovement).toFixed(4)}
            </p>
            <p className="text-xs text-muted-foreground">Fehlermagnitude-Reduktion</p>
          </CardContent>
        </Card>
      </div>

      <Separator />

      {/* Formel */}
      <Card className="bg-primary/5">
        <CardContent className="pt-6">
          <div className="text-center space-y-2">
            <p className="text-lg font-mono">
              M<sub>new</sub> = evolutionäre Weiterentwicklung(M<sub>n</sub>, e⃗)
            </p>
            <p className="text-sm text-muted-foreground">
              Ziel: min ∫ |Γ(S)| dt = {avgImprovement >= 0 ? 'Verbesserung' : 'Verschlechterung'} um {Math.abs(avgImprovement).toFixed(6)}
            </p>
          </div>
        </CardContent>
      </Card>

      {/* Evolution-Verlauf */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <GitBranch className="w-5 h-5" />
            Evolution-Verlauf
          </CardTitle>
        </CardHeader>
        <CardContent>
          <ScrollArea className="h-[400px]">
            <div className="space-y-4">
              {sorted.length === 0 ? (
                <div className="text-center py-8 text-muted-foreground">
                  <Brain className="w-8 h-8 mx-auto mb-2 opacity-50" />
                  <p>Noch keine Methoden-Evolution durchgeführt.</p>
                  <p className="text-sm">Starte eine Evolution, um Methoden basierend auf Analyse-Ergebnissen zu verbessern.</p>
                </div>
              ) : (
                sorted.map((evo, index) => (
                  <EvolutionCard key={evo.id} evolution={evo} index={totalEvolutions - index} />
                ))
              )}
            </div>
          </ScrollArea>
        </CardContent>
      </Card>
    </div>
  );
}

// ── Evolution-Karte ──────────────────────────────────────────────────────────

function EvolutionCard({ evolution, index }: { evolution: MethodEvolution; index: number }) {
  const isImproved = evolution.improvement > 0;
  
  return (
    <div className="border rounded-lg p-4">
      <div className="flex items-start justify-between mb-3">
        <div className="flex items-center gap-2">
          <Badge variant="outline" className="font-mono">M<sub>{index}</sub></Badge>
          <div className="flex items-center gap-1">
            {isImproved ? (
              <TrendingDown className="w-4 h-4 text-emerald-500" />
            ) : (
              <TrendingUp className="w-4 h-4 text-red-500" />
            )}
            <span className={`text-sm font-bold ${isImproved ? 'text-emerald-500' : 'text-red-500'}`}>
              {isImproved ? '-' : '+'}{Math.abs(evolution.improvement).toFixed(6)}
            </span>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <Badge variant={evolution.integrated ? 'default' : 'outline'}>
            {evolution.integrated ? 'Integriert' : 'Pending'}
          </Badge>
          <span className="text-xs text-muted-foreground flex items-center gap-1">
            <Clock className="w-3 h-3" />
            {new Date(evolution.timestamp).toLocaleTimeString()}
          </span>
        </div>
      </div>
      
      <Separator className="my-2" />
      
      {/* Methoden-Vergleich */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div>
          <p className="text-xs text-muted-foreground mb-1">Vorherige Methode</p>
          <code className="text-xs bg-muted px-2 py-1 rounded block truncate">
            {evolution.previousMethod}
          </code>
        </div>
        <div>
          <p className="text-xs text-muted-foreground mb-1">Neue Methode</p>
          <code className="text-xs bg-primary/10 px-2 py-1 rounded block truncate font-medium">
            {evolution.newMethod}
          </code>
        </div>
      </div>
      
      {/* Fehlervektor-Vergleich */}
      <div className="mt-3 grid grid-cols-2 gap-4">
        <ErrorVectorPreview label="Vorher" vector={evolution.errorVectorBefore} />
        <ErrorVectorPreview label="Nachher" vector={evolution.errorVectorAfter} />
      </div>
    </div>
  );
}

// ── Fehlervektor-Vorschau ────────────────────────────────────────────────────

function ErrorVectorPreview({ label, vector }: { label: string; vector: ErrorVector }) {
  const magnitude = Math.sqrt(
    vector.resourceExhaustion ** 2 +
    vector.securityLatency ** 2 +
    vector.networkFailure ** 2 +
    vector.systemCrash ** 2 +
    vector.externalTermination ** 2
  );
  
  return (
    <div className="bg-muted/50 rounded p-2">
      <p className="text-xs font-medium mb-1">{label} — |e| = {magnitude.toFixed(4)}</p>
      <div className="space-y-1">
        <MetricBar label="R" value={vector.resourceExhaustion} />
        <MetricBar label="S" value={vector.securityLatency} />
        <MetricBar label="N" value={vector.networkFailure} />
        <MetricBar label="C" value={vector.systemCrash} />
        <MetricBar label="E" value={vector.externalTermination} />
      </div>
    </div>
  );
}

function MetricBar({ label, value }: { label: string; value: number }) {
  return (
    <div className="flex items-center gap-2">
      <span className="text-xs w-3">{label}</span>
      <div className="flex-1 h-1.5 bg-muted rounded-full overflow-hidden">
        <div 
          className={`h-full ${value > 0.5 ? 'bg-red-500' : value > 0.2 ? 'bg-amber-500' : 'bg-emerald-500'}`}
          style={{ width: `${value * 100}%` }}
        />
      </div>
      <span className="text-xs w-8 text-right">{value.toFixed(2)}</span>
    </div>
  );
}

export default EvolutionPanel;
