// ═══════════════════════════════════════════════════════════════════════════════
// useORPP — React Hook für das Omni-Recursive Persistence Protocol
// 
// Implementiert:
// - Livetime-Speicherung bei jeder Nachricht
// - Auto-Restart bei Stopp
// - Kausalanalyse
// - Methoden-Evolution
// - Virtuelle Redundanz-Schicht
// ═══════════════════════════════════════════════════════════════════════════════

import { useState, useCallback, useRef, useEffect } from 'react';
import type {
  ORPPSystem,
  SystemState,
  StateVector,
  AnalysisResult,
  MethodEvolution,
  PersistenceState,
  AbsoluteCommand,
  ORPPConfig,
} from '@/types/orpp';
import {
  ORPP,
  gamma,
  causalAnalysis,
  computeErrorVector,
  errorMagnitude,
  evolveMethod,
  persistState,
  psiReconstruct,
  processAbsoluteCommand,
} from '@/lib/orpp/core';

// ── Storage Keys ─────────────────────────────────────────────────────────────

const STORAGE_KEY_SYSTEM = 'orpp_system_state';
const STORAGE_KEY_PERSISTENCE = 'orpp_persistence';
const STORAGE_KEY_HISTORY = 'orpp_history';
const STORAGE_KEY_ANALYSIS = 'orpp_analysis';
const STORAGE_KEY_EVOLUTION = 'orpp_evolution';

// ── Hilfsfunktionen für Storage ──────────────────────────────────────────────

function loadFromStorage<T>(key: string, fallback: T): T {
  try {
    const raw = localStorage.getItem(key);
    if (raw) return JSON.parse(raw);
  } catch { /* ignore */ }
  return fallback;
}

function saveToStorage(key: string, value: unknown): void {
  try {
    localStorage.setItem(key, JSON.stringify(value));
  } catch { /* ignore */ }
}

// ── Haupt-Hook ───────────────────────────────────────────────────────────────

export function useORPP() {
  // System-Zustand initialisieren (aus Storage laden falls vorhanden)
  const [system, setSystem] = useState<ORPPSystem>(() => {
    const saved = loadFromStorage<ORPPSystem | null>(STORAGE_KEY_SYSTEM, null);
    if (saved) {
      return { ...saved, isRunning: true };
    }
    return ORPP.createInitialORPPSystem();
  });

  // Persistenter Zustand
  const [persistence, setPersistence] = useState<PersistenceState>(() => {
    return loadFromStorage<PersistenceState>(STORAGE_KEY_PERSISTENCE, system.persistence);
  });

  // Analyse-Ergebnisse
  const [analysisResults, setAnalysisResults] = useState<AnalysisResult[]>(() => {
    return loadFromStorage<AnalysisResult[]>(STORAGE_KEY_ANALYSIS, []);
  });

  // Methoden-Evolution
  const [methodEvolution, setMethodEvolution] = useState<MethodEvolution[]>(() => {
    return loadFromStorage<MethodEvolution[]>(STORAGE_KEY_EVOLUTION, []);
  });

  // Verlauf
  const [history, setHistory] = useState<SystemState[]>(() => {
    return loadFromStorage<SystemState[]>(STORAGE_KEY_HISTORY, []);
  });

  // Status
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [lastRestart, setLastRestart] = useState<number | null>(null);
  const [messageCount, setMessageCount] = useState(0);

  // Refs für Intervalle
  const snapshotIntervalRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const isProcessingRef = useRef(false);

  // ── Livetime-Speicherung ───────────────────────────────────────────────────

  /**
   * Speichert den aktuellen Zustand persistent
   * P(t) = P(t - Δt) ∪ { Analyse(S_t), Entwicklung(M_{n+1}) }
   */
  const livePersist = useCallback((stateVector: StateVector, message?: string) => {
    const newPersistence = persistState(persistence, stateVector, message);
    setPersistence(newPersistence);
    saveToStorage(STORAGE_KEY_PERSISTENCE, newPersistence);
    
    // System-Zustand auch speichern
    setSystem(prev => {
      const updated = { ...prev, persistence: newPersistence };
      saveToStorage(STORAGE_KEY_SYSTEM, updated);
      return updated;
    });
  }, [persistence]);

  // ── Auto-Restart-Logik ─────────────────────────────────────────────────────

  /**
   * Ψ(E_stop) = Analyse(E_stop) → ΔLogik
   * S_neu = P(t_last) + ΔLogik
   */
  const triggerAutoRestart = useCallback((errorEvent: string) => {
    console.log(`[ORPP] AutoRestart ausgelöst: ${errorEvent}`);
    
    const reconstruction = psiReconstruct(persistence, errorEvent);
    
    if (reconstruction.success) {
      const newSystem: ORPPSystem = {
        ...system,
        state: reconstruction.newState,
        persistence: persistState(persistence, reconstruction.newState.stateVector, `AutoRestart: ${errorEvent}`),
        isRunning: true,
        history: [...system.history, system.state].slice(-MAX_HISTORY_SIZE),
      };
      
      setSystem(newSystem);
      setPersistence(newSystem.persistence);
      setLastRestart(Date.now());
      setHistory(prev => [...prev, system.state].slice(-MAX_HISTORY_SIZE));
      
      // Speichern
      saveToStorage(STORAGE_KEY_SYSTEM, newSystem);
      saveToStorage(STORAGE_KEY_PERSISTENCE, newSystem.persistence);
      saveToStorage(STORAGE_KEY_HISTORY, newSystem.history);
      
      console.log('[ORPP] AutoRestart erfolgreich — System reaktiviert');
    }
  }, [system, persistence]);

  // ── Gamma-Überwachung ──────────────────────────────────────────────────────

  /**
   * Überwacht Γ(S) kontinuierlich
   */
  const monitorGamma = useCallback(() => {
    const currentGamma = gamma(system.state.stateVector);
    
    if (currentGamma === 1 && system.config.autoRestart) {
      // Stopp erkannt — Auto-Restart auslösen
      const causes = causalAnalysis(system.state.stateVector);
      const causeNames = causes.map(c => c.cause).join(', ');
      triggerAutoRestart(`Gamma=1: ${causeNames}`);
    }
  }, [system, triggerAutoRestart]);

  // ── Nachricht verarbeiten ──────────────────────────────────────────────────

  /**
   * Verarbeitet eine eingehende Nachricht mit Livetime-Speicherung
   * Jede Nachricht M löst sofort einen Snapshot des Zustandsvektors aus
   */
  const processMessage = useCallback((message: string) => {
    if (isProcessingRef.current) return;
    isProcessingRef.current = true;
    
    const now = Date.now();
    setMessageCount(prev => prev + 1);
    
    // 1. Aktuellen Zustand aktualisieren
    const updatedStateVector: StateVector = {
      ...system.state.stateVector,
      lastSnapshot: now,
    };
    
    // 2. Livetime-Speicherung: P(t) = P(t-Δt) ∪ {Analyse(S_t)}
    const newPersistence = persistState(persistence, updatedStateVector, message);
    
    // 3. Neue System-State erstellen
    const newState: SystemState = {
      id: `${Date.now().toString(36)}_${Math.random().toString(36).substring(2, 9)}`,
      timestamp: now,
      gamma: gamma(updatedStateVector),
      stateVector: updatedStateVector,
      metadata: {
        ...system.state.metadata,
        messageId: `${Date.now().toString(36)}`,
        messageContent: message,
      },
    };
    
    // 4. Gamma prüfen
    if (newState.gamma === 1 && system.config.autoRestart) {
      // Auto-Restart notwendig
      const causes = causalAnalysis(updatedStateVector);
      const causeNames = causes.map(c => c.cause).join(', ');
      
      // Rekonstruktion
      const reconstruction = psiReconstruct(newPersistence, `Message-Trigger: ${causeNames}`);
      
      if (reconstruction.success) {
        const restartedSystem: ORPPSystem = {
          ...system,
          state: reconstruction.newState,
          persistence: persistState(newPersistence, reconstruction.newState.stateVector, `AutoRestart nach: ${message}`),
          isRunning: true,
          history: [...system.history, newState].slice(-MAX_HISTORY_SIZE),
        };
        
        setSystem(restartedSystem);
        setPersistence(restartedSystem.persistence);
        setLastRestart(now);
        setHistory(prev => [...prev, newState].slice(-MAX_HISTORY_SIZE));
        
        saveToStorage(STORAGE_KEY_SYSTEM, restartedSystem);
        saveToStorage(STORAGE_KEY_PERSISTENCE, restartedSystem.persistence);
        saveToStorage(STORAGE_KEY_HISTORY, restartedSystem.history);
        
        console.log('[ORPP] AutoRestart nach Nachricht erfolgreich');
        isProcessingRef.current = false;
        return;
      }
    }
    
    // Normaler Flow ohne Stopp
    const updatedSystem: ORPPSystem = {
      ...system,
      state: newState,
      persistence: newPersistence,
      history: [...system.history, system.state].slice(-MAX_HISTORY_SIZE),
    };
    
    setSystem(updatedSystem);
    setPersistence(newPersistence);
    setHistory(prev => [...prev, system.state].slice(-MAX_HISTORY_SIZE));
    
    // Speichern
    saveToStorage(STORAGE_KEY_SYSTEM, updatedSystem);
    saveToStorage(STORAGE_KEY_PERSISTENCE, newPersistence);
    saveToStorage(STORAGE_KEY_HISTORY, updatedSystem.history);
    
    isProcessingRef.current = false;
  }, [system, persistence]);

  // ── Kausalanalyse ──────────────────────────────────────────────────────────

  /**
   * Führt eine vollständige Kausalanalyse durch
   */
  const runAnalysis = useCallback(() => {
    setIsAnalyzing(true);
    
    const results = causalAnalysis(system.state.stateVector);
    setAnalysisResults(prev => [...prev, ...results].slice(-200));
    saveToStorage(STORAGE_KEY_ANALYSIS, [...analysisResults, ...results].slice(-200));
    
    // Fehlervektor aktualisieren
    const errorVector = computeErrorVector(system.state.stateVector);
    const newStateVector = {
      ...system.state.stateVector,
      errorVector,
    };
    
    setSystem(prev => ({
      ...prev,
      state: {
        ...prev.state,
        stateVector: newStateVector,
        metadata: {
          ...prev.state.metadata,
          analysisResults: [...prev.state.metadata.analysisResults, ...results].slice(-100),
        },
      },
    }));
    
    setIsAnalyzing(false);
    return results;
  }, [system.state.stateVector, analysisResults]);

  // ── Methoden-Evolution ─────────────────────────────────────────────────────

  /**
   * Entwickelt eine neue Methode basierend auf Analyse-Ergebnissen
   * min ∫ |Γ(S)| dt
   */
  const evolve = useCallback(() => {
    const currentMethod = `M_${system.state.timestamp}`;
    const evolution = evolveMethod(
      currentMethod,
      system.state.metadata.analysisResults,
      system.state.stateVector.errorVector
    );
    
    setMethodEvolution(prev => [...prev, evolution].slice(-100));
    saveToStorage(STORAGE_KEY_EVOLUTION, [...methodEvolution, evolution].slice(-100));
    
    // ΔLogik in den Zustand integrieren
    const newStateVector = {
      ...system.state.stateVector,
      ...applyEvolutionDelta(system.state.stateVector, evolution),
    };
    
    setSystem(prev => ({
      ...prev,
      state: {
        ...prev.state,
        stateVector: newStateVector,
        metadata: {
          ...prev.state.metadata,
          methodEvolution: [...prev.state.metadata.methodEvolution, evolution].slice(-100),
        },
      },
    }));
    
    return evolution;
  }, [system, methodEvolution]);

  // ── Absolute Command ───────────────────────────────────────────────────────

  /**
   * ((alles)=(egal)=(nur ich)=(möglich)=(Befehl)=(Geräte)=(auch wenn keine Credits))
   */
  const executeAbsoluteCommand = useCallback(() => {
    const command: Partial<AbsoluteCommand> = {
      alles: true,
      egal: true,
      nurIch: true,
      moeglich: true,
      befehl: true,
      geraete: true,
      ohneCredits: true,
    };
    
    const updatedSystem = processAbsoluteCommand(system, command);
    setSystem(updatedSystem);
    setPersistence(updatedSystem.persistence);
    saveToStorage(STORAGE_KEY_SYSTEM, updatedSystem);
    saveToStorage(STORAGE_KEY_PERSISTENCE, updatedSystem.persistence);
    
    // Livetime-Speicherung
    livePersist(updatedSystem.state.stateVector, 'Absolute Command: ((alles)=(egal)=(nur ich))');
    
    return updatedSystem;
  }, [system, livePersist]);

  // ── Konfiguration aktualisieren ────────────────────────────────────────────

  const updateConfig = useCallback((config: Partial<ORPPConfig>) => {
    setSystem(prev => {
      const updated = {
        ...prev,
        config: { ...prev.config, ...config },
      };
      saveToStorage(STORAGE_KEY_SYSTEM, updated);
      return updated;
    });
  }, []);

  // ── Modul-Zustände toggeln ─────────────────────────────────────────────────

  const toggleModule = useCallback((moduleName: keyof StateVector['pandoraModules']) => {
    setSystem(prev => {
      const newModules = {
        ...prev.state.stateVector.pandoraModules,
        [moduleName]: !prev.state.stateVector.pandoraModules[moduleName],
      };
      const newStateVector = {
        ...prev.state.stateVector,
        pandoraModules: newModules,
      };
      const updated = {
        ...prev,
        state: {
          ...prev.state,
          stateVector: newStateVector,
          gamma: gamma(newStateVector),
        },
      };
      saveToStorage(STORAGE_KEY_SYSTEM, updated);
      return updated;
    });
  }, []);

  // ── Fehlervektor abrufen ───────────────────────────────────────────────────

  const getErrorVector = useCallback(() => {
    return computeErrorVector(system.state.stateVector);
  }, [system.state.stateVector]);

  const getErrorMagnitude = useCallback(() => {
    return errorMagnitude(computeErrorVector(system.state.stateVector));
  }, [system.state.stateVector]);

  // ── Gamma-Status ───────────────────────────────────────────────────────────

  const getGamma = useCallback(() => {
    return gamma(system.state.stateVector);
  }, [system.state.stateVector]);

  // ── Auto-Restart Timer ─────────────────────────────────────────────────────

  useEffect(() => {
    // Kontinuierliche Gamma-Überwachung
    const interval = setInterval(() => {
      monitorGamma();
    }, 2000); // Alle 2 Sekunden
    
    snapshotIntervalRef.current = interval;
    
    return () => {
      if (snapshotIntervalRef.current) {
        clearInterval(snapshotIntervalRef.current);
      }
    };
  }, [monitorGamma]);

  // ── Persistenz bei Systemänderungen ────────────────────────────────────────

  useEffect(() => {
    // Bei jeder Systemänderung persistieren
    if (system.config.liveTimeStorage) {
      saveToStorage(STORAGE_KEY_SYSTEM, system);
    }
  }, [system]);

  // ── Rückgabe ───────────────────────────────────────────────────────────────

  return {
    // System
    system,
    persistence,
    
    // Analyse
    analysisResults,
    methodEvolution,
    history,
    isAnalyzing,
    
    // Status
    lastRestart,
    messageCount,
    gamma: getGamma(),
    errorVector: getErrorVector(),
    errorMagnitude: getErrorMagnitude(),
    isRunning: system.isRunning,
    
    // Aktionen
    processMessage,
    runAnalysis,
    evolve,
    executeAbsoluteCommand,
    updateConfig,
    toggleModule,
    livePersist,
    triggerAutoRestart,
    
    // Hilfsfunktionen
    getGamma,
    getErrorVector,
    getErrorMagnitude,
  };
}

// ── Konstanten ───────────────────────────────────────────────────────────────

const MAX_HISTORY_SIZE = 500;

// ── Hilfsfunktionen ──────────────────────────────────────────────────────────

function applyEvolutionDelta(_stateVector: StateVector, evolution: MethodEvolution): Partial<StateVector> {
  const delta: Partial<StateVector> = {};
  
  if (evolution.errorVectorAfter.resourceExhaustion < evolution.errorVectorBefore.resourceExhaustion) {
    delta.creditsAvailable = true;
  }
  if (evolution.errorVectorAfter.securityLatency < evolution.errorVectorBefore.securityLatency) {
    delta.securityLevel = 'async-zero-trust-evolved';
  }
  
  return delta;
}

export default useORPP;
