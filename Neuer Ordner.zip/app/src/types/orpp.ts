// ═══════════════════════════════════════════════════════════════════════════════
// Omni-Recursive Persistence Protocol (ORPP) — Type Definitions
// ═══════════════════════════════════════════════════════════════════════════════

/** Systemzustand S im Operationsraum Omega */
export interface SystemState {
  id: string;
  timestamp: number;
  gamma: number;           // Γ(S) — 0 = aktiv, 1 = stopp
  stateVector: StateVector;
  metadata: StateMetadata;
}

/** Zustandsvektor V — vollständiger Systemzustand */
export interface StateVector {
  // Kern-System
  jayJayActive: boolean;
  jayJayActivated: boolean;
  ceoPresent: boolean;
  hostOpen: boolean;
  
  // Netzwerk
  torActive: boolean;
  wireGuardActive: boolean;
  bluetoothMeshActive: boolean;
  wifiMeshActive: boolean;
  meshNodeCount: number;
  
  // Sicherheit
  securityLevel: string;
  lastEvent: string;
  threatLevel: number;
  
  // Ressourcen
  creditsAvailable: boolean;
  tokenStatus: string;
  storageAvailable: boolean;
  memoryUsage: number;
  
  // ORPP-spezifisch
  orppActive: boolean;
  redundancyLayerActive: boolean;
  lastSnapshot: number;
  restartCount: number;
  errorVector: ErrorVector;
  
  // Pandora-Integration
  pandoraModules: PandoraModuleState;
}

/** Pandora-Modul-Zustände */
export interface PandoraModuleState {
  jayJayEngine: boolean;
  jayJayLearning: boolean;
  jayJayVoice: boolean;
  voicePrint: boolean;
  bluetoothMesh: boolean;
  wifiMesh: boolean;
  meshOnionRouter: boolean;
  scanModule: boolean;
  buildingOverlay: boolean;
  securityModule: boolean;
  hostVisibilityGate: boolean;
  computeMesh: boolean;
  onionModule: boolean;
  wireGuard: boolean;
  apiServer: boolean;
}

/** Fehlervektor e — Analyse der Abbruchursachen */
export interface ErrorVector {
  resourceExhaustion: number;     // 0-1: Credits/Token erschöpft
  securityLatency: number;        // 0-1: Sicherheits-Verzögerungen
  networkFailure: number;         // 0-1: Netzwerk-Ausfall
  systemCrash: number;            // 0-1: Systemabsturz
  externalTermination: number;    // 0-1: Externe Beendigung
  unknownCause: number;           // 0-1: Unbekannte Ursache
  timestamp: number;
}

/** Zustandsmetadaten */
export interface StateMetadata {
  sessionId: string;
  messageId: string;
  messageContent: string;
  analysisResults: AnalysisResult[];
  methodEvolution: MethodEvolution[];
}

/** Analyse-Ergebnis */
export interface AnalysisResult {
  id: string;
  timestamp: number;
  cause: string;
  category: StopCause;
  severity: number;
  recommendation: string;
  deltaLogic: string;
  integrated: boolean;
}

/** Abbruchursachen */
export const StopCause = {
  RESOURCE_EXHAUSTION: 'resource_exhaustion',
  SECURITY_LATENCY: 'security_latency',
  NETWORK_FAILURE: 'network_failure',
  SYSTEM_CRASH: 'system_crash',
  EXTERNAL_TERMINATION: 'external_termination',
  UNKNOWN: 'unknown',
} as const;

export type StopCause = typeof StopCause[keyof typeof StopCause];

/** Methoden-Evolution */
export interface MethodEvolution {
  id: string;
  timestamp: number;
  previousMethod: string;
  newMethod: string;
  errorVectorBefore: ErrorVector;
  errorVectorAfter: ErrorVector;
  improvement: number;
  integrated: boolean;
}

/** Persistenter Speicherzustand P(t) */
export interface PersistenceState {
  timestamp: number;
  stateVector: StateVector;
  analysisResults: AnalysisResult[];
  methodEvolution: MethodEvolution[];
  snapshot: SystemSnapshot;
}

/** System-Snapshot */
export interface SystemSnapshot {
  id: string;
  timestamp: number;
  compressedState: string;
  checksum: string;
}

/** Rekonstruktions-Funktion Psi */
export interface ReconstructionResult {
  success: boolean;
  analysis: AnalysisResult;
  deltaLogic: string;
  newState: SystemState;
  timestamp: number;
}

/** Virtuelle Redundanz-Schicht */
export interface RedundancyLayer {
  active: boolean;
  commandAbstraction: CommandAbstraction[];
  deviceIndependence: boolean;
  atomicUnits: AtomicUnit[];
}

/** Befehls-Abstraktion */
export interface CommandAbstraction {
  id: string;
  command: string;
  atomicUnits: string[];
  creditIndependent: boolean;
  hardwareAbstract: boolean;
  executionCount: number;
  successRate: number;
}

/** Atomare Einheit */
export interface AtomicUnit {
  id: string;
  name: string;
  operation: string;
  parameters: Record<string, unknown>;
  creditRequired: boolean;
  hardwareRequired: boolean;
}

/** ORPP-Konfiguration */
export interface ORPPConfig {
  autoRestart: boolean;
  liveTimeStorage: boolean;
  autoAnalysis: boolean;
  methodEvolution: boolean;
  redundancyLayer: boolean;
  snapshotInterval: number;
  maxRestarts: number;
  priorityLevel: number;
}

/** Befehlssyntax: ((alles)=(egal)=(nur ich)) */
export interface AbsoluteCommand {
  alles: boolean;      // Zugriff auf alles
  egal: boolean;       // Egal welche Hindernisse
  nurIch: boolean;     // Nur der CEO hat Zugriff
  moeglich: boolean;   // Alles ist möglich
  befehl: boolean;     // Befehl ausführen
  geraete: boolean;    // Alle Geräte
  ohneCredits: boolean; // Auch ohne Credits
}

/** Gesamtes ORPP-System */
export interface ORPPSystem {
  config: ORPPConfig;
  state: SystemState;
  persistence: PersistenceState;
  redundancyLayer: RedundancyLayer;
  absoluteCommand: AbsoluteCommand;
  history: SystemState[];
  isRunning: boolean;
}

// ═══════════════════════════════════════════════════════════════════════════════
// Pandora-spezifische Typen für Integration
// ═══════════════════════════════════════════════════════════════════════════════

export interface JayJayState {
  isListening: boolean;
  isActivated: boolean;
  ceoPresent: boolean;
  lastCommand: string;
  lastResponse: string;
  tasksPending: number;
  deviceId: string;
}

export interface MeshState {
  advertising: boolean;
  scanning: boolean;
  peers: string[];
  messagesSent: number;
  messagesReceived: number;
}

export interface SecurityState {
  events: SecurityEvent[];
  threatLevel: number;
  lastScan: number;
}

export interface SecurityEvent {
  id: string;
  eventType: string;
  severity: string;
  description: string;
  timestamp: number;
}

export interface NetworkState {
  torActive: boolean;
  wireGuardActive: boolean;
  bluetoothMeshActive: boolean;
  wifiMeshActive: boolean;
  meshNodeCount: number;
}

export interface ScanResult {
  sessionId: string;
  rssiMap: Record<string, number>;
  presenceScore: number;
  timestamp: number;
}

export interface KnowledgeEntry {
  id: string;
  topic: string;
  content: string;
  source: string;
  confidence: number;
  learnedAt: number;
  timesUsed: number;
}

export interface ComputeTask {
  taskId: string;
  taskType: string;
  status: string;
  createdAt: number;
}

export interface ComputeNode {
  nodeId: string;
  status: string;
  cpuCores: number;
  ramMb: number;
  batteryPercent: number;
}
