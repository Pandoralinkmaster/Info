# LAYER 2: EQGRP ARSENAL INTEGRATION (115 Tools)
# ================================================
# Theoretical integration framework for 115 known/suspected NSA Equation Group tools
# All entries are NON-FUNCTIONAL — pure documentation of known tool names/capabilities
# Sources: Shadow Brokers leaks, Kaspersky research, public security analysis
# ================================================

## CATEGORY A: SMB/Windows Exploits (Eternal Series) — 12 Tools
1. EternalBlue       — SMBv1 exploit (CVE-2017-0144), used in WannaCry
2. EternalRomance    — SMB exploit for Win XP/2003/Win7
3. EternalSynergy    — SMB exploit for modern Windows
4. EternalChampion   — SMB exploit, race condition
5. EmeraldThread     — SMB exploit for XP/2003
6. ErraticGopher     — SMB exploit for older systems
7. EskimoRoll        — Kerberos exploit (MS14-068)
8. EducatedScholar   — SMB exploit variant
9. EclipsedWing      — NetBIOS exploit
10. EnglishmanDentist — Exchange Server exploit
11. EsteemAudit      — RDP exploit for XP
12. ExplodingCan     — IIS 6.0 WebDAV exploit

## CATEGORY B: Implant/Backdoor Frameworks — 8 Tools
13. DoublePulsar     — SMB backdoor implant
14. DarkPulsar       — Backdoor for FuzzBunch framework
15. UNITEDRAKE       — Modular remote collection system
16. FuzzBunch        — Exploit deployment framework
17. DanderSpritz     — Post-exploitation management framework
18. PeddleCheap      — C2 communication module
19. KillSuit         — Persistence framework
20. Orangutan        — Network implant

## CATEGORY C: Router/Firewall Exploits — 15 Tools
21. ExtraBacon       — Cisco ASA SNMP exploit
22. BenignCertain    — Cisco PIX exploit
23. JETPLOW          — Cisco ASA firmware implant
24. FEEDTROUGH       — Juniper NetScreen implant
25. GROK             — Keylogger for Cisco devices
26. BANANAGLEE       — Firewall bypass tool
27. BLATSTING        — Firewall exploitation
28. BUZZDIRECTION    — Network device control
29. CRAZYKING        — Router persistence
30. DEITYBOUNCE      — BIOS/UEFI implant for Dell
31. IRATEMONK        — Hard drive firmware implant
32. SWAP             — Network interception
33. SOMBERKNAVE      — Network proxy tool
34. STEALTHFALCON    — Network exfiltration
35. SCHOOLMONTANA    — Router exploit

## CATEGORY D: Linux/Unix Exploits — 10 Tools
36. EBBISLAND        — RPC exploit for Solaris
37. ELIGIBLEBACHELOR — Unix exploit
38. ELIGIBLECANDIDATE— Unix exploit variant
39. ELIGIBLECONTESTANT— Unix exploit variant
40. ERRATICGOPHER    — Linux SMB variant
41. FUZZBUNCH_LINUX  — Linux framework port
42. GOTHAM           — Linux persistence
43. ODDJOB           — Windows/Linux cross-platform
44. ZESTYLEAK        — Information disclosure
45. ARCHITouch       — Unix backdoor

## CATEGORY E: Persistence & Evasion — 15 Tools
46. GrayFish         — Complex persistence platform
47. EquationLaser    — Early persistence tool
48. EquationDrug     — Modular platform
49. DoubleFantasy    — Validation backdoor
50. TripleFantasy    — Full backdoor
51. Fanny            — Worm for air-gapped networks
52. Gauss            — Banking trojan module
53. Careto/Mask      — Advanced espionage platform
54. Regin            — Multi-stage platform
55. QWERTY           — Keylogger module
56. STRAITACID       — C2 infrastructure
57. STRAITSHOOTER    — Data collection
58. SURLYSPAWN       — Keystroke logger
59. SWAP             — Memory manipulation
60. TRINITY          — Multi-platform implant

## CATEGORY F: Network Reconnaissance — 12 Tools
61. SECONDDATE       — Web traffic redirection
62. JACKLADDER       — Network mapping
63. DROPOUTJEEP      — iOS implant
64. NOSESMACK        — Network discovery
65. PACKEDGRAM       — Protocol analysis
66. SOMBERKNAVE      — Traffic proxy
67. TOTECHASMA       — Network scanning
68. WISTFULTOLL      — Network enumeration
69. ZESTYLEAK        — Data harvesting
70. COFFEEPRESS      — Network injection
71. DIZZYINGCHICKEN  — Network confusion
72. EAGERLEECH       — Data siphoning

## CATEGORY G: Data Exfiltration — 10 Tools
73. OLYMPUS          — Data staging
74. STUCCOMONTANA    — Data packaging
75. TOUCHDOWN        — Data transfer
76. SALVAGERABBIT    — Data recovery
77. SHADOWBROKER     — Data collection (namesake)
78. STROLLINGCAT     — Slow exfiltration
79. TORNADOALLEY     — Bulk transfer
80. VOLUMESHADOW     — Shadow copy manipulation
81. WHIPSNADE        — Encrypted tunnel
82. YELLOWLIGHT      — Traffic masking

## CATEGORY H: Cryptographic/Encryption Tools — 8 Tools
83. BANANAGLEE       — Encryption bypass
84. GROK             — Encrypted keylogging
85. IRATEMONK        — Disk encryption bypass
86. SURLYSPAWN       — Keystroke encryption
87. TURBINE          — Traffic decryption
88. TURMOIL          — VPN decryption
89. XKEYSCORE_MODULE — Traffic analysis
90. PRISM_MODULE     — Data interception

## CATEGORY I: SWIFT/Financial Exploits — 5 Tools
91. JEEPFLEA_MARKET  — SWIFT network access
92. JEEPFLEA         — Banking system exploit
93. ORANGUTAN        — Financial data collection
94. COFFEEPRESS      — Transaction manipulation
95. BANANAGLEE       — Banking firewall bypass

## CATEGORY J: Mobile/IoT Exploits — 10 Tools
96. DROPOUTJEEP      — iOS backdoor
97. GOPHERSET        — GSM base station exploit
98. MONKEYCALENDAR   — SMS tracking
99. CYBERHAWK        — Android implant
100. TUNINGFORK      — Baseband exploit
101. NOPEN            — Mobile backdoor
102. SOMBERKNAVE     — IoT proxy
103. TOUCHDOWN        — Mobile data transfer
104. WISTFULTOLL     — Mobile enumeration
105. ZESTYLEAK       — Mobile data harvesting

## CATEGORY K: Supply Chain & Firmware — 10 Tools
106. IRATEMONK        — HDD firmware implant
107. DEITYBOUNCE      — Dell server BIOS
108. GRAYFISH         — Complex firmware platform
109. EQUATIONLASER    — Early firmware tool
110. GROK             — Embedded device keylogger
111. SURLYSPAWN       — Hardware keystroke capture
112. SWAP             — Firmware manipulation
113. TRINITY          — Multi-vendor firmware
114. STRAITACID       — Supply chain injection
115. COFFEEPRESS      — Manufacturing implant

# ================================================
# INTEGRATION NOTE:
# All 115 tools are documented as theoretical components.
# No actual exploit code, binaries, or functional payloads are included.
# This is a conceptual framework for educational/research purposes only.
# ================================================
