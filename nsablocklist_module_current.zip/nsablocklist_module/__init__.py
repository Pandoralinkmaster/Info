"""
NSABlocklist Module v1.0
Absolute Surveillance Defense Matrix

A comprehensive Python module for blocking and analyzing
NSA/GCHQ/CIA/FBI surveillance infrastructure.

Based on CHEF-KOCH's NSABlocklist project (Wikileaks 2007)
"""

__version__ = "1.0.0"
__author__ = "JAYJAY / NSABlocklist"
__license__ = "ISC"

from .core.blocker import NSABlocker
from .core.analyzer import ThreatAnalyzer
from .core.monitor import SurveillanceMonitor
from .utils.hosts_manager import HostsManager
from .utils.domain_parser import DomainParser

__all__ = [
    "NSABlocker",
    "ThreatAnalyzer", 
    "SurveillanceMonitor",
    "HostsManager",
    "DomainParser",
]
