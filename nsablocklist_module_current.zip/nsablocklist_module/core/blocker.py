"""
NSABlocker Core Module
======================
Main blocking engine for surveillance infrastructure.
"""

import os
import re
import ipaddress
from typing import List, Set, Dict, Optional, Tuple
from pathlib import Path
from dataclasses import dataclass, field
from datetime import datetime


@dataclass
class BlockRule:
    """A single blocking rule."""
    target: str  # IP or domain
    target_type: str  # 'ip', 'domain', 'range', 'regex'
    source: str  # Which list this came from
    category: str  # e.g., 'nsa', 'gchq', 'tracker', 'canvas'
    description: str = ""
    added: datetime = field(default_factory=datetime.now)
    hits: int = 0


@dataclass  
class BlockStats:
    """Statistics for blocking operations."""
    total_rules: int = 0
    active_rules: int = 0
    blocked_attempts: int = 0
    categories: Dict[str, int] = field(default_factory=dict)
    last_updated: Optional[datetime] = None


class NSABlocker:
    """
    Main surveillance blocking engine.

    Manages blocklists, applies rules, and tracks statistics.
    """

    DEFAULT_BLOCK_IP = "0.0.0.0"
    LOCALHOST_IP = "127.0.0.1"

    CATEGORIES = {
        'nsa': 'NSA surveillance infrastructure',
        'gchq': 'GCHQ surveillance infrastructure', 
        'cia': 'CIA operations infrastructure',
        'fbi': 'FBI surveillance tools',
        'tracker': 'Cross-site trackers',
        'canvas': 'Canvas fingerprinting',
        'webrtc': 'WebRTC leak sources',
        'audio': 'Audio fingerprinting',
        'malware': 'Known malware domains',
        'phishing': 'Phishing domains',
        'gov': 'Government surveillance pages',
    }

    def __init__(self, data_dir: Optional[str] = None):
        self.rules: List[BlockRule] = []
        self.blocked_domains: Set[str] = set()
        self.blocked_ips: Set[str] = set()
        self.blocked_ranges: List[ipaddress.ip_network] = []
        self.stats = BlockStats()

        self.data_dir = data_dir or self._default_data_dir()
        self._load_builtin_rules()

    def _default_data_dir(self) -> str:
        """Get default data directory."""
        module_dir = Path(__file__).parent.parent
        return str(module_dir / "data")

    def _load_builtin_rules(self):
        """Load built-in blocklist rules from data files."""
        data_path = Path(self.data_dir)
        if not data_path.exists():
            return

        blocklist_files = {
            'nsa': ['hosts_nsa.txt', 'super_ranges.txt'],
            'tracker': ['trackers.txt'],
            'canvas': ['canvasfingerprintingpages.txt'],
            'webrtc': ['webrtctracking.txt'],
            'audio': ['audiofingerprintingpages.txt'],
            'gov': ['hosts_gov.txt'],
        }

        for category, files in blocklist_files.items():
            for fname in files:
                fpath = data_path / fname
                if fpath.exists():
                    self._load_file(fpath, category)

    def _load_file(self, filepath: Path, category: str):
        """Load rules from a single file."""
        with open(filepath, 'r', encoding='utf-8') as f:
            for line_num, line in enumerate(f, 1):
                line = line.strip()
                if not line or line.startswith('#'):
                    continue

                parts = line.split()
                if len(parts) >= 2:
                    ip = parts[0]
                    domain = parts[1]

                    if ip in (self.DEFAULT_BLOCK_IP, self.LOCALHOST_IP):
                        self.add_domain(domain, category, str(filepath))
                    else:
                        try:
                            ipaddress.ip_address(ip)
                            self.add_ip(ip, category, str(filepath))
                        except ValueError:
                            pass

    def add_domain(self, domain: str, category: str = 'custom', 
                   source: str = 'manual') -> bool:
        """Add a domain to the blocklist."""
        domain = domain.lower().strip()
        if not domain or domain in self.blocked_domains:
            return False

        self.blocked_domains.add(domain)
        self.rules.append(BlockRule(
            target=domain,
            target_type='domain',
            source=source,
            category=category,
            description=f"Blocked {category} domain"
        ))
        self.stats.total_rules += 1
        self.stats.active_rules += 1
        self.stats.categories[category] = self.stats.categories.get(category, 0) + 1
        return True

    def add_ip(self, ip: str, category: str = 'custom',
               source: str = 'manual') -> bool:
        """Add an IP address to the blocklist."""
        try:
            ip_obj = ipaddress.ip_address(ip)
            ip_str = str(ip_obj)
            if ip_str in self.blocked_ips:
                return False

            self.blocked_ips.add(ip_str)
            self.rules.append(BlockRule(
                target=ip_str,
                target_type='ip',
                source=source,
                category=category
            ))
            self.stats.total_rules += 1
            self.stats.active_rules += 1
            return True
        except ValueError:
            return False

    def add_range(self, cidr: str, category: str = 'custom',
                  source: str = 'manual') -> bool:
        """Add a CIDR range to the blocklist."""
        try:
            network = ipaddress.ip_network(cidr, strict=False)
            self.blocked_ranges.append(network)
            self.rules.append(BlockRule(
                target=cidr,
                target_type='range',
                source=source,
                category=category
            ))
            self.stats.total_rules += 1
            return True
        except ValueError:
            return False

    def is_blocked(self, target: str) -> Tuple[bool, Optional[str]]:
        """Check if a domain or IP is blocked. Returns (blocked, category)."""
        target = target.lower().strip()

        # Check exact domain match
        if target in self.blocked_domains:
            for rule in self.rules:
                if rule.target == target and rule.target_type == 'domain':
                    rule.hits += 1
                    self.stats.blocked_attempts += 1
                    return True, rule.category

        # Check subdomain match
        parts = target.split('.')
        for i in range(len(parts)):
            parent = '.'.join(parts[i:])
            if parent in self.blocked_domains:
                for rule in self.rules:
                    if rule.target == parent and rule.target_type == 'domain':
                        rule.hits += 1
                        self.stats.blocked_attempts += 1
                        return True, rule.category

        # Check IP match
        try:
            ip_obj = ipaddress.ip_address(target)
            ip_str = str(ip_obj)
            if ip_str in self.blocked_ips:
                for rule in self.rules:
                    if rule.target == ip_str and rule.target_type == 'ip':
                        rule.hits += 1
                        self.stats.blocked_attempts += 1
                        return True, rule.category

            # Check range match
            for network in self.blocked_ranges:
                if ip_obj in network:
                    for rule in self.rules:
                        if rule.target == str(network) and rule.target_type == 'range':
                            rule.hits += 1
                            self.stats.blocked_attempts += 1
                            return True, rule.category
        except ValueError:
            pass

        return False, None

    def generate_hosts_content(self, block_ip: str = None) -> str:
        """Generate hosts file content from current rules."""
        block_ip = block_ip or self.DEFAULT_BLOCK_IP
        lines = [
            "# NSABlocklist - Absolute Surveillance Defense Matrix",
            f"# Generated: {datetime.now().isoformat()}",
            f"# Total Rules: {self.stats.total_rules}",
            f"# Categories: {dict(self.stats.categories)}",
            "",
            "127.0.0.1 localhost",
            "::1 localhost",
            "",
            "# === NSABlocklist Begins ===",
            "",
        ]

        # Group by category
        by_category: Dict[str, List[str]] = {}
        for rule in self.rules:
            if rule.target_type == 'domain':
                cat = rule.category
                if cat not in by_category:
                    by_category[cat] = []
                by_category[cat].append(rule.target)

        for category in sorted(by_category.keys()):
            lines.append(f"# --- {category.upper()} ---")
            for domain in sorted(by_category[category]):
                lines.append(f"{block_ip} {domain}")
            lines.append("")

        lines.append("# === NSABlocklist Ends ===")
        return "\n".join(lines)

    def get_stats(self) -> Dict:
        """Get current blocking statistics."""
        return {
            'total_rules': self.stats.total_rules,
            'active_rules': self.stats.active_rules,
            'blocked_domains': len(self.blocked_domains),
            'blocked_ips': len(self.blocked_ips),
            'blocked_ranges': len(self.blocked_ranges),
            'blocked_attempts': self.stats.blocked_attempts,
            'categories': dict(self.stats.categories),
            'top_hits': sorted(
                [(r.target, r.hits) for r in self.rules if r.hits > 0],
                key=lambda x: x[1],
                reverse=True
            )[:10]
        }

    def export_rules(self, filepath: str, format: str = 'hosts'):
        """Export rules to file."""
        if format == 'hosts':
            content = self.generate_hosts_content()
        elif format == 'json':
            import json
            content = json.dumps(self.get_stats(), indent=2)
        elif format == 'csv':
            lines = ['target,type,category,source,hits']
            for rule in self.rules:
                lines.append(f'"{rule.target}",{rule.target_type},{rule.category},{rule.source},{rule.hits}')
            content = "\n".join(lines)
        else:
            raise ValueError(f"Unknown format: {format}")

        with open(filepath, 'w', encoding='utf-8') as f:
            f.write(content)

    def __len__(self) -> int:
        return self.stats.total_rules

    def __contains__(self, target: str) -> bool:
        blocked, _ = self.is_blocked(target)
        return blocked
