"""NSABlocklist Module - core"""
