"""
Domain Parser Utility
=====================
Parses and validates domains, IPs, and blocklist entries.
"""

import re
import ipaddress
from typing import List, Tuple, Optional, Dict
from dataclasses import dataclass
from enum import Enum


class EntryType(Enum):
    """Types of blocklist entries."""
    IPV4 = "ipv4"
    IPV6 = "ipv6"
    DOMAIN = "domain"
    WILDCARD = "wildcard"
    COMMENT = "comment"
    BLANK = "blank"
    INVALID = "invalid"


@dataclass
class ParsedEntry:
    """Represents a parsed blocklist entry."""
    raw_line: str
    entry_type: EntryType
    ip: Optional[str] = None
    domain: Optional[str] = None
    comment: Optional[str] = None
    line_number: int = 0

    @property
    def is_valid(self) -> bool:
        """Check if entry is a valid blockable item."""
        return self.entry_type in (EntryType.IPV4, EntryType.IPV6, 
                                   EntryType.DOMAIN, EntryType.WILDCARD)


class DomainParser:
    """
    Parser for DNS blocklist entries (hosts file format).

    Supports standard hosts file format:
        0.0.0.0 domain.com # comment
        127.0.0.1 localhost
        ::1 localhost
    """

    def __init__(self):
        # Fixed: Use raw string for regex pattern
        self.ip_pattern = re.compile(
            r'^(\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}|0\.0\.0\.0|127\.0\.0\.1)$'
        )
        self.ipv6_pattern = re.compile(
            r'^([0-9a-fA-F:]+)$'
        )
        self.domain_pattern = re.compile(
            r'^([a-zA-Z0-9]([a-zA-Z0-9\-]{0,61}[a-zA-Z0-9])?\.)*'
            r'[a-zA-Z0-9]([a-zA-Z0-9\-]{0,61}[a-zA-Z0-9])?$'
        )
        self.wildcard_pattern = re.compile(
            r'^(\*\.)?([a-zA-Z0-9]([a-zA-Z0-9\-]{0,61}[a-zA-Z0-9])?\.)*'
            r'[a-zA-Z0-9]([a-zA-Z0-9\-]{0,61}[a-zA-Z0-9])?$'
        )

    def parse_line(self, line: str, line_number: int = 0) -> ParsedEntry:
        """
        Parse a single line from a hosts file.

        Args:
            line: Raw line from hosts file
            line_number: Line number for error reporting

        Returns:
            ParsedEntry with type and extracted data
        """
        raw = line.strip()

        # Blank line
        if not raw:
            return ParsedEntry(raw, EntryType.BLANK, line_number=line_number)

        # Comment line
        if raw.startswith('#') or raw.startswith(';'):
            return ParsedEntry(
                raw, EntryType.COMMENT, 
                comment=raw[1:].strip(),
                line_number=line_number
            )

        # Extract inline comment
        comment = None
        if '#' in raw:
            parts = raw.split('#', 1)
            raw = parts[0].strip()
            comment = parts[1].strip()

        # Split into parts
        parts = raw.split()

        if len(parts) < 2:
            return ParsedEntry(
                line.strip(), EntryType.INVALID,
                comment=comment, line_number=line_number
            )

        ip = parts[0]
        domain = parts[1]

        # Validate IP
        ip_type = self._classify_ip(ip)

        # Validate domain
        domain_type = self._classify_domain(domain)

        if ip_type == EntryType.INVALID or domain_type == EntryType.INVALID:
            return ParsedEntry(
                line.strip(), EntryType.INVALID,
                ip=ip, domain=domain,
                comment=comment, line_number=line_number
            )

        return ParsedEntry(
            line.strip(), ip_type,
            ip=ip, domain=domain,
            comment=comment, line_number=line_number
        )

    def _classify_ip(self, ip: str) -> EntryType:
        """Classify an IP address string."""
        if self.ip_pattern.match(ip):
            try:
                ipaddress.IPv4Address(ip)
                return EntryType.IPV4
            except ValueError:
                return EntryType.INVALID
        if self.ipv6_pattern.match(ip):
            try:
                ipaddress.IPv6Address(ip)
                return EntryType.IPV6
            except ValueError:
                pass
        return EntryType.INVALID

    def _classify_domain(self, domain: str) -> EntryType:
        """Classify a domain string."""
        if domain.startswith('*.'):
            if self.wildcard_pattern.match(domain):
                return EntryType.WILDCARD
            return EntryType.INVALID
        if self.domain_pattern.match(domain):
            return EntryType.DOMAIN
        return EntryType.INVALID

    def parse_file(self, content: str) -> List[ParsedEntry]:
        """
        Parse entire hosts file content.

        Args:
            content: Full hosts file content

        Returns:
            List of ParsedEntry objects
        """
        entries = []
        for i, line in enumerate(content.split('\n'), 1):
            entries.append(self.parse_line(line, i))
        return entries

    def extract_domains(self, entries: List[ParsedEntry]) -> List[str]:
        """Extract valid domains from parsed entries."""
        return [
            e.domain for e in entries 
            if e.is_valid and e.domain
        ]

    def extract_ips(self, entries: List[ParsedEntry]) -> List[str]:
        """Extract valid IPs from parsed entries."""
        return [
            e.ip for e in entries
            if e.is_valid and e.ip
        ]

    def get_statistics(self, entries: List[ParsedEntry]) -> Dict:
        """Generate statistics about parsed entries."""
        stats = {
            'total_lines': len(entries),
            'valid_entries': 0,
            'invalid_entries': 0,
            'comments': 0,
            'blank_lines': 0,
            'by_type': {}
        }

        for e in entries:
            type_name = e.entry_type.value
            stats['by_type'][type_name] = stats['by_type'].get(type_name, 0) + 1

            if e.is_valid:
                stats['valid_entries'] += 1
            elif e.entry_type == EntryType.INVALID:
                stats['invalid_entries'] += 1
            elif e.entry_type == EntryType.COMMENT:
                stats['comments'] += 1
            elif e.entry_type == EntryType.BLANK:
                stats['blank_lines'] += 1

        return stats

    def filter_by_tld(self, domains: List[str], tld: str) -> List[str]:
        """Filter domains by top-level domain."""
        tld_lower = tld.lower()
        return [d for d in domains if d.lower().endswith(f'.{tld_lower}')]

    def filter_government(self, domains: List[str]) -> List[str]:
        """Filter government domains."""
        gov_patterns = ['.gov', '.gov.', '.mil', '.gov.au', '.gov.uk', 
                         '.gov.cn', '.go.jp', '.gob.mx']
        return [
            d for d in domains
            if any(d.lower().endswith(p) for p in gov_patterns)
        ]

    def detect_nameservers(self, domains: List[str]) -> List[str]:
        """Detect nameserver domains."""
        ns_patterns = ['ns.', 'dns.', 'ns1.', 'ns2.', 'dns1.', 'dns2.']
        return [
            d for d in domains
            if any(d.lower().startswith(p) for p in ns_patterns)
        ]


if __name__ == '__main__':
    # Demo
    parser = DomainParser()
    test_lines = [
        '# NSABlocklist test',
        '0.0.0.0 nsa.gov',
        '127.0.0.1 localhost',
        '0.0.0.0 tracker.example.com # tracking',
        'invalid line',
        '',
        '::1 localhost',
    ]

    entries = [parser.parse_line(line, i) for i, line in enumerate(test_lines, 1)]
    for e in entries:
        print(f"Line {e.line_number}: {e.entry_type.value} | IP={e.ip} | Domain={e.domain}")

    stats = parser.get_statistics(entries)
    print(f"\nStatistics: {json.dumps(stats, indent=2)}")
