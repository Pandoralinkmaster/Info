"""
Hosts File Manager
Handles reading, writing, and merging hosts files.
"""

import os
import shutil
from datetime import datetime
from typing import List, Tuple, Optional
from .domain_parser import DomainParser


class HostsManager:
    """Manage system hosts file operations."""

    HOSTS_PATHS = {
        'linux': '/etc/hosts',
        'darwin': '/etc/hosts',
        'windows': r'C:\Windows\System32\drivers\etc\hosts',
    }

    def __init__(self, custom_path: Optional[str] = None):
        self.parser = DomainParser()
        self.path = custom_path or self._detect_hosts_path()
        self.backup_dir = os.path.expanduser('~/.nsablocklist/backups')

    def _detect_hosts_path(self) -> str:
        """Auto-detect hosts file path based on OS."""
        import platform
        system = platform.system().lower()
        return self.HOSTS_PATHS.get(system, '/etc/hosts')

    def read_hosts(self) -> str:
        """Read current hosts file content."""
        try:
            with open(self.path, 'r', encoding='utf-8') as f:
                return f.read()
        except FileNotFoundError:
            return ""

    def parse_current(self) -> List[Tuple[str, str]]:
        """Parse current hosts file entries."""
        content = self.read_hosts()
        return self.parser.parse_file(content)

    def backup(self) -> str:
        """Create timestamped backup of hosts file."""
        os.makedirs(self.backup_dir, exist_ok=True)
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        backup_path = os.path.join(self.backup_dir, f'hosts_backup_{timestamp}')

        if os.path.exists(self.path):
            shutil.copy2(self.path, backup_path)
        return backup_path

    def restore(self, backup_path: str) -> bool:
        """Restore hosts from backup."""
        if os.path.exists(backup_path):
            shutil.copy2(backup_path, self.path)
            return True
        return False

    def merge_blocklist(self, blocklist_content: str, 
                        marker: str = '# === NSABLOCKLIST START ===',
                        end_marker: str = '# === NSABLOCKLIST END ===') -> str:
        """
        Merge blocklist into hosts file with markers.
        Returns the merged content (does not write).
        """
        current = self.read_hosts()

        # Remove existing blocklist section
        if marker in current:
            before = current.split(marker)[0].rstrip()
            after = current.split(end_marker)[-1].lstrip() if end_marker in current else ''
            current = before + '\n' + after if after else before

        # Add new blocklist section
        merged = current.rstrip() + '\n\n' + marker + '\n'
        merged += f'# Generated: {datetime.now().isoformat()}\n'
        merged += blocklist_content.strip() + '\n'
        merged += end_marker + '\n'

        return merged

    def write_hosts(self, content: str, create_backup: bool = True) -> bool:
        """Write content to hosts file."""
        try:
            if create_backup:
                self.backup()
            with open(self.path, 'w', encoding='utf-8') as f:
                f.write(content)
            return True
        except PermissionError:
            print(f"Permission denied: {self.path}")
            print("Run with sudo/administrator privileges.")
            return False

    def apply_blocklist(self, blocklist_path: str) -> bool:
        """Apply a blocklist file to system hosts."""
        with open(blocklist_path, 'r', encoding='utf-8') as f:
            content = f.read()

        merged = self.merge_blocklist(content)
        return self.write_hosts(merged)

    def remove_blocklist(self) -> bool:
        """Remove NSABlocklist section from hosts."""
        current = self.read_hosts()
        marker = '# === NSABLOCKLIST START ==='
        end_marker = '# === NSABLOCKLIST END ==='

        if marker not in current:
            return True  # Nothing to remove

        before = current.split(marker)[0].rstrip()
        after = current.split(end_marker)[-1].lstrip() if end_marker in current else ''
        cleaned = before + '\n\n' + after if after else before

        return self.write_hosts(cleaned)

    def get_stats(self) -> dict:
        """Get statistics about current hosts file."""
        entries = self.parse_current()
        return self.parser.analyze_entries(entries)
