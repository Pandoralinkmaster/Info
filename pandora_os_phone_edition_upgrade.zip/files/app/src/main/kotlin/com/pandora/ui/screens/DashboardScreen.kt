package com.pandora.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.pandora.core.ConfigManager
import com.pandora.visibility.HostVisibilityGate
import org.koin.compose.koinInject

@Composable
fun DashboardScreen(
    config: ConfigManager,
    onNavigateAdmin: () -> Unit,
    onNavigateJayJay: () -> Unit,
    onNavigateMesh: () -> Unit,
    onNavigateWallet: () -> Unit,
    onNavigateShop: () -> Unit,
    onNavigateSystem: () -> Unit = {},
    onNavigateStorage: () -> Unit = {},
    onNavigateBackup: () -> Unit = {},
    onNavigatePermissions: () -> Unit = {},
    onNavigateSecurity: () -> Unit = {},
    onNavigateNetwork: () -> Unit = {},
    onNavigateApps: () -> Unit = {},
    onNavigateSettings: () -> Unit = {},
    onNavigateLogs: () -> Unit = {},
    onNavigateCompute: () -> Unit = {},
    onNavigateScan: () -> Unit = {},
    onNavigateBuildings: () -> Unit = {},
    onNavigateOnion: () -> Unit = {},
    onNavigateWireGuard: () -> Unit = {},
) {
    val gate: HostVisibilityGate = koinInject()
    val gateState by gate.state.collectAsState()

    val wallpaperTop = Color(0xFF1C1237)
    val wallpaperMid = Color(0xFF070711)
    val wallpaperBottom = Color(0xFF101827)
    val glass = Color.White.copy(alpha = 0.105f)
    val glassStrong = Color.White.copy(alpha = 0.155f)
    val stroke = Color.White.copy(alpha = 0.18f)
    val accent = Color(0xFFB968FF)
    val cyan = Color(0xFF5AD7FF)
    val green = Color(0xFF63F6A7)
    val gold = Color(0xFFFFD76A)
    val red = Color(0xFFFF5C7A)

    Surface(Modifier.fillMaxSize(), color = wallpaperMid) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Brush.verticalGradient(listOf(wallpaperTop, wallpaperMid, wallpaperBottom)))
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
                    .padding(horizontal = 16.dp, vertical = 14.dp)
            ) {
                PhoneStatusBar(
                    title = "Pandora OS",
                    subtitle = "Phone Edition · Android Base",
                    status = if (gateState.isOpen) "Host aktiv" else "Host gesperrt",
                    statusColor = if (gateState.isOpen) green else red
                )

                Spacer(Modifier.height(14.dp))

                PhoneHeroCard(
                    glass = glassStrong,
                    stroke = stroke,
                    accent = accent,
                    gateOpen = gateState.isOpen,
                    appMode = config.appMode.name,
                    setupStatus = config.setupStatus.name,
                    onUnlock = { gate.unlock("phone-os-manual") }
                )

                Spacer(Modifier.height(18.dp))

                Text(
                    "System",
                    color = Color.White,
                    fontSize = 22.sp,
                    fontWeight = FontWeight.Black,
                    modifier = Modifier.padding(start = 4.dp, bottom = 10.dp)
                )

                PhoneGridRow(
                    PhoneApp("⌂", "Home", "OS Übersicht", accent, onNavigateSystem),
                    PhoneApp("▣", "Storage", "S24 DB · M.2 Backup", cyan, onNavigateStorage),
                    PhoneApp("⇪", "Backup", "Sichern", green, onNavigateBackup),
                    PhoneApp("◎", "Rechte", "Freigaben", gold, onNavigatePermissions),
                    glass, stroke
                )

                PhoneGridRow(
                    PhoneApp("☰", "Logs", "Status", Color(0xFFB388FF), onNavigateLogs),
                    PhoneApp("⚙", "Setup", "Einstellungen", Color(0xFF8FC7FF), onNavigateSettings),
                    PhoneApp("⚑", "Admin", "Geräte", Color(0xFFFF9C4A), onNavigateAdmin),
                    PhoneApp("▰", "Apps", "Module", Color(0xFFFF7AB6), onNavigateApps),
                    glass, stroke
                )

                Spacer(Modifier.height(18.dp))

                Text(
                    "Pandora",
                    color = Color.White,
                    fontSize = 22.sp,
                    fontWeight = FontWeight.Black,
                    modifier = Modifier.padding(start = 4.dp, bottom = 10.dp)
                )

                PhoneGridRow(
                    PhoneApp("✦", "JayJay", "KI-Konsole", accent, onNavigateJayJay),
                    PhoneApp("⌁", "Mesh", "Nodes", cyan, onNavigateMesh),
                    PhoneApp("◌", "Netz", "API · Host", Color(0xFF40C4FF), onNavigateNetwork),
                    PhoneApp("₿", "Wallet", "Hardware", Color(0xFFFFD700), onNavigateWallet),
                    glass, stroke
                )

                PhoneGridRow(
                    PhoneApp("▤", "Shop", "Checkout", Color(0xFF4FE39A), onNavigateShop),
                    PhoneApp("⌕", "Scan", "BLE · RSSI", Color(0xFF27D3E6), onNavigateScan),
                    PhoneApp("▧", "Gebäude", "3D", Color(0xFF9D7BFF), onNavigateBuildings),
                    PhoneApp("◈", "Compute", "Knoten", Color(0xFFFF667A), onNavigateCompute),
                    glass, stroke
                )

                PhoneGridRow(
                    PhoneApp("◐", "Onion", "Relay", Color(0xFF6AF0AF), onNavigateOnion),
                    PhoneApp("◇", "WireGuard", "VPN", Color(0xFF73C6FF), onNavigateWireGuard),
                    PhoneApp("🛡", "Security", "Schutz", Color(0xFFFF6A6A), onNavigateSecurity),
                    PhoneApp("⋯", "Mehr", "Module", Color(0xFFCAC7FF), onNavigateApps),
                    glass, stroke
                )

                Spacer(Modifier.height(22.dp))

                PhoneInfoWidget(
                    title = "Phone-only Design",
                    body = "Pandora OS ist für Handys optimiert: Hochformat, Daumen-Navigation, Dock, App-Grid, runde Glas-Karten und interne Datenbank auf dem Galaxy S24 Ultra.",
                    glass = glass,
                    stroke = stroke
                )

                Spacer(Modifier.height(92.dp))
            }

            PhoneDock(
                glass = Color.White.copy(alpha = 0.18f),
                stroke = Color.White.copy(alpha = 0.22f),
                modifier = Modifier.align(Alignment.BottomCenter),
                items = listOf(
                    PhoneApp("⌂", "Home", "Übersicht", accent, onNavigateSystem),
                    PhoneApp("✦", "JayJay", "KI", accent, onNavigateJayJay),
                    PhoneApp("▣", "Storage", "Daten", cyan, onNavigateStorage),
                    PhoneApp("⚙", "Setup", "System", Color(0xFF8FC7FF), onNavigateSettings)
                )
            )
        }
    }
}

@Composable
private fun PhoneStatusBar(title: String, subtitle: String, status: String, statusColor: Color) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title, color = Color.White, fontSize = 30.sp, fontWeight = FontWeight.Black)
            Text(subtitle, color = Color.White.copy(alpha = 0.66f), fontSize = 12.sp)
        }
        Surface(
            shape = RoundedCornerShape(50),
            color = statusColor.copy(alpha = 0.16f),
            border = BorderStroke(1.dp, statusColor.copy(alpha = 0.72f))
        ) {
            Text(status, color = statusColor, fontSize = 11.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 11.dp, vertical = 7.dp))
        }
    }
}

@Composable
private fun PhoneHeroCard(
    glass: Color,
    stroke: Color,
    accent: Color,
    gateOpen: Boolean,
    appMode: String,
    setupStatus: String,
    onUnlock: () -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = glass),
        border = BorderStroke(1.dp, stroke),
        shape = RoundedCornerShape(32.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(Modifier.padding(18.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    Modifier
                        .size(58.dp)
                        .clip(RoundedCornerShape(18.dp))
                        .background(Brush.linearGradient(listOf(Color(0xFF7E2CFF), Color(0xFFFF53C0)))),
                    contentAlignment = Alignment.Center
                ) {
                    Text("P", color = Color.White, fontSize = 30.sp, fontWeight = FontWeight.Black)
                }
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text("Pandora OS", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Black)
                    Text("Android-basiertes Handy-Betriebssystem", color = Color.White.copy(alpha = 0.68f), fontSize = 12.sp)
                }
            }

            Spacer(Modifier.height(16.dp))

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                MiniPill("Phone", Color.White.copy(alpha = 0.82f))
                MiniPill("DB: S24", Color.White.copy(alpha = 0.82f))
                MiniPill("M.2: Backup", Color.White.copy(alpha = 0.82f))
            }

            Spacer(Modifier.height(10.dp))

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                MiniPill("Modus $appMode", accent)
                MiniPill("Setup $setupStatus", accent)
            }

            if (!gateOpen) {
                Spacer(Modifier.height(14.dp))
                Button(
                    onClick = onUnlock,
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = accent)
                ) {
                    Text("Pandora Host entsperren", fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

private data class PhoneApp(
    val icon: String,
    val title: String,
    val subtitle: String,
    val color: Color,
    val onClick: () -> Unit
)

@Composable
private fun PhoneGridRow(
    a: PhoneApp,
    b: PhoneApp,
    c: PhoneApp,
    d: PhoneApp,
    glass: Color,
    stroke: Color
) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        PhoneAppIcon(a, glass, stroke, Modifier.weight(1f))
        PhoneAppIcon(b, glass, stroke, Modifier.weight(1f))
        PhoneAppIcon(c, glass, stroke, Modifier.weight(1f))
        PhoneAppIcon(d, glass, stroke, Modifier.weight(1f))
    }
    Spacer(Modifier.height(14.dp))
}

@Composable
private fun PhoneAppIcon(app: PhoneApp, glass: Color, stroke: Color, modifier: Modifier = Modifier) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = modifier.clickable { app.onClick() }
    ) {
        Box(
            Modifier
                .size(64.dp)
                .clip(RoundedCornerShape(20.dp))
                .background(Brush.linearGradient(listOf(app.color.copy(alpha = 0.95f), app.color.copy(alpha = 0.52f), glass)))
                .padding(2.dp),
            contentAlignment = Alignment.Center
        ) {
            Surface(
                shape = RoundedCornerShape(18.dp),
                color = Color.Black.copy(alpha = 0.08f),
                border = BorderStroke(1.dp, stroke),
                modifier = Modifier.fillMaxSize()
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Text(app.icon, color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Black)
                }
            }
        }
        Spacer(Modifier.height(6.dp))
        Text(app.title, color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
        Text(app.subtitle, color = Color.White.copy(alpha = 0.54f), fontSize = 9.sp, maxLines = 1)
    }
}

@Composable
private fun PhoneDock(glass: Color, stroke: Color, modifier: Modifier, items: List<PhoneApp>) {
    Column(modifier.padding(horizontal = 16.dp, vertical = 10.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Surface(
            color = glass,
            border = BorderStroke(1.dp, stroke),
            shape = RoundedCornerShape(30.dp),
            tonalElevation = 0.dp,
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                Modifier.padding(horizontal = 14.dp, vertical = 12.dp),
                horizontalArrangement = Arrangement.SpaceAround,
                verticalAlignment = Alignment.CenterVertically
            ) {
                items.forEach { app ->
                    Box(
                        Modifier
                            .size(52.dp)
                            .clip(RoundedCornerShape(17.dp))
                            .background(Brush.linearGradient(listOf(app.color.copy(alpha = 0.92f), app.color.copy(alpha = 0.45f))))
                            .clickable { app.onClick() },
                        contentAlignment = Alignment.Center
                    ) {
                        Text(app.icon, color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Black)
                    }
                }
            }
        }
        Spacer(Modifier.height(8.dp))
        Box(Modifier.width(128.dp).height(5.dp).clip(CircleShape).background(Color.White.copy(alpha = 0.38f)))
    }
}

@Composable
private fun PhoneInfoWidget(title: String, body: String, glass: Color, stroke: Color) {
    Card(
        colors = CardDefaults.cardColors(containerColor = glass),
        border = BorderStroke(1.dp, stroke),
        shape = RoundedCornerShape(28.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(Modifier.padding(18.dp)) {
            Text(title, color = Color.White, fontWeight = FontWeight.Black, fontSize = 16.sp)
            Spacer(Modifier.height(8.dp))
            Text(body, color = Color.White.copy(alpha = 0.74f), fontSize = 12.sp)
        }
    }
}

@Composable
private fun MiniPill(text: String, color: Color) {
    Surface(shape = RoundedCornerShape(50), color = Color.White.copy(alpha = 0.08f), border = BorderStroke(1.dp, Color.White.copy(alpha = 0.12f))) {
        Text(text, color = color, fontSize = 10.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 9.dp, vertical = 5.dp))
    }
}
