Pandora OS Phone Edition Upgrade

Installieren:
cd ~/pandora-android
unzip -o /storage/internal_new/Download/pandora_os_phone_edition_upgrade.zip -d /tmp/pandora_phone
sh /tmp/pandora_phone/install_pandora_phone_os_upgrade.sh
./gradlew assembleDebug --no-daemon --console=plain

Danach APK:
~/pandora-android/app/build/outputs/apk/debug/app-debug.apk

Ziel:
Nur Handys. Android-Basis. iOS-inspirierte Pandora-Oberfläche. Pandora-Funktionen integriert.
