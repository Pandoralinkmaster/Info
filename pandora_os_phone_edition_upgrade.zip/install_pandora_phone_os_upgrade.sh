#!/bin/sh
set -e

PROJECT_DIR="${1:-$PWD}"
SCRIPT_DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)"
cd "$PROJECT_DIR"

if [ ! -f "app/build.gradle" ]; then
  echo "Bitte im Android-Projektordner ausführen, z.B.: cd ~/pandora-android"
  exit 1
fi

echo ">>> Installiere Pandora OS Phone Edition Dateien..."
cp -r "$SCRIPT_DIR/files/"* .

# App als Phone OS markieren
if ! grep -q "Pandora OS Phone Edition" app/src/main/res/values/strings.xml 2>/dev/null; then
  echo "strings.xml wurde ersetzt."
fi

# Phone-only Orientierung
grep -q "android:screenOrientation=\"portrait\"" app/src/main/AndroidManifest.xml || true

# Home-Shell: wenn MainActivity noch keinen HOME-Intent hat, Kategorie ergänzen, wo MAIN/LAUNCHER existiert.
# Das ist bewusst defensiv, damit der Build nicht bricht, falls bereits eine PandoraLauncherActivity existiert.
if ! grep -q "android.intent.category.HOME" app/src/main/AndroidManifest.xml; then
  sed -i '/android.intent.category.LAUNCHER/a\                <category android:name="android.intent.category.HOME" />\n                <category android:name="android.intent.category.DEFAULT" />' app/src/main/AndroidManifest.xml
fi

# Telefon-/Touch-Fokus. required=false für optionale Features, damit Build nicht blockiert.
grep -q 'android.hardware.touchscreen' app/src/main/AndroidManifest.xml || \
  sed -i '/<manifest/a\    <uses-feature android:name="android.hardware.touchscreen" android:required="true" />' app/src/main/AndroidManifest.xml

# Tablet/TV nicht aktiv unterstützen: Portrait bleibt gesetzt; UI ist auf normale Handy-Breite gebaut.
grep -q 'supports-screens' app/src/main/AndroidManifest.xml || \
  sed -i '/<application/i\    <supports-screens android:smallScreens="false" android:normalScreens="true" android:largeScreens="false" android:xlargeScreens="false" android:anyDensity="true" />' app/src/main/AndroidManifest.xml

# Alte Build-Fixes sicher beibehalten
grep -q 'android.suppressUnsupportedCompileSdk=36' gradle.properties || echo 'android.suppressUnsupportedCompileSdk=36' >> gradle.properties
grep -q 'org.gradle.workers.max=1' gradle.properties || echo 'org.gradle.workers.max=1' >> gradle.properties
grep -q 'android.aapt2FromMavenOverride=/usr/bin/aapt2' gradle.properties || echo 'android.aapt2FromMavenOverride=/usr/bin/aapt2' >> gradle.properties

echo ">>> Pandora OS Phone Edition installiert."
echo "Jetzt bauen:"
echo "./gradlew assembleDebug --no-daemon --console=plain"
