package com.pandora.os

import android.app.ActivityManager
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import android.net.TrafficStats
import android.os.BatteryManager
import android.os.Build
import android.util.Log
import kotlinx.coroutines.*
import kotlinx.serialization.Serializable
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json

/**
 * Pandora OS – Systemmanager
 *
 * Zentrales Modul für alle OS-Level-Funktionen:
 *   - Ressourcenmessung (CPU, RAM, Batterie, Netzwerk)
 *   - Sponsor-Beitrags-Tracking (was das Gerät beiträgt)
 *   - Device Admin Operationen (Sperren, Wipe)
 *   - Accessibility-Integration
 *   - Sicherheitsmonitoring (welche Apps laufen)
 *
 * Alle Funktionen die Admin-Rechte erfordern sind
 * durch Finn's Gesetze geschützt: nur CEO kann
 * destruktive Aktionen (z.B. Remote-Wipe) auslösen.
 */
@Serializable
data class DeviceContribution(
    val deviceId: String,
    val model: String,
    val cpuCores: Int,
    val totalRamMb: Int,
    val availableRamMb: Int,
    val storageContributedMb: Int,
    val batteryPercent: Int,
    val isCharging: Boolean,
    val networkBytesSent: Long,
    val networkBytesReceived: Long,
    val uptimeMs: Long,
    val isAdminActive: Boolean,
    val isLauncherActive: Boolean,
    val isAccessibilityActive: Boolean,
    val sessionStarted: Long,
)

object PandoraOsManager {

    private const val TAG = "PandoraOS"
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val json  = Json { prettyPrint = false }

    @Volatile private var initialized      = false
    @Volatile private var adminActive      = false
    @Volatile private var accessibilityOn  = false
    @Volatile private var sessionStart     = System.currentTimeMillis()

    // Sicherheitsmonitoring: unbekannte Apps
    private val suspiciousApps = mutableSetOf<String>()

    // ── Initialisierung ──────────────────────────────────────────────────────

    fun initialize(context: Context) {
        if (initialized) return
        initialized = true
        sessionStart = System.currentTimeMillis()
        Log.i(TAG, "⚙ Pandora OS initialisiert")

        // Ressourcen-Monitoring Schleife
        scope.launch {
            while (isActive) {
                try {
                    val contribution = measureContribution(context)
                    Log.d(TAG, "Sponsor-Beitrag: CPU=${contribution.cpuCores}Kerne " +
                        "RAM=${contribution.availableRamMb}MB " +
                        "Bat=${contribution.batteryPercent}% " +
                        "Charging=${contribution.isCharging}")
                    reportContribution(context, contribution)
                } catch (e: Exception) {
                    Log.w(TAG, "Messung fehlgeschlagen: ${e.message}")
                }
                delay(60_000) // jede Minute messen
            }
        }
    }

    // ── Ressourcenmessung ────────────────────────────────────────────────────

    fun measureContribution(context: Context): DeviceContribution {
        val am = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val memInfo = ActivityManager.MemoryInfo().also { am.getMemoryInfo(it) }
        val bm = context.getSystemService(Context.BATTERY_SERVICE) as BatteryManager

        val battery   = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
        val charging  = bm.isCharging
        val totalRam  = (memInfo.totalMem / 1_048_576).toInt()
        val availRam  = (memInfo.availMem / 1_048_576).toInt()
        val runtime   = Runtime.getRuntime()

        val dpm = context.getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
        val adminComp = ComponentName(context, PandoraDeviceAdmin::class.java)

        return DeviceContribution(
            deviceId               = android.provider.Settings.Secure.getString(
                                        context.contentResolver,
                                        android.provider.Settings.Secure.ANDROID_ID) ?: "unknown",
            model                  = "${Build.MANUFACTURER} ${Build.MODEL}",
            cpuCores               = runtime.availableProcessors(),
            totalRamMb             = totalRam,
            availableRamMb         = availRam,
            storageContributedMb   = 2048, // 2GB reserviert (§1 TOS)
            batteryPercent         = battery,
            isCharging             = charging,
            networkBytesSent       = TrafficStats.getTotalTxBytes(),
            networkBytesReceived   = TrafficStats.getTotalRxBytes(),
            uptimeMs               = System.currentTimeMillis() - sessionStart,
            isAdminActive          = dpm.isAdminActive(adminComp),
            isLauncherActive       = false, // wird vom System-Intent ermittelt
            isAccessibilityActive  = accessibilityOn,
            sessionStarted         = sessionStart,
        )
    }

    private fun reportContribution(context: Context, contribution: DeviceContribution) {
        // Lokal zwischenspeichern – wird beim nächsten Netzwerk-Sync übertragen
        val prefs = context.getSharedPreferences("pandora_os", Context.MODE_PRIVATE)
        prefs.edit()
            .putString("last_contribution", json.encodeToString(contribution))
            .putLong("last_report_at", System.currentTimeMillis())
            .apply()
    }

    // ── Device Admin Operationen ─────────────────────────────────────────────

    /**
     * Gerät sofort sperren.
     * Kann von JayJay auf Finn's Befehl ausgeführt werden.
     */
    fun lockDevice(context: Context) {
        try {
            val dpm = context.getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
            dpm.lockNow()
            Log.i(TAG, "Gerät gesperrt – CEO-Befehl")
        } catch (e: Exception) {
            Log.e(TAG, "Sperren fehlgeschlagen: ${e.message}")
        }
    }

    /**
     * Remote-Wipe – AUSSCHLIESSLICH auf Finn's direkten Befehl.
     * Löscht alle Daten auf dem Gerät.
     * Nutzer hat dem in §2 der TOS zugestimmt.
     */
    fun remoteWipe(context: Context, confirmedByCeo: Boolean) {
        if (!confirmedByCeo) {
            Log.e(TAG, "Remote-Wipe verweigert – kein CEO-Befehl")
            return
        }
        try {
            val dpm = context.getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
            Log.w(TAG, "🔴 Remote-Wipe wird ausgeführt – CEO-Bestätigung erhalten")
            dpm.wipeData(DevicePolicyManager.WIPE_EXTERNAL_STORAGE)
        } catch (e: Exception) {
            Log.e(TAG, "Wipe fehlgeschlagen: ${e.message}")
        }
    }

    /**
     * Passwort-Policy setzen (Mindeststärke).
     */
    fun enforcePasswordPolicy(context: Context) {
        try {
            val dpm  = context.getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
            val comp = ComponentName(context, PandoraDeviceAdmin::class.java)
            if (dpm.isAdminActive(comp)) {
                dpm.setPasswordMinimumLength(comp, 8)
                dpm.setPasswordMinimumUpperCase(comp, 1)
                dpm.setPasswordMinimumNumbers(comp, 1)
                Log.i(TAG, "Passwort-Policy gesetzt: min. 8 Zeichen")
            }
        } catch (e: Exception) {
            Log.w(TAG, "Policy fehlgeschlagen: ${e.message}")
        }
    }

    // ── Sicherheitsmonitoring ─────────────────────────────────────────────────

    /**
     * Wird vom Accessibility Service aufgerufen wenn eine fremde App
     * in den Vordergrund kommt.
     */
    fun onForegroundAppChanged(packageName: String) {
        val knownSafe = setOf(
            "com.pandora", "android", "com.android",
            "com.samsung", "com.google", "com.sec"
        )
        val isSafe = knownSafe.any { packageName.startsWith(it) }
        if (!isSafe && packageName !in suspiciousApps) {
            suspiciousApps.add(packageName)
            Log.d(TAG, "Unbekannte App im Vordergrund: $packageName")
        }
    }

    fun getSuspiciousApps(): List<String> = suspiciousApps.toList()

    // ── Status-Callbacks ─────────────────────────────────────────────────────

    fun onAdminEnabled(context: Context) {
        adminActive = true
        enforcePasswordPolicy(context)
        Log.i(TAG, "Admin: aktiv")
    }

    fun onAdminDisabled(context: Context) {
        adminActive = false
        Log.w(TAG, "Admin: deaktiviert")
    }

    fun onPasswordFailed(context: Context) {
        Log.w(TAG, "Falsches Passwort")
        // Nach 10 Fehlversuchen: JayJay informiert Finn
    }

    fun onAccessibilityConnected(context: Context) {
        accessibilityOn = true
        Log.i(TAG, "Accessibility: aktiv")
    }

    fun isAdminActive() = adminActive
    fun isAccessibilityActive() = accessibilityOn
    fun isInitialized() = initialized

    fun getOsStatus(): String = buildString {
        appendLine("⬡ PANDORA OS STATUS")
        appendLine("• Initialisiert: $initialized")
        appendLine("• Device Admin: $adminActive")
        appendLine("• Accessibility: $accessibilityOn")
        appendLine("• Uptime: ${(System.currentTimeMillis() - sessionStart) / 60_000}min")
        appendLine("• Verdächtige Apps: ${suspiciousApps.size}")
    }
}
