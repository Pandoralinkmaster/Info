package com.pandora.jayjay

import android.util.Log
import kotlinx.coroutines.*
import kotlinx.serialization.Serializable
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import com.pandora.database.SsdStorageManager

/**
 * JayJay Attack Defense Engine
 *
 * JayJay lernt selbstständig Angriffsmuster und entwickelt Abwehrstrategien.
 * Je mehr Angriffe sie sieht, desto besser wird sie.
 *
 * Erkannte Angriffskategorien:
 *   - BRUTE_FORCE        Viele Fehlversuche in kurzer Zeit
 *   - REPLAY_ATTACK      Alte Tokens/Pakete werden wiederholt
 *   - MITM               Man-in-the-Middle (unbekannte Zertifikate, ARP-Spoofing)
 *   - PORT_SCAN          Systematisches Port-Scanning
 *   - UNAUTHORIZED_VOICE Jemand versucht Finn's Stimme zu imitieren
 *   - QUANTUM_ATTACK     Angriff auf die Quanten-Key-Infrastruktur
 *   - MESH_INJECTION     Versuch, unbekannte Knoten ins Mesh einzuschleusen
 *   - CEO_IMPERSONATION  Jemand versucht sich als Finn auszugeben
 *   - DOS                Denial-of-Service Angriff auf API-Server
 *
 * Abwehrmaßnahmen:
 *   - Auto-Blocklist (IP, DeviceID, Pattern)
 *   - Automatische Quantum-Key-Rotation
 *   - Netzwerk-Isolation einzelner Knoten
 *   - Benachrichtigung an Finn via JayJay
 *   - Angriffsmuster auf SSD lernen → nächstes Mal früher erkennen
 */
@Serializable
enum class AttackType {
    BRUTE_FORCE,
    REPLAY_ATTACK,
    MITM,
    PORT_SCAN,
    UNAUTHORIZED_VOICE,
    QUANTUM_ATTACK,
    MESH_INJECTION,
    CEO_IMPERSONATION,
    DOS,
    CODE_TAMPERING,      // App-Code wurde verändert (Signatur/Checksumme passt nicht)
    CODE_INJECTION,      // Hooking-Framework (Frida/Xposed) versucht Code einzuschleusen
    APP_REPURPOSING,     // App wurde umgepackt / Package-Name geändert
    DEBUGGER_ATTACHED,   // Debugger/Tracer versucht den Code zu analysieren
    UNKNOWN
}

@Serializable
enum class ThreatLevel { LOW, MEDIUM, HIGH, CRITICAL }

@Serializable
data class AttackEvent(
    val id: String,
    val type: AttackType,
    val level: ThreatLevel,
    val sourceIp: String = "",
    val sourceDeviceId: String = "",
    val description: String,
    val detectedAt: Long = System.currentTimeMillis(),
    val blocked: Boolean = false,
    val learnedPattern: String = "",
)

@Serializable
data class DefenseRule(
    val id: String,
    val pattern: String,          // Erkanntes Muster
    val attackType: AttackType,
    val action: String,           // block_ip | isolate_node | rotate_keys | alert_finn | shutdown
    val confidence: Float,        // 0.0 - 1.0
    val triggeredCount: Int = 0,
    val learnedAt: Long = System.currentTimeMillis(),
    val lastTriggered: Long = 0L,
)

@Serializable
data class DefenseMemory(
    val attackHistory: MutableList<AttackEvent> = mutableListOf(),
    val learnedRules: MutableList<DefenseRule> = mutableListOf(),
    val blockedIps: MutableSet<String> = mutableSetOf(),
    val blockedDevices: MutableSet<String> = mutableSetOf(),
    val totalAttacksBlocked: Int = 0,
    val lastScanAt: Long = 0L,
)

class AttackDefenseEngine(
    private val ssd: SsdStorageManager,
) {
    private val TAG   = "JayJayDefense"
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val json  = Json { ignoreUnknownKeys = true; prettyPrint = true }

    private var memory = DefenseMemory()

    // Echtzeit-Tracker (In-Memory, kein Disk-IO)
    private val recentAttempts = mutableMapOf<String, MutableList<Long>>() // IP → Timestamps
    private val recentVoiceFailures = mutableListOf<Long>()

    companion object {
        const val DEFENSE_FILE      = "jayjay_defense.json"
        const val BRUTE_THRESHOLD   = 5     // 5 Versuche in 60s = Brute Force
        const val DOS_THRESHOLD     = 50    // 50 Requests in 10s = DoS
        const val VOICE_FAIL_LIMIT  = 3     // 3 falsche Stimmen in 5min = CEO-Imitation
    }

    // ── Laden / Speichern ────────────────────────────────────────────────────

    suspend fun loadMemory() = withContext(Dispatchers.IO) {
        val raw = ssd.readFile("jayjay", DEFENSE_FILE)
        if (raw != null) {
            memory = runCatching { json.decodeFromString<DefenseMemory>(raw) }.getOrElse { DefenseMemory() }
            Log.i(TAG, "Verteidigungs-Gedächtnis geladen: ${memory.learnedRules.size} Regeln, ${memory.attackHistory.size} Angriffe")
        }
    }

    private suspend fun saveMemory() = withContext(Dispatchers.IO) {
        // Nur letzte 500 Einträge behalten
        if (memory.attackHistory.size > 500) {
            memory.attackHistory.sortByDescending { it.detectedAt }
            while (memory.attackHistory.size > 500) memory.attackHistory.removeLast()
        }
        ssd.writeFile("jayjay", DEFENSE_FILE, json.encodeToString(memory))
    }

    // ── Angriffserkennung ────────────────────────────────────────────────────

    /**
     * Analysiert jede eingehende Anfrage.
     * Gibt zurück: ob die Anfrage blockiert werden soll.
     */
    fun analyzeRequest(sourceIp: String, path: String, deviceId: String = ""): Boolean {
        // Geblockte IPs sofort ablehnen
        if (sourceIp in memory.blockedIps) {
            Log.w(TAG, "🚫 Blockierte IP: $sourceIp")
            return true
        }
        if (deviceId.isNotBlank() && deviceId in memory.blockedDevices) {
            Log.w(TAG, "🚫 Blockiertes Gerät: $deviceId")
            return true
        }

        // Rate-Limiting
        val now = System.currentTimeMillis()
        val attempts = recentAttempts.getOrPut(sourceIp) { mutableListOf() }
        attempts.add(now)
        attempts.removeAll { now - it > 60_000 } // Letzte 60s

        if (attempts.size >= DOS_THRESHOLD) {
            scope.launch { detectAttack(AttackType.DOS, ThreatLevel.CRITICAL, sourceIp, deviceId, "DoS: ${attempts.size} Anfragen/60s") }
            return true
        }

        return false
    }

    /**
     * Fehlgeschlagener Login-Versuch.
     */
    fun recordAuthFailure(sourceIp: String, deviceId: String = "") {
        val now = System.currentTimeMillis()
        val attempts = recentAttempts.getOrPut("auth:$sourceIp") { mutableListOf() }
        attempts.add(now)
        attempts.removeAll { now - it > 60_000 }

        if (attempts.size >= BRUTE_THRESHOLD) {
            scope.launch {
                detectAttack(AttackType.BRUTE_FORCE, ThreatLevel.HIGH, sourceIp, deviceId,
                    "Brute-Force: ${attempts.size} Fehlversuche in 60s")
                blockIp(sourceIp)
            }
        }
    }

    /**
     * Unbekannte Stimme hat versucht sich als CEO auszugeben.
     */
    fun recordVoiceSpoofAttempt(confidence: Float, deviceId: String) {
        val now = System.currentTimeMillis()
        recentVoiceFailures.add(now)
        recentVoiceFailures.removeAll { now - it > 5 * 60_000 }

        Log.w(TAG, "⚠ Stimm-Imitationsversuch (Konfidenz: ${"%.2f".format(confidence)}) auf Gerät $deviceId")

        if (recentVoiceFailures.size >= VOICE_FAIL_LIMIT) {
            scope.launch {
                detectAttack(AttackType.CEO_IMPERSONATION, ThreatLevel.CRITICAL,
                    "", deviceId, "CEO-Imitation: ${recentVoiceFailures.size}x in 5min")
            }
        }
    }

    /**
     * Unbekannter Mesh-Knoten versucht beizutreten.
     */
    fun recordUnknownMeshNode(nodeId: String, address: String) {
        scope.launch {
            detectAttack(AttackType.MESH_INJECTION, ThreatLevel.HIGH,
                address, nodeId, "Unbekannter Mesh-Knoten: $nodeId@$address")
        }
    }

    /**
     * Replay-Angriff erkannt (alter Token).
     */
    fun recordReplayAttempt(sourceIp: String, tokenAge: Long) {
        scope.launch {
            detectAttack(AttackType.REPLAY_ATTACK, ThreatLevel.MEDIUM,
                sourceIp, "", "Token ist ${tokenAge / 1000}s alt – Replay-Verdacht")
        }
    }

    /**
     * Code-Integritätsverletzung erkannt (vom CodeIntegrityGuard).
     * Jemand hat versucht den App-Code zu verändern, umzupacken,
     * Code einzuschleusen (Frida/Xposed) oder zu debuggen.
     */
    fun recordCodeTampering(type: AttackType, level: ThreatLevel, description: String) {
        scope.launch {
            detectAttack(type, level, "", "self", description)
        }
    }

    // ── Angriff verarbeiten + lernen ─────────────────────────────────────────

    private suspend fun detectAttack(
        type: AttackType,
        level: ThreatLevel,
        sourceIp: String,
        sourceDevice: String,
        description: String,
    ) {
        val event = AttackEvent(
            id = java.util.UUID.randomUUID().toString().take(8),
            type = type,
            level = level,
            sourceIp = sourceIp,
            sourceDeviceId = sourceDevice,
            description = description,
            blocked = true,
        )

        Log.w(TAG, "🛡 ANGRIFF ERKANNT [${type.name}/${level.name}]: $description")

        memory.attackHistory.add(event)

        // Aus dem Angriff eine neue Regel lernen
        learnFromAttack(event)

        // Sofortige Abwehr
        applyDefense(event)

        saveMemory()
    }

    private fun learnFromAttack(event: AttackEvent) {
        // Prüfen ob ähnliche Regel schon existiert
        val existing = memory.learnedRules.find {
            it.attackType == event.type && it.pattern.contains(event.sourceIp.take(10))
        }

        if (existing != null) {
            // Konfidenz erhöhen (JayJay wird besser)
            val idx = memory.learnedRules.indexOf(existing)
            memory.learnedRules[idx] = existing.copy(
                confidence = minOf(1.0f, existing.confidence + 0.05f),
                triggeredCount = existing.triggeredCount + 1,
                lastTriggered = System.currentTimeMillis(),
            )
            Log.i(TAG, "📈 Regel verstärkt: ${event.type} (Konfidenz: ${memory.learnedRules[idx].confidence})")
        } else {
            // Neue Regel lernen
            val rule = DefenseRule(
                id = java.util.UUID.randomUUID().toString().take(8),
                pattern = buildPattern(event),
                attackType = event.type,
                action = recommendAction(event.level),
                confidence = 0.6f, // Startkonfidenz bei neuer Regel
            )
            memory.learnedRules.add(rule)
            Log.i(TAG, "🧠 Neue Abwehrregel gelernt: ${event.type} → ${rule.action}")
        }
    }

    private fun buildPattern(event: AttackEvent): String = buildString {
        if (event.sourceIp.isNotBlank()) append("ip:${event.sourceIp.substringBeforeLast(".")}. ")
        if (event.sourceDeviceId.isNotBlank()) append("device:${event.sourceDeviceId.take(12)} ")
        append("type:${event.type.name}")
    }

    private fun recommendAction(level: ThreatLevel) = when (level) {
        ThreatLevel.LOW      -> "alert_finn"
        ThreatLevel.MEDIUM   -> "block_ip"
        ThreatLevel.HIGH     -> "block_ip|alert_finn|rotate_keys"
        ThreatLevel.CRITICAL -> "block_ip|isolate_node|alert_finn|rotate_keys"
    }

    private suspend fun applyDefense(event: AttackEvent) {
        when (event.level) {
            ThreatLevel.LOW    -> Log.i(TAG, "ℹ Niedriges Risiko – nur protokolliert")
            ThreatLevel.MEDIUM -> {
                if (event.sourceIp.isNotBlank()) blockIp(event.sourceIp)
            }
            ThreatLevel.HIGH   -> {
                if (event.sourceIp.isNotBlank()) blockIp(event.sourceIp)
                if (event.sourceDeviceId.isNotBlank()) blockDevice(event.sourceDeviceId)
            }
            ThreatLevel.CRITICAL -> {
                if (event.sourceIp.isNotBlank()) blockIp(event.sourceIp)
                if (event.sourceDeviceId.isNotBlank()) blockDevice(event.sourceDeviceId)
                Log.e(TAG, "🔴 KRITISCHER ANGRIFF – Finn wird informiert!")
                // JayJay informiert Finn beim nächsten Kontakt
            }
        }
    }

    // ── Blocklisten ──────────────────────────────────────────────────────────

    private suspend fun blockIp(ip: String) {
        memory.blockedIps.add(ip)
        Log.w(TAG, "🚫 IP blockiert: $ip")
    }

    private suspend fun blockDevice(deviceId: String) {
        memory.blockedDevices.add(deviceId)
        Log.w(TAG, "🚫 Gerät blockiert: $deviceId")
    }

    fun unblockIp(ip: String) {
        memory.blockedIps.remove(ip)
        scope.launch { saveMemory() }
        Log.i(TAG, "✓ IP freigegeben: $ip (CEO-Befehl)")
    }

    fun unblockDevice(deviceId: String) {
        memory.blockedDevices.remove(deviceId)
        scope.launch { saveMemory() }
        Log.i(TAG, "✓ Gerät freigegeben: $deviceId (CEO-Befehl)")
    }

    // ── Bericht für JayJay/Finn ──────────────────────────────────────────────

    fun getSecurityReport(): String = buildString {
        val recent = memory.attackHistory
            .sortedByDescending { it.detectedAt }
            .take(5)
        appendLine("🛡 SICHERHEITSBERICHT – Pandora Defense")
        appendLine("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
        appendLine("Gelernte Abwehrregeln: ${memory.learnedRules.size}")
        appendLine("Blockierte IPs: ${memory.blockedIps.size}")
        appendLine("Blockierte Geräte: ${memory.blockedDevices.size}")
        appendLine("Angriffe gesamt: ${memory.attackHistory.size}")
        appendLine("")
        if (recent.isEmpty()) {
            appendLine("Keine Angriffe bekannt.")
        } else {
            appendLine("Letzte Angriffe:")
            recent.forEach { e ->
                val ago = (System.currentTimeMillis() - e.detectedAt) / 60_000
                appendLine("• [${e.level}] ${e.type} – ${e.description.take(60)} (vor ${ago}min)")
            }
        }
    }

    fun getCriticalAlerts(): List<AttackEvent> = memory.attackHistory
        .filter { it.level == ThreatLevel.CRITICAL }
        .sortedByDescending { it.detectedAt }
        .take(3)

    fun getThreatLevel(): ThreatLevel {
        val recent = memory.attackHistory.filter {
            System.currentTimeMillis() - it.detectedAt < 60 * 60 * 1000L
        }
        return when {
            recent.any { it.level == ThreatLevel.CRITICAL } -> ThreatLevel.CRITICAL
            recent.any { it.level == ThreatLevel.HIGH }     -> ThreatLevel.HIGH
            recent.any { it.level == ThreatLevel.MEDIUM }   -> ThreatLevel.MEDIUM
            recent.isNotEmpty()                              -> ThreatLevel.LOW
            else                                             -> ThreatLevel.LOW
        }
    }
}
