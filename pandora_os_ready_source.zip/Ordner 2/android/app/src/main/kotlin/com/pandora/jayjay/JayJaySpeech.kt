package com.pandora.jayjay

import android.content.Context
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.speech.tts.Voice
import android.util.Log
import java.util.Locale
import java.util.concurrent.atomic.AtomicBoolean

/**
 * JayJaySpeech – JayJays Stimme (sie spricht, und sie ist ein Mädchen)
 *
 * Nutzt Android TextToSpeech und wählt bewusst eine WEIBLICHE deutsche
 * Stimme. JayJay ist weiblich – jede Antwort wird laut ausgesprochen,
 * mit einer jungen, klaren Frauenstimme.
 *
 * Auswahl der Stimme:
 *   1. Deutsche Stimmen filtern (de-DE bevorzugt).
 *   2. Davon die weiblichen erkennen (Voice-Name + Geschlechts-Heuristik).
 *   3. Die natürlichste (höchste Qualität, nicht "network required"-only) wählen.
 *
 * CEO: Finn Jona Thorsten Lischke
 */
class JayJaySpeech(private val context: Context) {

    private var tts: TextToSpeech? = null
    private val ready = AtomicBoolean(false)
    private val shuttingDown = AtomicBoolean(false)
    private var chosenVoice: Voice? = null

    // Alle TTS-Operationen laufen serialisiert über den Main-Looper (TTS ist nicht thread-safe)
    private val handler = Handler(Looper.getMainLooper())

    // Antworten, die ankommen bevor die Stimme bereit ist, werden gepuffert
    @Volatile private var pending: String? = null

    // JayJay-Stimme: jung, freundlich, leicht über Normaltempo
    var pitch = 1.18f     // höher = weiblicher/jünger
    var rate  = 1.02f     // Sprechtempo

    companion object {
        private const val TAG = "JayJaySpeech"
        // Schlüsselwörter, die in Voice-Namen auf eine Frauenstimme hindeuten
        private val FEMALE_HINTS = listOf(
            "female", "#female", "-f-", "_f_", "woman", "girl",
            "weiblich", "frau", "fem",
        )
        // Bekannte männliche Marker zum Ausschließen
        private val MALE_HINTS = listOf("male", "#male", "-m-", "_m_", "man", "männlich", "mann")
    }

    fun init(onReady: (() -> Unit)? = null) {
        tts = TextToSpeech(context.applicationContext) { status ->
            if (status == TextToSpeech.SUCCESS) {
                configureGermanFemaleVoice()
                tts?.setPitch(pitch)
                tts?.setSpeechRate(rate)
                ready.set(true)
                Log.i(TAG, "JayJay-Stimme bereit: ${chosenVoice?.name ?: "Standard"}")
                // Gepufferte Antwort nachholen, damit nichts verloren geht
                pending?.let { buffered ->
                    pending = null
                    speak(buffered)
                }
                onReady?.invoke()
            } else {
                Log.w(TAG, "TextToSpeech-Init fehlgeschlagen ($status)")
            }
        }
    }

    /** Wählt die beste weibliche deutsche Stimme aus. */
    private fun configureGermanFemaleVoice() {
        val engine = tts ?: return
        engine.language = Locale.GERMAN

        val voices = runCatching { engine.voices }.getOrNull()?.filterNotNull() ?: emptySet<Voice>().toList()
        if (voices.isEmpty()) {
            engine.language = Locale.GERMAN
            return
        }

        val german = voices.filter {
            it.locale.language == Locale.GERMAN.language
        }.ifEmpty { voices.toList() }

        fun isFemale(v: Voice): Boolean {
            val n = v.name.lowercase()
            if (MALE_HINTS.any { it in n }) return false
            return FEMALE_HINTS.any { it in n }
        }
        // de-DE (Hochdeutsch) vor anderen deutschen Varianten (de-AT/de-CH) bevorzugen
        fun isDeDe(v: Voice): Boolean = v.locale.country.equals("DE", ignoreCase = true)

        // Priorität: weiblich → de-DE → offline → hohe Qualität
        val best = german
            .sortedWith(
                compareByDescending<Voice> { isFemale(it) }
                    .thenByDescending { isDeDe(it) }             // Hochdeutsch bevorzugt
                    .thenBy { it.isNetworkConnectionRequired }   // offline bevorzugt
                    .thenByDescending { it.quality }             // beste Qualität zuerst
            )
            .firstOrNull()

        chosenVoice = best
        if (best != null) {
            runCatching { engine.voice = best }
            if (!isFemale(best)) {
                Log.w(TAG, "Keine eindeutig weibliche Stimme gefunden – nutze beste verfügbare: ${best.name}")
            }
        }
    }

    /** JayJay spricht den Text laut aus. Thread-sicher (serialisiert auf Main-Looper). */
    fun speak(text: String, flush: Boolean = true) {
        if (shuttingDown.get() || text.isBlank()) return
        // Emojis/Markup entfernen, damit die Stimme natürlich klingt
        val clean = sanitize(text)
        if (clean.isBlank()) return
        // Noch nicht bereit? Letzte Antwort puffern – init() holt sie nach
        if (!ready.get()) {
            pending = text
            return
        }
        handler.post {
            val engine = tts ?: return@post
            if (shuttingDown.get()) return@post
            val mode = if (flush) TextToSpeech.QUEUE_FLUSH else TextToSpeech.QUEUE_ADD
            val params = Bundle().apply {
                putString(TextToSpeech.Engine.KEY_PARAM_UTTERANCE_ID, "jayjay-${System.nanoTime()}")
            }
            runCatching { engine.speak(clean, mode, params, "jayjay") }
        }
    }

    fun stop() { handler.post { runCatching { tts?.stop() } } }

    fun isSpeaking(): Boolean = runCatching { tts?.isSpeaking == true }.getOrDefault(false)

    fun setProgressListener(listener: UtteranceProgressListener) {
        tts?.setOnUtteranceProgressListener(listener)
    }

    fun shutdown() {
        shuttingDown.set(true)
        ready.set(false)
        pending = null
        handler.post {
            runCatching { tts?.stop(); tts?.shutdown() }
            tts = null
        }
    }

    /** Entfernt Emojis, Trennlinien und Markup für sauberes Vorlesen. */
    private fun sanitize(text: String): String {
        return text
            .replace(Regex("[\\p{So}\\p{Cn}]"), "")          // Symbole/Emojis
            .replace(Regex("[━─•▪◦*#]+"), " ")               // Listen-/Trennzeichen
            .replace(Regex("https?://\\S+"), "Link")          // URLs nicht buchstabieren
            .replace(Regex("\\s{2,}"), " ")
            .trim()
    }
}
