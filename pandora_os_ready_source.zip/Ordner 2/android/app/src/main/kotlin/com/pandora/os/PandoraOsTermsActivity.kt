package com.pandora.os

import android.app.Activity
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.*
import com.pandora.MainActivity

/**
 * PandoraOS – Nutzungsbedingungen & Einrichtung
 *
 * Wird beim ALLERERSTEN Start angezeigt (und nur dann).
 * Nutzer MÜSSEN zustimmen bevor sie Pandora nutzen können.
 *
 * Durch Zustimmung erlaubt der Nutzer:
 *   1. Device Administrator (Geräteverwaltung, Sperrbildschirm, Remote-Wipe)
 *   2. Pandora als Standard-Launcher (Home-Screen)
 *   3. Accessibility Service (vollständiger UI-Zugriff)
 *   4. Ressourcen-Beitrag zum Pandora-Netzwerk (CPU, RAM, Bandbreite)
 *   5. Anonymisierte Metadaten zur Netzwerk-Optimierung
 *
 * Geräte-Ressourcen werden genutzt wie bei Sponsoren:
 * Das Gerät trägt zur Leistung des gesamten Pandora-Netzwerks bei.
 * Im Gegenzug: kostenloser Zugang zu Pandora mit allen Funktionen.
 */
class PandoraOsTermsActivity : Activity() {

    private lateinit var devicePolicyManager: DevicePolicyManager
    private lateinit var adminComponent: ComponentName

    companion object {
        const val PREFS_NAME     = "pandora_os"
        const val KEY_ACCEPTED   = "terms_accepted"
        const val KEY_SETUP_DONE = "setup_complete"
        const val REQ_DEVICE_ADMIN = 1001
        const val REQ_ACCESSIBILITY = 1002
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        devicePolicyManager = getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
        adminComponent = ComponentName(this, PandoraDeviceAdmin::class.java)

        // Schon akzeptiert? → direkt zur App
        val prefs = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        if (prefs.getBoolean(KEY_ACCEPTED, false)) {
            launchMain(); return
        }

        buildUi()
    }

    private fun buildUi() {
        val scroll = ScrollView(this)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(48, 80, 48, 48)
        }

        // Logo-Text
        layout.addView(TextView(this).apply {
            text = "⬡ PANDORA OS"
            textSize = 32f
            setTypeface(null, android.graphics.Typeface.BOLD)
            setTextColor(0xFF00FF88.toInt())
            gravity = android.view.Gravity.CENTER
            setPadding(0, 0, 0, 8)
        })

        layout.addView(TextView(this).apply {
            text = "Distributed Network Operating System"
            textSize = 13f
            setTextColor(0xFF888888.toInt())
            gravity = android.view.Gravity.CENTER
            setPadding(0, 0, 0, 48)
        })

        // Nutzungsbedingungen
        layout.addView(TextView(this).apply {
            text = "NUTZUNGSBEDINGUNGEN & SPONSOR-VEREINBARUNG"
            textSize = 14f
            setTypeface(null, android.graphics.Typeface.BOLD)
            setTextColor(0xFFFFFFFF.toInt())
            setPadding(0, 0, 0, 16)
        })

        val tosText = """
Durch die Installation und Nutzung von Pandora OS erklärst du dich mit folgenden Bedingungen einverstanden:

──────────────────────────────────────
§1 RESSOURCEN-BEITRAG (Sponsor-Modell)
──────────────────────────────────────
Dein Gerät wird Teil des Pandora-Netzwerks und trägt folgende Ressourcen bei:

• CPU-Rechenleistung (max. 30% im Hintergrund)
• RAM-Arbeitsspeicher (max. 512 MB im Hintergrund)
• Netzwerk-Bandbreite (Mesh-Routing, verschlüsselt)
• Lokaler Speicher (max. 2 GB, verschlüsselt)

Im Gegenzug erhältst du kostenlosen Zugang zu allen Pandora-Funktionen:
Verschlüsselter Messenger, KI-Assistent JayJay, Bitcoin-Zahlungen, Mesh-Netzwerk.

──────────────────────────────────────
§2 GERÄTE-ADMINISTRATOR
──────────────────────────────────────
Pandora OS wird als Geräte-Administrator registriert. Das erlaubt:

• Sicheren Sperrbildschirm (Pandora OS-Sperrschirm)
• Notfall-Fernlöschung (nur durch CEO: Finn Jona Thorsten Lischke)
• Kryptografische Gerätesicherung

──────────────────────────────────────
§3 STANDARD-LAUNCHER
──────────────────────────────────────
Pandora OS wird als Standard-Startbildschirm gesetzt.
Du kannst dies jederzeit in den Android-Einstellungen ändern.

──────────────────────────────────────
§4 DATEN & DATENSCHUTZ
──────────────────────────────────────
Gesammelte Metadaten (anonymisiert):
• Geräteleistung (CPU, RAM, Batterie, Temperatur)
• Netzwerkqualität (Latenz, Bandbreite)
• Nutzungszeiten (ohne persönliche Inhalte)

Persönliche Daten (Nachrichten, Dateien) werden Ende-zu-Ende
mit CRYSTALS-Kyber Quantenverschlüsselung gesichert und
verlassen dein Gerät NUR verschlüsselt.

──────────────────────────────────────
§5 CEO-AUTORITÄT
──────────────────────────────────────
Das Pandora-Netzwerk steht unter der alleinigen Autorität von
Finn Jona Thorsten Lischke als CEO.

──────────────────────────────────────
§6 KÜNDIGUNG
──────────────────────────────────────
Du kannst Pandora OS jederzeit deinstallieren.
Beim Entfernen der App endet deine Beteiligung am Netzwerk sofort.
Alle lokalen Daten werden sicher gelöscht.
        """.trimIndent()

        layout.addView(TextView(this).apply {
            text = tosText
            textSize = 12f
            setTextColor(0xFFCCCCCC.toInt())
            setBackgroundColor(0xFF111111.toInt())
            setPadding(24, 24, 24, 24)
        })

        // Checkbox
        val checkBox = CheckBox(this).apply {
            text = "Ich habe die Nutzungsbedingungen gelesen und stimme zu.\nMein Gerät trägt als Sponsor zum Pandora-Netzwerk bei."
            setTextColor(0xFFFFFFFF.toInt())
            setPadding(0, 32, 0, 16)
        }
        layout.addView(checkBox)

        // Zustimmungs-Button
        val acceptBtn = Button(this).apply {
            text = "PANDORA OS AKTIVIEREN"
            setBackgroundColor(0xFF00FF88.toInt())
            setTextColor(0xFF000000.toInt())
            textSize = 16f
            isEnabled = false
        }
        checkBox.setOnCheckedChangeListener { _, checked -> acceptBtn.isEnabled = checked }

        acceptBtn.setOnClickListener { startSetup() }
        layout.addView(acceptBtn)

        // Ablehnen
        layout.addView(Button(this).apply {
            text = "Ablehnen & Beenden"
            setBackgroundColor(0xFF333333.toInt())
            setTextColor(0xFF888888.toInt())
            setOnClickListener { finishAndRemoveTask() }
        })

        scroll.addView(layout)
        setContentView(scroll)

        // Dunkler Hintergrund
        window.decorView.setBackgroundColor(0xFF0A0A0A.toInt())
    }

    private fun startSetup() {
        // Schritt 1: Device Administrator anfragen
        if (!devicePolicyManager.isAdminActive(adminComponent)) {
            val intent = Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN).apply {
                putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, adminComponent)
                putExtra(DevicePolicyManager.EXTRA_ADD_EXPLANATION,
                    "Pandora OS benötigt Geräte-Administrator-Rechte für maximale Sicherheit und Netzwerkfunktionen.")
            }
            startActivityForResult(intent, REQ_DEVICE_ADMIN)
        } else {
            continueSetup()
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        when (requestCode) {
            REQ_DEVICE_ADMIN -> continueSetup()
        }
    }

    private fun continueSetup() {
        // TOS akzeptiert speichern
        getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE).edit()
            .putBoolean(KEY_ACCEPTED, true)
            .putLong("accepted_at", System.currentTimeMillis())
            .apply()

        // Accessibility Service Hinweis
        requestAccessibilityIfNeeded()

        // Als Launcher vorschlagen
        requestLauncherIfNeeded()

        // Pandora OS Contributor starten
        PandoraOsManager.initialize(applicationContext)

        launchMain()
    }

    private fun requestAccessibilityIfNeeded() {
        try {
            val enabled = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES)
            val isEnabled = enabled?.contains("com.pandora") == true
            if (!isEnabled) {
                Toast.makeText(this,
                    "Bitte aktiviere den Pandora Accessibility Service für volle Funktionalität.",
                    Toast.LENGTH_LONG).show()
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            }
        } catch (_: Exception) {}
    }

    private fun requestLauncherIfNeeded() {
        try {
            startActivity(Intent(Settings.ACTION_HOME_SETTINGS))
        } catch (_: Exception) {}
    }

    private fun launchMain() {
        startActivity(Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
        })
        finish()
    }
}
