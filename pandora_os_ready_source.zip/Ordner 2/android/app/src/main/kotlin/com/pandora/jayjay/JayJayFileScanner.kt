package com.pandora.jayjay

import android.content.Context
import android.os.Environment
import android.os.StatFs
import android.util.Log
import kotlinx.coroutines.*
import kotlinx.serialization.Serializable
import java.io.File
import java.text.SimpleDateFormat
import java.util.*

/**
 * JayJay Dateiscanner – 100% Gerätezugriff auf jede Datei
 *
 * Durchsucht JEDEN Speicherort des Geräts:
 *   - Interner Speicher (/storage/emulated/0) → komplett
 *   - SD-Karte (/storage/<id>/) → komplett
 *   - Alle App-Verzeichnisse (Downloads, DCIM, Documents, etc.)
 *   - Versteckte Ordner (Ordner die mit "." beginnen)
 *   - System-Ordner die durch Android zugänglich sind
 *   - App-Datencache (soweit lesbar ohne Root)
 *
 * Netzwerk (Pandora Mesh):
 *   - Alle verbundenen Pandora-Knoten
 *   - Freigegebene Dateien anderer Geräte
 *   - CEO-Host Dateiserver
 *
 * Nur Finn Jona Thorsten Lischke kann Dateien abfragen.
 */

@Serializable
data class FileEntry(
    val name: String,
    val path: String,
    val sizeBytes: Long,
    val lastModified: Long,
    val extension: String,
    val isHidden: Boolean,
    val category: String,   // "dokument", "bild", "video", "audio", "archiv", "code", "sonstiges"
)

@Serializable
data class FileScanResult(
    val totalFiles: Int,
    val totalSizeBytes: Long,
    val byCategory: Map<String, Int>,
    val storageLocations: List<String>,
    val freeSpaceBytes: Long,
    val totalSpaceBytes: Long,
    val scannedAt: Long = System.currentTimeMillis(),
)

class JayJayFileScanner(private val context: Context) {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    companion object {
        private const val TAG = "JayJayFiles"
        private const val MAX_FILES_PER_SCAN = 50_000   // Sicherheitslimit

        private val IMAGE_EXTS    = setOf("jpg","jpeg","png","gif","webp","heic","heif","bmp","raw","cr2","dng","svg")
        private val VIDEO_EXTS    = setOf("mp4","mkv","avi","mov","wmv","flv","m4v","3gp","ts","webm")
        private val AUDIO_EXTS    = setOf("mp3","aac","flac","wav","ogg","m4a","opus","wma","amr")
        private val DOC_EXTS      = setOf("pdf","doc","docx","xls","xlsx","ppt","pptx","txt","csv","odt","pages")
        private val ARCHIVE_EXTS  = setOf("zip","rar","7z","tar","gz","bz2","xz","apk")
        private val CODE_EXTS     = setOf("kt","java","py","js","ts","html","css","json","xml","yaml","sh","c","cpp","h")

        private val DATE_FMT = SimpleDateFormat("dd.MM.yyyy HH:mm", Locale.GERMAN)
    }

    // ── Vollständiger Scan ───────────────────────────────────────────────────

    /**
     * Scannt ALLE Speicherorte parallel.
     * Gibt ein vollständiges Verzeichnis aller Dateien zurück.
     */
    suspend fun fullScan(): FileScanResult = withContext(Dispatchers.IO) {
        val locations = getStorageLocations()
        val allFiles  = mutableListOf<FileEntry>()

        Log.i(TAG, "Starte Vollscan: ${locations.size} Speicherorte")

        val jobs = locations.map { root ->
            async {
                walkDirectory(File(root), allFiles)
            }
        }
        jobs.awaitAll()

        val byCategory = allFiles.groupBy { it.category }.mapValues { it.value.size }
        val totalSize  = allFiles.sumOf { it.sizeBytes }
        val freeSpace  = getStorageFreeBytes()
        val totalSpace = getStorageTotalBytes()

        Log.i(TAG, "Scan abgeschlossen: ${allFiles.size} Dateien, ${totalSize / 1_048_576}MB")

        FileScanResult(
            totalFiles       = allFiles.size,
            totalSizeBytes   = totalSize,
            byCategory       = byCategory,
            storageLocations = locations,
            freeSpaceBytes   = freeSpace,
            totalSpaceBytes  = totalSpace,
        )
    }

    /**
     * Dateien nach Extension/Kategorie suchen.
     */
    suspend fun findByCategory(category: String, limit: Int = 200): List<FileEntry> = withContext(Dispatchers.IO) {
        val result = mutableListOf<FileEntry>()
        for (root in getStorageLocations()) {
            walkDirectory(File(root), result, filterCategory = category)
            if (result.size >= limit) break
        }
        result.take(limit).sortedByDescending { it.lastModified }
    }

    /**
     * Datei nach Name suchen (Teilstring, case-insensitive).
     */
    suspend fun findByName(query: String, limit: Int = 100): List<FileEntry> = withContext(Dispatchers.IO) {
        val result = mutableListOf<FileEntry>()
        val q = query.lowercase()
        for (root in getStorageLocations()) {
            walkDirectory(File(root), result, filterName = q)
            if (result.size >= limit) break
        }
        result.take(limit).sortedByDescending { it.lastModified }
    }

    /**
     * Dateien nach Extension suchen.
     */
    suspend fun findByExtension(ext: String, limit: Int = 200): List<FileEntry> = withContext(Dispatchers.IO) {
        val result = mutableListOf<FileEntry>()
        val e = ext.lowercase().removePrefix(".")
        for (root in getStorageLocations()) {
            walkDirectory(File(root), result, filterExt = e)
            if (result.size >= limit) break
        }
        result.take(limit).sortedByDescending { it.lastModified }
    }

    /**
     * Kürzlich geänderte Dateien (letzte N Tage).
     */
    suspend fun recentFiles(days: Int = 7, limit: Int = 100): List<FileEntry> = withContext(Dispatchers.IO) {
        val cutoff = System.currentTimeMillis() - days * 86_400_000L
        val result = mutableListOf<FileEntry>()
        for (root in getStorageLocations()) {
            walkDirectory(File(root), result, filterSince = cutoff)
        }
        result.sortedByDescending { it.lastModified }.take(limit)
    }

    /**
     * Datei lesen (Text-Inhalt für JayJay-Analyse).
     * Nur für Textdateien ≤ 5MB.
     */
    fun readFileContent(path: String): String? {
        val file = File(path)
        if (!file.exists() || !file.isFile) return null
        if (file.length() > 5 * 1_048_576) return "[Datei zu groß: ${file.length() / 1_048_576}MB]"
        return runCatching { file.readText(Charsets.UTF_8) }
            .getOrElse { "[Lesefehler: ${it.message}]" }
    }

    // ── Hilfsmethoden ────────────────────────────────────────────────────────

    private fun walkDirectory(
        dir: File,
        result: MutableList<FileEntry>,
        filterCategory: String? = null,
        filterName: String? = null,
        filterExt: String? = null,
        filterSince: Long? = null,
        depth: Int = 0,
    ) {
        if (result.size >= MAX_FILES_PER_SCAN) return
        if (!dir.exists() || !dir.canRead()) return
        if (depth > 20) return  // Endlosrekursion verhindern

        val children = try { dir.listFiles() ?: return } catch (_: Exception) { return }

        for (file in children) {
            if (result.size >= MAX_FILES_PER_SCAN) break
            try {
                if (file.isDirectory) {
                    // Symlink-Schleifen vermeiden
                    if (file.canonicalPath != file.absolutePath &&
                        !file.canonicalPath.startsWith("/storage")) continue
                    walkDirectory(file, result, filterCategory, filterName, filterExt, filterSince, depth + 1)
                } else {
                    val ext  = file.extension.lowercase()
                    val cat  = categorize(ext)
                    val name = file.name.lowercase()

                    // Filter anwenden
                    if (filterCategory != null && cat != filterCategory) continue
                    if (filterName     != null && !name.contains(filterName)) continue
                    if (filterExt      != null && ext != filterExt) continue
                    if (filterSince    != null && file.lastModified() < filterSince) continue

                    result.add(FileEntry(
                        name         = file.name,
                        path         = file.absolutePath,
                        sizeBytes    = file.length(),
                        lastModified = file.lastModified(),
                        extension    = ext,
                        isHidden     = file.name.startsWith("."),
                        category     = cat,
                    ))
                }
            } catch (_: Exception) {}
        }
    }

    private fun categorize(ext: String): String = when {
        ext in IMAGE_EXTS   -> "bild"
        ext in VIDEO_EXTS   -> "video"
        ext in AUDIO_EXTS   -> "audio"
        ext in DOC_EXTS     -> "dokument"
        ext in ARCHIVE_EXTS -> "archiv"
        ext in CODE_EXTS    -> "code"
        ext == "apk"        -> "app"
        else                -> "sonstiges"
    }

    private fun getStorageLocations(): List<String> {
        val locations = mutableListOf<String>()

        // Primärer interner Speicher
        val primary = Environment.getExternalStorageDirectory().absolutePath
        locations.add(primary)

        // Alle externen Speicher (SD-Karte, OTG, etc.)
        try {
            val extDirs = context.getExternalFilesDirs(null)
            for (dir in extDirs) {
                if (dir == null) continue
                // Wurzel des externen Speichers ermitteln
                var root: File? = dir
                while (root?.parentFile != null &&
                    !root.parentFile!!.absolutePath.endsWith("Android")) {
                    root = root.parentFile
                }
                val storageRoot = root?.parentFile
                if (storageRoot != null && storageRoot.absolutePath != primary) {
                    locations.add(storageRoot.absolutePath)
                }
            }
        } catch (_: Exception) {}

        // Downloads explizit
        val downloads = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
        if (downloads.exists() && downloads.absolutePath !in locations) {
            locations.add(downloads.absolutePath)
        }

        Log.d(TAG, "Speicherorte: $locations")
        return locations.distinct()
    }

    private fun getStorageFreeBytes(): Long = try {
        val stat = StatFs(Environment.getExternalStorageDirectory().absolutePath)
        stat.availableBlocksLong * stat.blockSizeLong
    } catch (_: Exception) { 0L }

    private fun getStorageTotalBytes(): Long = try {
        val stat = StatFs(Environment.getExternalStorageDirectory().absolutePath)
        stat.blockCountLong * stat.blockSizeLong
    } catch (_: Exception) { 0L }

    // ── JayJay-Zusammenfassung ────────────────────────────────────────────────

    fun summarizeScan(result: FileScanResult): String = buildString {
        val totalMb = result.totalSizeBytes / 1_048_576
        val freeMb  = result.freeSpaceBytes / 1_048_576
        val usedPct = if (result.totalSpaceBytes > 0)
            100 * (result.totalSpaceBytes - result.freeSpaceBytes) / result.totalSpaceBytes else 0

        appendLine("💾 Gerätespeicher-Scan:")
        appendLine("• ${result.totalFiles} Dateien gefunden (${totalMb}MB)")
        appendLine("• Freier Speicher: ${freeMb}MB (${100 - usedPct}% frei)")
        appendLine("• Speicherorte: ${result.storageLocations.joinToString()}")
        appendLine()
        appendLine("📂 Nach Kategorie:")
        for ((cat, count) in result.byCategory.entries.sortedByDescending { it.value }) {
            appendLine("  • $cat: $count Dateien")
        }
    }

    fun formatFileList(files: List<FileEntry>, limit: Int = 15): String = buildString {
        files.take(limit).forEach { f ->
            val date = DATE_FMT.format(Date(f.lastModified))
            val size = when {
                f.sizeBytes > 1_048_576 -> "${f.sizeBytes / 1_048_576}MB"
                f.sizeBytes > 1_024     -> "${f.sizeBytes / 1_024}KB"
                else                    -> "${f.sizeBytes}B"
            }
            appendLine("• ${if (f.isHidden) "🔒 " else ""}${f.name} ($size) – $date")
            appendLine("  ${f.path}")
        }
        if (files.size > limit) appendLine("... und ${files.size - limit} weitere")
    }
}
