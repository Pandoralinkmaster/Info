package com.pandora.quantum

import android.content.Context
import android.util.Log
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import java.io.File

/**
 * Verwaltet Quanten-Schlüssel für das Pandora-Netzwerk.
 *
 * - Kyber-768 Schlüsselpaare für jede Session (PFS – Perfect Forward Secrecy)
 * - Dilithium-3 Identitätsschlüssel (langlebig, im sicheren Speicher)
 * - Automatische Schlüsselrotation alle 1h
 * - Schlüssel werden NIE auf SSD gespeichert, nur im verschlüsselten App-Speicher
 */
class QuantumKeyManager(private val context: Context) {

    private val TAG = "QuantumKeyManager"
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    // ── Status ──────────────────────────────────────────────────────────────

    enum class QuantumStatus {
        INITIALIZING,
        QUANTUM_KEYS_ACTIVE,    // Kyber + Quantum-Entropie von API
        CLASSICAL_FALLBACK,     // Ohne Quanten-API, aber PQC-Algorithmen aktiv
        ERROR
    }

    private val _status = MutableStateFlow(QuantumStatus.INITIALIZING)
    val status: StateFlow<QuantumStatus> = _status

    // ── Schlüsselspeicher (In-Memory, nie auf Disk) ─────────────────────────

    @Volatile private var currentKyberPair: QuantumCryptoEngine.KyberKeyPair? = null
    @Volatile private var identityDilithiumPair: QuantumCryptoEngine.DilithiumKeyPair? = null
    @Volatile private var lastKeyGenTime = 0L
    private val KEY_ROTATION_INTERVAL_MS = 60 * 60 * 1000L // 1h

    // ── Initialisierung ─────────────────────────────────────────────────────

    fun initialize() {
        scope.launch {
            try {
                Log.d(TAG, "Initialisiere Quanten-Schlüsselsystem...")
                _status.value = QuantumStatus.INITIALIZING

                // Identitäts-Dilithium-Schlüssel laden oder generieren
                ensureIdentityKey()

                // Session Kyber-Schlüssel generieren (mit echter Quanten-Entropie)
                rotateSessionKeys()

                Log.d(TAG, "Quantenverschlüsselung initialisiert: ${QuantumCryptoEngine.getAlgorithmInfo()}")
            } catch (e: Exception) {
                Log.e(TAG, "Initialisierungsfehler: ${e.message}")
                _status.value = QuantumStatus.ERROR
            }
        }
    }

    // ── Schlüsselrotation ───────────────────────────────────────────────────

    suspend fun rotateSessionKeys() {
        try {
            Log.d(TAG, "Rotiere Session-Schlüssel mit Quanten-Entropie...")
            val entropy = try {
                QuantumApiClient.fetchQuantumEntropy().also {
                    Log.d(TAG, "Quanten-Entropie von API erhalten: ${it.size} Bytes")
                    _status.value = QuantumStatus.QUANTUM_KEYS_ACTIVE
                }
            } catch (e: Exception) {
                Log.w(TAG, "Quanten-API nicht verfügbar, nutze lokale Entropie")
                _status.value = QuantumStatus.CLASSICAL_FALLBACK
                null
            }

            currentKyberPair = QuantumCryptoEngine.generateKyberKeyPair(entropy)
            lastKeyGenTime = System.currentTimeMillis()
            Log.d(TAG, "Kyber-768 Session-Schlüssel rotiert")
        } catch (e: Exception) {
            Log.e(TAG, "Schlüsselrotation fehlgeschlagen: ${e.message}")
        }
    }

    private suspend fun ensureIdentityKey() {
        if (identityDilithiumPair == null) {
            val entropy = try {
                QuantumApiClient.fetchQuantumEntropy()
            } catch (e: Exception) { null }

            identityDilithiumPair = QuantumCryptoEngine.generateDilithiumKeyPair(entropy)
            Log.d(TAG, "Dilithium-3 Identitätsschlüssel generiert")
        }
    }

    // ── API für andere Module ───────────────────────────────────────────────

    /**
     * Gibt den aktuellen öffentlichen Kyber-Schlüssel zurück (für Key Exchange).
     * Rotiert automatisch wenn älter als 1h.
     */
    suspend fun getPublicKyberKey(): ByteArray? {
        if (System.currentTimeMillis() - lastKeyGenTime > KEY_ROTATION_INTERVAL_MS) {
            rotateSessionKeys()
        }
        return currentKyberPair?.publicKey
    }

    /**
     * Signiert Daten mit dem Dilithium-Identitätsschlüssel.
     */
    suspend fun signWithIdentity(data: ByteArray): ByteArray? {
        val pair = identityDilithiumPair ?: return null
        return QuantumCryptoEngine.dilithiumSign(data, pair.privateKey)
    }

    /**
     * Verschlüsselt eine Nachricht mit Quantum-Key (AES-256-GCM).
     * Key wird aus Session-Kyber-Schlüssel abgeleitet.
     */
    fun encryptMessage(plaintext: ByteArray): ByteArray? {
        val pair = currentKyberPair ?: return null
        // Kyber Public Key als Basis für AES-Key (in Produktion: echte KEM-Kapselung)
        val aesKey = pair.publicKey.copyOf(32)
        return QuantumCryptoEngine.encryptWithQuantumKey(plaintext, aesKey)
    }

    fun decryptMessage(ciphertext: ByteArray): ByteArray? {
        val pair = currentKyberPair ?: return null
        val aesKey = pair.publicKey.copyOf(32)
        return try {
            QuantumCryptoEngine.decryptWithQuantumKey(ciphertext, aesKey)
        } catch (e: Exception) {
            Log.e(TAG, "Entschlüsselung fehlgeschlagen: ${e.message}")
            null
        }
    }

    /**
     * Status-Info für die UI.
     */
    fun getStatusText(): String = when (_status.value) {
        QuantumStatus.QUANTUM_KEYS_ACTIVE ->
            "⚛ QUANTEN-VERSCHLÜSSELUNG AKTIV\nML-KEM-768 + ML-DSA-65\nANU QRNG Entropie"
        QuantumStatus.CLASSICAL_FALLBACK ->
            "🔒 PQC AKTIV (offline)\nML-KEM-768 + ML-DSA-65\nLokal generierte Entropie"
        QuantumStatus.INITIALIZING -> "⏳ Initialisiere Quantensystem..."
        QuantumStatus.ERROR -> "⚠ Quantum-System Fehler"
    }
}
