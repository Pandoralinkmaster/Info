package com.pandora.jayjay

import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.Debug
import android.util.Log
import kotlinx.coroutines.*
import java.io.File
import java.security.MessageDigest
import java.util.concurrent.CopyOnWriteArrayList

/**
 * CodeIntegrityGuard – JayJay überwacht ihren eigenen Code
 *
 * Der Fokus liegt auf den HANDYS (besonders dem CEO-Handy als Herz).
 * Egal welche anderen Geräte im Netzwerk sind – die Handy-APK ist das
 * Zentrum, und genau dieser Code wird permanent gegen Manipulation geschützt.
 *
 * JayJay erkennt, wenn jemand versucht:
 *   • CODE_TAMPERING     den App-Code zu verändern (Signatur/Checksumme passt nicht)
 *   • APP_REPURPOSING    die App umzupacken / Package-Namen zu ändern
 *   • CODE_INJECTION     Code einzuschleusen (Frida, Xposed, LSPosed, Substrate)
 *   • DEBUGGER_ATTACHED  den Code zu debuggen / zu tracen / zu analysieren
 *
 * Wird etwas erkannt, meldet JayJay es an die AttackDefenseEngine und
 * informiert Finn. Bei kritischer Manipulation kann der Dead-Man's-Switch
 * ausgelöst werden (App sperrt sich / löscht sensible Daten).
 *
 * Wichtig: Die erwartete Signatur (FINN_CERT_SHA256) muss nach dem ersten
 * offiziellen Build einmalig gesetzt werden. Solange sie leer ist, lernt
 * JayJay die aktuelle Signatur als Referenz ("Trust on first run").
 *
 * CEO: Finn Jona Thorsten Lischke
 */
class CodeIntegrityGuard(private val context: Context) {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    /** Wird gesetzt von AppModule, damit Funde gemeldet werden können */
    var defenseEngine: AttackDefenseEngine? = null

    /** Callback an JayJay/Finn bei kritischem Fund */
    var onCriticalTamper: ((String) -> Unit)? = null

    private var baselineSignature: String? = null
    private var baselinePackage: String?   = null
    @Volatile private var monitoring = false
    // Thread-sicher: Monitoring-Loop (quickScan) und on-demand fullScan laufen parallel
    private val findings = CopyOnWriteArrayList<String>()

    companion object {
        private const val TAG = "CodeIntegrity"

        /**
         * Erwarteter SHA-256 der App-Signatur (Finn's Cert).
         * Leer = Trust-on-first-run: erste Signatur wird als Referenz gelernt.
         * Nach offiziellem Release-Build hier den echten Hash eintragen.
         */
        private const val FINN_CERT_SHA256 = ""

        private const val EXPECTED_PACKAGE = "com.pandora"

        // Bekannte Hooking-/Injection-Frameworks
        private val INJECTION_PACKAGES = listOf(
            "de.robv.android.xposed.installer",   // Xposed
            "org.lsposed.manager",                // LSPosed
            "com.saurik.substrate",               // Cydia Substrate
            "io.va.exposed",                      // VirtualXposed
            "me.weishu.exp",                      // TaiChi / EdXposed
        )

        // Frida-Artefakte (Code-Injection zur Laufzeit)
        private val FRIDA_ARTIFACTS = listOf(
            "frida-server", "frida-agent", "frida-gadget",
            "re.frida.server", "gum-js-loop", "gmain",
        )

        // Verdächtige Library-Pfade die auf Injection hindeuten
        private val SUSPICIOUS_LIBS = listOf(
            "libfrida", "libxposed", "libsubstrate", "libriru",
        )
    }

    // ── Start ───────────────────────────────────────────────────────────────

    /**
     * Startet die kontinuierliche Code-Überwachung.
     * Erst sofortiger Vollcheck, dann alle 30s ein Schnellcheck.
     */
    fun startMonitoring() {
        if (monitoring) return
        monitoring = true
        captureBaseline()

        scope.launch {
            fullScan()                       // sofort beim Start
            while (monitoring && isActive) {
                delay(30_000)
                quickScan()                  // alle 30s
            }
        }
        Log.i(TAG, "Code-Integritätsüberwachung gestartet (Fokus: Handy-APK)")
    }

    fun stopMonitoring() { monitoring = false }

    // ── Baseline (Referenz) ───────────────────────────────────────────────────

    private fun captureBaseline() {
        baselinePackage   = context.packageName
        baselineSignature = computeSignatureHash()
        Log.i(TAG, "Referenz erfasst: pkg=${baselinePackage}, sig=${baselineSignature?.take(12)}…")
    }

    // ── Vollscan (alle Prüfungen) ─────────────────────────────────────────────

    suspend fun fullScan(): List<String> = withContext(Dispatchers.IO) {
        findings.clear()

        checkSignature()        // App-Signatur unverändert?
        checkPackageName()      // Package-Name = com.pandora?
        checkInstaller()        // aus vertrauenswürdiger Quelle?
        checkDebugger()         // Debugger angehängt?
        checkInjectionApps()    // Xposed/LSPosed installiert?
        checkFridaArtifacts()   // Frida läuft?
        checkSuspiciousLibs()   // verdächtige Libraries geladen?
        checkDebuggableFlag()   // App als debuggable gebaut?

        if (findings.isEmpty()) {
            Log.i(TAG, "✓ Code-Integrität OK – kein Manipulationsversuch")
        } else {
            Log.w(TAG, "⚠ ${findings.size} Integritäts-Funde")
        }
        findings.toList()
    }

    /** Schnellcheck für die Dauerüberwachung (nur Laufzeit-Indikatoren) */
    private suspend fun quickScan() = withContext(Dispatchers.IO) {
        checkDebugger()
        checkFridaArtifacts()
        checkSuspiciousLibs()
    }

    // ── Einzelne Prüfungen ────────────────────────────────────────────────────

    /** Signatur unverändert? Schützt vor Umpacken & Re-Signieren */
    private fun checkSignature() {
        val current = computeSignatureHash() ?: return
        val expected = FINN_CERT_SHA256.ifEmpty { baselineSignature }

        if (expected != null && current != expected) {
            report(
                AttackType.CODE_TAMPERING, ThreatLevel.CRITICAL,
                "App-Signatur verändert! Erwartet ${expected.take(12)}…, ist ${current.take(12)}… " +
                "→ App wurde re-signiert/umgepackt."
            )
        }
    }

    /** Package-Name verändert? Schützt vor Zweckentfremdung/Klonen */
    private fun checkPackageName() {
        val pkg = context.packageName
        // Strikt gegen den festen Release-Namen prüfen – ein umgepacktes
        // Klon-APK trägt einen anderen Package-Namen und wird so erkannt.
        if (pkg != EXPECTED_PACKAGE) {
            report(
                AttackType.APP_REPURPOSING, ThreatLevel.CRITICAL,
                "Package-Name ist '$pkg' statt '$EXPECTED_PACKAGE' → App wurde geklont/zweckentfremdet."
            )
        }
    }

    /** Aus vertrauenswürdiger Quelle installiert? */
    private fun checkInstaller() {
        val installer = runCatching {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R)
                context.packageManager.getInstallSourceInfo(context.packageName).installingPackageName
            else
                @Suppress("DEPRECATION")
                context.packageManager.getInstallerPackageName(context.packageName)
        }.getOrNull()
        Log.d(TAG, "Installer: $installer")
        // Nur protokollieren – Sideload ist bei Pandora gewollt (kein eigener Fund)
    }

    /** Debugger/Tracer angehängt? */
    private fun checkDebugger() {
        if (Debug.isDebuggerConnected() || Debug.waitingForDebugger()) {
            report(
                AttackType.DEBUGGER_ATTACHED, ThreatLevel.HIGH,
                "Debugger angehängt – jemand versucht den Code zur Laufzeit zu analysieren."
            )
        }
        // TracerPid aus /proc/self/status (ptrace-Erkennung)
        runCatching {
            File("/proc/self/status").readLines()
                .firstOrNull { it.startsWith("TracerPid:") }
                ?.substringAfter(":")?.trim()?.toIntOrNull()
                ?.let { if (it != 0) report(
                    AttackType.DEBUGGER_ATTACHED, ThreatLevel.HIGH,
                    "Prozess wird getract (TracerPid=$it) – Code-Analyse-Versuch."
                ) }
        }
    }

    /** Hooking-Frameworks installiert? (Xposed/LSPosed/Substrate) */
    private fun checkInjectionApps() {
        val pm = context.packageManager
        INJECTION_PACKAGES.forEach { pkg ->
            runCatching {
                pm.getPackageInfo(pkg, 0)
                report(
                    AttackType.CODE_INJECTION, ThreatLevel.CRITICAL,
                    "Hooking-Framework erkannt: $pkg → kann Code einschleusen."
                )
            }
        }
    }

    /** Frida-Artefakte zur Laufzeit? (Code-Injection-Tool) */
    private fun checkFridaArtifacts() {
        // Geladene Maps nach Frida durchsuchen
        runCatching {
            val maps = File("/proc/self/maps").readText().lowercase()
            FRIDA_ARTIFACTS.forEach { artifact ->
                if (maps.contains(artifact.lowercase())) {
                    report(
                        AttackType.CODE_INJECTION, ThreatLevel.CRITICAL,
                        "Frida erkannt ('$artifact' im Speicher) → aktiver Code-Injection-Versuch."
                    )
                }
            }
        }
        // Typische Frida-Ports prüfen (27042 = Standard)
        runCatching {
            val sock = java.net.Socket()
            sock.connect(java.net.InetSocketAddress("127.0.0.1", 27042), 200)
            sock.close()
            report(
                AttackType.CODE_INJECTION, ThreatLevel.CRITICAL,
                "Frida-Server lauscht auf Port 27042 → Code-Injection aktiv."
            )
        }
    }

    /** Verdächtige Libraries im Adressraum? */
    private fun checkSuspiciousLibs() {
        runCatching {
            val maps = File("/proc/self/maps").readText().lowercase()
            SUSPICIOUS_LIBS.forEach { lib ->
                if (maps.contains(lib)) {
                    report(
                        AttackType.CODE_INJECTION, ThreatLevel.HIGH,
                        "Verdächtige Library geladen: $lib → möglicher Injection-Versuch."
                    )
                }
            }
        }
    }

    /** App als debuggable gebaut? (sollte im Release NIE sein) */
    private fun checkDebuggableFlag() {
        val debuggable = (context.applicationInfo.flags and
                android.content.pm.ApplicationInfo.FLAG_DEBUGGABLE) != 0
        if (debuggable) {
            report(
                AttackType.CODE_TAMPERING, ThreatLevel.MEDIUM,
                "App ist als 'debuggable' markiert – im Release ein Manipulationsindiz."
            )
        }
    }

    // ── Signatur-Hash berechnen ───────────────────────────────────────────────

    private fun computeSignatureHash(): String? = runCatching {
        val pm = context.packageManager
        val sigs = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            val info = pm.getPackageInfo(context.packageName, PackageManager.GET_SIGNING_CERTIFICATES)
            info.signingInfo?.apkContentsSigners
        } else {
            @Suppress("DEPRECATION")
            pm.getPackageInfo(context.packageName, PackageManager.GET_SIGNATURES).signatures
        } ?: return null

        val md = MessageDigest.getInstance("SHA-256")
        sigs.forEach { md.update(it.toByteArray()) }
        md.digest().joinToString("") { "%02x".format(it) }
    }.getOrNull()

    // ── Fund melden ───────────────────────────────────────────────────────────

    private fun report(type: AttackType, level: ThreatLevel, description: String) {
        if (description in findings) return
        findings.add(description)
        Log.e(TAG, "🛡 INTEGRITÄTS-VERLETZUNG [$type/$level]: $description")

        defenseEngine?.recordCodeTampering(type, level, description)

        if (level == ThreatLevel.CRITICAL) {
            onCriticalTamper?.invoke(description)
        }
    }

    // ── Bericht für JayJay/Finn ───────────────────────────────────────────────

    fun getIntegrityReport(): String = buildString {
        appendLine("🔐 CODE-INTEGRITÄT – Pandora (Handy-APK)")
        appendLine("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
        appendLine("Überwachung: ${if (monitoring) "AKTIV" else "inaktiv"}")
        appendLine("Package: ${context.packageName}")
        appendLine("Signatur: ${baselineSignature?.take(16)}…")
        appendLine("Referenz-Modus: ${if (FINN_CERT_SHA256.isEmpty()) "Trust-on-first-run" else "fixierter Cert-Hash"}")
        appendLine("")
        if (findings.isEmpty()) {
            appendLine("✓ Kein Manipulationsversuch erkannt.")
            appendLine("✓ Niemand kann Code einschleusen oder verändern.")
        } else {
            appendLine("⚠ ${findings.size} Funde:")
            findings.forEach { appendLine("• $it") }
        }
    }

    fun isClean(): Boolean = findings.isEmpty()
    fun getFindings(): List<String> = findings.toList()
}
