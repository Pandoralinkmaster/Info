package com.pandora.ui.screens

import androidx.compose.runtime.Composable
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.pandora.core.ConfigManager

@Composable
fun PandoraNavHost(
    config: ConfigManager,
    onRequestSsdPicker: () -> Unit,
) {
    val nav = rememberNavController()
    val startDest = if (config.isSetupComplete()) "dashboard" else "setup"

    fun go(route: String) = nav.navigate(route) { launchSingleTop = true }

    NavHost(navController = nav, startDestination = startDest) {
        composable("setup") {
            SetupScreen(
                config = config,
                onRequestSsdPicker = onRequestSsdPicker,
                onSetupComplete = { nav.navigate("dashboard") { popUpTo("setup") { inclusive = true } } }
            )
        }
        composable("dashboard") {
            DashboardScreen(
                config = config,
                onNavigateAdmin = { go("admin") },
                onNavigateJayJay = { go("jayjay") },
                onNavigateMesh = { go("mesh") },
                onNavigateWallet = { go("wallet") },
                onNavigateShop = { go("shop") },
                onNavigateSystem = { go("system") },
                onNavigateStorage = { go("storage") },
                onNavigateBackup = { go("backup") },
                onNavigatePermissions = { go("permissions") },
                onNavigateSecurity = { go("security") },
                onNavigateNetwork = { go("network") },
                onNavigateApps = { go("apps") },
                onNavigateSettings = { go("settings") },
                onNavigateLogs = { go("logs") },
                onNavigateCompute = { go("compute") },
                onNavigateScan = { go("scan") },
                onNavigateBuildings = { go("buildings") },
                onNavigateOnion = { go("onion") },
                onNavigateWireGuard = { go("wireguard") },
            )
        }

        composable("admin") { AdminScreen(onBack = { nav.popBackStack() }) }
        composable("jayjay") { JayJayScreen(onBack = { nav.popBackStack() }) }
        composable("mesh") { MeshScreen(onBack = { nav.popBackStack() }) }
        composable("wallet") { WalletScreen(onBack = { nav.popBackStack() }) }
        composable("shop") { ShopScreen(onBack = { nav.popBackStack() }) }

        composable("system") { PandoraSystemScreen(onBack = { nav.popBackStack() }) }
        composable("storage") { PandoraStorageScreen(config = config, onRequestSsdPicker = onRequestSsdPicker, onBack = { nav.popBackStack() }) }
        composable("backup") { PandoraBackupScreen(onBack = { nav.popBackStack() }) }
        composable("permissions") { PandoraPermissionsScreen(onBack = { nav.popBackStack() }) }
        composable("security") { PandoraSecurityScreen(onBack = { nav.popBackStack() }) }
        composable("network") { PandoraNetworkScreen(onBack = { nav.popBackStack() }) }
        composable("apps") { PandoraAppsScreen(onBack = { nav.popBackStack() }) }
        composable("settings") { PandoraSettingsScreen(config = config, onBack = { nav.popBackStack() }) }
        composable("logs") { PandoraLogsScreen(onBack = { nav.popBackStack() }) }
        composable("compute") { PandoraComputeScreen(onBack = { nav.popBackStack() }) }
        composable("scan") { PandoraScanScreen(onBack = { nav.popBackStack() }) }
        composable("buildings") { PandoraBuildingsScreen(onBack = { nav.popBackStack() }) }
        composable("onion") { PandoraOnionScreen(onBack = { nav.popBackStack() }) }
        composable("wireguard") { PandoraWireGuardScreen(onBack = { nav.popBackStack() }) }
    }
}
