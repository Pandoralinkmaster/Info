package com.pandora.jayjay

import android.content.Context
import android.net.wifi.WifiManager
import android.util.Log
import kotlinx.coroutines.*
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.serialization.Serializable
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import com.pandora.database.SsdStorageManager
import java.io.File
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.Socket

/**
 * NetworkIntelligence – JayJay analysiert FREMDE Netzwerke bis ins kleinste Detail
 *
 * Während der JayJayNetworkScanner nur die eigenen Pandora-Knoten sucht,
 * seziert dieses Modul JEDES Netzwerk in das sich das CEO-Handy einklinkt:
 *
 *   • Jedes Gerät (IP, MAC, Hersteller via OUI, Hostname, Latenz)
 *   • Jeden offenen Port + den dahinterliegenden Dienst (Banner-Grabbing)
 *   • Geräteklasse ableiten (Router, Kamera, Drucker, NAS, IoT, PC, Handy…)
 *   • Betriebssystem grob schätzen (Port-Signaturen)
 *   • Sicherheitslage bewerten (offene/unsichere Dienste → Risiko)
 *   • Netzwerk-Charakter ableiten (Zuhause / Büro / Öffentlich / Feindlich)
 *
 * UND: JayJay LERNT. Jedes analysierte Netzwerk wird als Fingerprint
 * gespeichert. Beim Wiedersehen erkennt sie es, vergleicht und leitet ab,
 * was sich verändert hat (neues Gerät? offener Port? = Anomalie).
 * Funde mit Risiko gehen an die AttackDefenseEngine.
 *
 * Fokus bleibt das Handy: die Analyse läuft auf dem CEO-Handy, das jedes
 * fremde Netz beim Betreten durchleuchtet.
 *
 * CEO: Finn Jona Thorsten Lischke
 */

@Serializable
data class PortService(
    val port: Int,
    val service: String,
    val banner: String = "",
    val secure: Boolean = true,
)

@Serializable
data class AnalyzedHost(
    val ip: String,
    val mac: String = "",
    val vendor: String = "",            // aus MAC-OUI abgeleitet
    val hostname: String = "",
    val deviceClass: String = "unbekannt", // Router/Kamera/Drucker/NAS/IoT/PC/Phone…
    val osGuess: String = "",
    val latencyMs: Long = 0,
    val openPorts: List<PortService> = emptyList(),
    val riskScore: Int = 0,             // 0–100
    val riskNotes: List<String> = emptyList(),
)

@Serializable
data class NetworkFingerprint(
    val ssid: String,
    val bssid: String,
    val subnet: String,
    val gatewayIp: String,
    val hostCount: Int,
    val deviceClasses: Map<String, Int> = emptyMap(),
    val character: String = "unbekannt", // Zuhause/Büro/Öffentlich/Feindlich
    val avgRisk: Int = 0,
    val firstSeen: Long = System.currentTimeMillis(),
    val lastSeen: Long = System.currentTimeMillis(),
    val seenCount: Int = 1,
    val hostSignature: Set<String> = emptySet(), // IPs+offene Ports zum Vergleich
)

@Serializable
data class NetworkAnalysis(
    val fingerprint: NetworkFingerprint,
    val hosts: List<AnalyzedHost>,
    val derived: List<String>,           // abgeleitete Erkenntnisse
    val anomalies: List<String>,         // Veränderungen ggü. letztem Besuch
    val analyzedAt: Long = System.currentTimeMillis(),
)

@Serializable
private data class IntelMemory(
    val networks: MutableMap<String, NetworkFingerprint> = mutableMapOf(),
)

class NetworkIntelligence(
    private val context: Context,
    private val ssd: SsdStorageManager,
) {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val json  = Json { ignoreUnknownKeys = true; prettyPrint = true }

    var defenseEngine: AttackDefenseEngine? = null

    @Volatile private var memory = IntelMemory()
    private val memLock  = Any()      // schützt die memory-Map (Lesen/Schreiben/Serialisieren)
    private val runMutex = Mutex()    // nur EINE Analyse gleichzeitig (kein Parallel-Scan-Sturm)

    // Gelerntes Netz-Wissen beim Start laden – Analyse wartet via initJob.join()
    private val initJob = scope.launch { loadMemory() }

    companion object {
        private const val TAG = "NetIntel"
        private const val MEM_FILE = "network_intel.json"
        private const val WORKERS  = 48
        private const val CONNECT_TIMEOUT = 400

        // Ports → Dienst + ob als sicher gilt
        private val PORTS = linkedMapOf(
            21   to ("FTP" to false),
            22   to ("SSH" to true),
            23   to ("Telnet" to false),       // unverschlüsselt = Risiko
            25   to ("SMTP" to true),
            53   to ("DNS" to true),
            80   to ("HTTP" to true),
            110  to ("POP3" to false),
            139  to ("NetBIOS" to false),
            143  to ("IMAP" to true),
            443  to ("HTTPS" to true),
            445  to ("SMB" to false),          // SMB offen = Risiko
            554  to ("RTSP" to true),          // Kameras
            631  to ("IPP/Drucker" to true),
            1883 to ("MQTT" to false),         // IoT
            3389 to ("RDP" to false),          // Fernzugriff = Risiko
            5000 to ("UPnP/NAS" to true),
            5060 to ("SIP/VoIP" to true),
            8080 to ("HTTP-Alt" to true),
            8443 to ("HTTPS-Alt" to true),
            9100 to ("Drucker-RAW" to true),
            32400 to ("Plex/Media" to true),
            2323 to ("Telnet-IoT" to false),   // Mirai-typisch = hohes Risiko
        )

        // MAC-OUI (erste 3 Bytes) → Hersteller (Kurzliste der häufigsten)
        private val OUI = mapOf(
            "FCFBFB" to "Cisco", "001A11" to "Google", "3C5AB4" to "Google",
            "B827EB" to "Raspberry Pi", "DCA632" to "Raspberry Pi",
            "001788" to "Philips Hue", "ECFABC" to "Shelly", "A4CF12" to "Espressif/IoT",
            "D8A011" to "TP-Link", "50C7BF" to "TP-Link", "F4F26D" to "TP-Link",
            "00156D" to "Ubiquiti", "FCECDA" to "Ubiquiti",
            "AC8112" to "Samsung", "5CF8A1" to "Samsung", "8C7712" to "Samsung",
            "F0D1A9" to "Apple", "A85C2C" to "Apple", "DC2B2A" to "Apple",
            "001132" to "Synology", "0011D8" to "ASUSTek", "AC220B" to "ASUSTek",
            "002618" to "AVM/FritzBox", "3810D5" to "AVM/FritzBox",
        )
    }

    // ── Laden / Speichern ────────────────────────────────────────────────────

    suspend fun loadMemory() = withContext(Dispatchers.IO) {
        val raw = ssd.readFile("jayjay", MEM_FILE)
        if (raw != null) {
            val loaded = runCatching { json.decodeFromString<IntelMemory>(raw) }.getOrNull()
            if (loaded != null) {
                synchronized(memLock) { memory = loaded }
                Log.i(TAG, "Netz-Intel geladen: ${loaded.networks.size} bekannte Netzwerke")
            }
        }
    }

    private suspend fun saveMemory() {
        // Snapshot unter Lock serialisieren (verhindert CME beim Encode), dann I/O ohne Lock
        val snapshot = synchronized(memLock) { json.encodeToString(memory) }
        withContext(Dispatchers.IO) { ssd.writeFile("jayjay", MEM_FILE, snapshot) }
    }

    // ── Hauptanalyse ──────────────────────────────────────────────────────────

    /**
     * Durchleuchtet das aktuelle Netzwerk vollständig und leitet Erkenntnisse ab.
     */
    suspend fun analyzeCurrentNetwork(): NetworkAnalysis = runMutex.withLock {
        initJob.join()  // sicherstellen, dass gelerntes Wissen geladen ist
        withContext(Dispatchers.IO) {
        val wm      = context.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
        val localIp = ipToString(wm.connectionInfo.ipAddress)
        val subnet  = localIp.substringBeforeLast(".")
        val ssid    = runCatching { wm.connectionInfo.ssid?.trim('"') ?: "" }.getOrDefault("")
        val bssid   = runCatching { wm.connectionInfo.bssid ?: "" }.getOrDefault("")
        val gateway = "$subnet.1"

        Log.i(TAG, "Analysiere fremdes Netz: '$ssid' ($subnet.0/24)")

        // ARP-Tabelle für MAC-Adressen vorab lesen
        val arp = readArpTable()

        // Alle Hosts parallel tief analysieren
        val hosts = (1..254).chunked(WORKERS).flatMap { chunk ->
            chunk.map { i -> async { analyzeHost("$subnet.$i", arp) } }.awaitAll().filterNotNull()
        }.sortedBy { it.ip.substringAfterLast(".").toIntOrNull() ?: 0 }

        // Fingerprint bauen
        val classes  = hosts.groupingBy { it.deviceClass }.eachCount()
        val avgRisk  = if (hosts.isEmpty()) 0 else hosts.sumOf { it.riskScore } / hosts.size
        val signature = hosts.map { "${it.ip}:${it.openPorts.joinToString("/") { p -> p.port.toString() }}" }.toSet()

        val character = deriveCharacter(ssid, hosts, classes)

        val key      = bssid.ifEmpty { "$ssid@$subnet" }

        // Kritische Sektion: vorherigen Stand lesen, Fingerprint bauen, speichern
        val previous = synchronized(memLock) { memory.networks[key] }
        val anomalies = if (previous != null) deriveAnomalies(previous, signature, hosts) else emptyList()

        val fingerprint = NetworkFingerprint(
            ssid = ssid, bssid = bssid, subnet = "$subnet.0/24", gatewayIp = gateway,
            hostCount = hosts.size, deviceClasses = classes, character = character, avgRisk = avgRisk,
            firstSeen = previous?.firstSeen ?: System.currentTimeMillis(),
            lastSeen = System.currentTimeMillis(),
            seenCount = (previous?.seenCount ?: 0) + 1,
            hostSignature = signature,
        )

        // Lernen: Fingerprint speichern
        synchronized(memLock) { memory.networks[key] = fingerprint }
        saveMemory()

        // Erkenntnisse ableiten
        val derived = deriveInsights(fingerprint, hosts, previous)

        // Risiken an die Verteidigung melden
        reportRisks(ssid, hosts, anomalies)

        NetworkAnalysis(fingerprint, hosts, derived, anomalies)
        }
    }

    // ── Einzel-Host tief analysieren ───────────────────────────────────────────

    private suspend fun analyzeHost(ip: String, arp: Map<String, String>): AnalyzedHost? = withContext(Dispatchers.IO) {
        val t0 = System.currentTimeMillis()
        val reachable = runCatching { InetAddress.getByName(ip).isReachable(500) }.getOrDefault(false)

        // Port-Scan – auch wenn ping geblockt ist, kann ein Port offen sein
        val openPorts = PORTS.entries.mapNotNull { (port, def) ->
            if (probePort(ip, port)) {
                val banner = grabBanner(ip, port)
                PortService(port, def.first, banner, def.second)
            } else null
        }
        val latency = System.currentTimeMillis() - t0

        if (!reachable && openPorts.isEmpty()) return@withContext null

        val mac    = arp[ip] ?: ""
        val vendor = vendorFromMac(mac)
        val hostname = runCatching { InetAddress.getByName(ip).canonicalHostName }.getOrDefault(ip)
            .takeIf { it != ip } ?: ""

        val deviceClass = classifyDevice(openPorts, vendor, hostname)
        val osGuess     = guessOs(openPorts, vendor)
        val (risk, notes) = assessRisk(openPorts, deviceClass)

        AnalyzedHost(
            ip = ip, mac = mac, vendor = vendor, hostname = hostname,
            deviceClass = deviceClass, osGuess = osGuess, latencyMs = latency,
            openPorts = openPorts, riskScore = risk, riskNotes = notes,
        )
    }

    private fun probePort(ip: String, port: Int): Boolean = runCatching {
        Socket().use { s ->
            s.connect(InetSocketAddress(ip, port), CONNECT_TIMEOUT)
            true
        }
    }.getOrDefault(false)

    /** Banner-Grabbing: erste Antwort des Dienstes lesen (Dienst-Version) */
    private fun grabBanner(ip: String, port: Int): String = runCatching {
        Socket().use { s ->
            s.connect(InetSocketAddress(ip, port), CONNECT_TIMEOUT)
            s.soTimeout = 500
            // Bei HTTP einen minimalen Request senden
            if (port == 80 || port == 8080 || port == 8443) {
                s.getOutputStream().write("HEAD / HTTP/1.0\r\n\r\n".toByteArray())
                s.getOutputStream().flush()
            }
            val buf = ByteArray(256)
            val n = s.getInputStream().read(buf)
            if (n > 0) String(buf, 0, n).lines().firstOrNull()?.take(80)?.trim() ?: "" else ""
        }
    }.getOrDefault("")

    // ── Ableitung / Klassifikation ─────────────────────────────────────────────

    private fun classifyDevice(ports: List<PortService>, vendor: String, hostname: String): String {
        val p = ports.map { it.port }.toSet()
        val h = hostname.lowercase()
        return when {
            554 in p || "cam" in h || "ipcam" in h -> "Kamera"
            631 in p || 9100 in p || "print" in h              -> "Drucker"
            445 in p && 5000 in p || "nas" in h || vendor == "Synology" -> "NAS"
            1883 in p || 2323 in p || vendor.contains("Espressif") ||
                vendor == "Shelly" || vendor == "Philips Hue"  -> "IoT-Gerät"
            53 in p && 80 in p || vendor.contains("FritzBox") ||
                vendor == "TP-Link" || vendor == "Ubiquiti" || vendor == "ASUSTek" -> "Router/AP"
            3389 in p || (445 in p && 139 in p)                -> "Windows-PC"
            22 in p && 80 in p                                 -> "Server/Linux"
            vendor == "Apple" || vendor == "Samsung" || vendor == "Google" -> "Smartphone/Tablet"
            32400 in p                                          -> "Media-Server"
            p.isEmpty()                                         -> "stilles Gerät"
            else                                               -> "unbekannt"
        }
    }

    private fun guessOs(ports: List<PortService>, vendor: String): String {
        val p = ports.map { it.port }.toSet()
        return when {
            3389 in p || 445 in p && 139 in p -> "Windows"
            vendor == "Apple"                 -> "macOS/iOS"
            vendor == "Samsung" || vendor == "Google" -> "Android"
            vendor == "Raspberry Pi"          -> "Linux (Raspbian)"
            22 in p                           -> "Linux/Unix"
            else                              -> ""
        }
    }

    private fun assessRisk(ports: List<PortService>, deviceClass: String): Pair<Int, List<String>> {
        var risk = 0
        val notes = mutableListOf<String>()
        val portSet = ports.map { it.port }.toSet()
        ports.forEach { ps ->
            if (!ps.secure) {
                risk += 25
                notes.add("Unsicherer Dienst offen: ${ps.service} (Port ${ps.port})")
            }
        }
        // Telnet/2323 = klassische IoT-Hintertür (Mirai) → muss die Melde-Schwelle (60) reißen
        if (23 in portSet || 2323 in portSet) {
            risk += 40; notes.add("Telnet offen – klassische IoT-Schwachstelle (Mirai)")
        }
        if (3389 in portSet) { risk += 20; notes.add("RDP exponiert – Fernzugriff-Risiko") }
        return minOf(100, risk) to notes
    }

    private fun deriveCharacter(ssid: String, hosts: List<AnalyzedHost>, classes: Map<String, Int>): String {
        val s = ssid.lowercase()
        return when {
            // Hochrisiko zuerst – darf nicht von "Zuhause"/"Büro" verdeckt werden
            hosts.any { it.riskScore >= 60 } -> "Feindlich/Unsicher"
            hosts.size > 30 || (classes["Drucker"] ?: 0) > 1 || (classes["Server/Linux"] ?: 0) > 2 -> "Büro/Firma"
            s.contains("free") || s.contains("public") || s.contains("gast") ||
                s.contains("hotel") || (s.contains("wifi") && hosts.size > 15) -> "Öffentlich (Vorsicht!)"
            (classes["IoT-Gerät"] ?: 0) >= 1 || (classes["Smartphone/Tablet"] ?: 0) >= 1 -> "Zuhause"
            else -> "unbekannt"
        }
    }

    private fun deriveInsights(
        fp: NetworkFingerprint, hosts: List<AnalyzedHost>, previous: NetworkFingerprint?,
    ): List<String> {
        val out = mutableListOf<String>()
        out.add("Netz-Charakter: ${fp.character}")
        out.add("${fp.hostCount} Geräte, durchschn. Risiko ${fp.avgRisk}/100")
        fp.deviceClasses.entries.sortedByDescending { it.value }.forEach { out.add("${it.value}× ${it.key}") }
        hosts.filter { it.riskScore >= 50 }.forEach {
            out.add("⚠ ${it.ip} (${it.deviceClass}, ${it.vendor}): Risiko ${it.riskScore}")
        }
        if (previous != null) out.add("Bereits ${previous.seenCount}× gesehen – Erstkontakt ${ageText(previous.firstSeen)}")
        else out.add("Neues Netzwerk – Fingerprint gespeichert, JayJay erkennt es künftig wieder.")
        return out
    }

    private fun deriveAnomalies(
        previous: NetworkFingerprint, currentSig: Set<String>, hosts: List<AnalyzedHost>,
    ): List<String> {
        val out = mutableListOf<String>()
        val newHosts = currentSig - previous.hostSignature
        val goneHosts = previous.hostSignature - currentSig
        newHosts.forEach { out.add("Neu aufgetaucht: ${it.substringBefore(":")}") }
        if (goneHosts.size <= 5) goneHosts.forEach { out.add("Verschwunden: ${it.substringBefore(":")}") }
        return out
    }

    // ── Risiken an Verteidigung melden ─────────────────────────────────────────

    private fun reportRisks(ssid: String, hosts: List<AnalyzedHost>, anomalies: List<String>) {
        hosts.filter { it.riskScore >= 60 }.forEach { h ->
            defenseEngine?.recordCodeTampering(
                AttackType.PORT_SCAN, ThreatLevel.MEDIUM,
                "Riskantes Gerät in '$ssid': ${h.ip} (${h.deviceClass}) – ${h.riskNotes.firstOrNull() ?: "offene Dienste"}"
            )
        }
    }

    // ── Hilfen ─────────────────────────────────────────────────────────────────

    private fun readArpTable(): Map<String, String> = runCatching {
        File("/proc/net/arp").readLines().drop(1).mapNotNull { line ->
            val cols = line.trim().split(Regex("\\s+"))
            if (cols.size >= 4 && cols[3] != "00:00:00:00:00:00") cols[0] to cols[3].uppercase() else null
        }.toMap()
    }.getOrDefault(emptyMap())

    private fun vendorFromMac(mac: String): String {
        if (mac.isBlank()) return ""
        val oui = mac.replace(":", "").take(6).uppercase()
        return OUI[oui] ?: ""
    }

    private fun ipToString(ip: Int): String = String.format(
        "%d.%d.%d.%d", ip and 0xff, ip shr 8 and 0xff, ip shr 16 and 0xff, ip shr 24 and 0xff)

    private fun ageText(ts: Long): String {
        val d = (System.currentTimeMillis() - ts) / 86_400_000L
        return if (d <= 0) "heute" else "vor ${d}d"
    }

    // ── Bericht für JayJay/Finn ────────────────────────────────────────────────

    fun summarize(a: NetworkAnalysis): String = buildString {
        val fp = a.fingerprint
        appendLine("🔬 NETZWERK-ANALYSE: ${fp.ssid.ifEmpty { fp.subnet }}")
        appendLine("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
        appendLine("Charakter: ${fp.character} | Risiko Ø ${fp.avgRisk}/100")
        appendLine("Geräte: ${fp.hostCount}")
        fp.deviceClasses.entries.sortedByDescending { it.value }.forEach {
            appendLine("  • ${it.value}× ${it.key}")
        }
        appendLine()
        appendLine("Abgeleitet:")
        a.derived.forEach { appendLine("  – $it") }
        if (a.anomalies.isNotEmpty()) {
            appendLine()
            appendLine("⚠ Veränderungen seit letztem Besuch:")
            a.anomalies.take(8).forEach { appendLine("  – $it") }
        }
        appendLine()
        appendLine("Auffällige Geräte:")
        a.hosts.filter { it.openPorts.isNotEmpty() }.sortedByDescending { it.riskScore }.take(10).forEach { h ->
            val ports = h.openPorts.joinToString(",") { "${it.port}/${it.service}" }
            appendLine("  ${h.ip} [${h.deviceClass}${if (h.vendor.isNotEmpty()) "/${h.vendor}" else ""}] $ports")
        }
    }

    fun getKnownNetworks(): List<NetworkFingerprint> =
        synchronized(memLock) { memory.networks.values.toList() }.sortedByDescending { it.lastSeen }
}
