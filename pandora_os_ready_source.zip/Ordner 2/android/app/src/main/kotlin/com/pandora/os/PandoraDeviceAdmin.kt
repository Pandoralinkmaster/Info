package com.pandora.os

import android.app.admin.DeviceAdminReceiver
import android.content.Context
import android.content.Intent
import android.util.Log

/**
 * Pandora OS – Device Administrator
 *
 * Gibt Pandora OS erhöhte Systemberechtigungen:
 *   - Sperrbildschirm verwalten (Passwort-Policy setzen)
 *   - Gerät sofort sperren (lockNow)
 *   - Kamera sperren (optional, CEO-Befehl)
 *   - Remote-Wipe (nur CEO: Finn Jona Thorsten Lischke)
 *   - Sichere Zertifikate installieren
 *
 * Aktivierung: Nutzer stimmt Nutzungsbedingungen zu →
 * PandoraOsTermsActivity startet DevicePolicyManager-Intent →
 * Nutzer bestätigt im System-Dialog → Pandora ist Admin.
 */
class PandoraDeviceAdmin : DeviceAdminReceiver() {

    companion object {
        private const val TAG = "PandoraDeviceAdmin"
    }

    override fun onEnabled(context: Context, intent: Intent) {
        Log.i(TAG, "✓ Pandora OS – Device Administrator aktiviert")
        PandoraOsManager.onAdminEnabled(context)
    }

    override fun onDisabled(context: Context, intent: Intent) {
        Log.w(TAG, "⚠ Pandora OS – Device Administrator deaktiviert")
        PandoraOsManager.onAdminDisabled(context)
    }

    override fun onPasswordFailed(context: Context, intent: Intent) {
        Log.w(TAG, "Falsches Passwort – möglicher Einbruchsversuch")
        PandoraOsManager.onPasswordFailed(context)
    }

    override fun onPasswordSucceeded(context: Context, intent: Intent) {
        Log.d(TAG, "Entsperrt")
    }

    override fun onLockTaskModeEntering(context: Context, intent: Intent, pkg: String) {
        Log.i(TAG, "Lock Task Mode: $pkg")
    }

    override fun onLockTaskModeExiting(context: Context, intent: Intent) {
        Log.i(TAG, "Lock Task Mode beendet")
    }
}
