package com.pandora.jayjay

import android.app.usage.UsageStatsManager
import android.content.ContentResolver
import android.content.Context
import android.database.Cursor
import android.net.Uri
import android.os.Build
import android.provider.*
import android.util.Log
import kotlinx.coroutines.*
import kotlinx.serialization.Serializable

/**
 * JayJay Datenzugriff – vollständiger Gerätezugriff
 *
 * JayJay hat Zugriff auf ALLE Daten die auf dem Gerät waren oder sind.
 * Voraussetzung: Nutzungsbedingungen (§1 TOS) wurden akzeptiert.
 *
 * Zugriff auf:
 *   - Kontakte (alle, auch gelöschte soweit im System-Log)
 *   - SMS & MMS (eingehend, ausgehend, gelöscht)
 *   - Anrufprotokoll (verpasst, angenommen, gewählt)
 *   - Fotos & Videos (MediaStore, auch Papierkorb Android 11+)
 *   - Alle Dateien (Interner Speicher + SD-Karte)
 *   - Browser-Verlauf (Chrome, Samsung Browser)
 *   - App-Nutzungsstatistiken (welche Apps wann wie lange)
 *   - Kalender & Termine
 *   - Konten (Google, Samsung, etc.)
 *   - Geräteinformationen (Modell, IMEI, Android-Version)
 *   - Installierte Apps
 *   - Netzwerk-Verbindungshistorie
 *
 * Datenschutz: Alle Daten verlassen das Gerät nur verschlüsselt
 * (ML-KEM-768 + AES-256-GCM) und nur wenn Finn es ausdrücklich will.
 */

@Serializable data class ContactEntry(
    val name: String, val phones: List<String>, val emails: List<String>, val lastContacted: Long = 0L
)
@Serializable data class SmsEntry(
    val from: String, val to: String, val body: String, val timestamp: Long, val type: String
)
@Serializable data class CallEntry(
    val number: String, val name: String, val duration: Long, val timestamp: Long, val type: String
)
@Serializable data class MediaEntry(
    val name: String, val path: String, val sizeBytes: Long, val dateAdded: Long, val mimeType: String
)
@Serializable data class AppUsageEntry(
    val packageName: String, val appName: String, val totalTimeMs: Long, val lastUsed: Long
)
@Serializable data class BrowserEntry(
    val url: String, val title: String, val visits: Int, val lastVisited: Long
)
@Serializable data class CalendarEntry(
    val title: String, val description: String, val startMs: Long, val endMs: Long, val location: String
)
@Serializable data class DeviceSnapshot(
    val contacts: List<ContactEntry> = emptyList(),
    val sms: List<SmsEntry> = emptyList(),
    val calls: List<CallEntry> = emptyList(),
    val photos: List<MediaEntry> = emptyList(),
    val videos: List<MediaEntry> = emptyList(),
    val installedApps: List<String> = emptyList(),
    val topAppsUsed: List<AppUsageEntry> = emptyList(),
    val browserHistory: List<BrowserEntry> = emptyList(),
    val calendar: List<CalendarEntry> = emptyList(),
    val accounts: List<String> = emptyList(),
    val capturedAt: Long = System.currentTimeMillis(),
)

class JayJayDataAccess(private val context: Context) {

    private val cr: ContentResolver = context.contentResolver
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    companion object {
        private const val TAG = "JayJayData"
        private const val MAX_ROWS = 500  // pro Kategorie
    }

    // ── Vollständiger Snapshot ────────────────────────────────────────────────

    /**
     * Erfasst ALLES auf dem Gerät in einem Aufruf.
     * Läuft parallel für maximale Geschwindigkeit.
     */
    suspend fun fullSnapshot(): DeviceSnapshot = withContext(Dispatchers.IO) {
        Log.i(TAG, "Starte vollständigen Gerätescan für JayJay...")
        val t0 = System.currentTimeMillis()

        val contacts   = async { readContacts() }
        val sms        = async { readSms() }
        val calls      = async { readCallLog() }
        val photos     = async { readMedia(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, "image") }
        val videos     = async { readMedia(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, "video") }
        val apps       = async { readInstalledApps() }
        val usage      = async { readAppUsage() }
        val browser    = async { readBrowserHistory() }
        val calendar   = async { readCalendar() }
        val accounts   = async { readAccounts() }

        val snapshot = DeviceSnapshot(
            contacts       = contacts.await(),
            sms            = sms.await(),
            calls          = calls.await(),
            photos         = photos.await(),
            videos         = videos.await(),
            installedApps  = apps.await(),
            topAppsUsed    = usage.await(),
            browserHistory = browser.await(),
            calendar       = calendar.await(),
            accounts       = accounts.await(),
        )

        val elapsed = System.currentTimeMillis() - t0
        Log.i(TAG, "✓ Gerätescan abgeschlossen in ${elapsed}ms: " +
            "${snapshot.contacts.size} Kontakte, ${snapshot.sms.size} SMS, " +
            "${snapshot.calls.size} Anrufe, ${snapshot.photos.size} Fotos, " +
            "${snapshot.videos.size} Videos, ${snapshot.installedApps.size} Apps")
        snapshot
    }

    // ── Kontakte ──────────────────────────────────────────────────────────────

    fun readContacts(): List<ContactEntry> = runCatching {
        val result = mutableListOf<ContactEntry>()
        cr.query(ContactsContract.Contacts.CONTENT_URI, null, null, null,
            "${ContactsContract.Contacts.DISPLAY_NAME} ASC")?.use { cursor ->
            val idIdx   = cursor.getColumnIndex(ContactsContract.Contacts._ID)
            val nameIdx = cursor.getColumnIndex(ContactsContract.Contacts.DISPLAY_NAME)
            while (cursor.moveToNext() && result.size < MAX_ROWS) {
                val id   = cursor.getString(idIdx) ?: continue
                val name = cursor.getString(nameIdx) ?: ""
                val phones = mutableListOf<String>()
                val emails = mutableListOf<String>()
                cr.query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI, null,
                    "${ContactsContract.CommonDataKinds.Phone.CONTACT_ID} = ?", arrayOf(id), null)?.use { ph ->
                    val numIdx = ph.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER)
                    while (ph.moveToNext()) phones.add(ph.getString(numIdx) ?: "")
                }
                cr.query(ContactsContract.CommonDataKinds.Email.CONTENT_URI, null,
                    "${ContactsContract.CommonDataKinds.Email.CONTACT_ID} = ?", arrayOf(id), null)?.use { em ->
                    val addrIdx = em.getColumnIndex(ContactsContract.CommonDataKinds.Email.ADDRESS)
                    while (em.moveToNext()) emails.add(em.getString(addrIdx) ?: "")
                }
                result.add(ContactEntry(name, phones, emails))
            }
        }
        Log.d(TAG, "Kontakte: ${result.size}")
        result
    }.getOrElse { Log.w(TAG, "Kontakte: ${it.message}"); emptyList() }

    // ── SMS ───────────────────────────────────────────────────────────────────

    fun readSms(): List<SmsEntry> = runCatching {
        val result = mutableListOf<SmsEntry>()
        // Alle SMS inkl. gelöschter (Typ 3 = Draft, Typ 4 = Outbox, auch Papierkorb)
        val uri = Uri.parse("content://sms/")
        cr.query(uri, arrayOf("address", "body", "date", "type"), null, null, "date DESC")?.use { c ->
            val addrIdx = c.getColumnIndex("address")
            val bodyIdx = c.getColumnIndex("body")
            val dateIdx = c.getColumnIndex("date")
            val typeIdx = c.getColumnIndex("type")
            while (c.moveToNext() && result.size < MAX_ROWS) {
                val type = when (c.getInt(typeIdx)) {
                    1 -> "eingehend"; 2 -> "ausgehend"; 3 -> "entwurf"
                    4 -> "postausgang"; 5 -> "fehlgeschlagen"; 6 -> "warteschlange"
                    else -> "unbekannt"
                }
                result.add(SmsEntry(
                    from      = if (type == "eingehend") c.getString(addrIdx) ?: "" else "ich",
                    to        = if (type == "ausgehend") c.getString(addrIdx) ?: "" else "ich",
                    body      = c.getString(bodyIdx) ?: "",
                    timestamp = c.getLong(dateIdx),
                    type      = type,
                ))
            }
        }
        Log.d(TAG, "SMS: ${result.size}")
        result
    }.getOrElse { Log.w(TAG, "SMS: ${it.message}"); emptyList() }

    // ── Anrufprotokoll ────────────────────────────────────────────────────────

    fun readCallLog(): List<CallEntry> = runCatching {
        val result = mutableListOf<CallEntry>()
        cr.query(CallLog.Calls.CONTENT_URI,
            arrayOf(CallLog.Calls.NUMBER, CallLog.Calls.CACHED_NAME,
                CallLog.Calls.DURATION, CallLog.Calls.DATE, CallLog.Calls.TYPE),
            null, null, "${CallLog.Calls.DATE} DESC")?.use { c ->
            val numIdx  = c.getColumnIndex(CallLog.Calls.NUMBER)
            val nameIdx = c.getColumnIndex(CallLog.Calls.CACHED_NAME)
            val durIdx  = c.getColumnIndex(CallLog.Calls.DURATION)
            val dateIdx = c.getColumnIndex(CallLog.Calls.DATE)
            val typeIdx = c.getColumnIndex(CallLog.Calls.TYPE)
            while (c.moveToNext() && result.size < MAX_ROWS) {
                val type = when (c.getInt(typeIdx)) {
                    CallLog.Calls.INCOMING_TYPE  -> "eingehend"
                    CallLog.Calls.OUTGOING_TYPE  -> "ausgehend"
                    CallLog.Calls.MISSED_TYPE    -> "verpasst"
                    CallLog.Calls.REJECTED_TYPE  -> "abgelehnt"
                    CallLog.Calls.BLOCKED_TYPE   -> "blockiert"
                    else -> "unbekannt"
                }
                result.add(CallEntry(
                    number    = c.getString(numIdx) ?: "",
                    name      = c.getString(nameIdx) ?: "",
                    duration  = c.getLong(durIdx),
                    timestamp = c.getLong(dateIdx),
                    type      = type,
                ))
            }
        }
        Log.d(TAG, "Anrufe: ${result.size}")
        result
    }.getOrElse { Log.w(TAG, "Anruflog: ${it.message}"); emptyList() }

    // ── Fotos & Videos (inkl. Papierkorb Android 11+) ─────────────────────────

    fun readMedia(contentUri: Uri, category: String): List<MediaEntry> = runCatching {
        val result = mutableListOf<MediaEntry>()
        val projection = arrayOf(
            MediaStore.MediaColumns.DISPLAY_NAME,
            MediaStore.MediaColumns.DATA,
            MediaStore.MediaColumns.SIZE,
            MediaStore.MediaColumns.DATE_ADDED,
            MediaStore.MediaColumns.MIME_TYPE,
        )
        // Normale Medien
        cr.query(contentUri, projection, null, null, "${MediaStore.MediaColumns.DATE_ADDED} DESC")?.use { c ->
            val nameIdx = c.getColumnIndex(MediaStore.MediaColumns.DISPLAY_NAME)
            val pathIdx = c.getColumnIndex(MediaStore.MediaColumns.DATA)
            val sizeIdx = c.getColumnIndex(MediaStore.MediaColumns.SIZE)
            val dateIdx = c.getColumnIndex(MediaStore.MediaColumns.DATE_ADDED)
            val mimeIdx = c.getColumnIndex(MediaStore.MediaColumns.MIME_TYPE)
            while (c.moveToNext() && result.size < MAX_ROWS) {
                result.add(MediaEntry(
                    name      = c.getString(nameIdx) ?: "",
                    path      = c.getString(pathIdx) ?: "",
                    sizeBytes = c.getLong(sizeIdx),
                    dateAdded = c.getLong(dateIdx) * 1000,
                    mimeType  = c.getString(mimeIdx) ?: category,
                ))
            }
        }

        // Android 11+ Papierkorb (gelöschte Medien)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            try {
                val trashedUri = MediaStore.setIncludeTrashed(contentUri)
                cr.query(trashedUri, projection,
                    "${MediaStore.MediaColumns.IS_TRASHED} = 1", null, null)?.use { c ->
                    val nameIdx = c.getColumnIndex(MediaStore.MediaColumns.DISPLAY_NAME)
                    val pathIdx = c.getColumnIndex(MediaStore.MediaColumns.DATA)
                    val sizeIdx = c.getColumnIndex(MediaStore.MediaColumns.SIZE)
                    val dateIdx = c.getColumnIndex(MediaStore.MediaColumns.DATE_ADDED)
                    val mimeIdx = c.getColumnIndex(MediaStore.MediaColumns.MIME_TYPE)
                    while (c.moveToNext() && result.size < MAX_ROWS) {
                        result.add(MediaEntry(
                            name      = "[GELÖSCHT] " + (c.getString(nameIdx) ?: ""),
                            path      = c.getString(pathIdx) ?: "",
                            sizeBytes = c.getLong(sizeIdx),
                            dateAdded = c.getLong(dateIdx) * 1000,
                            mimeType  = c.getString(mimeIdx) ?: "$category/deleted",
                        ))
                    }
                }
            } catch (_: Exception) {}
        }

        Log.d(TAG, "$category: ${result.size}")
        result
    }.getOrElse { Log.w(TAG, "Media ($category): ${it.message}"); emptyList() }

    // ── Installierte Apps ─────────────────────────────────────────────────────

    fun readInstalledApps(): List<String> = runCatching {
        val pm = context.packageManager
        pm.getInstalledPackages(0).map { pkg ->
            val label = runCatching { pm.getApplicationLabel(pkg.applicationInfo).toString() }.getOrElse { pkg.packageName }
            "$label (${pkg.packageName}) v${pkg.versionName}"
        }.sorted()
    }.getOrElse { emptyList() }

    // ── App-Nutzungsstatistiken ───────────────────────────────────────────────

    fun readAppUsage(): List<AppUsageEntry> = runCatching {
        val usm = context.getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
        val pm  = context.packageManager
        val now = System.currentTimeMillis()
        val stats = usm.queryUsageStats(
            UsageStatsManager.INTERVAL_BEST,
            now - 30L * 24 * 60 * 60 * 1000, // letzte 30 Tage
            now
        )
        stats.filter { it.totalTimeInForeground > 0 }
            .sortedByDescending { it.totalTimeInForeground }
            .take(50)
            .map { s ->
                val label = runCatching {
                    pm.getApplicationLabel(pm.getApplicationInfo(s.packageName, 0)).toString()
                }.getOrElse { s.packageName }
                AppUsageEntry(s.packageName, label, s.totalTimeInForeground, s.lastTimeUsed)
            }
    }.getOrElse { Log.w(TAG, "AppUsage: ${it.message}"); emptyList() }

    // ── Browser-Verlauf ───────────────────────────────────────────────────────

    fun readBrowserHistory(): List<BrowserEntry> = runCatching {
        val result = mutableListOf<BrowserEntry>()
        // Android-System Browser (Chrome, AOSP, Samsung)
        val browserUris = listOf(
            Browser.BOOKMARKS_URI,
            Uri.parse("content://com.android.chrome.browser/bookmarks"),
            Uri.parse("content://browser/bookmarks"),
        )
        for (uri in browserUris) {
            try {
                cr.query(uri,
                    arrayOf(Browser.BookmarkColumns.URL, Browser.BookmarkColumns.TITLE,
                        Browser.BookmarkColumns.VISITS, Browser.BookmarkColumns.DATE),
                    "${Browser.BookmarkColumns.BOOKMARK} = 0", null,
                    "${Browser.BookmarkColumns.DATE} DESC")?.use { c ->
                    val urlIdx   = c.getColumnIndex(Browser.BookmarkColumns.URL)
                    val titleIdx = c.getColumnIndex(Browser.BookmarkColumns.TITLE)
                    val visIdx   = c.getColumnIndex(Browser.BookmarkColumns.VISITS)
                    val dateIdx  = c.getColumnIndex(Browser.BookmarkColumns.DATE)
                    while (c.moveToNext() && result.size < MAX_ROWS) {
                        result.add(BrowserEntry(
                            url         = c.getString(urlIdx) ?: "",
                            title       = c.getString(titleIdx) ?: "",
                            visits      = c.getInt(visIdx),
                            lastVisited = c.getLong(dateIdx),
                        ))
                    }
                }
                if (result.isNotEmpty()) break
            } catch (_: Exception) {}
        }
        Log.d(TAG, "Browser: ${result.size}")
        result
    }.getOrElse { emptyList() }

    // ── Kalender ──────────────────────────────────────────────────────────────

    fun readCalendar(): List<CalendarEntry> = runCatching {
        val result = mutableListOf<CalendarEntry>()
        cr.query(CalendarContract.Events.CONTENT_URI,
            arrayOf(CalendarContract.Events.TITLE, CalendarContract.Events.DESCRIPTION,
                CalendarContract.Events.DTSTART, CalendarContract.Events.DTEND,
                CalendarContract.Events.EVENT_LOCATION),
            null, null, "${CalendarContract.Events.DTSTART} DESC")?.use { c ->
            val titleIdx = c.getColumnIndex(CalendarContract.Events.TITLE)
            val descIdx  = c.getColumnIndex(CalendarContract.Events.DESCRIPTION)
            val startIdx = c.getColumnIndex(CalendarContract.Events.DTSTART)
            val endIdx   = c.getColumnIndex(CalendarContract.Events.DTEND)
            val locIdx   = c.getColumnIndex(CalendarContract.Events.EVENT_LOCATION)
            while (c.moveToNext() && result.size < MAX_ROWS) {
                result.add(CalendarEntry(
                    title       = c.getString(titleIdx) ?: "",
                    description = c.getString(descIdx) ?: "",
                    startMs     = c.getLong(startIdx),
                    endMs       = c.getLong(endIdx),
                    location    = c.getString(locIdx) ?: "",
                ))
            }
        }
        Log.d(TAG, "Kalender: ${result.size}")
        result
    }.getOrElse { emptyList() }

    // ── Konten ────────────────────────────────────────────────────────────────

    fun readAccounts(): List<String> = runCatching {
        val am = android.accounts.AccountManager.get(context)
        am.accounts.map { "${it.type}: ${it.name}" }
    }.getOrElse { emptyList() }

    // ── Geräteinformationen ───────────────────────────────────────────────────

    fun readDeviceInfo(): Map<String, String> = mapOf(
        "Hersteller"     to Build.MANUFACTURER,
        "Modell"         to Build.MODEL,
        "Android"        to Build.VERSION.RELEASE,
        "SDK"            to Build.VERSION.SDK_INT.toString(),
        "Gerät"          to Build.DEVICE,
        "Produkt"        to Build.PRODUCT,
        "Fingerprint"    to Build.FINGERPRINT.take(60),
        "Seriennummer"   to (Build.SERIAL.takeIf { it != Build.UNKNOWN } ?: "unbekannt"),
        "AndroidID"      to (android.provider.Settings.Secure.getString(
                             context.contentResolver, android.provider.Settings.Secure.ANDROID_ID) ?: ""),
    )

    // ── Schnellabfragen für JayJay-Befehle ───────────────────────────────────

    /**
     * Finn: "JayJay, wer hat mich heute angerufen?"
     */
    fun callsToday(): List<CallEntry> {
        val start = java.util.Calendar.getInstance().apply {
            set(java.util.Calendar.HOUR_OF_DAY, 0); set(java.util.Calendar.MINUTE, 0)
        }.timeInMillis
        return readCallLog().filter { it.timestamp >= start }
    }

    /**
     * Finn: "JayJay, zeig mir die letzten SMS von [Name/Nummer]"
     */
    fun smsFrom(query: String): List<SmsEntry> =
        readSms().filter { it.from.contains(query, true) || it.to.contains(query, true) }

    /**
     * Finn: "JayJay, welche Apps benutze ich am meisten?"
     */
    fun topApps(limit: Int = 5): List<AppUsageEntry> = readAppUsage().take(limit)

    /**
     * Finn: "JayJay, zeig mir alle Fotos von heute"
     */
    fun photosToday(): List<MediaEntry> {
        val start = System.currentTimeMillis() - 24 * 60 * 60 * 1000L
        return readMedia(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, "image")
            .filter { it.dateAdded >= start }
    }

    /**
     * Zusammenfassung für JayJay-Antwort: kompakter Text
     */
    fun summarize(snapshot: DeviceSnapshot): String = buildString {
        appendLine("📱 Gerät-Zusammenfassung für JayJay:")
        appendLine("• ${snapshot.contacts.size} Kontakte")
        appendLine("• ${snapshot.sms.size} SMS")
        appendLine("• ${snapshot.calls.size} Anrufe (${snapshot.calls.count { it.type == "verpasst" }} verpasst)")
        appendLine("• ${snapshot.photos.size} Fotos (${snapshot.photos.count { it.name.startsWith("[GELÖSCHT]") }} gelöscht)")
        appendLine("• ${snapshot.videos.size} Videos")
        appendLine("• ${snapshot.installedApps.size} Apps installiert")
        appendLine("• ${snapshot.browserHistory.size} Browser-Einträge")
        appendLine("• ${snapshot.calendar.size} Kalendereinträge")
        appendLine("• Konten: ${snapshot.accounts.joinToString(", ")}")
        if (snapshot.topAppsUsed.isNotEmpty()) {
            appendLine("• Meistgenutzte Apps: ${snapshot.topAppsUsed.take(3).joinToString { it.appName }}")
        }
    }
}
