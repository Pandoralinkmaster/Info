package com.pandora.os

import android.content.Context
import android.net.wifi.WifiManager
import android.util.Log
import kotlinx.coroutines.*
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import java.net.InetAddress
import java.util.concurrent.TimeUnit

/**
 * PandoraOS – IoT-Controller
 *
 * JayJay steuert über dieses Modul ALLE Smart-Home-Geräte im Netzwerk:
 *
 *   🔆 Lampen (Philips Hue, IKEA TRÅDFRI, Govee, TP-Link Kasa, Shelly)
 *   🌡  Thermostate (Nest, Ecobee, HomeMatic)
 *   🔌 Steckdosen (SmartPlug, Shelly, AVM FRITZ!DECT)
 *   📺 Fernseher (Samsung SmartTV, LG WebOS)
 *   🎮 Konsolen (über API: PlayStation, Xbox — soweit verfügbar)
 *   🖥  PCs (via Wake-on-LAN + SSH wenn aktiviert)
 *   🔒 Schlösser, Kameras, Alarmanlagen (REST-API)
 *   🏠 Alle Geräte mit HTTP-REST-API im gleichen Netzwerk
 *
 * Erkennung: automatischer Scan des lokalen Netzwerks nach bekannten
 * IoT-Ports (80, 443, 8080, 8123, 9123, etc.)
 *
 * Pandora ist der zentrale Hub — JayJay fragt, PandoraOS steuert.
 */

enum class IoTDeviceType {
    SMART_BULB,       // Intelligente Lampe (RGBW)
    SMART_SWITCH,     // Schaltbare Steckdose
    THERMOSTAT,       // Thermostat / Heizung
    SMART_TV,         // Fernseher
    PC,               // Computer (WoL + SSH)
    GAMING_CONSOLE,   // PlayStation/Xbox
    ROUTER,           // Router / Gateway
    CAMERA,           // Überwachungskamera
    SPEAKER,          // Lautsprecher (Sonos, etc.)
    HOME_HUB,         // Home Assistant, openHAB, etc.
    GENERIC_HTTP,     // Generisches HTTP-Gerät
}

enum class IoTProtocol {
    PHILIPS_HUE,      // Hue Bridge REST API
    IKEA_TRADFRI,     // COAP/Gateway API
    GOVEE_LOCAL,      // Govee LAN Control
    SHELLY,           // Shelly REST API (sehr einfach)
    TPLINK_KASA,      // TP-Link Kasa
    HOME_ASSISTANT,   // Home Assistant REST API
    SAMSUNG_TV,       // Samsung SmartThings / Tizen API
    WAKE_ON_LAN,      // Magic Packet für PC
    GENERIC_REST,     // Generische REST-Befehle
}

@Serializable
data class IoTDevice(
    val id:          String,
    val name:        String,
    val type:        IoTDeviceType,
    val protocol:    IoTProtocol,
    val ip:          String,
    val port:        Int,
    val apiKey:      String = "",       // Wenn benötigt (Hue Bridge, HA Token)
    val isOnline:    Boolean = false,
    val isOn:        Boolean = false,
    val brightness:  Int = 100,         // 0–100%
    val colorR:      Int = 255,
    val colorG:      Int = 255,
    val colorB:      Int = 255,
    val lastSeen:    Long = System.currentTimeMillis(),
)

@Serializable
data class IoTCommand(
    val deviceId: String,
    val action:   String,               // "on", "off", "brightness", "color", "wol", etc.
    val value:    String = "",
)

class PandoraIoTController(private val context: Context) {

    private val scope  = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val json   = Json { ignoreUnknownKeys = true; prettyPrint = false }
    private val http   = OkHttpClient.Builder()
        .connectTimeout(3, TimeUnit.SECONDS)
        .readTimeout(5, TimeUnit.SECONDS)
        .build()

    private val knownDevices  = mutableMapOf<String, IoTDevice>()
    private var homeAssistantUrl = ""
    private var homeAssistantToken = ""

    companion object {
        private const val TAG = "PandoraIoT"

        // Bekannte IoT-Ports für auto-Erkennung
        private val IOT_PORTS = listOf(
            80, 443, 8080, 8123,  // Home Assistant
            8888,                  // Govee
            9123,                  // Philips Hue Bridge
            3000,                  // Custom APIs
        )

        // Philips Hue-typische Ports
        private const val HUE_PORT = 80
        // Home Assistant default
        private const val HA_PORT  = 8123
    }

    // ── Netzwerk-Scan nach IoT-Geräten ───────────────────────────────────────

    /**
     * Scannt das lokale Netzwerk nach bekannten IoT-Geräten.
     * Findet Lampen, Schalter, Hubs, TVs, etc. automatisch.
     */
    suspend fun discoverDevices(): List<IoTDevice> = withContext(Dispatchers.IO) {
        val localIp = getLocalIp()
        val subnet  = localIp.substringBeforeLast(".")
        Log.i(TAG, "IoT-Scan: $subnet.* ...")

        val found = (1..254).map { i ->
            async {
                val ip = "$subnet.$i"
                tryDetectIoTDevice(ip)
            }
        }.awaitAll().filterNotNull()

        found.forEach { knownDevices[it.id] = it }
        Log.i(TAG, "IoT-Geräte gefunden: ${found.size}")
        found
    }

    private suspend fun tryDetectIoTDevice(ip: String): IoTDevice? = withContext(Dispatchers.IO) {
        try {
            if (!InetAddress.getByName(ip).isReachable(500)) return@withContext null

            // Philips Hue Bridge
            tryHueBridge(ip)?.let { return@withContext it }

            // Home Assistant
            tryHomeAssistant(ip)?.let { return@withContext it }

            // Shelly-Gerät
            tryShelly(ip)?.let { return@withContext it }

            // Generische HTTP-API
            tryGenericHttp(ip)?.let { return@withContext it }

            null
        } catch (_: Exception) { null }
    }

    private fun tryHueBridge(ip: String): IoTDevice? = runCatching {
        val resp = http.newCall(
            Request.Builder().url("http://$ip:$HUE_PORT/api").build()
        ).execute()
        if (resp.isSuccessful) {
            val body = resp.body?.string() ?: ""
            if ("hue" in body.lowercase() || "bridge" in body.lowercase()) {
                return IoTDevice(
                    id = "hue_$ip", name = "Philips Hue Bridge ($ip)",
                    type = IoTDeviceType.HOME_HUB, protocol = IoTProtocol.PHILIPS_HUE,
                    ip = ip, port = HUE_PORT, isOnline = true,
                )
            }
        }
        null
    }.getOrNull()

    private fun tryHomeAssistant(ip: String): IoTDevice? = runCatching {
        val resp = http.newCall(
            Request.Builder().url("http://$ip:$HA_PORT/api/").build()
        ).execute()
        if (resp.isSuccessful || resp.code == 401) {
            // HA antwortet mit 401 wenn kein Token → trotzdem erkannt
            homeAssistantUrl = "http://$ip:$HA_PORT"
            return IoTDevice(
                id = "ha_$ip", name = "Home Assistant ($ip)",
                type = IoTDeviceType.HOME_HUB, protocol = IoTProtocol.HOME_ASSISTANT,
                ip = ip, port = HA_PORT, isOnline = true,
            )
        }
        null
    }.getOrNull()

    private fun tryShelly(ip: String): IoTDevice? = runCatching {
        val resp = http.newCall(
            Request.Builder().url("http://$ip/shelly").build()
        ).execute()
        if (resp.isSuccessful) {
            val body = resp.body?.string() ?: ""
            if ("shelly" in body.lowercase()) {
                val name = if ("light" in body.lowercase()) "Shelly Lampe" else "Shelly Steckdose"
                val type = if ("light" in body.lowercase()) IoTDeviceType.SMART_BULB else IoTDeviceType.SMART_SWITCH
                return IoTDevice(
                    id = "shelly_$ip", name = "$name ($ip)",
                    type = type, protocol = IoTProtocol.SHELLY,
                    ip = ip, port = 80, isOnline = true,
                )
            }
        }
        null
    }.getOrNull()

    private fun tryGenericHttp(ip: String): IoTDevice? = runCatching {
        val resp = http.newCall(Request.Builder().url("http://$ip/").build()).execute()
        if (resp.isSuccessful) {
            val body = resp.body?.string()?.lowercase() ?: ""
            val type = when {
                "lamp" in body || "light" in body || "bulb" in body -> IoTDeviceType.SMART_BULB
                "plug" in body || "switch" in body || "socket" in body -> IoTDeviceType.SMART_SWITCH
                "thermostat" in body || "heiz" in body || "temperature" in body -> IoTDeviceType.THERMOSTAT
                "tv" in body || "television" in body || "samsung" in body -> IoTDeviceType.SMART_TV
                else -> return null
            }
            return IoTDevice(
                id = "http_$ip", name = "Gerät ($ip)", type = type,
                protocol = IoTProtocol.GENERIC_REST, ip = ip, port = 80, isOnline = true,
            )
        }
        null
    }.getOrNull()

    // ── Geräte steuern ────────────────────────────────────────────────────────

    /** Lampe/Gerät einschalten */
    suspend fun turnOn(deviceId: String): Boolean = sendCommand(deviceId, "on")

    /** Lampe/Gerät ausschalten */
    suspend fun turnOff(deviceId: String): Boolean = sendCommand(deviceId, "off")

    /** Helligkeit setzen (0–100) */
    suspend fun setBrightness(deviceId: String, percent: Int): Boolean =
        sendCommand(deviceId, "brightness", percent.toString())

    /** Farbe setzen (RGB 0–255) */
    suspend fun setColor(deviceId: String, r: Int, g: Int, b: Int): Boolean =
        sendCommand(deviceId, "color", "$r,$g,$b")

    /** PC via Wake-on-LAN aufwecken */
    suspend fun wakeOnLan(mac: String): Boolean = withContext(Dispatchers.IO) {
        try {
            val bytes = mac.split(":").map { it.toInt(16).toByte() }.toByteArray()
            val magic = ByteArray(102).also { buf ->
                for (i in 0..5) buf[i] = 0xFF.toByte()
                for (i in 1..16) System.arraycopy(bytes, 0, buf, 6 + (i - 1) * 6, 6)
            }
            val socket = java.net.DatagramSocket()
            socket.send(java.net.DatagramPacket(magic, magic.size,
                InetAddress.getByName("255.255.255.255"), 9))
            socket.close()
            Log.i(TAG, "WoL-Paket gesendet an $mac")
            true
        } catch (e: Exception) {
            Log.e(TAG, "WoL fehlgeschlagen: ${e.message}")
            false
        }
    }

    /** Alle Lichter ausschalten */
    suspend fun allLightsOff(): List<Boolean> = withContext(Dispatchers.IO) {
        knownDevices.values
            .filter { it.type == IoTDeviceType.SMART_BULB || it.type == IoTDeviceType.SMART_SWITCH }
            .map { async { turnOff(it.id) } }
            .awaitAll()
    }

    /** Alle Lichter einschalten */
    suspend fun allLightsOn(): List<Boolean> = withContext(Dispatchers.IO) {
        knownDevices.values
            .filter { it.type == IoTDeviceType.SMART_BULB || it.type == IoTDeviceType.SMART_SWITCH }
            .map { async { turnOn(it.id) } }
            .awaitAll()
    }

    private suspend fun sendCommand(deviceId: String, action: String, value: String = ""): Boolean =
        withContext(Dispatchers.IO) {
            val device = knownDevices[deviceId] ?: return@withContext false
            try {
                when (device.protocol) {
                    IoTProtocol.SHELLY       -> sendShellyCommand(device, action, value)
                    IoTProtocol.PHILIPS_HUE  -> sendHueCommand(device, action, value)
                    IoTProtocol.HOME_ASSISTANT -> sendHaCommand(device, action, value)
                    IoTProtocol.GENERIC_REST -> sendGenericCommand(device, action, value)
                    else -> false
                }
            } catch (e: Exception) {
                Log.w(TAG, "Befehl fehlgeschlagen ($deviceId.$action): ${e.message}")
                false
            }
        }

    // ── Protokoll-Implementierungen ───────────────────────────────────────────

    private fun sendShellyCommand(device: IoTDevice, action: String, value: String): Boolean {
        val url = when (action) {
            "on"         -> "http://${device.ip}/relay/0?turn=on"
            "off"        -> "http://${device.ip}/relay/0?turn=off"
            "brightness" -> "http://${device.ip}/light/0?brightness=$value"
            "color"      -> {
                val (r, g, b) = value.split(",").map { it.toInt() }
                "http://${device.ip}/light/0?red=$r&green=$g&blue=$b"
            }
            else         -> return false
        }
        return http.newCall(Request.Builder().url(url).build()).execute().isSuccessful
    }

    private fun sendHueCommand(device: IoTDevice, action: String, value: String): Boolean {
        val body = when (action) {
            "on"         -> """{"on":true}"""
            "off"        -> """{"on":false}"""
            "brightness" -> """{"on":true,"bri":${(value.toIntOrNull() ?: 100) * 254 / 100}}"""
            "color"      -> {
                val (r, g, b) = value.split(",").map { it.toInt() / 255.0 }
                """{"on":true,"xy":[${rgbToXy(r, g, b)}]}"""
            }
            else         -> return false
        }
        val url = "http://${device.ip}/api/${device.apiKey}/lights/1/state"
        val req = Request.Builder().url(url)
            .put(body.toRequestBody("application/json".toMediaType()))
            .build()
        return http.newCall(req).execute().isSuccessful
    }

    private fun sendHaCommand(device: IoTDevice, action: String, value: String): Boolean {
        if (homeAssistantUrl.isEmpty() || homeAssistantToken.isEmpty()) return false
        val service = when (action) {
            "on"  -> "turn_on"
            "off" -> "turn_off"
            else  -> "turn_on"
        }
        val body = """{"entity_id":"light.pandora"}"""
        val req  = Request.Builder()
            .url("$homeAssistantUrl/api/services/light/$service")
            .header("Authorization", "Bearer $homeAssistantToken")
            .post(body.toRequestBody("application/json".toMediaType()))
            .build()
        return http.newCall(req).execute().isSuccessful
    }

    private fun sendGenericCommand(device: IoTDevice, action: String, value: String): Boolean {
        val url = "http://${device.ip}/api/$action" + if (value.isNotEmpty()) "?value=$value" else ""
        return runCatching {
            http.newCall(Request.Builder().url(url).build()).execute().isSuccessful
        }.getOrElse { false }
    }

    private fun rgbToXy(r: Double, g: Double, b: Double): String {
        val rg = if (r > 0.04045) ((r + 0.055) / 1.055).pow(2.4) else r / 12.92
        val gg = if (g > 0.04045) ((g + 0.055) / 1.055).pow(2.4) else g / 12.92
        val bg = if (b > 0.04045) ((b + 0.055) / 1.055).pow(2.4) else b / 12.92
        val X  = rg * 0.664511 + gg * 0.154324 + bg * 0.162028
        val Y  = rg * 0.283881 + gg * 0.668433 + bg * 0.047685
        val Z  = rg * 0.000088 + gg * 0.072310 + bg * 0.986039
        val s  = X + Y + Z
        return if (s == 0.0) "0.3127,0.3290" else "${"%.4f".format(X / s)},${"%.4f".format(Y / s)}"
    }

    private fun Double.pow(n: Double) = Math.pow(this, n)

    // ── Home Assistant Token setzen (CEO-only) ────────────────────────────────

    fun configureHomeAssistant(url: String, token: String) {
        homeAssistantUrl   = url
        homeAssistantToken = token
        Log.i(TAG, "Home Assistant konfiguriert: $url")
    }

    // ── Status ────────────────────────────────────────────────────────────────

    fun getKnownDevices(): List<IoTDevice> = knownDevices.values.toList()
    fun addDevice(device: IoTDevice) { knownDevices[device.id] = device }

    private fun getLocalIp(): String {
        return try {
            val wm = context.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
            val ip = wm.connectionInfo.ipAddress
            String.format("%d.%d.%d.%d",
                ip and 0xff, ip shr 8 and 0xff, ip shr 16 and 0xff, ip shr 24 and 0xff)
        } catch (_: Exception) { "192.168.1.1" }
    }

    fun summarize(): String = buildString {
        val devices = getKnownDevices()
        appendLine("🏠 IoT-Geräte (${devices.size} gefunden):")
        if (devices.isEmpty()) {
            appendLine("• Kein IoT-Gerät im Netzwerk erkannt.")
            appendLine("• Scan starten: 'JayJay, scanne Smart Home'")
        } else {
            devices.groupBy { it.type }.forEach { (type, list) ->
                appendLine("${emojiFor(type)} $type (${list.size}):")
                list.forEach { d -> appendLine("  • ${d.name} [${if (d.isOn) "AN" else "AUS"}]") }
            }
        }
    }

    private fun emojiFor(type: IoTDeviceType) = when (type) {
        IoTDeviceType.SMART_BULB     -> "💡"
        IoTDeviceType.SMART_SWITCH   -> "🔌"
        IoTDeviceType.THERMOSTAT     -> "🌡"
        IoTDeviceType.SMART_TV       -> "📺"
        IoTDeviceType.PC             -> "🖥"
        IoTDeviceType.GAMING_CONSOLE -> "🎮"
        IoTDeviceType.ROUTER         -> "📡"
        IoTDeviceType.CAMERA         -> "📷"
        IoTDeviceType.SPEAKER        -> "🔊"
        IoTDeviceType.HOME_HUB       -> "🏠"
        IoTDeviceType.GENERIC_HTTP   -> "⚙"
    }
}
