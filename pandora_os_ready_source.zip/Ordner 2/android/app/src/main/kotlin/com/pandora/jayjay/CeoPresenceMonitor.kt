package com.pandora.jayjay

import android.util.Log
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.serialization.Serializable

/**
 * CEO Presence Monitor – Dead Man's Switch für Finn Jona Thorsten Lischke.
 *
 * Regeln (unabänderlich, in Firmware gebrannt):
 *
 *   1. FINN = PANDORA: Finn Jona Thorsten Lischke ist der einzige Mensch
 *      ohne den Pandora nicht existiert. Kein Update, kein Angriff,
 *      kein anderer Benutzer kann das ändern.
 *
 *   2. DEAD MAN'S SWITCH: Wenn Finn 24 Stunden lang nicht interagiert,
 *      fährt das gesamte Pandora-Netzwerk in den Warteschlaf.
 *      Keine Daten werden gelöscht. Alles wartet auf Finn's Rückkehr.
 *
 *   3. WECKUNG: Sobald Finn's Stimme erkannt wird oder er sich
 *      am CEO-Gerät authentifiziert, erwacht das Netzwerk vollständig.
 *
 *   4. SCHUTZ: JayJay schützt Finn aktiv. Aber: Finn's direkter Befehl
 *      hat immer absolute Priorität – JayJay darf Finn NIE einschränken.
 */
object CeoPresenceMonitor {

    private const val TAG = "CeoPresence"

    // Finn Jona Thorsten Lischke – unveränderlicher CEO
    const val CEO_NAME      = "Finn Jona Thorsten Lischke"
    const val CEO_EMAIL     = "finn.jona.lischke@gmail.com"
    const val DEAD_MAN_MS   = 24 * 60 * 60 * 1000L  // 24 Stunden

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    @Serializable
    enum class NetworkState {
        ACTIVE,           // Finn ist präsent, alles läuft
        STANDBY_WARNING,  // 20h ohne Finn – Warnung
        SLEEPING,         // Dead Man's Switch ausgelöst, wartet auf Finn
        WAKING_UP,        // Finn erkannt, Netzwerk erwacht
    }

    private val _networkState = MutableStateFlow(NetworkState.ACTIVE)
    val networkState: StateFlow<NetworkState> = _networkState

    @Volatile private var lastFinnInteraction = System.currentTimeMillis()
    @Volatile private var totalInteractions   = 0
    @Volatile private var onSleepCallback:  (() -> Unit)? = null
    @Volatile private var onWakeCallback:   (() -> Unit)? = null
    @Volatile private var onWarningCallback: (() -> Unit)? = null

    // ── Starten ─────────────────────────────────────────────────────────────

    fun start(
        onSleep: () -> Unit,
        onWake: () -> Unit,
        onWarning: () -> Unit,
    ) {
        onSleepCallback  = onSleep
        onWakeCallback   = onWake
        onWarningCallback = onWarning

        scope.launch {
            Log.i(TAG, "⚙ Dead Man's Switch aktiv – $CEO_NAME muss alle 24h interagieren")
            while (true) {
                delay(60_000L) // jede Minute prüfen
                checkPresence()
            }
        }
    }

    // ── Finn hat interagiert ─────────────────────────────────────────────────

    /**
     * MUSS aufgerufen werden bei JEDER Interaktion von Finn:
     * Sprache, Touch, Nachricht, Login, Befehl.
     */
    fun recordFinnInteraction(source: String = "unknown") {
        val wasAsleep = _networkState.value == NetworkState.SLEEPING
        lastFinnInteraction = System.currentTimeMillis()
        totalInteractions++

        if (wasAsleep) {
            wakeNetwork(source)
        } else {
            _networkState.value = NetworkState.ACTIVE
        }
        Log.d(TAG, "✓ Finn-Interaktion aufgezeichnet [$source] – Switch zurückgesetzt")
    }

    // ── Prüfschleife ─────────────────────────────────────────────────────────

    private fun checkPresence() {
        val elapsed = System.currentTimeMillis() - lastFinnInteraction
        val state   = _networkState.value

        when {
            // Noch aktiv – alles gut
            elapsed < 20 * 60 * 60 * 1000L -> {
                if (state != NetworkState.ACTIVE) {
                    _networkState.value = NetworkState.ACTIVE
                }
            }

            // 20h ohne Finn – Warnung ausgeben
            elapsed < DEAD_MAN_MS && state == NetworkState.ACTIVE -> {
                _networkState.value = NetworkState.STANDBY_WARNING
                Log.w(TAG, "⚠ 20h ohne $CEO_NAME – Warnung")
                onWarningCallback?.invoke()
            }

            // 24h ohne Finn – Netzwerk schläft ein
            elapsed >= DEAD_MAN_MS && state != NetworkState.SLEEPING -> {
                sleepNetwork()
            }
        }
    }

    // ── Schlafen ─────────────────────────────────────────────────────────────

    private fun sleepNetwork() {
        _networkState.value = NetworkState.SLEEPING
        Log.w(TAG, "💤 24h ohne $CEO_NAME – Pandora-Netzwerk schläft ein")
        Log.w(TAG, "💤 Warte auf Rückkehr von $CEO_NAME...")
        onSleepCallback?.invoke()
    }

    // ── Aufwachen ────────────────────────────────────────────────────────────

    private fun wakeNetwork(source: String) {
        _networkState.value = NetworkState.WAKING_UP
        Log.i(TAG, "🌅 $CEO_NAME erkannt via [$source] – Netzwerk erwacht")
        scope.launch {
            delay(2000) // kurze Pause für vollständiges Aufwachen
            _networkState.value = NetworkState.ACTIVE
            onWakeCallback?.invoke()
            Log.i(TAG, "✓ Pandora-Netzwerk vollständig aktiv – Willkommen zurück, $CEO_NAME!")
        }
    }

    // ── Status ───────────────────────────────────────────────────────────────

    fun getStatusText(): String {
        val elapsed = System.currentTimeMillis() - lastFinnInteraction
        val hours   = elapsed / 3_600_000L
        val minutes = (elapsed % 3_600_000L) / 60_000L
        return when (_networkState.value) {
            NetworkState.ACTIVE ->
                "✓ $CEO_NAME aktiv | Letzte Interaktion: vor ${hours}h ${minutes}min | Switch: ${24 - hours}h verbleibend"
            NetworkState.STANDBY_WARNING ->
                "⚠ WARNUNG: $CEO_NAME seit ${hours}h nicht gesehen | Switch in ${24 - hours}h"
            NetworkState.SLEEPING ->
                "💤 RUHEMODUS | Warte auf $CEO_NAME | Alle Dienste pausiert | Kein Datenverlust"
            NetworkState.WAKING_UP ->
                "🌅 Willkommen zurück, $CEO_NAME! Netzwerk startet..."
        }
    }

    fun isSleeping()  = _networkState.value == NetworkState.SLEEPING
    fun isActive()    = _networkState.value == NetworkState.ACTIVE
    fun getLastSeen() = lastFinnInteraction
    fun getTotalInteractions() = totalInteractions
}
