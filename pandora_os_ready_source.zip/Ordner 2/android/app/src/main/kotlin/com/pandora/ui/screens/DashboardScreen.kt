package com.pandora.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.pandora.core.ConfigManager
import com.pandora.visibility.HostVisibilityGate
import org.koin.compose.koinInject

@Composable
fun DashboardScreen(
    config: ConfigManager,
    onNavigateAdmin: () -> Unit,
    onNavigateJayJay: () -> Unit,
    onNavigateMesh: () -> Unit,
    onNavigateWallet: () -> Unit,
    onNavigateShop: () -> Unit,
    onNavigateSystem: () -> Unit = {},
    onNavigateStorage: () -> Unit = {},
    onNavigateBackup: () -> Unit = {},
    onNavigatePermissions: () -> Unit = {},
    onNavigateSecurity: () -> Unit = {},
    onNavigateNetwork: () -> Unit = {},
    onNavigateApps: () -> Unit = {},
    onNavigateSettings: () -> Unit = {},
    onNavigateLogs: () -> Unit = {},
    onNavigateCompute: () -> Unit = {},
    onNavigateScan: () -> Unit = {},
    onNavigateBuildings: () -> Unit = {},
    onNavigateOnion: () -> Unit = {},
    onNavigateWireGuard: () -> Unit = {},
) {
    val gate: HostVisibilityGate = koinInject()
    val gateState by gate.state.collectAsState()
    val bg = Color(0xFF07070D)
    val surface = Color(0xFF12121A)
    val accent = Color(0xFFE040FB)
    val cyan = Color(0xFF00BCD4)
    val green = Color(0xFF00E676)
    val red = Color(0xFFFF1744)

    Surface(modifier = Modifier.fillMaxSize(), color = bg) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(16.dp)
        ) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(
                        Brush.linearGradient(listOf(Color(0xFF23002F), Color(0xFF080811))),
                        RoundedCornerShape(24.dp)
                    )
                    .padding(18.dp)
            ) {
                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("PANDORA OS", color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.Black, letterSpacing = 2.sp)
                            Text("Home Shell · Systemzentrale · S24 Ultra", color = Color.White.copy(alpha = 0.72f), fontSize = 12.sp)
                        }
                        StatusPill(
                            text = if (gateState.isOpen) "HOST AKTIV" else "HOST GESPERRT",
                            color = if (gateState.isOpen) green else red
                        )
                    }
                    Spacer(Modifier.height(14.dp))
                    Text("Aktive Datenbank: Samsung Galaxy S24 Ultra", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    Text("M.2 SSD: nur Backup, Wiederherstellung und Archiv", color = Color.White.copy(alpha = 0.68f), fontSize = 12.sp)
                    Spacer(Modifier.height(10.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        SmallChip("Modus: ${config.appMode.name}", accent)
                        SmallChip("Setup: ${config.setupStatus.name}", cyan)
                    }
                }
            }

            Spacer(Modifier.height(16.dp))

            if (!gateState.isOpen) {
                Card(
                    colors = CardDefaults.cardColors(containerColor = surface),
                    border = BorderStroke(1.dp, red.copy(alpha = 0.45f)),
                    shape = RoundedCornerShape(18.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(Modifier.padding(16.dp)) {
                        Text("🔒 Host gesperrt", color = Color.White, fontWeight = FontWeight.Bold)
                        Text("Entsperre Pandora OS nur bewusst. Keine versteckten Aktionen.", color = Color.Gray, fontSize = 12.sp)
                        Spacer(Modifier.height(10.dp))
                        Button(
                            onClick = { gate.unlock("manual") },
                            colors = ButtonDefaults.buttonColors(containerColor = accent),
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(12.dp)
                        ) { Text("Pandora Host entsperren", fontWeight = FontWeight.Bold) }
                    }
                }
                Spacer(Modifier.height(16.dp))
            }

            SectionTitle("System")
            GridRow(
                OsTile("🏠", "Home", "Pandora OS Übersicht", accent, onNavigateSystem),
                OsTile("💾", "Storage", "S24 DB · M.2 Backup", cyan, onNavigateStorage)
            )
            GridRow(
                OsTile("🗄️", "Backup", "Sichern & Wiederherstellen", Color(0xFF00E676), onNavigateBackup),
                OsTile("🔐", "Berechtigungen", "Android-Freigaben", Color(0xFFFFD54F), onNavigatePermissions)
            )
            GridRow(
                OsTile("📋", "Logs", "Ereignisse & Status", Color(0xFFB388FF), onNavigateLogs),
                OsTile("⚙️", "Einstellungen", "Modus & Setup", Color(0xFF90CAF9), onNavigateSettings)
            )

            SectionTitle("Oberflächen")
            GridRow(
                OsTile("🤖", "JayJay", "KI-Konsole", accent, onNavigateJayJay),
                OsTile("🛡️", "Admin", "Rollen & Geräte", Color(0xFFFF6D00), onNavigateAdmin)
            )
            GridRow(
                OsTile("🔗", "Mesh", "BT · WiFi · Nodes", Color(0xFF00BCD4), onNavigateMesh),
                OsTile("🌐", "Netzwerk", "Host · API · Verbindungen", Color(0xFF40C4FF), onNavigateNetwork)
            )
            GridRow(
                OsTile("₿", "Wallet", "Bitcoin Hardware", Color(0xFFFFD700), onNavigateWallet),
                OsTile("🛒", "Shop", "Produkte & Checkout", Color(0xFF4CAF50), onNavigateShop)
            )
            GridRow(
                OsTile("📡", "Scan", "RSSI · BLE · CSI", Color(0xFF26C6DA), onNavigateScan),
                OsTile("🏢", "Gebäude", "3D Overlay", Color(0xFF7C4DFF), onNavigateBuildings)
            )
            GridRow(
                OsTile("🧠", "Compute", "Rechenknoten", Color(0xFFFF5252), onNavigateCompute),
                OsTile("🧅", "Onion", "Privater Relay-Modus", Color(0xFF69F0AE), onNavigateOnion)
            )
            GridRow(
                OsTile("🛰️", "WireGuard", "VPN-Tunnel", Color(0xFF40C4FF), onNavigateWireGuard),
                OsTile("📱", "Apps", "Pandora Module", Color(0xFFFF80AB), onNavigateApps)
            )

            Spacer(Modifier.height(24.dp))
            Text("Pandora OS läuft als Android-Home-Shell. Ein echtes Custom-ROM ist eine spätere Stufe.", color = Color.Gray, fontSize = 11.sp)
        }
    }
}

@Composable
private fun SectionTitle(text: String) {
    Spacer(Modifier.height(16.dp))
    Text(text, color = Color.White, fontWeight = FontWeight.Black, fontSize = 16.sp)
    Spacer(Modifier.height(8.dp))
}

@Composable
private fun GridRow(left: OsTile, right: OsTile) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        OsCard(left, Modifier.weight(1f))
        OsCard(right, Modifier.weight(1f))
    }
    Spacer(Modifier.height(10.dp))
}

private data class OsTile(
    val icon: String,
    val title: String,
    val subtitle: String,
    val color: Color,
    val onClick: () -> Unit,
)

@Composable
private fun OsCard(tile: OsTile, modifier: Modifier = Modifier) {
    Card(
        colors = CardDefaults.cardColors(containerColor = Color(0xFF12121A)),
        border = BorderStroke(1.dp, tile.color.copy(alpha = 0.35f)),
        shape = RoundedCornerShape(18.dp),
        modifier = modifier.height(112.dp).clickable { tile.onClick() }
    ) {
        Column(Modifier.fillMaxSize().padding(14.dp), verticalArrangement = Arrangement.SpaceBetween) {
            Text(tile.icon, fontSize = 26.sp)
            Column {
                Text(tile.title, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                Text(tile.subtitle, color = Color.Gray, fontSize = 11.sp, maxLines = 2)
            }
        }
    }
}

@Composable
private fun StatusPill(text: String, color: Color) {
    Surface(shape = RoundedCornerShape(50), color = color.copy(alpha = 0.15f), border = BorderStroke(1.dp, color)) {
        Text(text, color = color, fontSize = 11.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp))
    }
}

@Composable
private fun SmallChip(text: String, color: Color) {
    Surface(shape = RoundedCornerShape(50), color = color.copy(alpha = 0.13f), border = BorderStroke(1.dp, color.copy(alpha = 0.35f))) {
        Text(text, color = Color.White.copy(alpha = 0.86f), fontSize = 10.sp, modifier = Modifier.padding(horizontal = 9.dp, vertical = 5.dp))
    }
}
