package com.pandora.jayjay

import android.content.Context
import android.net.wifi.WifiManager
import android.util.Log
import kotlinx.coroutines.*
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import java.util.concurrent.TimeUnit

/**
 * PandoraFleetController – Das CEO-Handy als Herz des Systems
 *
 * Das Samsung S24 (diese APK) ist die ZENTRALE. JayJay steuert von hier
 * aus ALLE anderen Pandora-Geräte (Desktop-Agents auf PC/Mac/Linux/Raspi).
 *
 * Funktioniert in JEDER Konstellation:
 *   • Nur Handys      → Handys bilden Mesh, ein CEO-Handy ist Herz
 *   • Nur PCs         → PCs laufen als Agents, CEO-Handy steuert sie
 *   • Gemischt        → alles verbunden, CEO-Handy kontrolliert alles
 *   • Nur CEO-Handy   → läuft autark, voll funktionsfähig allein
 *
 * Desktop-Agents lauschen auf Port 7777 (HTTP) + 7778 (WebSocket).
 * Dieses Modul erkennt sie und sendet Befehle.
 *
 * CEO: Finn Jona Thorsten Lischke
 */

@Serializable
data class FleetNode(
    val nodeId:     String,
    val hostname:   String,
    val ip:         String,
    val deviceType: String,            // PC_WINDOWS, PC_LINUX, RASPBERRY_PI, etc.
    val features:   List<String> = emptyList(),
    val cpuPct:     Int = 0,
    val ramPct:     Int = 0,
    val uptime:     String = "",
    val isOnline:   Boolean = true,
)

@Serializable
private data class AgentInfo(
    val pandora:    Boolean = false,
    val nodeId:     String = "",
    val hostname:   String = "",
    val deviceType: String = "",
    val features:   List<String> = emptyList(),
)

class PandoraFleetController(private val context: Context) {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val json  = Json { ignoreUnknownKeys = true }
    private val http  = OkHttpClient.Builder()
        .connectTimeout(2, TimeUnit.SECONDS)
        .readTimeout(5, TimeUnit.SECONDS)
        .build()

    private val fleet = mutableMapOf<String, FleetNode>()

    companion object {
        private const val TAG = "PandoraFleet"
        private const val AGENT_PORT = 7777        // Desktop-Agent HTTP-Port
        private const val JSON_MEDIA = "application/json"
    }

    // ── Flotte entdecken ──────────────────────────────────────────────────────

    /**
     * Scannt das Netzwerk nach Pandora-Desktop-Agents.
     * Findet alle PCs, Macs, Linux-Rechner, Raspberry Pis.
     */
    suspend fun discoverFleet(): List<FleetNode> = withContext(Dispatchers.IO) {
        val subnet = getSubnet()
        Log.i(TAG, "Flotten-Scan: $subnet.1–254 (Port $AGENT_PORT)")

        val nodes = (1..254).map { i ->
            async { probeAgent("$subnet.$i") }
        }.awaitAll().filterNotNull()

        nodes.forEach { fleet[it.nodeId] = it }
        Log.i(TAG, "Flotte: ${nodes.size} Pandora-Agents gefunden")
        nodes
    }

    private suspend fun probeAgent(ip: String): FleetNode? = withContext(Dispatchers.IO) {
        runCatching {
            val req  = Request.Builder().url("http://$ip:$AGENT_PORT/api/info").build()
            val resp = http.newCall(req).execute()
            if (!resp.isSuccessful) return@runCatching null
            val body = resp.body?.string() ?: return@runCatching null
            val info = json.decodeFromString<AgentInfo>(body)
            if (!info.pandora) return@runCatching null

            FleetNode(
                nodeId     = info.nodeId.ifEmpty { ip },
                hostname   = info.hostname.ifEmpty { ip },
                ip         = ip,
                deviceType = info.deviceType,
                features   = info.features,
                isOnline   = true,
            )
        }.getOrNull()
    }

    // ── Befehle an die Flotte senden ──────────────────────────────────────────

    /** Befehl an EIN Gerät senden */
    suspend fun command(nodeId: String, cmd: String, args: Map<String, String> = emptyMap()): String =
        withContext(Dispatchers.IO) {
            val node = fleet[nodeId] ?: return@withContext "Gerät $nodeId nicht gefunden."
            sendCommand(node.ip, cmd, args)
        }

    /** Befehl an ALLE Geräte senden (Broadcast) */
    suspend fun commandAll(cmd: String, args: Map<String, String> = emptyMap()): Map<String, String> =
        withContext(Dispatchers.IO) {
            fleet.values.map { node ->
                async { node.hostname to sendCommand(node.ip, cmd, args) }
            }.awaitAll().toMap()
        }

    private fun sendCommand(ip: String, cmd: String, args: Map<String, String>): String {
        return runCatching {
            val argsJson = args.entries.joinToString(",") { (k, v) ->
                "\"${escapeJson(k)}\":\"${escapeJson(v)}\""
            }
            val payload = "{\"command\":\"${escapeJson(cmd)}\",\"args\":{$argsJson}}"
            val req = Request.Builder()
                .url("http://$ip:$AGENT_PORT/api/command")
                .post(payload.toRequestBody(JSON_MEDIA.toMediaType()))
                .build()
            val resp = http.newCall(req).execute()
            resp.body?.string() ?: "Keine Antwort"
        }.getOrElse { "Fehler: ${it.message}" }
    }

    // ── Komfort-Befehle für JayJay ────────────────────────────────────────────

    /** System-Info von allen Geräten holen */
    suspend fun getAllSystemInfo(): String = withContext(Dispatchers.IO) {
        if (fleet.isEmpty()) discoverFleet()
        if (fleet.isEmpty()) return@withContext "Keine Pandora-Geräte im Netzwerk."

        buildString {
            appendLine("🖥 Flotten-Status (${fleet.size} Geräte):")
            fleet.values.forEach { node ->
                appendLine("• ${node.hostname} [${node.deviceType}] – ${node.ip}")
            }
        }
    }

    /** Datei auf einem Remote-Gerät suchen */
    suspend fun findFileOnFleet(name: String): String = withContext(Dispatchers.IO) {
        if (fleet.isEmpty()) discoverFleet()
        val results = fleet.values.map { node ->
            async {
                val resp = runCatching {
                    val req = Request.Builder()
                        .url("http://${node.ip}:$AGENT_PORT/api/files/scan?name=$name&limit=20")
                        .build()
                    http.newCall(req).execute().body?.string() ?: ""
                }.getOrDefault("")
                node.hostname to resp
            }
        }.awaitAll()

        buildString {
            appendLine("🔍 Suche '$name' auf der Flotte:")
            results.forEach { (host, resp) ->
                val count = Regex("\"count\":(\\d+)").find(resp)?.groupValues?.get(1) ?: "0"
                appendLine("• $host: $count Treffer")
            }
        }
    }

    /** Remote-PC herunterfahren (nur Finn) */
    suspend fun shutdownNode(nodeId: String, finnAuthorized: Boolean): String {
        if (!finnAuthorized) return "Nur Finn darf Geräte herunterfahren."
        return command(nodeId, "system.shutdown", mapOf("finnAuth" to "true"))
    }

    /** Remote-PC neustarten (nur Finn) */
    suspend fun rebootNode(nodeId: String, finnAuthorized: Boolean): String {
        if (!finnAuthorized) return "Nur Finn darf Geräte neustarten."
        return command(nodeId, "system.reboot", mapOf("finnAuth" to "true"))
    }

    /** PC per Wake-on-LAN aufwecken (über einen Agent im Netz) */
    suspend fun wakePc(mac: String): String = withContext(Dispatchers.IO) {
        if (fleet.isEmpty()) discoverFleet()
        val anyNode = fleet.values.firstOrNull()
            ?: return@withContext "Kein Agent verfügbar um WoL zu senden."
        sendCommand(anyNode.ip, "network.wol", mapOf("mac" to mac))
    }

    // ── Status ────────────────────────────────────────────────────────────────

    fun getFleet(): List<FleetNode> = fleet.values.toList()
    fun getNodeCount(): Int = fleet.size

    private fun escapeJson(s: String): String =
        s.replace("\\", "\\\\").replace("\"", "\\\"")

    fun summarize(): String = buildString {
        val nodes = getFleet()
        appendLine("⬡ Pandora-Flotte (CEO-Handy = Herz):")
        if (nodes.isEmpty()) {
            appendLine("• Noch keine Desktop-Agents gefunden.")
            appendLine("• Sage: 'JayJay, finde alle Geräte'")
        } else {
            appendLine("• ${nodes.size} verbundene Geräte:")
            nodes.groupBy { it.deviceType }.forEach { (type, list) ->
                appendLine("  ${emojiFor(type)} $type: ${list.size}")
                list.forEach { appendLine("    • ${it.hostname} (${it.ip})") }
            }
        }
    }

    private fun emojiFor(type: String) = when {
        type.contains("WINDOWS") -> "🪟"
        type.contains("MAC")     -> "🍎"
        type.contains("LINUX")   -> "🐧"
        type.contains("RASP")    -> "🥧"
        type.contains("TV")      -> "📺"
        type.contains("CAR")     -> "🚗"
        else                     -> "🖥"
    }

    private fun getSubnet(): String {
        return try {
            val wm = context.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
            val ip = wm.connectionInfo.ipAddress
            String.format("%d.%d.%d",
                ip and 0xff, ip shr 8 and 0xff, ip shr 16 and 0xff)
        } catch (_: Exception) { "192.168.1" }
    }
}
