package com.pandora.di

import com.pandora.api.PandoraApiServer
import com.pandora.building.BuildingOverlay3D
import com.pandora.compute.ComputeMeshManager
import com.pandora.core.ConfigManager
import com.pandora.database.PandoraDatabase
import com.pandora.database.SsdStorageManager
import com.pandora.jayjay.AttackDefenseEngine
import com.pandora.jayjay.FaceRecognitionManager
import com.pandora.jayjay.JayJayDataAccess
import com.pandora.jayjay.JayJayEngine
import com.pandora.jayjay.JayJayFileScanner
import com.pandora.jayjay.JayJayLearningEngine
import com.pandora.jayjay.CeoAuthority
import com.pandora.jayjay.CodeIntegrityGuard
import com.pandora.jayjay.NetworkIntelligence
import com.pandora.jayjay.JayJaySpeech
import com.pandora.jayjay.JayJayNetworkScanner
import com.pandora.jayjay.PandoraFleetController
import com.pandora.jayjay.VoicePrintManager
import com.pandora.os.PandoraDeviceProfile
import com.pandora.os.PandoraIoTController
import com.pandora.mesh.BluetoothMeshManager
import com.pandora.mesh.MeshOnionRouter
import com.pandora.mesh.WifiMeshManager
import com.pandora.onion.OnionModule
import com.pandora.quantum.QuantumKeyManager
import com.pandora.scan.ScanModule
import com.pandora.security.SecurityModule
import com.pandora.visibility.HostVisibilityGate
import com.pandora.wireguard.WireGuardModule
import org.koin.android.ext.koin.androidContext
import org.koin.dsl.module

val appModule = module {

    // ── Core ─────────────────────────────────────────────────────────────────
    single { ConfigManager.getInstance(androidContext()) }
    single { SecurityModule() }

    // ── Quantum (CEO hostet QKD-Server → verteilt Keys ans Netz) ─────────────
    single {
        QuantumKeyManager(androidContext()).also { it.initialize() }
    }

    // ── Storage ───────────────────────────────────────────────────────────────
    single { SsdStorageManager(androidContext(), get()) }
    single { PandoraDatabase.getInstance(androidContext(), get<SsdStorageManager>().getDatabasePath()) }

    // ── Visibility Gate ───────────────────────────────────────────────────────
    single { HostVisibilityGate(get()) }

    // ── Network ───────────────────────────────────────────────────────────────
    single { BluetoothMeshManager(androidContext()) }
    single { WifiMeshManager(androidContext()) }
    single { MeshOnionRouter(get()) }
    single { OnionModule(androidContext()) }
    single { WireGuardModule(androidContext()) }

    // ── JayJay KI ────────────────────────────────────────────────────────────
    single { VoicePrintManager(androidContext(), get()) }
    single { JayJayLearningEngine(get(), get()) }

    // AttackDefenseEngine: JayJay lernt Angriffe abzuwehren
    single { AttackDefenseEngine(get()) }

    // JayJayDataAccess: Gerätedaten (Kontakte, SMS, Fotos, Kalender, etc.)
    single { JayJayDataAccess(androidContext()) }

    // JayJayFileScanner: jede einzelne Datei auf dem Gerät
    single { JayJayFileScanner(androidContext()) }

    // JayJayNetworkScanner: alles im Pandora-Netzwerk
    single { JayJayNetworkScanner(androidContext()) }

    // FaceRecognitionManager: ML Kit Gesichtserkennung + Liveness
    single { FaceRecognitionManager(androidContext()) }

    // PandoraDeviceProfile: erkennt Gerätetyp → passt Features an
    single { PandoraDeviceProfile.detect(androidContext()) }

    // PandoraIoTController: steuert Lampen, Steckdosen, TVs, PCs im Netzwerk
    single { PandoraIoTController(androidContext()) }

    // PandoraFleetController: CEO-Handy als Herz, steuert alle Desktop-Agents
    single { PandoraFleetController(androidContext()) }

    // CodeIntegrityGuard: JayJay überwacht den eigenen Code (Fokus Handy-APK)
    single {
        CodeIntegrityGuard(androidContext()).also { guard ->
            guard.defenseEngine = get()       // Funde an Angriffsabwehr melden
            guard.startMonitoring()           // Dauerüberwachung sofort starten
        }
    }

    // CeoAuthority: CEO-Handy = zentrale Auth. Offline = alles gesperrt.
    single {
        CeoAuthority(androidContext()).also { auth ->
            auth.fleetController = get()       // findet die Geräte
            auth.defenseEngine   = get()       // meldet Anomalien
            auth.goOnline()                    // Handy online → Heartbeats starten
        }
    }

    // NetworkIntelligence: JayJay seziert fremde Netze + lernt daraus
    single {
        NetworkIntelligence(androidContext(), get<SsdStorageManager>()).also { intel ->
            intel.defenseEngine = get()        // Risiken an Angriffsabwehr melden
        }
    }

    // JayJaySpeech: JayJays weibliche Stimme – sie spricht jede Antwort aus
    single {
        JayJaySpeech(androidContext()).also { it.init() }
    }

    // JayJayEngine: alles verbunden
    single {
        JayJayEngine(androidContext(), get(), get(), get(), get(), get()).also { engine ->
            engine.defenseEngine    = get()   // Angriffsabwehr
            engine.dataAccess       = get()   // Gerätedaten
            engine.fileScanner      = get()   // 100% Datei-Zugriff
            engine.networkScanner   = get()   // Netzwerk-Zugriff
            engine.faceRecognition  = get()   // Gesichtserkennung
            engine.iotController    = get()   // Smart Home / IoT
            engine.deviceProfile    = get()   // Geräte-Profil
            engine.fleetController  = get()   // Flotte (Desktop-Agents)
            engine.integrityGuard   = get()   // Code-Selbstüberwachung
            engine.ceoAuthority     = get()   // CEO-Handy = zentrale Auth
            engine.netIntel         = get()   // Fremdnetz-Analyse + Lernen
            engine.speech           = get()   // JayJays weibliche Stimme
            engine.initialize()               // Dead Man's Switch starten
        }
    }

    // ── API Server (CEO hostet QKD + Defense nutzt API-Layer) ────────────────
    single { PandoraApiServer(get(), get(), get(), get(), get()) }

    // ── Features ─────────────────────────────────────────────────────────────
    single { ScanModule(androidContext(), get(), get()) }
    single { BuildingOverlay3D(get(), get()) }
    single { ComputeMeshManager(androidContext(), get(), get()) }
}
