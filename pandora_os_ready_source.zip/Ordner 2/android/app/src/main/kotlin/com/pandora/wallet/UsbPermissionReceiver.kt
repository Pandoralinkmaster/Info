package com.pandora.wallet

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.util.Log

class UsbPermissionReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == "com.pandora.USB_PERMISSION") {
            Log.i("PandoraUSB", "USB permission response received")
        }
    }
}
