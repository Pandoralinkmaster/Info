package com.pandora.jayjay

import android.content.Context
import android.util.Base64
import android.util.Log
import kotlinx.coroutines.*
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import java.util.concurrent.TimeUnit
import javax.crypto.Mac
import javax.crypto.spec.SecretKeySpec

/**
 * CeoAuthority – Das CEO-Handy ist die zentrale Authentifizierungs-Instanz
 *
 * Grundregel (vom CEO gefordert):
 *   • ALLES im Netzwerk muss vom CEO-Handy authentifiziert werden.
 *   • Wenn das CEO-Handy OFFLINE ist, kann NIEMAND zugreifen.
 *     → Alle Geräte (Desktop-Agents) sperren sich automatisch (fail-closed).
 *
 * Funktionsweise:
 *   1. Das CEO-Handy sendet im Takt (alle 20s) einen signierten "Heartbeat"
 *      an jedes bekannte Gerät. Damit beweist es: "Finn ist online & präsent".
 *   2. Jedes Gerät merkt sich den letzten Heartbeat. Bleibt er länger als
 *      CEO_TIMEOUT (60s) aus → das Gerät geht in LOCKDOWN und lehnt jeden
 *      Zugriff ab, bis das CEO-Handy wieder da ist.
 *   3. Für sensible Aktionen stellt das CEO-Handy zusätzlich kurzlebige,
 *      HMAC-signierte Zugriffs-Tokens aus, die nur es erzeugen kann.
 *   4. JayJay (die KI) überwacht diese Instanz selbst und meldet Anomalien
 *      an die AttackDefenseEngine.
 *
 * Sicherheit: HMAC-SHA256 über einen gemeinsamen Netzwerkschlüssel.
 * Nur wer den Schlüssel hat (CEO-Handy), kann gültige Heartbeats/Tokens
 * erzeugen. Desktop-Agents verifizieren mit demselben Schlüssel.
 *
 * CEO: Finn Jona Thorsten Lischke
 */
class CeoAuthority(private val context: Context) {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val http  = OkHttpClient.Builder()
        .connectTimeout(2, TimeUnit.SECONDS)
        .readTimeout(3, TimeUnit.SECONDS)
        .build()

    /** Wird von AppModule gesetzt: zum Finden der Geräte */
    var fleetController: PandoraFleetController? = null
    /** Wird von AppModule gesetzt: Anomalien melden */
    var defenseEngine:   AttackDefenseEngine?    = null

    @Volatile private var online   = false        // sendet das Handy gerade Heartbeats?
    @Volatile private var heartbeatJob: Job? = null
    @Volatile private var lastBeatSent = 0L
    @Volatile private var beatsSent    = 0L

    companion object {
        private const val TAG = "CeoAuthority"
        private const val AGENT_PORT   = 7777
        private const val BEAT_INTERVAL_MS = 20_000L   // alle 20s Heartbeat
        const val CEO_TIMEOUT_MS = 60_000L             // 60s ohne Beat → Lockdown
        private const val JSON = "application/json"

        /**
         * Gemeinsamer Netzwerkschlüssel (Pairing-Key).
         * MUSS auf CEO-Handy und allen Desktop-Agents identisch sein.
         * Desktop: config.ceoSecret. Für Produktion einen eigenen Wert setzen.
         */
        const val NETWORK_KEY = "PandoraNetz-Finn-Jona-Thorsten-Lischke-CEO"
    }

    // ── Präsenz starten / stoppen ─────────────────────────────────────────────

    /**
     * CEO-Handy geht online → beginnt Heartbeats an die ganze Flotte zu senden.
     * Solange das läuft, dürfen die Geräte arbeiten.
     */
    fun goOnline() {
        if (online) return
        online = true
        heartbeatJob = scope.launch {
            Log.i(TAG, "CEO-Handy ONLINE – sende Heartbeats an die Flotte")
            while (online && isActive) {
                broadcastHeartbeat()
                delay(BEAT_INTERVAL_MS)
            }
        }
    }

    /**
     * CEO-Handy geht offline (Finn sperrt / verlässt) → Heartbeats stoppen.
     * Die Geräte laufen in ihren Timeout und sperren sich selbst.
     * Zusätzlich senden wir einen sofortigen Lockdown-Befehl.
     */
    fun goOffline() {
        if (!online) return
        online = false
        heartbeatJob?.cancel()
        Log.w(TAG, "CEO-Handy OFFLINE – Netzwerk sperrt sich (fail-closed)")
        scope.launch { broadcastLockdown() }
    }

    fun isOnline() = online

    // ── Heartbeat senden ──────────────────────────────────────────────────────

    private suspend fun broadcastHeartbeat() = withContext(Dispatchers.IO) {
        val nodes = fleetController?.getFleet().orEmpty()
        if (nodes.isEmpty()) {
            // Noch keine Flotte bekannt → einmal scannen
            fleetController?.discoverFleet()
        }
        val ts    = System.currentTimeMillis()
        val nonce = java.util.UUID.randomUUID().toString().take(8)
        val sig   = sign("ceo:$ts:$nonce")
        val payload = "{\"type\":\"heartbeat\",\"ts\":$ts,\"nonce\":\"$nonce\",\"sig\":\"$sig\"}"

        fleetController?.getFleet().orEmpty().forEach { node ->
            launch { postToNode(node.ip, "/api/ceo/heartbeat", payload) }
        }
        lastBeatSent = ts
        beatsSent++
    }

    private suspend fun broadcastLockdown() = withContext(Dispatchers.IO) {
        val ts    = System.currentTimeMillis()
        val nonce = java.util.UUID.randomUUID().toString().take(8)
        val sig   = sign("lockdown:$ts:$nonce")
        val payload = "{\"type\":\"lockdown\",\"ts\":$ts,\"nonce\":\"$nonce\",\"sig\":\"$sig\"}"
        fleetController?.getFleet().orEmpty().forEach { node ->
            launch { postToNode(node.ip, "/api/ceo/lockdown", payload) }
        }
    }

    private fun postToNode(ip: String, path: String, payload: String) {
        runCatching {
            val req = Request.Builder()
                .url("http://$ip:$AGENT_PORT$path")
                .post(payload.toRequestBody(JSON.toMediaType()))
                .build()
            http.newCall(req).execute().close()
        }
    }

    // ── Zugriffs-Token ausstellen ─────────────────────────────────────────────

    /**
     * Stellt ein kurzlebiges, signiertes Zugriffs-Token aus.
     * Nur das CEO-Handy (mit dem Netzwerkschlüssel) kann das.
     *
     * Format: base64("scope:expiry") + "." + HMAC-Signatur
     *
     * @param scope  z.B. "files", "system", "shutdown", "all"
     * @param ttlMs  Gültigkeitsdauer in ms (Standard 5 min)
     */
    fun issueAccessToken(scope: String, ttlMs: Long = 5 * 60_000L): String {
        val expiry  = System.currentTimeMillis() + ttlMs
        val claim   = "$scope:$expiry"
        val claimB64 = Base64.encodeToString(claim.toByteArray(), Base64.NO_WRAP or Base64.URL_SAFE)
        val sig     = sign(claimB64)
        Log.i(TAG, "Zugriffs-Token ausgestellt: scope=$scope, gültig ${ttlMs / 1000}s")
        return "$claimB64.$sig"
    }

    // ── HMAC-Signatur ─────────────────────────────────────────────────────────

    private fun sign(data: String): String {
        val mac = Mac.getInstance("HmacSHA256")
        mac.init(SecretKeySpec(NETWORK_KEY.toByteArray(), "HmacSHA256"))
        return mac.doFinal(data.toByteArray()).joinToString("") { "%02x".format(it) }
    }

    // ── Selbst-Überwachung durch JayJay ───────────────────────────────────────

    /**
     * JayJay prüft, ob die Authentifizierungs-Instanz gesund ist.
     * Wenn Heartbeats hängen während sie online sein sollte → Anomalie.
     */
    fun selfCheck() {
        if (online) {
            val sinceLast = System.currentTimeMillis() - lastBeatSent
            if (lastBeatSent > 0 && sinceLast > BEAT_INTERVAL_MS * 3) {
                defenseEngine?.recordCodeTampering(
                    AttackType.CODE_TAMPERING, ThreatLevel.HIGH,
                    "CEO-Heartbeat hängt (${sinceLast / 1000}s) obwohl online – möglicher Eingriff in die Auth-Instanz."
                )
            }
        }
    }

    // ── Status / Bericht ──────────────────────────────────────────────────────

    fun getAuthorityReport(): String = buildString {
        val nodes = fleetController?.getFleet().orEmpty()
        appendLine("🔑 CEO-AUTHENTIFIZIERUNG (Handy = Schlüssel)")
        appendLine("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
        appendLine("Status: ${if (online) "✓ ONLINE – Netzwerk freigegeben" else "🔒 OFFLINE – Netzwerk gesperrt"}")
        appendLine("Heartbeats gesendet: $beatsSent")
        appendLine("Timeout bis Lockdown: ${CEO_TIMEOUT_MS / 1000}s ohne Handy")
        appendLine("Geräte unter Kontrolle: ${nodes.size}")
        appendLine("")
        if (online) {
            appendLine("→ Solange dein Handy online ist, dürfen die Geräte arbeiten.")
        } else {
            appendLine("→ Dein Handy ist offline – NIEMAND kommt an die Geräte.")
        }
    }
}
