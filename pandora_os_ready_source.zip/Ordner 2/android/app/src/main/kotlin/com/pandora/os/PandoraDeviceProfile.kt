package com.pandora.os

import android.app.UiModeManager
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.telephony.TelephonyManager
import android.util.DisplayMetrics
import android.view.WindowManager
import android.util.Log

/**
 * PandoraOS – Geräteprofilierung
 *
 * Pandora erkennt automatisch auf welchem Gerät es läuft und
 * stellt entsprechende Funktionen bereit:
 *
 *   ┌─────────────────┬──────────────────────────────────────────┐
 *   │ Gerättyp        │ Pandora-Funktionen                       │
 *   ├─────────────────┼──────────────────────────────────────────┤
 *   │ Smartphone      │ Alle Features: JayJay, BTC, Mesh, Kamera │
 *   │ Tablet          │ Wie Smartphone + erweitertes Dashboard    │
 *   │ Android TV      │ Kiosk-Modus, Fernbedienung, Media-Hub    │
 *   │ Android Auto    │ Sprachsteuerung only (keine UI-Ablenkung) │
 *   │ Wear OS         │ JayJay-Stimme, Vitaldaten, Benachricht.  │
 *   │ Smart Home Hub  │ IoT-Gateway, Lampen/Geräte steuern       │
 *   │ PC (via Waydroid)│ Vollständiges Dashboard, alle Features  │
 *   └─────────────────┴──────────────────────────────────────────┘
 *
 * Pandora KANN NICHT das Android-Betriebssystem selbst ersetzen —
 * es läuft AUF Android. Mit Device Admin + Launcher + Accessibility
 * ist es aber aus Nutzersicht das Betriebssystem.
 *
 * Für nicht-Android-Geräte (Lampen, PC, Konsole) gibt es separate
 * Pandora-Agenten die über das Mesh-Netzwerk kommunizieren.
 */

enum class PandoraDeviceType {
    SMARTPHONE,         // Normales Android-Handy
    TABLET,             // Android-Tablet (≥ 7" Bildschirm)
    ANDROID_TV,         // Android TV / Google TV
    ANDROID_AUTO,       // Im Auto
    WEAR_OS,            // Smartwatch
    SMART_HOME_HUB,     // Raspberry Pi / Android Things / dedizierter Hub
    PC_WAYDROID,        // PC mit Waydroid (Android in Linux)
    UNKNOWN,
}

data class DeviceCapabilities(
    val deviceType:       PandoraDeviceType,
    val hasCamera:        Boolean,
    val hasMicrophone:    Boolean,
    val hasCellular:      Boolean,
    val hasBluetooth:     Boolean,
    val hasNfc:           Boolean,
    val hasBiometric:     Boolean,
    val screenDiagonalIn: Float,       // Bildschirmdiagonale in Zoll
    val isLowEndDevice:   Boolean,     // RAM < 2GB
    val androidVersion:   Int,
    val manufacturer:     String,

    // Welche Features sind auf diesem Gerät aktiv
    val features: Set<PandoraFeature>,
)

enum class PandoraFeature {
    JAYJAY_VOICE,       // Sprachsteuerung mit JayJay
    JAYJAY_FULL,        // Vollständige JayJay KI mit GPT
    FACE_RECOGNITION,   // Gesichtserkennung
    BITCOIN_WALLET,     // BTC-Zahlungen
    MESH_NETWORK,       // P2P Mesh-Netzwerk
    ENCRYPTED_MESSENGER,// Link-Messenger
    DEVICE_ADMIN,       // Geräte-Administrator
    LAUNCHER,           // Als Standard-Launcher
    FILE_ACCESS,        // Vollständiger Dateizugriff
    IOT_CONTROLLER,     // Smart Home / IoT steuern
    MEDIA_HUB,          // Medienserver (TV-Modus)
    CAR_MODE,           // Auto-Modus (nur Sprache)
    WATCH_MODE,         // Uhr-Modus (minimal UI)
    DASHBOARD,          // Erweitiertes CEO-Dashboard
    NETWORK_SCANNER,    // Netzwerk-Geräte scannen
    DATA_ACCESS,        // Kontakte, SMS, Fotos, etc.
}

object PandoraDeviceProfile {

    private const val TAG = "PandoraDevice"

    fun detect(context: Context): DeviceCapabilities {
        val pm  = context.packageManager
        val wm  = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val um  = context.getSystemService(Context.UI_MODE_SERVICE) as UiModeManager

        // Bildschirmgröße
        val metrics = DisplayMetrics()
        @Suppress("DEPRECATION")
        wm.defaultDisplay.getRealMetrics(metrics)
        val widthIn  = metrics.widthPixels  / metrics.xdpi
        val heightIn = metrics.heightPixels / metrics.ydpi
        val diagIn   = Math.sqrt((widthIn * widthIn + heightIn * heightIn).toDouble()).toFloat()

        // Gerättyp ermitteln
        val uiMode     = um.currentModeType
        val isTV       = pm.hasSystemFeature(PackageManager.FEATURE_LEANBACK)
        val isWatch    = pm.hasSystemFeature(PackageManager.FEATURE_WATCH)
        val isCar      = uiMode == UiModeManager.MODE_TYPE_CAR
        val isTablet   = diagIn >= 7.0f && !isTV && !isWatch && !isCar
        val isHub      = isSmartHomeHub(context)

        val deviceType = when {
            isWatch  -> PandoraDeviceType.WEAR_OS
            isCar    -> PandoraDeviceType.ANDROID_AUTO
            isTV     -> PandoraDeviceType.ANDROID_TV
            isHub    -> PandoraDeviceType.SMART_HOME_HUB
            isTablet -> PandoraDeviceType.TABLET
            else     -> PandoraDeviceType.SMARTPHONE
        }

        // Hardware-Features
        val hasCamera     = pm.hasSystemFeature(PackageManager.FEATURE_CAMERA_ANY)
        val hasMic        = pm.hasSystemFeature(PackageManager.FEATURE_MICROPHONE)
        val hasBt         = pm.hasSystemFeature(PackageManager.FEATURE_BLUETOOTH)
        val hasNfc        = pm.hasSystemFeature(PackageManager.FEATURE_NFC)
        val hasBiometric  = pm.hasSystemFeature(PackageManager.FEATURE_FINGERPRINT)
        val hasCellular   = hasTelephony(context)
        val isLowEnd      = isLowEndDevice()

        val features = determineFeaturesFor(deviceType, hasCamera, hasMic, hasBt, hasCellular, isLowEnd)

        Log.i(TAG, "Gerätetyp erkannt: $deviceType (${diagIn}\")")
        Log.i(TAG, "Features: ${features.joinToString()}")

        return DeviceCapabilities(
            deviceType       = deviceType,
            hasCamera        = hasCamera,
            hasMicrophone    = hasMic,
            hasCellular      = hasCellular,
            hasBluetooth     = hasBt,
            hasNfc           = hasNfc,
            hasBiometric     = hasBiometric,
            screenDiagonalIn = diagIn,
            isLowEndDevice   = isLowEnd,
            androidVersion   = Build.VERSION.SDK_INT,
            manufacturer     = Build.MANUFACTURER,
            features         = features,
        )
    }

    private fun determineFeaturesFor(
        type: PandoraDeviceType,
        hasCamera: Boolean,
        hasMic: Boolean,
        hasBt: Boolean,
        hasCellular: Boolean,
        isLowEnd: Boolean,
    ): Set<PandoraFeature> = when (type) {

        PandoraDeviceType.SMARTPHONE -> buildSet {
            add(PandoraFeature.JAYJAY_VOICE)
            add(PandoraFeature.MESH_NETWORK)
            add(PandoraFeature.ENCRYPTED_MESSENGER)
            add(PandoraFeature.BITCOIN_WALLET)
            add(PandoraFeature.DEVICE_ADMIN)
            add(PandoraFeature.LAUNCHER)
            add(PandoraFeature.FILE_ACCESS)
            add(PandoraFeature.DATA_ACCESS)
            add(PandoraFeature.IOT_CONTROLLER)
            add(PandoraFeature.NETWORK_SCANNER)
            add(PandoraFeature.DASHBOARD)
            if (!isLowEnd) add(PandoraFeature.JAYJAY_FULL)
            if (hasCamera) add(PandoraFeature.FACE_RECOGNITION)
        }

        PandoraDeviceType.TABLET -> buildSet {
            // Alles wie Smartphone + Dashboard
            add(PandoraFeature.JAYJAY_VOICE)
            add(PandoraFeature.JAYJAY_FULL)
            add(PandoraFeature.MESH_NETWORK)
            add(PandoraFeature.ENCRYPTED_MESSENGER)
            add(PandoraFeature.BITCOIN_WALLET)
            add(PandoraFeature.DEVICE_ADMIN)
            add(PandoraFeature.LAUNCHER)
            add(PandoraFeature.FILE_ACCESS)
            add(PandoraFeature.DATA_ACCESS)
            add(PandoraFeature.IOT_CONTROLLER)
            add(PandoraFeature.NETWORK_SCANNER)
            add(PandoraFeature.DASHBOARD)
            add(PandoraFeature.MEDIA_HUB)
            if (hasCamera) add(PandoraFeature.FACE_RECOGNITION)
        }

        PandoraDeviceType.ANDROID_TV -> buildSet {
            // TV: Media-Hub, IoT-Controller, Sprache — keine Kamera/Face
            add(PandoraFeature.JAYJAY_VOICE)
            add(PandoraFeature.MEDIA_HUB)
            add(PandoraFeature.IOT_CONTROLLER)
            add(PandoraFeature.MESH_NETWORK)
            add(PandoraFeature.NETWORK_SCANNER)
            add(PandoraFeature.LAUNCHER)     // Als TV-Launcher
            if (!isLowEnd) add(PandoraFeature.JAYJAY_FULL)
        }

        PandoraDeviceType.ANDROID_AUTO -> buildSet {
            // Auto: NUR Sprache (Sicherheit!)
            add(PandoraFeature.JAYJAY_VOICE)
            add(PandoraFeature.CAR_MODE)
            // Keine UI-Ablenkung, kein Dateizugriff während Fahrt
        }

        PandoraDeviceType.WEAR_OS -> buildSet {
            // Uhr: minimal, nur Stimme und Vitaldaten
            add(PandoraFeature.JAYJAY_VOICE)
            add(PandoraFeature.WATCH_MODE)
            add(PandoraFeature.ENCRYPTED_MESSENGER)
        }

        PandoraDeviceType.SMART_HOME_HUB -> buildSet {
            // Hub: IoT-Gateway, kein UI nötig
            add(PandoraFeature.IOT_CONTROLLER)
            add(PandoraFeature.MESH_NETWORK)
            add(PandoraFeature.NETWORK_SCANNER)
            add(PandoraFeature.JAYJAY_VOICE)
            if (!isLowEnd) add(PandoraFeature.JAYJAY_FULL)
        }

        PandoraDeviceType.PC_WAYDROID -> buildSet {
            // PC via Waydroid: alles außer Telefonie
            add(PandoraFeature.JAYJAY_FULL)
            add(PandoraFeature.JAYJAY_VOICE)
            add(PandoraFeature.MESH_NETWORK)
            add(PandoraFeature.ENCRYPTED_MESSENGER)
            add(PandoraFeature.BITCOIN_WALLET)
            add(PandoraFeature.FILE_ACCESS)
            add(PandoraFeature.IOT_CONTROLLER)
            add(PandoraFeature.NETWORK_SCANNER)
            add(PandoraFeature.DASHBOARD)
        }

        PandoraDeviceType.UNKNOWN -> emptySet()
    }

    private fun isSmartHomeHub(context: Context): Boolean {
        // Kein Display oder sehr kleines Display = wahrscheinlich Hub
        val pm = context.packageManager
        val hasDisplay  = pm.hasSystemFeature(PackageManager.FEATURE_SCREEN_PORTRAIT) ||
                          pm.hasSystemFeature(PackageManager.FEATURE_SCREEN_LANDSCAPE)
        val hasTelephony = hasTelephony(context)
        val model = Build.MODEL.lowercase()
        val hubKeywords = listOf("raspberry", "pi", "orangepi", "nano", "hub", "gateway", "server")
        return hubKeywords.any { it in model } || (!hasDisplay && !hasTelephony)
    }

    private fun hasTelephony(context: Context): Boolean {
        return try {
            val tm = context.getSystemService(Context.TELEPHONY_SERVICE) as TelephonyManager
            tm.phoneType != TelephonyManager.PHONE_TYPE_NONE
        } catch (_: Exception) { false }
    }

    private fun isLowEndDevice(): Boolean {
        val runtime = Runtime.getRuntime()
        val maxMb   = runtime.maxMemory() / 1_048_576
        return maxMb < 512
    }

    fun describeDevice(caps: DeviceCapabilities): String = buildString {
        appendLine("📱 Pandora OS Geräte-Profil")
        appendLine("• Typ: ${caps.deviceType}")
        appendLine("• Hersteller: ${caps.manufacturer}")
        appendLine("• Bildschirm: ${"%.1f".format(caps.screenDiagonalIn)}\"")
        appendLine("• Kamera: ${if (caps.hasCamera) "✓" else "✗"}")
        appendLine("• Mobilfunk: ${if (caps.hasCellular) "✓" else "✗"}")
        appendLine("• NFC: ${if (caps.hasNfc) "✓" else "✗"}")
        appendLine("• Biometrie: ${if (caps.hasBiometric) "✓" else "✗"}")
        appendLine("• Low-End: ${if (caps.isLowEndDevice) "Ja (reduzierte Features)" else "Nein"}")
        appendLine()
        appendLine("🔧 Aktive Features (${caps.features.size}):")
        caps.features.forEach { appendLine("  ✓ $it") }
    }
}
