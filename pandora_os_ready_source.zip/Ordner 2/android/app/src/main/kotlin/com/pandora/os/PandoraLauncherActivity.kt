package com.pandora.os

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import com.pandora.MainActivity

/**
 * Pandora OS – Standard-Launcher (Home Screen)
 *
 * Wenn Pandora als Standard-Launcher gewählt wird,
 * öffnet ein Druck auf den Home-Button direkt Pandora.
 *
 * Der Nutzer hat dies beim Einrichten freiwillig gewählt
 * (§3 der Nutzungsbedingungen).
 *
 * Pandora ist damit immer erreichbar – kein normaler
 * Android-Homescreen dazwischen.
 */
class PandoraLauncherActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Direkt zur Pandora MainActivity weiterleiten
        startActivity(
            Intent(this, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
            }
        )
        finish()
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        startActivity(
            Intent(this, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
            }
        )
        finish()
    }
}
