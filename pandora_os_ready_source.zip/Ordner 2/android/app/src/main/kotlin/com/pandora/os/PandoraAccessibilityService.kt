package com.pandora.os

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.AccessibilityServiceInfo
import android.content.Intent
import android.util.Log
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

/**
 * Pandora OS – Accessibility Service
 *
 * Gibt Pandora vollständigen UI-Zugriff auf das Gerät:
 *   - Alle UI-Ereignisse sehen (Klicks, Eingaben, Fokus)
 *   - UI-Aktionen ausführen (Scrollen, Klicken, Eingabe)
 *   - Globale Aktionen (Home, Back, Recents, Notifications)
 *   - Bildschirminhalt lesen (für JayJay-Kontext-Awareness)
 *
 * Nutzer aktiviert dies freiwillig in den Einstellungen
 * nach Zustimmung zu den Nutzungsbedingungen.
 *
 * JayJay kann damit:
 *   - Den aktuellen Bildschirmkontext verstehen
 *   - Aufgaben automatisch ausführen (auf Finn's Befehl)
 *   - Das Gerät vollständig fernsteuern wenn Finn es will
 */
class PandoraAccessibilityService : AccessibilityService() {

    companion object {
        private const val TAG = "PandoraA11y"
        @Volatile var instance: PandoraAccessibilityService? = null
            private set
    }

    override fun onServiceConnected() {
        instance = this
        serviceInfo = serviceInfo.apply {
            eventTypes = AccessibilityEvent.TYPES_ALL_MASK
            feedbackType = AccessibilityServiceInfo.FEEDBACK_GENERIC
            flags = AccessibilityServiceInfo.FLAG_REPORT_VIEW_IDS or
                    AccessibilityServiceInfo.FLAG_RETRIEVE_INTERACTIVE_WINDOWS or
                    AccessibilityServiceInfo.FLAG_REQUEST_ENHANCED_WEB_ACCESSIBILITY
            notificationTimeout = 100
        }
        Log.i(TAG, "✓ Pandora Accessibility Service aktiv – vollständiger UI-Zugriff")
        PandoraOsManager.onAccessibilityConnected(applicationContext)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        event ?: return
        // Sicherheitsereignisse erfassen
        when (event.eventType) {
            AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED -> {
                val pkg = event.packageName?.toString() ?: return
                // Unbekannte Apps protokollieren (Sicherheitsmonitoring)
                if (!pkg.startsWith("com.pandora") &&
                    !pkg.startsWith("android") &&
                    !pkg.startsWith("com.android")) {
                    PandoraOsManager.onForegroundAppChanged(pkg)
                }
            }
        }
    }

    override fun onInterrupt() {
        Log.w(TAG, "Accessibility Service unterbrochen")
    }

    override fun onDestroy() {
        instance = null
        super.onDestroy()
    }

    // ── Aktionen die JayJay ausführen kann ──────────────────────────────────

    /** Zurück-Taste simulieren */
    fun pressBack() = performGlobalAction(GLOBAL_ACTION_BACK)

    /** Home-Taste simulieren */
    fun pressHome() = performGlobalAction(GLOBAL_ACTION_HOME)

    /** Benachrichtigungen öffnen */
    fun openNotifications() = performGlobalAction(GLOBAL_ACTION_NOTIFICATIONS)

    /** Schnelleinstellungen öffnen */
    fun openQuickSettings() = performGlobalAction(GLOBAL_ACTION_QUICK_SETTINGS)

    /** Alle Apps schließen (Recents) */
    fun closeAllApps() = performGlobalAction(GLOBAL_ACTION_RECENTS)

    /** Bildschirminhalt als Text lesen */
    fun readScreen(): String {
        val root = rootInActiveWindow ?: return ""
        return extractText(root)
    }

    private fun extractText(node: AccessibilityNodeInfo): String = buildString {
        if (!node.text.isNullOrBlank()) appendLine(node.text)
        if (!node.contentDescription.isNullOrBlank()) appendLine(node.contentDescription)
        for (i in 0 until node.childCount) {
            node.getChild(i)?.let { append(extractText(it)) }
        }
    }
}
