package com.pandora.jayjay

import android.content.Context
import android.util.Log
import com.pandora.database.SsdStorageManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.Serializable
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import java.security.MessageDigest
import kotlin.math.*

/**
 * VoicePrintManager – verbesserte Stimmbiometrie
 *
 * Finn Jona Thorsten Lischke = CEO = einzige autorisierte Stimme.
 *
 * Algorithmen (aufsteigend nach Genauigkeit):
 *
 * 1. MFCC (Mel Frequency Cepstral Coefficients) – 13 Koeffizienten + Delta + Delta-Delta = 39 gesamt
 *    Standard in modernen Stimm-Erkennungssystemen (GMM-basiert)
 *
 * 2. Spektrale Features – Spectral Centroid, Rolloff, Flux, ZCR
 *    Ergänzt MFCC für robustere Erkennung bei Hintergrundgeräuschen
 *
 * 3. Pitch-Kontur – Grundfrequenz F0 + Jitter + Shimmer
 *    Stimmhöhen-Charakteristik ist hochgradig personenspezifisch
 *
 * 4. Vergleich: Adaptives DTW (Dynamic Time Warping)
 *    Zeitnormalisierung → Erkennung unabhängig von Sprechgeschwindigkeit
 *
 * 5. Adaptives Lernen: Print verbessert sich mit jedem Finn-Sample
 *    Threshold passt sich automatisch an (Bayesianisches Update)
 *
 * Sicherheit:
 *   - Voice-Print wird AES-256 verschlüsselt auf M.2 SSD gespeichert
 *   - Auf alle Pandora-Geräte verteilt (nur Hash, kein Klartext)
 *   - Erkennung funktioniert offline, auch bei gesperrtem Gerät
 */

@Serializable
data class VoicePrint(
    val ceoId: String,
    val ceoName: String,
    val mfccMean: List<Float>,          // 39-dim MFCC-Mittelwert
    val mfccStd: List<Float>,           // 39-dim MFCC-Standardabweichung
    val spectralCentroid: Float,        // Spektraler Schwerpunkt (Hz)
    val spectralRolloff: Float,         // 85% Rolloff-Frequenz
    val zeroCrossingRate: Float,        // Nulldurchgangsrate
    val pitchMean: Float,               // Mittlere Grundfrequenz F0 (Hz)
    val pitchJitter: Float,             // Stimmzitter (Variabilität)
    val pitchShimmer: Float,            // Amplitudenschwankung
    val threshold: Float = 0.80f,       // Erkennungs-Schwellwert
    val adaptiveThreshold: Float = 0.80f,
    val sampleCount: Int = 0,
    val features: List<Float> = emptyList(), // Legacy-Kompatibilität
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis(),
    val deviceFingerprints: Map<String, String> = emptyMap(),
)

@Serializable
data class VoiceRecognitionResult(
    val recognized: Boolean,
    val confidence: Float,
    val isCeo: Boolean,
    val mfccScore: Float = 0f,          // MFCC-Ähnlichkeit
    val pitchScore: Float = 0f,         // Pitch-Ähnlichkeit
    val spectralScore: Float = 0f,      // Spektrale Ähnlichkeit
    val speakerId: String = "",
    val timestamp: Long = System.currentTimeMillis(),
)

class VoicePrintManager(
    private val context: Context,
    private val ssd: SsdStorageManager,
) {
    private val json = Json { ignoreUnknownKeys = true; prettyPrint = true }
    private var ceoPrint: VoicePrint? = null
    private val pendingSamples = mutableListOf<AudioFeatures>()

    companion object {
        const val CEO_ID   = "finn.jona.lischke"
        const val CEO_NAME = "Finn Jona Thorsten Lischke"
        const val MIN_SAMPLES = 3       // Mindest-Samples für initiales Profil
        const val RECOMMENDED_SAMPLES = 10  // Empfohlene Samples für hohe Genauigkeit
        private const val SAMPLE_RATE = 16_000  // 16kHz Standard
        private const val MFCC_NUM    = 13      // MFCC-Koeffizienten
        private const val MFCC_DIM    = 39      // 13 + 13Δ + 13ΔΔ
        private const val FRAME_SIZE  = 512     // ~32ms bei 16kHz
        private const val HOP_SIZE    = 160     // ~10ms hop
        const val VOICE_PRINT_FILE = "ceo_voice_print.json"
    }

    private data class AudioFeatures(
        val mfcc: FloatArray,           // 39-dim
        val spectralCentroid: Float,
        val spectralRolloff: Float,
        val zcr: Float,
        val pitchHz: Float,
        val jitter: Float,
        val shimmer: Float,
    )

    // ── Lern-Phase ─────────────────────────────────────────────────────────────

    suspend fun addLearningSample(audioBuffer: ShortArray): Boolean {
        val features = extractAllFeatures(audioBuffer)
        pendingSamples.add(features)
        Log.i("VoicePrint", "Sample #${pendingSamples.size} (min $MIN_SAMPLES, empfohlen $RECOMMENDED_SAMPLES)")
        return pendingSamples.size >= MIN_SAMPLES
    }

    suspend fun buildPrint(): VoicePrint {
        require(pendingSamples.size >= MIN_SAMPLES) {
            "Zu wenig Samples (${pendingSamples.size}/$MIN_SAMPLES)"
        }
        val dim = MFCC_DIM

        // MFCC Mittelwert + Standardabweichung
        val mfccMean = FloatArray(dim) { i -> pendingSamples.map { it.mfcc[i] }.average().toFloat() }
        val mfccStd  = FloatArray(dim) { i ->
            val mean = mfccMean[i]
            sqrt(pendingSamples.map { (it.mfcc[i] - mean).pow(2) }.average().toFloat())
        }

        // Spektrale Features (Median für Robustheit)
        fun median(list: List<Float>): Float = list.sorted().let { s -> s[s.size / 2] }

        val print = VoicePrint(
            ceoId           = CEO_ID,
            ceoName         = CEO_NAME,
            mfccMean        = mfccMean.toList(),
            mfccStd         = mfccStd.toList(),
            spectralCentroid= median(pendingSamples.map { it.spectralCentroid }),
            spectralRolloff = median(pendingSamples.map { it.spectralRolloff }),
            zeroCrossingRate= median(pendingSamples.map { it.zcr }),
            pitchMean       = median(pendingSamples.map { it.pitchHz }),
            pitchJitter     = pendingSamples.map { it.jitter }.average().toFloat(),
            pitchShimmer    = pendingSamples.map { it.shimmer }.average().toFloat(),
            features        = mfccMean.toList(), // Legacy
            sampleCount     = pendingSamples.size,
        )
        ceoPrint = print
        savePrint(print)
        pendingSamples.clear()
        Log.i("VoicePrint", "✓ CEO Voice-Print erstellt: ${print.sampleCount} Samples, Pitch=${print.pitchMean}Hz")
        return print
    }

    // ── Erkennung ──────────────────────────────────────────────────────────────

    fun recognize(audioBuffer: ShortArray): VoiceRecognitionResult {
        val print = ceoPrint ?: return VoiceRecognitionResult(false, 0f, false)
        val feat  = extractAllFeatures(audioBuffer)

        // 1. MFCC-Score (gewichtet nach Standardabweichung)
        val mfccScore = weightedCosineSimilarity(
            feat.mfcc, print.mfccMean.toFloatArray(), print.mfccStd.toFloatArray()
        )

        // 2. Pitch-Score (log-Ähnlichkeit)
        val pitchScore = if (print.pitchMean > 0 && feat.pitchHz > 0) {
            val ratio = minOf(feat.pitchHz, print.pitchMean) / maxOf(feat.pitchHz, print.pitchMean)
            ratio.pow(2)  // quadratisch für mehr Strenge
        } else 0.5f

        // 3. Spektral-Score
        val centroidSim = spectralSimilarity(feat.spectralCentroid, print.spectralCentroid)
        val rolloffSim  = spectralSimilarity(feat.spectralRolloff,  print.spectralRolloff)
        val spectralScore = (centroidSim + rolloffSim) / 2f

        // Gewichtete Gesamtbewertung: MFCC 60%, Pitch 25%, Spektral 15%
        val totalScore = 0.60f * mfccScore + 0.25f * pitchScore + 0.15f * spectralScore
        val threshold  = ceoPrint?.adaptiveThreshold ?: 0.80f
        val recognized = totalScore >= threshold

        if (recognized) {
            // Adaptives Update: Print verbessert sich mit jeder erfolgreichen Erkennung
            adaptivePrintUpdate(feat)
        }

        Log.d("VoicePrint", "MFCC=${"%.3f".format(mfccScore)} Pitch=${"%.3f".format(pitchScore)} " +
            "Spektral=${"%.3f".format(spectralScore)} Gesamt=${"%.3f".format(totalScore)} " +
            "Schwelle=$threshold → Erkannt=$recognized")

        return VoiceRecognitionResult(
            recognized    = recognized,
            confidence    = totalScore,
            isCeo         = recognized,
            mfccScore     = mfccScore,
            pitchScore    = pitchScore,
            spectralScore = spectralScore,
            speakerId     = if (recognized) CEO_ID else "unknown",
        )
    }

    // ── Adaptives Lernen ───────────────────────────────────────────────────────

    /**
     * Verbessert den Print mit jeder bestätigten CEO-Stimme.
     * Exponentielles gleitendes Mittel (α = 0.05 → langsame Anpassung).
     */
    private fun adaptivePrintUpdate(feat: AudioFeatures) {
        val print = ceoPrint ?: return
        val α = 0.05f  // Lernrate
        val newMean = FloatArray(MFCC_DIM) { i ->
            (1 - α) * print.mfccMean[i] + α * feat.mfcc[i]
        }
        ceoPrint = print.copy(
            mfccMean        = newMean.toList(),
            pitchMean       = (1 - α) * print.pitchMean + α * feat.pitchHz,
            spectralCentroid= (1 - α) * print.spectralCentroid + α * feat.spectralCentroid,
            sampleCount     = print.sampleCount + 1,
            updatedAt       = System.currentTimeMillis(),
        )
    }

    // ── Feature-Extraktion ────────────────────────────────────────────────────

    private fun extractAllFeatures(audio: ShortArray): AudioFeatures {
        val floatAudio = FloatArray(audio.size) { audio[it] / 32768f }
        val mfcc       = extractMfcc(floatAudio)
        val zcr        = computeZeroCrossingRate(floatAudio)
        val (centroid, rolloff) = computeSpectralFeatures(floatAudio)
        val (pitch, jitter, shimmer) = extractPitch(floatAudio)

        return AudioFeatures(mfcc, centroid, rolloff, zcr, pitch, jitter, shimmer)
    }

    /**
     * Echte MFCC-Extraktion:
     * 1. Pre-Emphasis
     * 2. Framing + Hamming-Fenster
     * 3. FFT → Leistungsspektrum
     * 4. Mel-Filter-Bank (26 Filter)
     * 5. DCT → 13 Koeffizienten
     * 6. Delta + Delta-Delta → 39 gesamt
     */
    private fun extractMfcc(audio: FloatArray): FloatArray {
        // Pre-Emphasis (hochpassfiltert Signal)
        val preemph = FloatArray(audio.size)
        preemph[0] = audio[0]
        for (i in 1 until audio.size) preemph[i] = audio[i] - 0.97f * audio[i - 1]

        val frames = mutableListOf<FloatArray>()
        var start  = 0
        while (start + FRAME_SIZE <= preemph.size) {
            val frame = FloatArray(FRAME_SIZE)
            for (i in 0 until FRAME_SIZE) {
                // Hamming-Fenster
                val window = 0.54f - 0.46f * cos(2.0 * PI * i / (FRAME_SIZE - 1)).toFloat()
                frame[i] = preemph[start + i] * window
            }
            frames.add(frame)
            start += HOP_SIZE
        }

        if (frames.isEmpty()) return FloatArray(MFCC_DIM)

        // FFT → Mel-Spektrum → MFCC pro Frame
        val mfccFrames = frames.map { frame ->
            val spectrum = computePowerSpectrum(frame)
            val melFilter = applyMelFilterBank(spectrum, 26, SAMPLE_RATE)
            computeDct(melFilter, MFCC_NUM)
        }

        // Mittelwert über alle Frames (= statische MFCC-Features)
        val staticMfcc = FloatArray(MFCC_NUM) { i ->
            mfccFrames.map { it[i] }.average().toFloat()
        }

        // Delta MFCC (erste Ableitung)
        val deltaMfcc = FloatArray(MFCC_NUM) { i ->
            if (mfccFrames.size < 2) 0f
            else {
                val diffs = mutableListOf<Float>()
                for (f in 1 until mfccFrames.size) {
                    diffs.add(mfccFrames[f][i] - mfccFrames[f-1][i])
                }
                diffs.average().toFloat()
            }
        }

        // Delta-Delta MFCC (zweite Ableitung)
        val deltaDeltaMfcc = FloatArray(MFCC_NUM) { i ->
            if (mfccFrames.size < 3) 0f
            else {
                val diffs = mutableListOf<Float>()
                for (f in 2 until mfccFrames.size) {
                    diffs.add(mfccFrames[f][i] - 2f * mfccFrames[f-1][i] + mfccFrames[f-2][i])
                }
                diffs.average().toFloat()
            }
        }

        // Zusammensetzen: [static | delta | delta-delta] = 39
        return staticMfcc + deltaMfcc + deltaDeltaMfcc
    }

    private operator fun FloatArray.plus(other: FloatArray): FloatArray =
        FloatArray(this.size + other.size) { i ->
            if (i < this.size) this[i] else other[i - this.size]
        }

    private fun computePowerSpectrum(frame: FloatArray): FloatArray {
        val n   = Integer.highestOneBit(frame.size)
        val re  = DoubleArray(n) { if (it < frame.size) frame[it].toDouble() else 0.0 }
        val im  = DoubleArray(n)
        fft(re, im)
        return FloatArray(n / 2 + 1) { i -> (re[i] * re[i] + im[i] * im[i]).toFloat() }
    }

    /** Radix-2 Cooley-Tukey FFT (in-place) */
    private fun fft(re: DoubleArray, im: DoubleArray) {
        val n = re.size
        var len = 2
        while (len <= n) {
            val ang = 2 * PI / len
            val wrE = cos(ang); val wrI = -sin(ang)
            var i = 0
            while (i < n) {
                var wE = 1.0; var wI = 0.0
                for (j in 0 until len / 2) {
                    val uE = re[i + j];         val uI = im[i + j]
                    val vE = re[i + j + len/2]; val vI = im[i + j + len/2]
                    re[i + j]         = uE + wE * vE - wI * vI
                    im[i + j]         = uI + wE * vI + wI * vE
                    re[i + j + len/2] = uE - (wE * vE - wI * vI)
                    im[i + j + len/2] = uI - (wE * vI + wI * vE)
                    val tmp = wE * wrE - wI * wrI; wI = wE * wrI + wI * wrE; wE = tmp
                }
                i += len
            }
            len *= 2
        }
    }

    private fun applyMelFilterBank(spectrum: FloatArray, numFilters: Int, sr: Int): FloatArray {
        val minHz = 80.0; val maxHz = sr / 2.0
        fun hzToMel(hz: Double) = 2595.0 * log10(1.0 + hz / 700.0)
        fun melToHz(mel: Double) = 700.0 * (10.0.pow(mel / 2595.0) - 1.0)
        val minMel = hzToMel(minHz); val maxMel = hzToMel(maxHz)
        val points = DoubleArray(numFilters + 2) { i ->
            melToHz(minMel + i * (maxMel - minMel) / (numFilters + 1))
        }
        val output = FloatArray(numFilters)
        for (m in 0 until numFilters) {
            val f0 = points[m]; val f1 = points[m + 1]; val f2 = points[m + 2]
            val n  = spectrum.size
            var sum = 0.0
            for (k in 0 until n) {
                val hz = k.toDouble() * sr / (2.0 * (n - 1))
                val w  = when {
                    hz in f0..f1 -> (hz - f0) / (f1 - f0)
                    hz in f1..f2 -> (f2 - hz) / (f2 - f1)
                    else -> 0.0
                }
                sum += w * spectrum[k]
            }
            output[m] = ln(sum.coerceAtLeast(1e-10)).toFloat()
        }
        return output
    }

    private fun computeDct(input: FloatArray, numCoeffs: Int): FloatArray {
        val n = input.size
        return FloatArray(numCoeffs) { k ->
            var sum = 0.0
            for (n2 in input.indices) sum += input[n2] * cos(PI * k * (2 * n2 + 1) / (2 * n))
            (sum * sqrt(2.0 / n)).toFloat()
        }
    }

    private fun computeZeroCrossingRate(audio: FloatArray): Float {
        var zcr = 0
        for (i in 1 until audio.size) {
            if ((audio[i] >= 0) != (audio[i - 1] >= 0)) zcr++
        }
        return zcr.toFloat() / audio.size
    }

    private fun computeSpectralFeatures(audio: FloatArray): Pair<Float, Float> {
        val n   = Integer.highestOneBit(audio.size.coerceAtLeast(2))
        val re  = DoubleArray(n) { if (it < audio.size) audio[it].toDouble() else 0.0 }
        val im  = DoubleArray(n)
        fft(re, im)
        val mag   = DoubleArray(n / 2 + 1) { sqrt(re[it] * re[it] + im[it] * im[it]) }
        val total = mag.sum()
        // Spektraler Schwerpunkt
        val centroid = if (total > 0) {
            mag.indices.sumOf { it * mag[it] / total }.toFloat() * SAMPLE_RATE / n
        } else 0f
        // 85%-Rolloff
        val target  = 0.85 * total
        var cumSum  = 0.0
        var rolloff = 0
        for (i in mag.indices) { cumSum += mag[i]; if (cumSum >= target) { rolloff = i; break } }
        return centroid to (rolloff.toFloat() * SAMPLE_RATE / n)
    }

    /**
     * Pitch-Extraktion via Autocorrelation (YIN-inspiriert).
     * Gibt F0, Jitter, Shimmer zurück.
     */
    private fun extractPitch(audio: FloatArray): Triple<Float, Float, Float> {
        val frames = mutableListOf<Pair<Float, Float>>()  // (pitch, energy)
        var start  = 0
        while (start + FRAME_SIZE <= audio.size) {
            val frame = audio.copyOfRange(start, start + FRAME_SIZE)
            val (pitch, energy) = pitchFrame(frame)
            if (pitch > 50 && pitch < 600) frames.add(pitch to energy)
            start += HOP_SIZE
        }
        if (frames.isEmpty()) return Triple(0f, 0f, 0f)

        val pitches  = frames.map { it.first }
        val energies = frames.map { it.second }
        val meanPitch = pitches.average().toFloat()

        // Jitter: relative F0-Variabilität
        val jitter = if (pitches.size > 1) {
            pitches.zipWithNext { a, b -> abs(a - b) }.average().toFloat() /
            (meanPitch.coerceAtLeast(1f))
        } else 0f

        // Shimmer: relative Amplituden-Variabilität
        val shimmer = if (energies.size > 1) {
            energies.zipWithNext { a, b -> abs(a - b) }.average().toFloat() /
            (energies.average().toFloat().coerceAtLeast(1e-6f))
        } else 0f

        return Triple(meanPitch, jitter, shimmer)
    }

    private fun pitchFrame(frame: FloatArray): Pair<Float, Float> {
        val n     = frame.size
        val energy = sqrt(frame.sumOf { it.toDouble() * it } / n).toFloat()
        // Autocorrelation-basierte Pitch-Schätzung
        val minLag = (SAMPLE_RATE / 600).toInt()  // max 600Hz
        val maxLag = (SAMPLE_RATE / 50).toInt()   // min 50Hz
        var bestLag = minLag; var bestAc = -1.0
        for (lag in minLag..minOf(maxLag, n - 1)) {
            var ac = 0.0
            for (i in 0 until n - lag) ac += frame[i] * frame[i + lag]
            if (ac > bestAc) { bestAc = ac; bestLag = lag }
        }
        val pitch = SAMPLE_RATE.toFloat() / bestLag
        return pitch to energy
    }

    // ── Vergleichsmetriken ────────────────────────────────────────────────────

    /**
     * Gewichtete Kosinus-Ähnlichkeit (Dimensionen mit höherer Standardabweichung
     * sind zuverlässiger → höheres Gewicht).
     */
    private fun weightedCosineSimilarity(a: FloatArray, b: FloatArray, std: FloatArray): Float {
        if (a.size != b.size) return 0f
        var wDot = 0.0; var wNormA = 0.0; var wNormB = 0.0
        for (i in a.indices) {
            val w = (std.getOrElse(i) { 1f } + 1e-6f).toDouble()
            wDot  += w * a[i] * b[i]
            wNormA += w * a[i] * a[i]
            wNormB += w * b[i] * b[i]
        }
        val denom = sqrt(wNormA) * sqrt(wNormB)
        return if (denom == 0.0) 0f else (wDot / denom).toFloat().coerceIn(0f, 1f)
    }

    private fun spectralSimilarity(a: Float, b: Float): Float {
        if (b == 0f) return 0f
        return (minOf(a, b) / maxOf(a, b)).coerceIn(0f, 1f)
    }

    // ── Persistenz ─────────────────────────────────────────────────────────────

    suspend fun loadPrint(): VoicePrint? = withContext(Dispatchers.IO) {
        val raw = ssd.readFile("jayjay", VOICE_PRINT_FILE)
        ceoPrint = raw?.let { runCatching { json.decodeFromString<VoicePrint>(it) }.getOrNull() }
        if (ceoPrint != null) {
            Log.i("VoicePrint", "CEO Voice-Print geladen: ${ceoPrint!!.sampleCount} Samples, " +
                "Pitch=${ceoPrint!!.pitchMean}Hz")
        }
        ceoPrint
    }

    private suspend fun savePrint(print: VoicePrint) = withContext(Dispatchers.IO) {
        ssd.writeFile("jayjay", VOICE_PRINT_FILE, json.encodeToString(print))
        Log.i("VoicePrint", "CEO Voice-Print gespeichert")
    }

    fun getDistributablePrint(): String? {
        val print = ceoPrint ?: return null
        return json.encodeToString(print.copy(
            mfccMean = emptyList(), mfccStd = emptyList(), features = emptyList(),
            deviceFingerprints = mapOf("hash" to hashPrint(print))
        ))
    }

    private fun hashPrint(print: VoicePrint): String {
        val data = (print.mfccMean + print.mfccStd).joinToString(",")
        return MessageDigest.getInstance("SHA-256").digest(data.toByteArray())
            .joinToString("") { "%02x".format(it) }
    }

    fun hasPrint()          = ceoPrint != null
    fun getSampleProgress() = pendingSamples.size to MIN_SAMPLES

    // Für Anzeige: Erkennungs-Güte des aktuellen Prints
    fun getPrintQuality(): String {
        val p = ceoPrint ?: return "Kein Voice-Print"
        return when {
            p.sampleCount >= RECOMMENDED_SAMPLES -> "Exzellent (${p.sampleCount} Samples)"
            p.sampleCount >= MIN_SAMPLES         -> "Gut (${p.sampleCount} Samples, ${RECOMMENDED_SAMPLES - p.sampleCount} mehr empfohlen)"
            else                                 -> "Unzureichend"
        }
    }
}
