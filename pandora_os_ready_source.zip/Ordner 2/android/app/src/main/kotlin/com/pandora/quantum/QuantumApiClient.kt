package com.pandora.quantum

import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import okhttp3.OkHttpClient
import okhttp3.Request
import android.util.Base64
import java.util.concurrent.TimeUnit

/**
 * Quantum-Entropie Client mit dreistufiger Fallback-Kette:
 *
 *   1. CEO-Host (Pandora Quantum Key Distribution Server)
 *      → GET http://<ceo-host>:8765/pandora/quantum/entropy
 *      → Kein externes Internet nötig, funktioniert im lokalen Netz
 *
 *   2. ANU QRNG (Australian National University – kostenlos, kein API-Key)
 *      → https://qrng.anu.edu.au/API/jsonI.php
 *
 *   3. NIST Randomness Beacon (öffentlich, alle 60s neue Quanten-Entropie)
 *      → https://beacon.nist.gov/beacon/2.0/pulse/last
 *
 *   4. Lokale SecureRandom-Entropie (Offline-Fallback)
 */
object QuantumApiClient {

    private const val TAG = "QuantumApiClient"

    // CEO-Host Konfiguration (wird zur Laufzeit gesetzt)
    @Volatile var ceoHostUrl: String? = null      // z.B. "http://192.168.1.100:8765"
    @Volatile var authToken: String? = null        // Bearer-Token für CEO-Host

    // Externe APIs
    private const val ANU_QRNG_URL =
        "https://qrng.anu.edu.au/API/jsonI.php?length=64&type=uint8&size=1"
    private const val NIST_BEACON_URL =
        "https://beacon.nist.gov/beacon/2.0/pulse/last"

    private val client = OkHttpClient.Builder()
        .connectTimeout(8, TimeUnit.SECONDS)
        .readTimeout(12, TimeUnit.SECONDS)
        .build()

    private val json = Json { ignoreUnknownKeys = true }

    @Serializable
    private data class AnuResponse(val success: Boolean, val data: List<Int> = emptyList())

    @Serializable
    private data class NistResponse(val pulse: NistPulse)

    @Serializable
    private data class NistPulse(val outputValue: String)

    /**
     * Holt 64 Quanten-Entropie-Bytes.
     * Versucht CEO-Host → ANU QRNG → NIST Beacon → Lokal.
     */
    suspend fun fetchQuantumEntropy(): ByteArray = withContext(Dispatchers.IO) {

        // ① CEO-Host (lokales Pandora-Netz)
        val ceo = ceoHostUrl
        val token = authToken
        if (ceo != null && token != null) {
            try {
                val result = fetchFromCeoHost(ceo, token)
                Log.d(TAG, "✓ Quanten-Entropie vom CEO-Host (${result.size} Bytes)")
                return@withContext result
            } catch (e: Exception) {
                Log.w(TAG, "CEO-Host nicht erreichbar: ${e.message}")
            }
        }

        // ② ANU QRNG
        try {
            val result = fetchFromAnu()
            Log.d(TAG, "✓ Quanten-Entropie von ANU QRNG (${result.size} Bytes)")
            return@withContext result
        } catch (e: Exception) {
            Log.w(TAG, "ANU QRNG nicht erreichbar: ${e.message}")
        }

        // ③ NIST Beacon
        try {
            val result = fetchFromNist()
            Log.d(TAG, "✓ Quanten-Entropie von NIST Beacon (${result.size} Bytes)")
            return@withContext result
        } catch (e: Exception) {
            Log.w(TAG, "NIST Beacon nicht erreichbar: ${e.message}")
        }

        // ④ Lokaler Fallback
        Log.w(TAG, "Alle Quellen offline → lokale SecureRandom-Entropie")
        generateLocalFallbackEntropy()
    }

    /**
     * Holt das komplette Quantum Key Bundle vom CEO-Host.
     * Gibt null zurück wenn CEO offline oder Bundle nicht bereit.
     */
    suspend fun fetchKeyBundleFromCeo(ceoUrl: String, token: String): QuantumKeyServer.QuantumKeyBundle? =
        withContext(Dispatchers.IO) {
            try {
                val request = Request.Builder()
                    .url("$ceoUrl/pandora/quantum/keys")
                    .header("Authorization", "Bearer $token")
                    .build()
                val response = client.newCall(request).execute()
                if (!response.isSuccessful) return@withContext null
                val body = response.body?.string() ?: return@withContext null
                json.decodeFromString<QuantumKeyServer.QuantumKeyBundle>(body)
            } catch (e: Exception) {
                Log.w(TAG, "Key Bundle vom CEO nicht abrufbar: ${e.message}")
                null
            }
        }

    // ── Private Fetch-Methoden ───────────────────────────────────────────────

    private fun fetchFromCeoHost(ceoUrl: String, token: String): ByteArray {
        val request = Request.Builder()
            .url("$ceoUrl/pandora/quantum/entropy")
            .header("Authorization", "Bearer $token")
            .header("Accept", "application/json")
            .build()

        val response = client.newCall(request).execute()
        if (!response.isSuccessful) throw Exception("CEO-Host HTTP ${response.code}")

        val body = response.body?.string() ?: throw Exception("CEO-Host: leere Antwort")
        val parsed = json.parseToJsonElement(body).jsonObject

        val entropyB64 = parsed["entropy"]?.jsonPrimitive?.content
            ?: throw Exception("CEO-Host: kein entropy-Feld")

        return Base64.decode(entropyB64, Base64.NO_WRAP)
    }

    private fun fetchFromAnu(): ByteArray {
        val request = Request.Builder().url(ANU_QRNG_URL)
            .header("Accept", "application/json").build()
        val response = client.newCall(request).execute()
        if (!response.isSuccessful) throw Exception("ANU HTTP ${response.code}")
        val body = response.body?.string() ?: throw Exception("ANU: leere Antwort")
        val parsed = json.decodeFromString<AnuResponse>(body)
        if (!parsed.success || parsed.data.isEmpty()) throw Exception("ANU: ungültige Antwort")
        return parsed.data.map { it.toByte() }.toByteArray()
    }

    private fun fetchFromNist(): ByteArray {
        val request = Request.Builder().url(NIST_BEACON_URL)
            .header("Accept", "application/json").build()
        val response = client.newCall(request).execute()
        if (!response.isSuccessful) throw Exception("NIST HTTP ${response.code}")
        val body = response.body?.string() ?: throw Exception("NIST: leere Antwort")
        val parsed = json.decodeFromString<NistResponse>(body)
        return parsed.pulse.outputValue.chunked(2).map { it.toInt(16).toByte() }.toByteArray()
    }

    private fun generateLocalFallbackEntropy(): ByteArray {
        val seed = ByteArray(64)
        java.security.SecureRandom().nextBytes(seed)
        val extra = "${System.nanoTime()}${Runtime.getRuntime().freeMemory()}".toByteArray()
        for (i in seed.indices) {
            seed[i] = (seed[i].toInt() xor extra[i % extra.size].toInt()).toByte()
        }
        return seed
    }

    /**
     * Konfiguriert CEO-Host wenn sich ein Gerät authentifiziert.
     * Wird von AuthContext aufgerufen nach erfolgreichem Login.
     */
    fun configureCeoHost(hostUrl: String, token: String) {
        ceoHostUrl = hostUrl
        authToken = token
        Log.i(TAG, "CEO Quantum Host konfiguriert: $hostUrl")
    }

    fun clearCeoHost() {
        ceoHostUrl = null
        authToken = null
    }
}
