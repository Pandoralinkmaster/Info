package com.pandora.quantum

import android.util.Log
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.coroutines.delay
import kotlinx.serialization.Serializable
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import android.util.Base64

/**
 * Quantum Key Distribution (QKD) Server – läuft auf dem CEO-Gerät.
 *
 * Architektur:
 *   CEO-Host (Samsung S24 Ultra)
 *     ├── holt Quantenentropie von ANU QRNG API
 *     ├── generiert Kyber-768 Session-Keys
 *     ├── stellt /pandora/quantum/* Endpunkte bereit
 *     └── verteilt signierte Quantum-Keys an alle Netz-Teilnehmer
 *
 *   Clients (andere Android-Geräte)
 *     └── holen Keys vom CEO-Host (nie direkt von ANU API)
 *         Fallback: ANU API direkt (wenn CEO offline)
 *         Fallback: lokale Entropie (wenn komplett offline)
 *
 * Key-Rotation: automatisch alle 30 Minuten.
 */
object QuantumKeyServer {

    private const val TAG = "QuantumKeyServer"
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val json = Json { prettyPrint = false }

    // ── Verteilter Schlüsselpool ────────────────────────────────────────────

    @Volatile private var currentBundle: QuantumKeyBundle? = null
    @Volatile private var bundleGeneratedAt = 0L
    private val ROTATION_INTERVAL_MS = 30 * 60 * 1000L // 30 Minuten

    @Serializable
    data class QuantumKeyBundle(
        val bundleId: String,
        val kyberPublicKey: String,       // Base64, ML-KEM-768
        val dilithiumPublicKey: String,   // Base64, ML-DSA-65
        val entropySource: String,        // "ANU_QRNG" | "NIST_BEACON" | "LOCAL"
        val quantumBytes: Int,            // Anzahl der Quanten-Entropie-Bytes
        val generatedAt: Long,
        val expiresAt: Long,
        val signature: String,           // Dilithium-Signatur des gesamten Bundles
        val algorithmInfo: String
    )

    @Serializable
    data class QuantumStatusResponse(
        val active: Boolean,
        val bundleId: String?,
        val entropySource: String?,
        val nextRotationIn: Long,        // Millisekunden
        val totalBundlesGenerated: Int,
        val algorithmSuite: String
    )

    private var totalBundles = 0

    // ── Initialisierung ─────────────────────────────────────────────────────

    fun start(keyManager: QuantumKeyManager) {
        Log.i(TAG, "Quantum Key Distribution Server gestartet")
        scope.launch {
            while (true) {
                try {
                    generateAndStoreBundle(keyManager)
                } catch (e: Exception) {
                    Log.e(TAG, "Bundle-Generierung fehlgeschlagen: ${e.message}")
                }
                delay(ROTATION_INTERVAL_MS)
            }
        }
    }

    // ── Bundle-Generierung ──────────────────────────────────────────────────

    private suspend fun generateAndStoreBundle(keyManager: QuantumKeyManager) {
        Log.d(TAG, "Generiere neues Quantum Key Bundle...")

        // Quanten-Entropie holen
        var entropySource = "LOCAL"
        val entropy = try {
            QuantumApiClient.fetchQuantumEntropy().also { entropySource = "ANU_QRNG" }
        } catch (e1: Exception) {
            try {
                QuantumApiClient.fetchQuantumEntropy().also { entropySource = "NIST_BEACON" }
            } catch (e2: Exception) {
                ByteArray(64).also { java.security.SecureRandom().nextBytes(it) }
            }
        }

        // Kyber + Dilithium Schlüsselpaare
        val kyberPair = QuantumCryptoEngine.generateKyberKeyPair(entropy)
        val dilPair = QuantumCryptoEngine.generateDilithiumKeyPair(entropy)

        val bundleId = "QKB-${System.currentTimeMillis()}-${entropy.take(4).joinToString("") { "%02x".format(it) }}"
        val now = System.currentTimeMillis()
        val expires = now + ROTATION_INTERVAL_MS

        // Bundle signieren mit Dilithium
        val bundleData = "${bundleId}${Base64.encodeToString(kyberPair.publicKey, Base64.NO_WRAP)}${now}".toByteArray()
        val signature = try {
            QuantumCryptoEngine.dilithiumSign(bundleData, dilPair.privateKey)
        } catch (e: Exception) {
            ByteArray(0)
        }

        currentBundle = QuantumKeyBundle(
            bundleId = bundleId,
            kyberPublicKey = Base64.encodeToString(kyberPair.publicKey, Base64.NO_WRAP),
            dilithiumPublicKey = Base64.encodeToString(dilPair.publicKey, Base64.NO_WRAP),
            entropySource = entropySource,
            quantumBytes = entropy.size,
            generatedAt = now,
            expiresAt = expires,
            signature = Base64.encodeToString(signature, Base64.NO_WRAP),
            algorithmInfo = "ML-KEM-768 + ML-DSA-65 + AES-256-GCM"
        )
        bundleGeneratedAt = now
        totalBundles++

        Log.i(TAG, "✓ Quantum Key Bundle generiert: $bundleId (Entropie: $entropySource, ${entropy.size} Bytes)")
    }

    // ── API Antworten ────────────────────────────────────────────────────────

    /**
     * Gibt das aktuelle Key Bundle als JSON zurück (für /pandora/quantum/keys).
     */
    fun getCurrentBundleJson(): String {
        val bundle = currentBundle ?: return """{"error":"bundle_not_ready"}"""
        return json.encodeToString(bundle)
    }

    /**
     * Status-Antwort für /pandora/quantum/status.
     */
    fun getStatusJson(): String {
        val bundle = currentBundle
        val nextRotation = if (bundle != null)
            ROTATION_INTERVAL_MS - (System.currentTimeMillis() - bundleGeneratedAt)
        else 0L

        return json.encodeToString(QuantumStatusResponse(
            active = bundle != null,
            bundleId = bundle?.bundleId,
            entropySource = bundle?.entropySource,
            nextRotationIn = maxOf(0L, nextRotation),
            totalBundlesGenerated = totalBundles,
            algorithmSuite = "CRYSTALS-Kyber ML-KEM-768 + CRYSTALS-Dilithium ML-DSA-65"
        ))
    }

    /**
     * Frische Quanten-Entropie on-demand (für /pandora/quantum/entropy).
     * Nur für autorisierte CEO/Manager-Geräte.
     */
    suspend fun getFreshEntropyJson(): String {
        return try {
            val entropy = QuantumApiClient.fetchQuantumEntropy()
            val encoded = Base64.encodeToString(entropy, Base64.NO_WRAP)
            """{"entropy":"$encoded","bytes":${entropy.size},"source":"ANU_QRNG"}"""
        } catch (e: Exception) {
            """{"error":"${e.message}"}"""
        }
    }

    fun isReady() = currentBundle != null
}
