package com.pandora.quantum

import android.util.Log
import org.bouncycastle.pqc.jcajce.provider.BouncyCastlePQCProvider
import org.bouncycastle.pqc.jcajce.spec.KyberParameterSpec
import org.bouncycastle.pqc.jcajce.spec.DilithiumParameterSpec
import java.security.KeyPairGenerator
import java.security.KeyFactory
import java.security.Security
import java.security.PublicKey
import java.security.PrivateKey
import java.security.SecureRandom
import javax.crypto.KeyAgreement
import javax.crypto.Cipher
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.SecretKeySpec
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * Quanten-resistente Kryptographie-Engine für Pandora.
 *
 * Algorithmen:
 *   - CRYSTALS-Kyber (ML-KEM-768) — Post-Quanten Key Encapsulation (NIST-Standard)
 *   - CRYSTALS-Dilithium (ML-DSA-65) — Post-Quanten Digitalsignatur (NIST-Standard)
 *   - AES-256-GCM — symmetrische Nachrichtenverschlüsselung mit Quantum-Key
 *
 * Quantensicherheit: Sicher gegen Shor- und Grover-Algorithmus auf Quantencomputern.
 */
object QuantumCryptoEngine {

    private const val TAG = "QuantumCryptoEngine"
    private const val GCM_IV_LENGTH = 12
    private const val GCM_TAG_LENGTH = 128

    init {
        // Bouncy Castle PQC Provider registrieren
        if (Security.getProvider("BCPQC") == null) {
            Security.addProvider(BouncyCastlePQCProvider())
            Log.d(TAG, "Bouncy Castle PQC Provider registriert")
        }
    }

    // ── Kyber Key Encapsulation ─────────────────────────────────────────────

    data class KyberKeyPair(
        val publicKey: ByteArray,
        val privateKey: ByteArray
    )

    data class KyberCiphertext(
        val ciphertext: ByteArray,  // Kyber-Kapselung
        val sharedSecret: ByteArray // 32 Bytes gemeinsames Geheimnis
    )

    /**
     * Generiert ein Kyber-768 Schlüsselpaar (Post-Quanten KEM).
     * Verwendet Quanten-Zufallsentropie für maximale Sicherheit.
     */
    suspend fun generateKyberKeyPair(quantumEntropy: ByteArray? = null): KyberKeyPair =
        withContext(Dispatchers.Default) {
            val rng = buildQuantumSecureRandom(quantumEntropy)
            val kpg = KeyPairGenerator.getInstance("Kyber", "BCPQC")
            kpg.initialize(KyberParameterSpec.kyber768, rng)
            val kp = kpg.generateKeyPair()

            KyberKeyPair(
                publicKey = kp.public.encoded,
                privateKey = kp.private.encoded
            ).also { Log.d(TAG, "Kyber-768 Schlüsselpaar generiert") }
        }

    /**
     * Kapselt einen zufälligen gemeinsamen Schlüssel mit dem öffentlichen Kyber-Key.
     * Erzeugt Kiphertext + SharedSecret (für AES-Verschlüsselung nutzen).
     */
    suspend fun kyberEncapsulate(publicKeyBytes: ByteArray): KyberCiphertext =
        withContext(Dispatchers.Default) {
            val entropy = QuantumApiClient.fetchQuantumEntropy()
            val rng = buildQuantumSecureRandom(entropy)

            val keyFactory = KeyFactory.getInstance("Kyber", "BCPQC")
            val pubKey = keyFactory.generatePublic(
                javax.crypto.spec.SecretKeySpec(publicKeyBytes, "Kyber").let {
                    java.security.spec.X509EncodedKeySpec(publicKeyBytes)
                }
            )

            val kem = javax.crypto.KeyAgreement.getInstance("Kyber", "BCPQC")
            kem.init(pubKey, rng)
            val sharedSecret = kem.generateSecret()

            KyberCiphertext(
                ciphertext = kem.generateSecret(), // Kapselung
                sharedSecret = sharedSecret.copyOf(32)
            ).also { Log.d(TAG, "Kyber-768 Kapselung erfolgreich") }
        }

    // ── Dilithium Signaturen ────────────────────────────────────────────────

    data class DilithiumKeyPair(
        val publicKey: ByteArray,
        val privateKey: ByteArray
    )

    /**
     * Generiert ein Dilithium-3 Signaturschlüsselpaar.
     */
    suspend fun generateDilithiumKeyPair(quantumEntropy: ByteArray? = null): DilithiumKeyPair =
        withContext(Dispatchers.Default) {
            val rng = buildQuantumSecureRandom(quantumEntropy)
            val kpg = KeyPairGenerator.getInstance("Dilithium", "BCPQC")
            kpg.initialize(DilithiumParameterSpec.dilithium3, rng)
            val kp = kpg.generateKeyPair()

            DilithiumKeyPair(
                publicKey = kp.public.encoded,
                privateKey = kp.private.encoded
            ).also { Log.d(TAG, "Dilithium-3 Schlüsselpaar generiert") }
        }

    /**
     * Signiert Daten mit Dilithium (post-quantum sicher).
     */
    suspend fun dilithiumSign(data: ByteArray, privateKeyBytes: ByteArray): ByteArray =
        withContext(Dispatchers.Default) {
            val keyFactory = KeyFactory.getInstance("Dilithium", "BCPQC")
            val privKey = keyFactory.generatePrivate(
                java.security.spec.PKCS8EncodedKeySpec(privateKeyBytes)
            )
            val sig = java.security.Signature.getInstance("Dilithium", "BCPQC")
            sig.initSign(privKey)
            sig.update(data)
            sig.sign().also { Log.d(TAG, "Dilithium-3 Signatur erstellt (${it.size} Bytes)") }
        }

    /**
     * Verifiziert eine Dilithium-Signatur.
     */
    suspend fun dilithiumVerify(
        data: ByteArray,
        signature: ByteArray,
        publicKeyBytes: ByteArray
    ): Boolean = withContext(Dispatchers.Default) {
        try {
            val keyFactory = KeyFactory.getInstance("Dilithium", "BCPQC")
            val pubKey = keyFactory.generatePublic(
                java.security.spec.X509EncodedKeySpec(publicKeyBytes)
            )
            val sig = java.security.Signature.getInstance("Dilithium", "BCPQC")
            sig.initVerify(pubKey)
            sig.update(data)
            sig.verify(signature).also { Log.d(TAG, "Dilithium Verifikation: $it") }
        } catch (e: Exception) {
            Log.e(TAG, "Dilithium Verifikation fehlgeschlagen: ${e.message}")
            false
        }
    }

    // ── AES-GCM mit Quantum-Key ─────────────────────────────────────────────

    /**
     * Verschlüsselt Nachricht mit AES-256-GCM und Quantum-abgeleitetem Schlüssel.
     */
    fun encryptWithQuantumKey(plaintext: ByteArray, quantumKey: ByteArray): ByteArray {
        val iv = ByteArray(GCM_IV_LENGTH)
        SecureRandom().nextBytes(iv)

        val keySpec = SecretKeySpec(quantumKey.copyOf(32), "AES")
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, keySpec, GCMParameterSpec(GCM_TAG_LENGTH, iv))

        val encrypted = cipher.doFinal(plaintext)
        return iv + encrypted // IV + Chiffretext
    }

    /**
     * Entschlüsselt Nachricht mit AES-256-GCM und Quantum-abgeleitetem Schlüssel.
     */
    fun decryptWithQuantumKey(ciphertext: ByteArray, quantumKey: ByteArray): ByteArray {
        val iv = ciphertext.copyOf(GCM_IV_LENGTH)
        val encrypted = ciphertext.copyOfRange(GCM_IV_LENGTH, ciphertext.size)

        val keySpec = SecretKeySpec(quantumKey.copyOf(32), "AES")
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.DECRYPT_MODE, keySpec, GCMParameterSpec(GCM_TAG_LENGTH, iv))

        return cipher.doFinal(encrypted)
    }

    // ── Hilfsmethoden ───────────────────────────────────────────────────────

    /**
     * Erstellt einen SecureRandom der mit Quanten-Entropie geseedet ist.
     */
    private fun buildQuantumSecureRandom(quantumEntropy: ByteArray?): SecureRandom {
        val rng = SecureRandom()
        if (quantumEntropy != null && quantumEntropy.isNotEmpty()) {
            rng.setSeed(quantumEntropy)
            Log.d(TAG, "SecureRandom mit ${quantumEntropy.size} Quanten-Entropie-Bytes geseedet")
        }
        return rng
    }

    /**
     * Kombinierer-Funktion: Holt Quanten-Entropie und generiert direkt Kyber-Schlüsselpaar.
     */
    suspend fun generateQuantumKeyPairWithEntropy(): KyberKeyPair {
        val entropy = QuantumApiClient.fetchQuantumEntropy()
        return generateKyberKeyPair(entropy)
    }

    /**
     * Status-String für UI-Anzeige.
     */
    fun getAlgorithmInfo(): String =
        "ML-KEM-768 (Kyber) + ML-DSA-65 (Dilithium) + AES-256-GCM\nANTI-QUANTEN-SCHUTZ AKTIV"
}
