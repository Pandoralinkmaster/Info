package com.pandora.ui.screens

import android.content.Intent
import android.net.Uri
import android.provider.Settings
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.pandora.core.ConfigManager
import com.pandora.database.PandoraDatabase
import com.pandora.database.SsdStorageManager
import kotlinx.coroutines.launch
import org.koin.compose.koinInject

@Composable
private fun OsShell(
    title: String,
    subtitle: String,
    accent: Color,
    onBack: () -> Unit,
    content: @Composable ColumnScope.() -> Unit,
) {
    Surface(Modifier.fillMaxSize(), color = Color(0xFF07070D)) {
        Column(Modifier.fillMaxSize()) {
            Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, contentDescription = "Zurück", tint = Color.White) }
                Spacer(Modifier.width(6.dp))
                Column(Modifier.weight(1f)) {
                    Text(title, color = accent, fontSize = 20.sp, fontWeight = FontWeight.Black)
                    Text(subtitle, color = Color.Gray, fontSize = 11.sp)
                }
            }
            Column(
                Modifier
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                content = content
            )
        }
    }
}

@Composable
private fun OsCard(title: String, body: String, accent: Color = Color(0xFFE040FB), footer: String? = null) {
    Card(
        colors = CardDefaults.cardColors(containerColor = Color(0xFF12121A)),
        border = BorderStroke(1.dp, accent.copy(alpha = 0.30f)),
        shape = RoundedCornerShape(16.dp),
        modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp)
    ) {
        Column(Modifier.padding(16.dp)) {
            Text(title, color = Color.White, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(6.dp))
            Text(body, color = Color.White.copy(alpha = 0.78f), fontSize = 12.sp)
            footer?.let {
                Spacer(Modifier.height(8.dp))
                Text(it, color = Color.Gray, fontSize = 11.sp)
            }
        }
    }
}

@Composable
private fun OsInfoRow(label: String, value: String) {
    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.Top) {
        Text(label, color = Color.Gray, fontSize = 12.sp, modifier = Modifier.width(130.dp))
        Text(value, color = Color.White, fontSize = 12.sp, modifier = Modifier.weight(1f))
    }
}

@Composable
fun PandoraSystemScreen(onBack: () -> Unit) {
    OsShell("Pandora OS", "Systemübersicht", Color(0xFFE040FB), onBack) {
        OsCard("Betriebsmodus", "Pandora OS ist eine Android-Home-Shell: eigene Oberfläche, eigene Menüs, eigene Datenzentrale. Android bleibt die Hardware-Basis.")
        OsCard("Stufe 1 fertig", "Launcher, Dashboard, Systemmenüs, Storage, Backup, Berechtigungen, Netzwerk, Admin, JayJay, Shop, Wallet und Diagnose sind verbunden.", Color(0xFF00BCD4))
        OsCard("Nächste Stufe", "Nach stabiler APK: Start-App festlegen, Berechtigungen bewusst erteilen, M.2 Backup testen, danach Fehler/Crashlogs ausbessern.", Color(0xFF00E676))
    }
}

@Composable
fun PandoraStorageScreen(config: ConfigManager, onRequestSsdPicker: () -> Unit, onBack: () -> Unit) {
    val ssd: SsdStorageManager = koinInject()
    var info by remember { mutableStateOf(ssd.getSsdInfo()) }
    OsShell("Storage", "S24 Ultra = Datenbank · M.2 = Backup", Color(0xFF00BCD4), onBack) {
        Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF12121A)), shape = RoundedCornerShape(16.dp), modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp)) {
                Text("Aktive Datenbank", color = Color.White, fontWeight = FontWeight.Bold)
                OsInfoRow("Ort", "Interner App-Speicher des Samsung Galaxy S24 Ultra")
                OsInfoRow("Pfad", ssd.getDatabasePath())
                OsInfoRow("Warum", "SQLite/Room braucht stabiles Datei-Locking. Darum nicht live auf exFAT.")
                Divider(Modifier.padding(vertical = 10.dp), color = Color.White.copy(alpha = 0.08f))
                Text("M.2 SSD", color = Color.White, fontWeight = FontWeight.Bold)
                OsInfoRow("Status", if (info["available"] == true) "verfügbar" else "nicht verbunden/freigegeben")
                OsInfoRow("URI", info["uri"].toString())
                OsInfoRow("Pandora-Root", info["pandoraRootExists"].toString())
                OsInfoRow("Frei", info["freeSpace"].toString())
                Spacer(Modifier.height(12.dp))
                Button(onClick = onRequestSsdPicker, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(12.dp)) { Text("M.2 SSD auswählen") }
                OutlinedButton(onClick = { info = ssd.getSsdInfo() }, modifier = Modifier.fillMaxWidth()) { Text("Status aktualisieren") }
            }
        }
    }
}

@Composable
fun PandoraBackupScreen(onBack: () -> Unit) {
    val ssd: SsdStorageManager = koinInject()
    val scope = rememberCoroutineScope()
    var status by remember { mutableStateOf("Bereit. Live-Datenbank bleibt auf dem Handy.") }
    OsShell("Backup", "Manuelle Sicherung & Wiederherstellung", Color(0xFF00E676), onBack) {
        OsCard("Backup-Regel", "Das Galaxy S24 Ultra ist die aktive Datenbank. Die M.2 SSD bekommt nur Kopien und Wiederherstellungspunkte.", Color(0xFF00E676))
        Text(status, color = Color.White.copy(alpha = 0.84f), fontSize = 12.sp, modifier = Modifier.padding(vertical = 10.dp))
        Button(
            onClick = {
                status = "Backup läuft ..."
                scope.launch {
                    status = if (ssd.backupDatabaseToSsd(ssd.getDatabasePath())) "Backup auf M.2 erstellt." else "Backup fehlgeschlagen: M.2 nicht verfügbar oder DB fehlt."
                }
            },
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(12.dp)
        ) { Text("Jetzt Backup erstellen") }
        OutlinedButton(
            onClick = {
                status = "Wiederherstellung läuft ..."
                scope.launch {
                    status = if (ssd.restoreLatestBackup(ssd.getDatabasePath())) "Letztes Backup wiederhergestellt. App danach neu starten." else "Keine Wiederherstellung möglich."
                }
            },
            modifier = Modifier.fillMaxWidth()
        ) { Text("Letztes Backup wiederherstellen") }
    }
}

@Composable
fun PandoraPermissionsScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    fun open(intent: Intent) = context.startActivity(intent)
    OsShell("Berechtigungen", "Freigaben bewusst verwalten", Color(0xFFFFD54F), onBack) {
        OsCard("Wichtig", "Pandora OS fordert Berechtigungen nur über Android-Systemdialoge an. Erteile nur, was du wirklich nutzen willst.", Color(0xFFFFD54F))
        Button(onClick = {
            open(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${context.packageName}")))
        }, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(12.dp)) { Text("App-Berechtigungen öffnen") }
        OutlinedButton(onClick = { open(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }, modifier = Modifier.fillMaxWidth()) { Text("Bedienungshilfen öffnen") }
        OutlinedButton(onClick = { open(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${context.packageName}"))) }, modifier = Modifier.fillMaxWidth()) { Text("Anzeige über anderen Apps") }
        OutlinedButton(onClick = { open(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)) }, modifier = Modifier.fillMaxWidth()) { Text("Akku-Optimierung") }
    }
}

@Composable
fun PandoraSecurityScreen(onBack: () -> Unit) {
    val db: PandoraDatabase = koinInject()
    val events by db.securityDao().recent().collectAsState(initial = emptyList())
    Surface(Modifier.fillMaxSize(), color = Color(0xFF07070D)) {
        Column(Modifier.fillMaxSize()) {
            Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, contentDescription = "Zurück", tint = Color.White) }
                Text("Security", color = Color(0xFFFF5252), fontSize = 20.sp, fontWeight = FontWeight.Black)
            }
            LazyColumn(Modifier.fillMaxSize().padding(16.dp)) {
                if (events.isEmpty()) item { OsCard("Keine Events", "Noch keine Security-Ereignisse gespeichert.", Color(0xFFFF5252)) }
                items(events) { e -> OsCard(e.eventType, e.description, Color(0xFFFF5252), "${e.severity} · ${e.timestamp}") }
            }
        }
    }
}

@Composable
fun PandoraNetworkScreen(onBack: () -> Unit) = OsShell("Netzwerk", "Host, API und lokale Verbindungen", Color(0xFF40C4FF), onBack) {
    OsCard("Lokaler Host", "Pandora API läuft im Host-Modus auf Port 8765, wenn der Host-Service aktiv ist.", Color(0xFF40C4FF))
    OsCard("Mesh", "Bluetooth/WiFi Mesh wird über die Mesh-Oberfläche verwaltet.", Color(0xFF00BCD4))
    OsCard("Sicherheit", "Netzwerkfunktionen nur für eigene Geräte und ausdrücklich freigegebene Verbindungen verwenden.", Color(0xFFFFD54F))
}

@Composable
fun PandoraAppsScreen(onBack: () -> Unit) = OsShell("Pandora Apps", "Module innerhalb von Pandora OS", Color(0xFFFF80AB), onBack) {
    listOf(
        "JayJay KI" to "Sprach- und Wissenszentrale",
        "Admin" to "Rollen, Geräte, Freigaben",
        "Storage" to "Datenbank und M.2 Backup",
        "Shop" to "Produkte und Checkout",
        "Wallet" to "Bitcoin Hardware Wallet",
        "Mesh" to "Lokales Pandora-Netz"
    ).forEach { (a, b) -> OsCard(a, b, Color(0xFFFF80AB)) }
}

@Composable
fun PandoraSettingsScreen(config: ConfigManager, onBack: () -> Unit) = OsShell("Einstellungen", "Modus, Setup und Identität", Color(0xFF90CAF9), onBack) {
    OsCard("CEO", "${config.ceoName}\n${config.ceoEmail}", Color(0xFF90CAF9))
    OsCard("App-Modus", config.appMode.name, Color(0xFFE040FB))
    OsCard("Setup-Status", config.setupStatus.name, Color(0xFF00E676))
}

@Composable
fun PandoraLogsScreen(onBack: () -> Unit) = OsShell("Logs", "Diagnose und Fehlersuche", Color(0xFFB388FF), onBack) {
    OsCard("Build & Runtime", "Hier werden später interne Log-Einträge, Backup-Status und Service-Starts angezeigt.", Color(0xFFB388FF))
    OsCard("Fehler-Ausbesserung", "Wenn die App crasht: Screenshot vom roten Fehler oder Logcat hier als nächster Schritt.", Color(0xFFFFD54F))
}

@Composable
fun PandoraComputeScreen(onBack: () -> Unit) = OsShell("Compute", "Rechenknoten", Color(0xFFFF5252), onBack) {
    OsCard("Status", "Compute-Mesh Oberfläche vorbereitet. Aufgabenverteilung wird nach stabiler Host-APK aktiviert.", Color(0xFFFF5252))
}

@Composable
fun PandoraScanScreen(onBack: () -> Unit) = OsShell("Scan", "RSSI, BLE und CSI", Color(0xFF26C6DA), onBack) {
    OsCard("Scan-Konsole", "Die Oberfläche ist bereit. Aktive Scans brauchen Android-Berechtigungen und werden nur bewusst gestartet.", Color(0xFF26C6DA))
}

@Composable
fun PandoraBuildingsScreen(onBack: () -> Unit) = OsShell("Gebäude", "3D Overlay und Räume", Color(0xFF7C4DFF), onBack) {
    OsCard("3D-Modell", "Gebäude, Etagen, Räume, Mesh-Knoten und Heatmaps werden hier zusammengeführt.", Color(0xFF7C4DFF))
}

@Composable
fun PandoraOnionScreen(onBack: () -> Unit) = OsShell("Onion", "Privater Relay-Modus", Color(0xFF69F0AE), onBack) {
    OsCard("Onion-Modul", "Relay-Funktion vorbereitet. Aktivierung erst nach Netzwerk-/Sicherheitsprüfung.", Color(0xFF69F0AE))
}

@Composable
fun PandoraWireGuardScreen(onBack: () -> Unit) = OsShell("WireGuard", "VPN-Tunnel", Color(0xFF40C4FF), onBack) {
    OsCard("VPN", "WireGuard-Konfiguration und Schlüsselverwaltung werden hier später bedient.", Color(0xFF40C4FF))
}
