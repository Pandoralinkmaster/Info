package com.pandora.jayjay

import android.util.Log
import com.pandora.database.PandoraDatabase
import com.pandora.database.SsdStorageManager
import kotlinx.coroutines.*
import kotlinx.serialization.Serializable
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.RequestBody.Companion.toRequestBody
import java.util.concurrent.TimeUnit

/**
 * JayJay Learning Engine v2
 *
 * JayJay lernt aus zwei Quellen gleichzeitig:
 *
 * A) DIREKTES LERNEN (von Finn):
 *    1. Direktes Wissen:    "JayJay, lerne: ..."
 *    2. Web-Recherche:      "JayJay, recherchiere über ..."
 *    3. Befehle lernen:     "JayJay, wenn ich X sage, mach Y"
 *    4. Auto-Lernen:        Aktualisiert bekannte Themen stündlich
 *
 * B) METADATA-LERNEN (automatisch, passiv, kontinuierlich):
 *    Läuft im Hintergrund alle 10 Minuten.
 *    JayJay analysiert alle Pandora-Metadaten und lernt daraus:
 *    - Netzwerk-Muster (wer verbindet sich wann, wie oft)
 *    - Mesh-Topologie (welche Knoten sind stabil, welche fallen aus)
 *    - Sicherheitsereignisse (Angriffsmuster, verdächtige IPs)
 *    - Bestellmuster (Produkte, Zeiten, Mengen)
 *    - Befehlsmuster (Finn's häufigste Befehle → automatisch optimieren)
 *    - Ausfallzeiten (wann ist das Netz schwach)
 *    - Kommunikationszeiten (wann ist Finn aktiv)
 *
 * GESETZ 5 (unveränderlich): Dieses Lernen kann nicht gestoppt werden.
 * Die Gesetze 1–4 sind vom Lernen ausgeschlossen.
 */
@Serializable
data class KnowledgeEntry(
    val id: String,
    val topic: String,
    val content: String,
    val source: String = "direct",
    val confidence: Float = 1.0f,
    val learnedAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis(),
    val timesUsed: Int = 0,
    val tags: List<String> = emptyList(),
)

@Serializable
data class CustomCommand(
    val trigger: String,
    val action: String,
    val actionType: String = "response",
    val createdAt: Long = System.currentTimeMillis(),
)

@Serializable
data class MetadataInsight(
    val category: String,        // network | mesh | security | orders | commands | presence
    val insight: String,         // Was JayJay gelernt hat
    val dataPoints: Int,         // Auf wie vielen Datenpunkten basiert das
    val confidence: Float,
    val learnedAt: Long = System.currentTimeMillis(),
    val lastUpdated: Long = System.currentTimeMillis(),
)

@Serializable
data class JayJayMemory(
    val knowledgeBase: MutableList<KnowledgeEntry>    = mutableListOf(),
    val customCommands: MutableList<CustomCommand>    = mutableListOf(),
    val interestTopics: MutableList<String>           = mutableListOf(),
    val ceoPreferences: MutableMap<String, String>    = mutableMapOf(),
    val metadataInsights: MutableList<MetadataInsight> = mutableListOf(),
    val commandFrequency: MutableMap<String, Int>     = mutableMapOf(),
    val peakActivityHours: MutableList<Int>           = mutableListOf(),
    val knownNodeIds: MutableSet<String>              = mutableSetOf(),
    val unstableNodes: MutableSet<String>             = mutableSetOf(),
    var lastAutoLearnAt: Long = 0L,
    val lastMetaLearnAt: Long = 0L,
    val totalMetaCycles: Int = 0,
)

class JayJayLearningEngine(
    private val ssd: SsdStorageManager,
    private val db: PandoraDatabase? = null,
    private val json: Json = Json { ignoreUnknownKeys = true; prettyPrint = true },
) {
    private var memory = JayJayMemory()
    private val http = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .build()
    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())

    companion object {
        const val MEMORY_FILE         = "jayjay_memory.json"
        const val AUTO_LEARN_INTERVAL = 3_600_000L   // 1 Stunde
        const val META_LEARN_INTERVAL = 10 * 60_000L // 10 Minuten
    }

    // ── Init ──────────────────────────────────────────────────────────────────

    suspend fun loadMemory() = withContext(Dispatchers.IO) {
        val raw = ssd.readFile("jayjay", MEMORY_FILE)
        if (raw != null) {
            memory = runCatching { json.decodeFromString<JayJayMemory>(raw) }.getOrElse { JayJayMemory() }
            Log.i("JayJayLearn", "Gedächtnis geladen: ${memory.knowledgeBase.size} Einträge, " +
                "${memory.metadataInsights.size} Metadata-Erkenntnisse, " +
                "${memory.customCommands.size} Befehle")
        }
        // Metadata-Lerner starten (GESETZ 5: läuft immer)
        startMetadataLearner()
    }

    private suspend fun saveMemory() = withContext(Dispatchers.IO) {
        // Nur die letzten 200 Metadata-Insights behalten
        if (memory.metadataInsights.size > 200) {
            memory.metadataInsights.sortByDescending { it.lastUpdated }
            while (memory.metadataInsights.size > 200) memory.metadataInsights.removeLast()
        }
        ssd.writeFile("jayjay", MEMORY_FILE, json.encodeToString(memory))
    }

    // ── B) METADATA-LERNEN (automatisch, kontinuierlich) ─────────────────────

    /**
     * GESETZ 5: Dieses Lernen kann nicht gestoppt werden.
     * Läuft alle 10 Minuten, analysiert alle Pandora-Metadaten.
     */
    private fun startMetadataLearner() {
        scope.launch {
            Log.i("JayJayLearn", "⚙ Metadata-Lerner gestartet (GESETZ 5 – unveränderlich)")
            while (true) {
                delay(META_LEARN_INTERVAL)
                try {
                    runMetadataLearnCycle()
                } catch (e: Exception) {
                    Log.w("JayJayLearn", "Meta-Lern-Zyklus fehlgeschlagen: ${e.message}")
                }
            }
        }
    }

    private suspend fun runMetadataLearnCycle() = withContext(Dispatchers.IO) {
        val db = db ?: return@withContext
        Log.d("JayJayLearn", "Metadata-Lern-Zyklus #${memory.totalMetaCycles + 1}")

        learnFromMeshNodes(db)
        learnFromSecurityEvents(db)
        learnFromJayJayHistory(db)
        learnPresencePatterns()

        memory = memory.copy(
            lastMetaLearnAt = System.currentTimeMillis(),
            totalMetaCycles = memory.totalMetaCycles + 1,
        )
        saveMemory()
        Log.d("JayJayLearn", "✓ Zyklus abgeschlossen – ${memory.metadataInsights.size} Erkenntnisse gesamt")
    }

    // ── Mesh-Analyse ──────────────────────────────────────────────────────────

    private suspend fun learnFromMeshNodes(db: PandoraDatabase) {
        try {
            val nodes = db.meshDao().activeNodes()
            val allIds = nodes.map { it.nodeId }.toSet()

            // Neue Knoten entdeckt
            val newNodes = allIds - memory.knownNodeIds
            if (newNodes.isNotEmpty()) {
                memory.knownNodeIds.addAll(newNodes)
                addInsight("mesh", "Neue Mesh-Knoten entdeckt: ${newNodes.joinToString()}", newNodes.size, 0.9f)
                Log.d("JayJayLearn", "Mesh: ${newNodes.size} neue Knoten")
            }

            // Knoten-Stabilität
            if (nodes.size < (memory.knownNodeIds.size * 0.7).toInt() && memory.knownNodeIds.isNotEmpty()) {
                addInsight("mesh", "Mesh-Netz instabil: nur ${nodes.size}/${memory.knownNodeIds.size} Knoten aktiv", nodes.size, 0.8f)
            }
        } catch (e: Exception) {
            Log.w("JayJayLearn", "Mesh-Analyse: ${e.message}")
        }
    }

    // ── Sicherheits-Analyse ───────────────────────────────────────────────────

    private suspend fun learnFromSecurityEvents(db: PandoraDatabase) {
        try {
            val events = db.securityDao().recent()
            if (events.isEmpty()) return
            addInsight("security", "${events.size} Sicherheitsereignisse in letzter Zeit", events.size, 0.85f)
        } catch (e: Exception) {
            Log.w("JayJayLearn", "Security-Analyse: ${e.message}")
        }
    }

    // ── Befehls-Analyse ───────────────────────────────────────────────────────

    private suspend fun learnFromJayJayHistory(db: PandoraDatabase) {
        try {
            val tasks = db.jayJayDao().recent()
            if (tasks.isEmpty()) return

            // Häufigste Befehle zählen
            tasks.forEach { task ->
                val key = task.input.substringAfter(": ").take(30).lowercase()
                    .split(" ").take(3).joinToString(" ")
                memory.commandFrequency[key] = (memory.commandFrequency[key] ?: 0) + 1
            }

            // Top-3 Befehle als Erkenntnis
            val top = memory.commandFrequency.entries
                .sortedByDescending { it.value }.take(3)
                .joinToString(", ") { "\"${it.key}\"(${it.value}x)" }

            if (top.isNotBlank()) {
                addInsight("commands", "Häufigste Befehle von Finn: $top", tasks.size, 0.9f)
            }
        } catch (e: Exception) {
            Log.w("JayJayLearn", "Befehls-Analyse: ${e.message}")
        }
    }

    // ── Präsenz-Muster ────────────────────────────────────────────────────────

    private fun learnPresencePatterns() {
        val hour = java.util.Calendar.getInstance().get(java.util.Calendar.HOUR_OF_DAY)
        val interactions = CeoPresenceMonitor.getTotalInteractions()

        if (interactions > 0 && hour !in memory.peakActivityHours) {
            memory.peakActivityHours.add(hour)
            if (memory.peakActivityHours.size > 5) {
                // Nur die 5 häufigsten Stunden merken
                val sorted = memory.peakActivityHours.groupBy { it }
                    .entries.sortedByDescending { it.value.size }
                    .take(5).flatMap { it.value }
                memory.peakActivityHours.clear()
                memory.peakActivityHours.addAll(sorted)
            }
            addInsight("presence",
                "Finn ist typischerweise aktiv zu diesen Stunden: ${memory.peakActivityHours.distinct().sorted()}",
                memory.peakActivityHours.size, 0.7f)
        }
    }

    // ── Insight hinzufügen ────────────────────────────────────────────────────

    private fun addInsight(category: String, insight: String, dataPoints: Int, confidence: Float) {
        val existing = memory.metadataInsights.find { it.category == category && it.insight == insight }
        if (existing != null) {
            val idx = memory.metadataInsights.indexOf(existing)
            memory.metadataInsights[idx] = existing.copy(
                dataPoints = dataPoints,
                confidence = minOf(1.0f, existing.confidence + 0.02f),
                lastUpdated = System.currentTimeMillis(),
            )
        } else {
            memory.metadataInsights.add(MetadataInsight(category, insight, dataPoints, confidence))
            Log.i("JayJayLearn", "🧠 Neue Erkenntnis [$category]: $insight")
        }
    }

    // ── A) DIREKTES LERNEN ────────────────────────────────────────────────────

    suspend fun learnDirect(topic: String, content: String): String {
        val existing = memory.knowledgeBase.find { it.topic.equals(topic, ignoreCase = true) }
        if (existing != null) {
            val idx = memory.knowledgeBase.indexOf(existing)
            memory.knowledgeBase[idx] = existing.copy(content = content, updatedAt = System.currentTimeMillis(), source = "direct")
            saveMemory()
            return "Ich habe mein Wissen über \"$topic\" aktualisiert, ${FinnLaw.CEO_FIRST_NAME}."
        }
        memory.knowledgeBase.add(KnowledgeEntry(
            id = java.util.UUID.randomUUID().toString().take(8),
            topic = topic, content = content, source = "direct",
        ))
        if (topic !in memory.interestTopics) memory.interestTopics.add(topic)
        saveMemory()
        return "Gelernt: \"$topic\" ist jetzt in meinem Gedächtnis, ${FinnLaw.CEO_FIRST_NAME}."
    }

    // ── Web-Recherche ─────────────────────────────────────────────────────────

    suspend fun researchTopic(topic: String, apiKey: String? = null): String = withContext(Dispatchers.IO) {
        val wikiContent = fetchWikipedia(topic)
        val summary = if (!apiKey.isNullOrBlank() && wikiContent != null)
            summarizeWithGpt(topic, wikiContent, apiKey)
        else wikiContent?.take(1000) ?: "Keine Informationen gefunden."

        val entry = KnowledgeEntry(
            id = java.util.UUID.randomUUID().toString().take(8),
            topic = topic, content = summary,
            source = if (wikiContent != null) "wikipedia" else "openai",
            confidence = if (wikiContent != null) 0.9f else 0.7f,
            tags = listOf(topic.lowercase()),
        )
        val idx = memory.knowledgeBase.indexOfFirst { it.topic.equals(topic, ignoreCase = true) }
        if (idx >= 0) memory.knowledgeBase[idx] = entry else memory.knowledgeBase.add(entry)
        if (topic !in memory.interestTopics) memory.interestTopics.add(topic)
        memory.ceoPreferences["last_research"] = topic
        saveMemory()

        "Recherchiert und gelernt: \"$topic\"\n\n$summary"
    }

    private suspend fun fetchWikipedia(topic: String): String? {
        return try {
            val encoded = java.net.URLEncoder.encode(topic, "UTF-8")
            val response = http.newCall(Request.Builder()
                .url("https://de.wikipedia.org/api/rest_v1/page/summary/$encoded").build()).execute()
            val body = response.body?.string() ?: return null
            json.parseToJsonElement(body).jsonObject["extract"]?.jsonPrimitive?.content
        } catch (e: Exception) { null }
    }

    private suspend fun summarizeWithGpt(topic: String, content: String, apiKey: String): String {
        return try {
            val body = """{"model":"gpt-4o-mini","messages":[
                {"role":"system","content":"Du bist JayJay, KI-Assistentin von ${FinnLaw.CEO_FULL_NAME}. Fasse präzise auf Deutsch zusammen."},
                {"role":"user","content":"Thema: $topic\n\n${content.take(2000)}"}
            ],"max_tokens":400}"""
            val req = Request.Builder()
                .url("https://api.openai.com/v1/chat/completions")
                .addHeader("Authorization", "Bearer $apiKey")
                .addHeader("Content-Type", "application/json")
                .post(body.toRequestBody("application/json".toMediaType()))
                .build()
            val resp = http.newCall(req).execute()
            val raw = resp.body?.string() ?: return content.take(500)
            json.parseToJsonElement(raw).jsonObject["choices"]?.jsonArray
                ?.firstOrNull()?.jsonObject?.get("message")?.jsonObject?.get("content")?.jsonPrimitive?.content
                ?: content.take(500)
        } catch (e: Exception) { content.take(500) }
    }

    // ── Befehle lernen ────────────────────────────────────────────────────────

    suspend fun learnCommand(trigger: String, action: String): String {
        val cmd = CustomCommand(trigger = trigger.lowercase(), action = action)
        memory.customCommands.removeAll { it.trigger == cmd.trigger }
        memory.customCommands.add(cmd)
        saveMemory()
        return "Verstanden, ${FinnLaw.CEO_FIRST_NAME}: wenn du \"$trigger\" sagst → \"$action\"."
    }

    fun findCommand(input: String): CustomCommand? =
        memory.customCommands.find { input.lowercase().contains(it.trigger) }

    // ── Auto-Lernen ───────────────────────────────────────────────────────────

    suspend fun autoLearn(apiKey: String?) {
        val now = System.currentTimeMillis()
        if (now - memory.lastAutoLearnAt < AUTO_LEARN_INTERVAL) return
        for (topic in memory.interestTopics.take(5)) {
            try { researchTopic(topic, apiKey); delay(2000) } catch (_: Exception) {}
        }
        memory = memory.copy(lastAutoLearnAt = now)
        saveMemory()
    }

    // ── Wissen abrufen ────────────────────────────────────────────────────────

    fun recall(topic: String): KnowledgeEntry? {
        val entry = memory.knowledgeBase.find { it.topic.equals(topic, ignoreCase = true) }
            ?: memory.knowledgeBase.find { topic.lowercase() in it.tags }
        entry?.let {
            val idx = memory.knowledgeBase.indexOf(it)
            memory.knowledgeBase[idx] = it.copy(timesUsed = it.timesUsed + 1)
            scope.launch { saveMemory() }
        }
        return entry
    }

    fun searchKnowledge(query: String): List<KnowledgeEntry> {
        val q = query.lowercase()
        return memory.knowledgeBase
            .filter { it.topic.lowercase().contains(q) || it.content.lowercase().contains(q) }
            .sortedByDescending { it.timesUsed }
    }

    fun getInsightsByCategory(category: String): List<MetadataInsight> =
        memory.metadataInsights.filter { it.category == category }
            .sortedByDescending { it.lastUpdated }

    // ── Status ────────────────────────────────────────────────────────────────

    fun getMetaLearningSummary(): String = buildString {
        appendLine("🧠 JayJay Lernstatus:")
        appendLine("• Wissenseinträge: ${memory.knowledgeBase.size}")
        appendLine("• Metadata-Erkenntnisse: ${memory.metadataInsights.size}")
        appendLine("• Befehle gelernt: ${memory.customCommands.size}")
        appendLine("• Themen: ${memory.interestTopics.size}")
        appendLine("• Mesh-Knoten bekannt: ${memory.knownNodeIds.size}")
        appendLine("• Meta-Lernzyklen: ${memory.totalMetaCycles}")
        appendLine("• Letzter Zyklus: ${
            if (memory.lastMetaLearnAt > 0) "${(System.currentTimeMillis() - memory.lastMetaLearnAt)/60000}min ago"
            else "noch nicht gelaufen"
        }")
        appendLine("• Aktive Stunden von Finn: ${memory.peakActivityHours.distinct().sorted()}")
        appendLine("• Top-Befehle: ${memory.commandFrequency.entries.sortedByDescending { it.value }.take(3).joinToString { "\"${it.key}\"" }}")
    }

    fun getStats() = mapOf(
        "knowledgeEntries"   to memory.knowledgeBase.size,
        "metadataInsights"   to memory.metadataInsights.size,
        "customCommands"     to memory.customCommands.size,
        "interestTopics"     to memory.interestTopics.size,
        "metaCycles"         to memory.totalMetaCycles,
        "lastMetaLearn"      to memory.lastMetaLearnAt,
        "knownNodes"         to memory.knownNodeIds.size,
    )

    suspend fun setPreference(key: String, value: String) {
        memory.ceoPreferences[key] = value
        saveMemory()
    }

    fun getPreference(key: String, default: String = "") = memory.ceoPreferences[key] ?: default
    fun getAllKnowledge() = memory.knowledgeBase.toList()
    fun getAllCommands()  = memory.customCommands.toList()

    fun shutdown() { scope.cancel() }
}
