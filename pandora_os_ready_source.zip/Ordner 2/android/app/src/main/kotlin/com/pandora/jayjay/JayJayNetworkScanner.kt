package com.pandora.jayjay

import android.content.Context
import android.net.ConnectivityManager
import android.net.wifi.WifiManager
import android.util.Log
import kotlinx.coroutines.*
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json
import okhttp3.OkHttpClient
import okhttp3.Request
import java.net.InetAddress
import java.util.concurrent.TimeUnit

/**
 * JayJay Netzwerkscanner – 100% Zugriff auf das gesamte Netzwerk
 *
 * JayJay sieht ALLES im Netzwerk:
 *   - Alle Pandora-Knoten (Mesh-Peers)
 *   - Alle Geräte im lokalen WLAN (IP-Scan)
 *   - CEO-Host Dateiserver (freigegebene Dateien)
 *   - Alle geteilten Pandora-Ressourcen (CPU, RAM, Dateien)
 *   - Netzwerk-Topologie (wer ist mit wem verbunden)
 *
 * Finn fragt → JayJay antwortet sofort was im Netzwerk ist.
 */

@Serializable
data class NetworkPeer(
    val peerId: String,
    val peerName: String,
    val ip: String,
    val port: Int,
    val role: String,           // "ceo_host", "pandora_node", "unknown"
    val isOnline: Boolean,
    val latencyMs: Long,
    val pandoraVersion: String = "",
    val sharedFiles: Int = 0,
    val cpuCores: Int = 0,
    val ramMb: Int = 0,
    val lastSeen: Long = System.currentTimeMillis(),
)

@Serializable
data class NetworkScanResult(
    val peers: List<NetworkPeer>,
    val localIp: String,
    val subnet: String,
    val onlineCount: Int,
    val pandoraNodeCount: Int,
    val totalSharedFiles: Int,
    val scannedAt: Long = System.currentTimeMillis(),
)

@Serializable
data class SharedFileEntry(
    val name: String,
    val sizeBytes: Long,
    val category: String,
    val peerId: String,
    val peerName: String,
    val downloadUrl: String,
)

class JayJayNetworkScanner(private val context: Context) {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val json  = Json { ignoreUnknownKeys = true }
    private val http  = OkHttpClient.Builder()
        .connectTimeout(2, TimeUnit.SECONDS)
        .readTimeout(3, TimeUnit.SECONDS)
        .build()

    companion object {
        private const val TAG = "JayJayNet"
        private const val PANDORA_PORT = 8443       // Pandora API-Port
        private const val PANDORA_DISCOVERY = 8444  // Pandora Discovery-Port
        private const val SCAN_WORKERS = 32          // Parallele Scans
    }

    // ── Vollständiger Netzwerkscan ───────────────────────────────────────────

    /**
     * Scannt das gesamte lokale Netzwerk + alle bekannten Pandora-Peers.
     */
    suspend fun fullNetworkScan(): NetworkScanResult = withContext(Dispatchers.IO) {
        val localIp = getLocalIp()
        val subnet  = localIp.substringBeforeLast(".")

        Log.i(TAG, "Netzwerkscan: $subnet.* (256 Hosts)")

        // Alle 256 Hosts parallel scannen
        val peers = (1..254).chunked(SCAN_WORKERS).flatMap { chunk ->
            chunk.map { i ->
                async { scanHost("$subnet.$i") }
            }.awaitAll().filterNotNull()
        }

        val pandoraNodes = peers.filter { it.role != "unknown" }
        val totalFiles   = pandoraNodes.sumOf { it.sharedFiles }

        Log.i(TAG, "✓ Netzwerkscan: ${peers.size} Geräte, ${pandoraNodes.size} Pandora-Knoten, $totalFiles Dateien")

        NetworkScanResult(
            peers            = peers.sortedWith(compareByDescending<NetworkPeer> { it.isOnline }.thenBy { it.ip }),
            localIp          = localIp,
            subnet           = "$subnet.0/24",
            onlineCount      = peers.count { it.isOnline },
            pandoraNodeCount = pandoraNodes.size,
            totalSharedFiles = totalFiles,
        )
    }

    /**
     * Freigegebene Dateien von allen Pandora-Knoten abrufen.
     */
    suspend fun listAllSharedFiles(category: String? = null): List<SharedFileEntry> = withContext(Dispatchers.IO) {
        val scan  = fullNetworkScan()
        val nodes = scan.peers.filter { it.isOnline && it.role != "unknown" }

        nodes.map { peer ->
            async { fetchSharedFiles(peer, category) }
        }.awaitAll().flatten()
    }

    /**
     * Datei von einem Peer herunterladen (gibt Bytes zurück).
     */
    suspend fun downloadFromPeer(downloadUrl: String): ByteArray? = withContext(Dispatchers.IO) {
        try {
            val req  = Request.Builder().url(downloadUrl).build()
            val resp = http.newCall(req).execute()
            if (resp.isSuccessful) resp.body?.bytes() else null
        } catch (e: Exception) {
            Log.w(TAG, "Download fehlgeschlagen: ${e.message}")
            null
        }
    }

    // ── Hilfsmethoden ────────────────────────────────────────────────────────

    private suspend fun scanHost(ip: String): NetworkPeer? = withContext(Dispatchers.IO) {
        try {
            val addr = InetAddress.getByName(ip)
            val t0   = System.currentTimeMillis()
            val reachable = addr.isReachable(800)  // 800ms Timeout
            val latency   = System.currentTimeMillis() - t0

            if (!reachable) return@withContext null

            // Pandora-Dienst prüfen
            val pandoraInfo = tryPandoraEndpoint(ip)

            return@withContext NetworkPeer(
                peerId         = pandoraInfo?.get("peerId") ?: ip,
                peerName       = pandoraInfo?.get("name") ?: addr.hostName ?: ip,
                ip             = ip,
                port           = if (pandoraInfo != null) PANDORA_PORT else 0,
                role           = pandoraInfo?.get("role") ?: "unknown",
                isOnline       = true,
                latencyMs      = latency,
                pandoraVersion = pandoraInfo?.get("version") ?: "",
                sharedFiles    = pandoraInfo?.get("sharedFiles")?.toIntOrNull() ?: 0,
                cpuCores       = pandoraInfo?.get("cpuCores")?.toIntOrNull() ?: 0,
                ramMb          = pandoraInfo?.get("ramMb")?.toIntOrNull() ?: 0,
            )
        } catch (_: Exception) { null }
    }

    private fun tryPandoraEndpoint(ip: String): Map<String, String>? = runCatching {
        val req  = Request.Builder()
            .url("http://$ip:$PANDORA_PORT/api/node/info")
            .header("X-Pandora-Auth", "mesh")
            .build()
        val resp = http.newCall(req).execute()
        if (resp.isSuccessful) {
            val body = resp.body?.string() ?: return null
            json.decodeFromString<Map<String, String>>(body)
        } else null
    }.getOrNull()

    private fun fetchSharedFiles(peer: NetworkPeer, category: String?): List<SharedFileEntry> {
        return runCatching {
            val url = "http://${peer.ip}:${peer.port}/api/files" +
                if (category != null) "?category=$category" else ""
            val req  = Request.Builder().url(url)
                .header("X-Pandora-Auth", "mesh").build()
            val resp = http.newCall(req).execute()
            if (!resp.isSuccessful) return emptyList()
            val body = resp.body?.string() ?: return emptyList()
            json.decodeFromString<List<SharedFileEntry>>(body)
        }.getOrElse { emptyList() }
    }

    private fun getLocalIp(): String {
        return try {
            val wm = context.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
            val ip = wm.connectionInfo.ipAddress
            String.format("%d.%d.%d.%d",
                ip and 0xff, ip shr 8 and 0xff, ip shr 16 and 0xff, ip shr 24 and 0xff)
        } catch (_: Exception) { "192.168.1.1" }
    }

    // ── JayJay-Zusammenfassung ────────────────────────────────────────────────

    fun summarize(result: NetworkScanResult): String = buildString {
        appendLine("🌐 Netzwerk-Scan (${result.subnet}):")
        appendLine("• Eigene IP: ${result.localIp}")
        appendLine("• ${result.onlineCount} Geräte online")
        appendLine("• ${result.pandoraNodeCount} Pandora-Knoten gefunden")
        appendLine("• ${result.totalSharedFiles} freigegebene Dateien im Netz")
        if (result.peers.isNotEmpty()) {
            appendLine()
            appendLine("Geräte:")
            result.peers.take(10).forEach { p ->
                val status = if (p.isOnline) "🟢" else "⚫"
                val tag    = if (p.role != "unknown") " [Pandora ${p.role}]" else ""
                appendLine("$status ${p.ip} – ${p.peerName}$tag (${p.latencyMs}ms)")
            }
        }
    }
}
