#!/usr/bin/env bash
# ╔══════════════════════════════════════════════════════════════╗
# ║       PandoraOS — Raspberry Pi Setup                        ║
# ║                                                              ║
# ║  Optimiert für:                                              ║
# ║    • Raspberry Pi 4 / 5 (Raspbian / Ubuntu)                 ║
# ║    • Raspberry Pi 3 (nur eingeschränkte Features)           ║
# ║    • Aktiviert GPIO-Steuerung für Relais, LEDs, etc.        ║
# ║    • Headless-Modus: kein Display nötig                     ║
# ║    • Startet beim Boot als system service                   ║
# ║                                                              ║
# ║  Verwendung:                                                 ║
# ║    chmod +x raspi-setup.sh && sudo ./raspi-setup.sh         ║
# ╚══════════════════════════════════════════════════════════════╝

set -e

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
PANDORA_USER="${SUDO_USER:-pi}"

echo "╔══════════════════════════════════════╗"
echo "║  PandoraOS Raspberry Pi Setup        ║"
echo "╚══════════════════════════════════════╝"
echo ""

# ── System-Update ───────────────────────────────────────────────
echo "System aktualisieren..."
apt-get update -qq
apt-get install -y -qq nodejs npm git curl

NODE_VERSION=$(node -v)
echo "✓ Node.js: $NODE_VERSION"

# ── GPIO-Tools installieren ─────────────────────────────────────
if [ -f /proc/cpuinfo ] && grep -q "Raspberry Pi" /proc/cpuinfo; then
  echo "Raspberry Pi erkannt — GPIO aktivieren..."
  apt-get install -y -qq wiringpi python3-gpiozero 2>/dev/null || true
  # GPIO-Gruppe
  usermod -aG gpio "$PANDORA_USER" 2>/dev/null || true
  echo "✓ GPIO aktiviert"
fi

# ── npm-Abhängigkeiten ──────────────────────────────────────────
echo "Installiere Abhängigkeiten..."
cd "$SCRIPT_DIR"
npm install --production
echo "✓ Abhängigkeiten installiert"

# ── Systemd-Dienst ──────────────────────────────────────────────
echo "Richte systemd-Dienst ein..."
cat > /etc/systemd/system/pandora-agent.service << EOF
[Unit]
Description=PandoraOS Agent (Raspberry Pi)
After=network.target

[Service]
Type=simple
User=$PANDORA_USER
WorkingDirectory=$SCRIPT_DIR
ExecStart=$(which node) $SCRIPT_DIR/server.js
Restart=always
RestartSec=5
Environment=PANDORA_PORT=7777
Environment=PANDORA_WS_PORT=7778
Environment=HOME=/home/$PANDORA_USER

[Install]
WantedBy=multi-user.target
EOF

systemctl daemon-reload
systemctl enable pandora-agent.service
systemctl start  pandora-agent.service

sleep 2
STATUS=$(systemctl is-active pandora-agent.service)
echo "✓ Dienst-Status: $STATUS"

# ── IP-Adresse anzeigen ─────────────────────────────────────────
IP=$(hostname -I | awk '{print $1}')

echo ""
echo "╔══════════════════════════════════════╗"
echo "║  PandoraOS Agent läuft!              ║"
echo "║                                      ║"
echo "║  Web UI: http://$IP:7777"
echo "║  WebSocket: ws://$IP:7778"
echo "║                                      ║"
echo "║  Startet automatisch beim Boot       ║"
echo "║  Logs: journalctl -u pandora-agent   ║"
echo "╚══════════════════════════════════════╝"
