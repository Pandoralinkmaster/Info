# PandoraOS Desktop Agent

Läuft auf **jedem Gerät** — PC, Mac, Linux, Raspberry Pi, Smart TV (Browser).

## Schnellstart

### Linux / Mac
```bash
chmod +x install.sh
./install.sh
```

### Windows
Rechtsklick auf `install.bat` → Als Administrator ausführen

### Raspberry Pi
```bash
chmod +x raspi-setup.sh
sudo ./raspi-setup.sh
```

### Manuell (überall wo Node.js läuft)
```bash
npm install
node server.js
```

Dann im Browser öffnen: **http://localhost:7777**

## Was der Agent macht

- Verbindet sich automatisch mit anderen Pandora-Agents im Netzwerk (Mesh)
- Stellt REST-API und WebSocket für JayJay bereit
- Web-UI: Dashboard, Dateizugriff, Netzwerk-Scanner, IoT-Steuerung, JayJay
- Startet beim Boot (systemd / LaunchAgent / Windows-Autostart)

## Ports

| Port | Funktion |
|------|----------|
| 7777 | HTTP REST-API + Web UI |
| 7778 | WebSocket (Mesh-Netzwerk) |

## Umgebungsvariablen

| Variable | Standard | Beschreibung |
|----------|----------|--------------|
| PANDORA_PORT | 7777 | HTTP-Port |
| PANDORA_WS_PORT | 7778 | WebSocket-Port |
| PANDORA_DEVICE | auto | Gerätetyp überschreiben (tv, car, hub) |
