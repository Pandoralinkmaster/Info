@echo off
REM ╔══════════════════════════════════════════════════════════════╗
REM ║       PandoraOS Desktop Agent — Windows Installer           ║
REM ║                                                              ║
REM ║  Rechtsklick → "Als Administrator ausführen"               ║
REM ╚══════════════════════════════════════════════════════════════╝

echo.
echo  ╔══════════════════════════════════════╗
echo  ║   PandoraOS Agent — Windows Setup   ║
echo  ╚══════════════════════════════════════╝
echo.

REM ── Node.js prüfen ──────────────────────────────────────────────
where node >nul 2>&1
if %ERRORLEVEL% NEQ 0 (
    echo Node.js nicht gefunden.
    echo Bitte installieren von: https://nodejs.org ^(LTS-Version^)
    echo Danach dieses Skript erneut ausfuehren.
    pause
    exit /b 1
)

for /f "tokens=*" %%i in ('node -v') do set NODE_VER=%%i
echo [OK] Node.js: %NODE_VER%

REM ── Abhängigkeiten installieren ─────────────────────────────────
echo Installiere Abhaengigkeiten...
cd /d "%~dp0"
call npm install --production
echo [OK] Abhaengigkeiten installiert

REM ── Als Windows-Dienst via NSSM ─────────────────────────────────
echo.
echo Richte Autostart ein...

REM Autostart-Eintrag in Registry
set REG_PATH=HKCU\Software\Microsoft\Windows\CurrentVersion\Run
set NODE_PATH=
for /f "tokens=*" %%i in ('where node') do set NODE_PATH=%%i
reg add "%REG_PATH%" /v "PandoraAgent" /t REG_SZ /d "\"%NODE_PATH%\" \"%~dp0server.js\"" /f >nul
echo [OK] Autostart eingerichtet

REM ── Firewall ─────────────────────────────────────────────────────
echo Konfiguriere Windows-Firewall...
netsh advfirewall firewall add rule ^
    name="PandoraOS Agent" ^
    dir=in ^
    action=allow ^
    protocol=TCP ^
    localport=7777,7778 ^
    profile=private >nul 2>&1
echo [OK] Firewall-Regel hinzugefuegt

REM ── Agent starten ────────────────────────────────────────────────
echo.
echo Starte Agent...
start "" /B node "%~dp0server.js"
timeout /t 3 /nobreak >nul

echo.
echo  ╔══════════════════════════════════════╗
echo  ║  PandoraOS Agent laeuft!             ║
echo  ║  Web UI: http://localhost:7777       ║
echo  ║  Startet beim Windows-Login          ║
echo  ╚══════════════════════════════════════╝
echo.
echo Oeffne http://localhost:7777 im Browser.
pause
