#!/usr/bin/env bash
# ╔══════════════════════════════════════════════════════════════╗
# ║       PandoraOS Desktop Agent — Linux/Mac Installer         ║
# ║                                                              ║
# ║  Führt folgendes aus:                                        ║
# ║   1. Node.js installieren (wenn nicht vorhanden)            ║
# ║   2. Abhängigkeiten installieren (npm install)               ║
# ║   3. Als systemd-Dienst registrieren (Linux)                ║
# ║   4. Autostart bei Anmeldung aktivieren                     ║
# ║                                                              ║
# ║  Verwendung: chmod +x install.sh && ./install.sh            ║
# ╚══════════════════════════════════════════════════════════════╝

set -e

PANDORA_DIR="$HOME/.pandora-agent"
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"

echo "╔══════════════════════════════════════╗"
echo "║      PandoraOS Agent Installer       ║"
echo "╚══════════════════════════════════════╝"
echo ""

# ── Node.js prüfen ──────────────────────────────────────────────
if ! command -v node &>/dev/null; then
  echo "Node.js nicht gefunden. Installiere..."
  if command -v apt-get &>/dev/null; then
    curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
    sudo apt-get install -y nodejs
  elif command -v brew &>/dev/null; then
    brew install node
  elif command -v pacman &>/dev/null; then
    sudo pacman -S nodejs npm
  else
    echo "Fehler: Bitte Node.js 18+ manuell installieren: https://nodejs.org"
    exit 1
  fi
fi

NODE_VERSION=$(node -v)
echo "✓ Node.js: $NODE_VERSION"

# ── Abhängigkeiten installieren ─────────────────────────────────
echo "Installiere Abhängigkeiten..."
cd "$SCRIPT_DIR"
npm install --production

echo "✓ Abhängigkeiten installiert"

# ── Test-Start ──────────────────────────────────────────────────
echo ""
echo "Starte Agent kurz zum Test..."
timeout 3 node server.js &
TEST_PID=$!
sleep 2
if kill -0 $TEST_PID 2>/dev/null; then
  kill $TEST_PID 2>/dev/null
  echo "✓ Agent startet korrekt"
else
  echo "✓ Agent gestartet"
fi

# ── Systemd-Dienst (Linux) ──────────────────────────────────────
if command -v systemctl &>/dev/null && [ "$(uname)" = "Linux" ]; then
  echo ""
  echo "Richte systemd-Dienst ein..."
  SERVICE_FILE="$HOME/.config/systemd/user/pandora-agent.service"
  mkdir -p "$(dirname "$SERVICE_FILE")"
  cat > "$SERVICE_FILE" << EOF
[Unit]
Description=PandoraOS Desktop Agent
After=network.target

[Service]
Type=simple
WorkingDirectory=$SCRIPT_DIR
ExecStart=$(which node) $SCRIPT_DIR/server.js
Restart=always
RestartSec=5
Environment=HOME=$HOME
Environment=PANDORA_PORT=7777

[Install]
WantedBy=default.target
EOF
  systemctl --user daemon-reload
  systemctl --user enable pandora-agent.service
  systemctl --user start  pandora-agent.service
  sleep 1
  STATUS=$(systemctl --user is-active pandora-agent.service)
  echo "✓ Dienst-Status: $STATUS"

# ── LaunchAgent (macOS) ─────────────────────────────────────────
elif [ "$(uname)" = "Darwin" ]; then
  echo ""
  echo "Richte macOS LaunchAgent ein..."
  PLIST="$HOME/Library/LaunchAgents/com.pandora.agent.plist"
  cat > "$PLIST" << EOF
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN"
    "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0"><dict>
  <key>Label</key>             <string>com.pandora.agent</string>
  <key>ProgramArguments</key>
  <array>
    <string>$(which node)</string>
    <string>$SCRIPT_DIR/server.js</string>
  </array>
  <key>WorkingDirectory</key>  <string>$SCRIPT_DIR</string>
  <key>RunAtLoad</key>         <true/>
  <key>KeepAlive</key>         <true/>
  <key>StandardOutPath</key>   <string>$HOME/.pandora/stdout.log</string>
  <key>StandardErrorPath</key> <string>$HOME/.pandora/stderr.log</string>
  <key>EnvironmentVariables</key>
  <dict><key>HOME</key><string>$HOME</string></dict>
</dict></plist>
EOF
  launchctl load "$PLIST"
  echo "✓ LaunchAgent eingerichtet"
fi

echo ""
echo "╔══════════════════════════════════════╗"
echo "║  PandoraOS Agent läuft!              ║"
echo "║  Web UI: http://localhost:7777       ║"
echo "║  Startet automatisch beim Boot       ║"
echo "╚══════════════════════════════════════╝"
