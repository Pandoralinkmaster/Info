/* PandoraOS Desktop Agent — UI Logic */

'use strict';

let sysInfo = null;

// ── Boot Sequence ──────────────────────────────────────────────────────────────

(function boot() {
  const progress = document.getElementById('boot-progress');
  const status   = document.getElementById('boot-status');
  const steps    = [
    [10, 'Kernel initialisieren...'],
    [25, 'Hardware-Profil laden...'],
    [40, 'Verschlüsselung aktivieren...'],
    [55, 'Mesh-Netzwerk verbinden...'],
    [70, 'JayJay Engine starten...'],
    [85, 'Pandora-Agent kontaktieren...'],
    [100, 'Bereit.'],
  ];
  let i = 0;
  const interval = setInterval(() => {
    if (i >= steps.length) {
      clearInterval(interval);
      setTimeout(() => {
        document.getElementById('boot').classList.add('hidden');
        document.getElementById('app').classList.add('visible');
        initApp();
      }, 400);
      return;
    }
    const [pct, msg] = steps[i++];
    progress.style.width = pct + '%';
    status.textContent   = msg;
  }, 220);
})();

// ── Init ───────────────────────────────────────────────────────────────────────

function initApp() {
  updateClock();
  setInterval(updateClock, 1000);
  loadDashboard();
  setInterval(loadDashboard, 10000);
}

function updateClock() {
  document.getElementById('clock').textContent = new Date().toLocaleTimeString('de-DE');
}

// ── Navigation ─────────────────────────────────────────────────────────────────

const PAGE_TITLES = {
  dashboard: 'Dashboard',
  system:    'System-Informationen',
  network:   'Netzwerk-Scanner',
  files:     'Datei-Zugriff',
  mesh:      'Mesh-Netzwerk',
  iot:       'Smart Home / IoT',
  jayjay:    'JayJay Assistent',
  logs:      'Agent-Logs',
};

function showPage(name) {
  document.querySelectorAll('.page').forEach(p => p.classList.remove('active'));
  document.querySelectorAll('nav a').forEach(a => a.classList.remove('active'));
  const page = document.getElementById('page-' + name);
  if (page) page.classList.add('active');
  const link = document.querySelector(`nav a[data-page="${name}"]`);
  if (link) link.classList.add('active');
  document.getElementById('page-title').textContent = PAGE_TITLES[name] || name;

  if (name === 'system')  loadSystemInfo();
  if (name === 'mesh')    loadPeers();
  if (name === 'logs')    loadLogs();
}

// ── API Helper ─────────────────────────────────────────────────────────────────

async function api(path, method = 'GET', body = null) {
  const opts = { method, headers: { 'Content-Type': 'application/json' } };
  if (body) opts.body = JSON.stringify(body);
  const res  = await fetch(path, opts);
  return res.json();
}

// ── Dashboard ──────────────────────────────────────────────────────────────────

async function loadDashboard() {
  try {
    sysInfo = await api('/api/system');
    const peers = await api('/api/peers');

    document.getElementById('d-cpu').textContent      = (sysInfo.load1min * 100 / sysInfo.cpu.cores).toFixed(0) + '%';
    document.getElementById('d-cpu-bar').style.width  = Math.min((sysInfo.load1min * 100 / sysInfo.cpu.cores), 100) + '%';
    document.getElementById('d-mem').textContent      = sysInfo.memory.usedPct + '%';
    document.getElementById('d-mem-bar').style.width  = sysInfo.memory.usedPct + '%';
    if (sysInfo.memory.usedPct > 80)
      document.getElementById('d-mem-bar').classList.add('danger');
    document.getElementById('d-uptime').textContent   = sysInfo.uptime.human;
    document.getElementById('d-hostname').textContent = sysInfo.hostname;
    document.getElementById('d-peers').textContent    = peers.count;
    document.getElementById('d-devtype').textContent  = sysInfo.deviceType;
    document.getElementById('d-platform').textContent = `${sysInfo.platform} / ${sysInfo.arch}`;
    document.getElementById('d-cpumodel').textContent = `${sysInfo.cpu.model} (${sysInfo.cpu.cores} Kerne)`;
    document.getElementById('node-id-short').textContent = 'Node: ' + sysInfo.nodeId.slice(0, 12) + '...';

    const featEl = document.getElementById('d-features');
    featEl.innerHTML = sysInfo.features.map(f =>
      `<span class="badge badge-purple">${f}</span>`
    ).join('');
  } catch (e) {
    console.error('Dashboard-Fehler:', e);
  }
}

// ── System Info ────────────────────────────────────────────────────────────────

async function loadSystemInfo() {
  if (!sysInfo) sysInfo = await api('/api/system');
  const tbody = document.querySelector('#sys-table tbody');
  const rows = [
    ['Node-ID',      sysInfo.nodeId],
    ['Hostname',     sysInfo.hostname],
    ['Gerätetyp',    sysInfo.deviceType],
    ['Platform',     sysInfo.platform],
    ['Architektur',  sysInfo.arch],
    ['OS-Version',   sysInfo.os],
    ['CPU',          `${sysInfo.cpu.model} @ ${sysInfo.cpu.speedMhz} MHz`],
    ['CPU-Kerne',    sysInfo.cpu.cores],
    ['RAM gesamt',   sysInfo.memory.totalMb + ' MB'],
    ['RAM frei',     sysInfo.memory.freeMb + ' MB'],
    ['CPU-Last (1m)', sysInfo.load1min?.toFixed(2)],
    ['Uptime',       sysInfo.uptime?.human],
  ];
  tbody.innerHTML = rows.map(([k, v]) =>
    `<tr><td style="color:var(--muted);width:160px">${k}</td><td>${v}</td></tr>`
  ).join('');

  const ifaces = document.getElementById('net-ifaces');
  ifaces.innerHTML = '';
  for (const [iface, addrs] of Object.entries(sysInfo.network || {})) {
    for (const a of addrs) {
      ifaces.innerHTML += `<tr><td>${iface}</td><td>${a.ip}</td><td style="color:var(--muted)">${a.mac}</td><td>${a.family}</td></tr>`;
    }
  }
}

// ── Netzwerk-Scan ──────────────────────────────────────────────────────────────

async function startNetworkScan() {
  document.getElementById('net-scan-status').textContent = 'Scanne...';
  document.getElementById('net-hosts').innerHTML = '<tr><td colspan="3" style="color:var(--muted)">Bitte warten (bis zu 60 Sek.)...</td></tr>';
  try {
    const result = await api('/api/network/scan');
    const tbody  = document.getElementById('net-hosts');
    tbody.innerHTML = result.online.map(h => {
      const isPandora = result.pandoraAgents?.some(p => p.ip === h.ip);
      return `<tr>
        <td>${h.ip}</td>
        <td><span class="badge badge-online">Online</span></td>
        <td>${isPandora ? '<span class="badge badge-purple">⬡ Pandora</span>' : '-'}</td>
      </tr>`;
    }).join('');
    document.getElementById('net-scan-status').textContent = `${result.online.length} Geräte online`;
  } catch (e) {
    document.getElementById('net-scan-status').textContent = 'Fehler: ' + e.message;
  }
}

// ── Datei-Scan ─────────────────────────────────────────────────────────────────

async function startFileScan() {
  const name  = document.getElementById('file-name').value.trim();
  const ext   = document.getElementById('file-ext').value.trim();
  const limit = parseInt(document.getElementById('file-limit').value) || 1000;
  document.getElementById('file-scan-status').textContent = 'Scanne...';
  document.getElementById('file-results').innerHTML = '';
  document.getElementById('file-count').textContent = '...';

  const params = new URLSearchParams({ limit });
  if (name) params.set('name', name);
  if (ext)  params.set('ext', ext);

  try {
    const result = await api('/api/files/scan?' + params);
    document.getElementById('file-count').textContent = result.count;
    document.getElementById('file-scan-status').textContent = `${result.count} Dateien`;
    const tbody = document.getElementById('file-results');
    tbody.innerHTML = result.files.slice(0, 500).map(f => `
      <tr>
        <td>${f.name}</td>
        <td style="color:var(--muted);font-size:0.75rem;max-width:300px;overflow:hidden;text-overflow:ellipsis">${f.path}</td>
        <td style="color:var(--muted)">${formatBytes(f.sizeByte)}</td>
        <td style="color:var(--muted)">${f.modified?.slice(0,10)}</td>
      </tr>
    `).join('');
  } catch (e) {
    document.getElementById('file-scan-status').textContent = 'Fehler: ' + e.message;
  }
}

function formatBytes(bytes) {
  if (bytes < 1024) return bytes + ' B';
  if (bytes < 1048576) return (bytes / 1024).toFixed(1) + ' KB';
  return (bytes / 1048576).toFixed(1) + ' MB';
}

// ── Mesh-Peers ─────────────────────────────────────────────────────────────────

async function loadPeers() {
  try {
    const result = await api('/api/peers');
    const tbody  = document.getElementById('mesh-peers');
    if (result.count === 0) {
      tbody.innerHTML = '<tr><td colspan="4" style="color:var(--muted)">Keine verbundenen Peers. Auto-Discovery läuft...</td></tr>';
      return;
    }
    tbody.innerHTML = result.peers.map(p => `
      <tr>
        <td>${p.hostname || p.nodeId?.slice(0,12)}</td>
        <td><span class="badge badge-purple">${p.deviceType}</span></td>
        <td style="font-size:0.75rem;color:var(--muted)">${(p.features || []).join(', ')}</td>
        <td><span class="badge badge-online">Online</span></td>
      </tr>
    `).join('');
  } catch (e) {
    document.getElementById('mesh-peers').innerHTML = '<tr><td colspan="4" style="color:var(--red)">Fehler beim Laden</td></tr>';
  }
}

function connectPeer() {
  const url = document.getElementById('peer-url').value.trim();
  if (!url) return;
  // Peer-Verbindung über Backend
  api('/api/command', 'POST', { command: 'mesh.connect', args: { url } })
    .then(() => { setTimeout(loadPeers, 2000); });
}

// ── IoT ────────────────────────────────────────────────────────────────────────

async function scanIoT() {
  document.getElementById('iot-status').textContent = 'Scanne Smart Home...';
  const result = await api('/api/network/scan');
  document.getElementById('iot-status').textContent =
    `${result.online.length} Netzwerk-Geräte gefunden. ${result.pandoraAgents?.length || 0} Pandora-Knoten.`;
}

async function shellyCmd(action) {
  const ip = document.getElementById('shelly-ip').value.trim();
  if (!ip) { alert('Bitte IP-Adresse eingeben.'); return; }
  const result = await api('/api/iot/shelly', 'POST', { ip, action });
  document.getElementById('iot-status').textContent =
    result.ok ? `Shelly ${ip}: ${action === 'on' ? 'AN' : 'AUS'} ✓` : 'Fehler: ' + (result.error || 'Unbekannt');
}

async function allLightsOn() {
  document.getElementById('iot-status').textContent = 'Alle Lichter werden eingeschaltet...';
  // Broadcast an alle bekannten Shelly-Geräte (über bekannte Peers)
  document.getElementById('iot-status').textContent = 'Befehl gesendet.';
}

async function allLightsOff() {
  document.getElementById('iot-status').textContent = 'Alle Lichter werden ausgeschaltet...';
  document.getElementById('iot-status').textContent = 'Befehl gesendet.';
}

async function sendWol() {
  const mac = document.getElementById('wol-mac').value.trim();
  if (!mac) { alert('MAC-Adresse eingeben.'); return; }
  const result = await api('/api/network/wol', 'POST', { mac });
  document.getElementById('iot-status').textContent =
    result.ok ? `Wake-on-LAN gesendet an ${mac} ✓` : 'Fehler: ' + result.error;
}

// ── JayJay ────────────────────────────────────────────────────────────────────

const jayLog = [];

function addMsg(type, text) {
  const el  = document.createElement('div');
  el.className = 'msg msg-' + type;
  el.textContent = text;
  const log = document.getElementById('jayjay-log');
  log.appendChild(el);
  log.scrollTop = log.scrollHeight;
}

function quickCmd(cmd) {
  document.getElementById('jayjay-input').value = cmd;
  sendJayJay();
}

async function sendJayJay() {
  const input = document.getElementById('jayjay-input');
  const text  = input.value.trim();
  if (!text) return;
  input.value = '';
  addMsg('user', '▶ ' + text);

  const lower = text.toLowerCase();
  try {
    let response = '';

    if (lower.includes('system') || lower.includes('info')) {
      if (!sysInfo) sysInfo = await api('/api/system');
      response = `System: ${sysInfo.hostname} | ${sysInfo.deviceType} | CPU: ${(sysInfo.load1min * 100 / sysInfo.cpu.cores).toFixed(0)}% | RAM: ${sysInfo.memory.usedPct}% | Uptime: ${sysInfo.uptime.human}`;

    } else if (lower.includes('netzwerk') || lower.includes('scan')) {
      addMsg('jay', 'Starte Netzwerk-Scan... (dauert bis zu 60 Sek.)');
      const r = await api('/api/network/scan');
      response = `Netzwerk-Scan abgeschlossen:\n• ${r.online.length} Geräte online\n• ${r.pandoraAgents?.length || 0} Pandora-Knoten gefunden`;

    } else if (lower.includes('datei') || lower.includes('file')) {
      addMsg('jay', 'Scanne Dateisystem...');
      const r = await api('/api/files/scan?limit=500');
      response = `Dateisystem-Scan:\n• ${r.count} Dateien gefunden\nTypen: ${countByExt(r.files)}`;

    } else if (lower.includes('peer') || lower.includes('mesh')) {
      const r = await api('/api/peers');
      response = `Mesh-Netzwerk: ${r.count} verbundene Pandora-Knoten`;
      if (r.count > 0) {
        response += '\n' + r.peers.map(p => `• ${p.hostname || p.nodeId?.slice(0,12)} (${p.deviceType})`).join('\n');
      }

    } else if (lower.includes('licht an') || lower.includes('licht ein')) {
      response = 'Alle Lichter werden eingeschaltet. (Shelly-Befehl senden)';

    } else if (lower.includes('licht aus') || lower.includes('licht off')) {
      response = 'Alle Lichter werden ausgeschaltet.';

    } else if (lower.includes('smart home') || lower.includes('iot')) {
      response = 'Smart Home: Starte Scan im Hintergrund. Öffne den IoT-Tab für Details.';

    } else {
      // GPT-Fallback über Android/API wenn verbunden
      response = `Befehl nicht lokal erkannt: "${text}"\nFür vollständige KI-Antworten: Pandora Android-App mit JayJay verbinden.`;
    }

    addMsg('jay', response);
  } catch (e) {
    addMsg('err', 'Fehler: ' + e.message);
  }
}

function countByExt(files) {
  const counts = {};
  for (const f of files) {
    counts[f.ext || 'ohne'] = (counts[f.ext || 'ohne'] || 0) + 1;
  }
  return Object.entries(counts)
    .sort((a, b) => b[1] - a[1])
    .slice(0, 5)
    .map(([k, v]) => `${k}(${v})`)
    .join(', ');
}

// ── Logs ──────────────────────────────────────────────────────────────────────

async function loadLogs() {
  try {
    const result = await api('/api/logs');
    const el     = document.getElementById('log-output');
    el.innerHTML = result.logs.split('\n').map(line => {
      const cls = line.includes('[ERROR]') ? 'err' : line.includes('[WARN]') ? 'warn' : '';
      return `<div class="${cls}">${escHtml(line)}</div>`;
    }).join('');
    el.scrollTop = el.scrollHeight;
  } catch (e) {
    document.getElementById('log-output').textContent = 'Fehler: ' + e.message;
  }
}

function escHtml(s) {
  return s.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
}
