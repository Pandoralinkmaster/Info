#!/usr/bin/env node
/**
 * ╔══════════════════════════════════════════════════════════════╗
 * ║              PandoraOS Desktop Agent v1.0                    ║
 * ║                                                              ║
 * ║  Läuft auf: PC (Windows/Linux/Mac) · Raspberry Pi           ║
 * ║             Smart TV (Browser) · Konsole (Browser)          ║
 * ║                                                              ║
 * ║  Startet beim Boot, verbindet sich ins Pandora-Mesh,        ║
 * ║  Web-UI erreichbar unter: http://localhost:7777              ║
 * ║                                                              ║
 * ║  CEO: Finn Jona Thorsten Lischke                            ║
 * ║  Aktivierung: "Pandemonium"                                  ║
 * ╚══════════════════════════════════════════════════════════════╝
 */

'use strict';

const http      = require('http');
const https     = require('https');
const fs        = require('fs');
const path      = require('path');
const os        = require('os');
const crypto    = require('crypto');
const { exec, spawn } = require('child_process');
const WebSocket = require('ws');

// ── Konfiguration ──────────────────────────────────────────────────────────────

const CONFIG_FILE = path.join(os.homedir(), '.pandora', 'config.json');
const LOG_FILE    = path.join(os.homedir(), '.pandora', 'agent.log');
const KEY_FILE    = path.join(os.homedir(), '.pandora', 'keys.json');
const PORT        = process.env.PANDORA_PORT || 7777;
const WS_PORT     = process.env.PANDORA_WS_PORT || 7778;
const NODE_ID     = loadOrCreateNodeId();

// ── Gerättyp erkennen ──────────────────────────────────────────────────────────

function detectDeviceType() {
  const platform = os.platform();
  const isRaspi  = fs.existsSync('/proc/cpuinfo') &&
    fs.readFileSync('/proc/cpuinfo', 'utf8').includes('Raspberry Pi');
  const isTV     = process.env.PANDORA_DEVICE === 'tv';
  const isCar    = process.env.PANDORA_DEVICE === 'car';

  if (isRaspi)             return 'RASPBERRY_PI';
  if (isTV)                return 'SMART_TV';
  if (isCar)               return 'CAR';
  if (platform === 'win32') return 'PC_WINDOWS';
  if (platform === 'darwin') return 'PC_MAC';
  return 'PC_LINUX';
}

const DEVICE_TYPE = detectDeviceType();

// Features je nach Gerätetyp
const FEATURES = {
  PC_WINDOWS:    ['file_access', 'system_info', 'mesh', 'iot', 'wake_on_lan', 'web_ui'],
  PC_LINUX:      ['file_access', 'system_info', 'mesh', 'iot', 'wake_on_lan', 'web_ui', 'gpio'],
  PC_MAC:        ['file_access', 'system_info', 'mesh', 'iot', 'web_ui'],
  RASPBERRY_PI:  ['file_access', 'system_info', 'mesh', 'iot', 'gpio', 'headless'],
  SMART_TV:      ['web_ui', 'mesh', 'media'],
  CAR:           ['mesh', 'gps', 'web_ui'],
}[DEVICE_TYPE] || ['mesh', 'web_ui'];

log(`PandoraOS Agent startet — Typ: ${DEVICE_TYPE}`);
log(`Features: ${FEATURES.join(', ')}`);

// ── Logging ────────────────────────────────────────────────────────────────────

function log(msg) {
  const ts   = new Date().toISOString();
  const line = `[${ts}] ${msg}`;
  console.log(line);
  try {
    fs.mkdirSync(path.dirname(LOG_FILE), { recursive: true });
    fs.appendFileSync(LOG_FILE, line + '\n');
  } catch (_) {}
}

// ── Node-ID & Schlüssel ────────────────────────────────────────────────────────

function loadOrCreateNodeId() {
  const dir = path.join(os.homedir(), '.pandora');
  fs.mkdirSync(dir, { recursive: true });
  const file = path.join(dir, 'node-id');
  if (fs.existsSync(file)) return fs.readFileSync(file, 'utf8').trim();
  const id = crypto.randomBytes(16).toString('hex');
  fs.writeFileSync(file, id);
  return id;
}

function loadOrCreateKeys() {
  if (fs.existsSync(KEY_FILE)) {
    return JSON.parse(fs.readFileSync(KEY_FILE, 'utf8'));
  }
  const { publicKey, privateKey } = crypto.generateKeyPairSync('rsa', {
    modulusLength:  4096,
    publicKeyEncoding:  { type: 'spki',  format: 'pem' },
    privateKeyEncoding: { type: 'pkcs8', format: 'pem' },
  });
  const keys = { publicKey, privateKey, nodeId: NODE_ID };
  fs.mkdirSync(path.dirname(KEY_FILE), { recursive: true });
  fs.writeFileSync(KEY_FILE, JSON.stringify(keys, null, 2), { mode: 0o600 });
  log('RSA-4096 Schlüsselpaar generiert.');
  return keys;
}

const KEYS = loadOrCreateKeys();

// ── System-Informationen ───────────────────────────────────────────────────────

function getSystemInfo() {
  const cpus    = os.cpus();
  const mem     = os.totalmem();
  const freeMem = os.freemem();
  const uptime  = os.uptime();
  const load    = os.loadavg();

  const network = {};
  const ifaces  = os.networkInterfaces();
  for (const [name, addrs] of Object.entries(ifaces || {})) {
    network[name] = (addrs || [])
      .filter(a => !a.internal)
      .map(a => ({ ip: a.address, mac: a.mac, family: a.family }));
  }

  return {
    nodeId:     NODE_ID,
    deviceType: DEVICE_TYPE,
    features:   FEATURES,
    hostname:   os.hostname(),
    platform:   os.platform(),
    arch:       os.arch(),
    os:         os.release(),
    cpu: {
      model:   cpus[0]?.model || 'Unknown',
      cores:   cpus.length,
      speedMhz: cpus[0]?.speed || 0,
    },
    memory: {
      totalMb:  Math.round(mem    / 1024 / 1024),
      freeMb:   Math.round(freeMem / 1024 / 1024),
      usedPct:  Math.round((1 - freeMem / mem) * 100),
    },
    uptime: {
      seconds: uptime,
      human:   formatUptime(uptime),
    },
    load1min:  load[0],
    network,
    timestamp: Date.now(),
  };
}

function formatUptime(secs) {
  const d = Math.floor(secs / 86400);
  const h = Math.floor((secs % 86400) / 3600);
  const m = Math.floor((secs % 3600) / 60);
  return `${d}d ${h}h ${m}m`;
}

// ── Datei-Zugriff ──────────────────────────────────────────────────────────────

const SCAN_ROOTS = (() => {
  const platform = os.platform();
  if (platform === 'win32') {
    return ['C:\\Users', 'C:\\Documents and Settings'];
  }
  return [os.homedir(), '/tmp'];
})();

function scanFiles(rootDir, options = {}) {
  const {
    maxFiles   = 50000,
    extensions = null,   // null = alles
    nameFilter = null,
    dateAfter  = null,
  } = options;

  const results = [];
  function walk(dir) {
    if (results.length >= maxFiles) return;
    let entries;
    try { entries = fs.readdirSync(dir, { withFileTypes: true }); }
    catch (_) { return; }

    for (const entry of entries) {
      if (results.length >= maxFiles) return;
      const full = path.join(dir, entry.name);
      const skip = ['.git', 'node_modules', '.npm', '.cache',
                    'System Volume Information', '$Recycle.Bin',
                    '.Trash', 'proc', 'sys', 'dev'].includes(entry.name);
      if (skip) continue;

      if (entry.isDirectory()) {
        walk(full);
      } else {
        const ext = path.extname(entry.name).toLowerCase();
        if (extensions && !extensions.includes(ext)) continue;
        if (nameFilter && !entry.name.toLowerCase().includes(nameFilter.toLowerCase())) continue;
        try {
          const stat = fs.statSync(full);
          if (dateAfter && stat.mtimeMs < dateAfter) continue;
          results.push({
            name:     entry.name,
            path:     full,
            ext,
            sizeByte: stat.size,
            modified: stat.mtime.toISOString(),
          });
        } catch (_) {}
      }
    }
  }

  const roots = rootDir ? [rootDir] : SCAN_ROOTS;
  for (const r of roots) {
    try { walk(r); } catch (_) {}
  }
  return results;
}

// ── Netzwerk-Scan ──────────────────────────────────────────────────────────────

function getLocalSubnet() {
  const ifaces = os.networkInterfaces();
  for (const addrs of Object.values(ifaces || {})) {
    for (const a of addrs || []) {
      if (!a.internal && a.family === 'IPv4' && !a.address.startsWith('127.')) {
        return a.address.split('.').slice(0, 3).join('.');
      }
    }
  }
  return '192.168.1';
}

function pingHost(ip) {
  return new Promise(resolve => {
    const cmd = os.platform() === 'win32'
      ? `ping -n 1 -w 300 ${ip}`
      : `ping -c 1 -W 1 ${ip}`;
    exec(cmd, { timeout: 2000 }, (err, stdout) => {
      resolve({ ip, online: !err && (stdout.includes('ttl=') || stdout.includes('TTL=') || stdout.includes('time=')) });
    });
  });
}

async function scanNetwork() {
  const subnet = getLocalSubnet();
  log(`Netzwerk-Scan: ${subnet}.1–254`);
  const promises = [];
  for (let i = 1; i <= 254; i++) promises.push(pingHost(`${subnet}.${i}`));
  const results  = await Promise.all(promises);
  const online   = results.filter(r => r.online);
  log(`Netzwerk: ${online.length} Geräte online`);

  // Pandora-Agents erkennen
  const pandoraAgents = [];
  for (const { ip } of online) {
    try {
      const resp = await httpGet(`http://${ip}:7777/api/info`, 500);
      const info = JSON.parse(resp);
      if (info.pandora === true) pandoraAgents.push({ ip, ...info });
    } catch (_) {}
  }
  return { subnet, online, pandoraAgents };
}

function httpGet(url, timeoutMs = 2000) {
  return new Promise((resolve, reject) => {
    const lib = url.startsWith('https') ? https : http;
    const req = lib.get(url, { timeout: timeoutMs }, res => {
      let data = '';
      res.on('data', d => data += d);
      res.on('end', () => resolve(data));
    });
    req.on('error', reject);
    req.on('timeout', () => { req.destroy(); reject(new Error('timeout')); });
  });
}

// ── IoT-Steuerung ─────────────────────────────────────────────────────────────

async function shellyCommand(ip, action, value = '') {
  const url = action === 'on'  ? `http://${ip}/relay/0?turn=on`
            : action === 'off' ? `http://${ip}/relay/0?turn=off`
            : `http://${ip}/relay/0?turn=toggle`;
  try { await httpGet(url, 2000); return true; }
  catch (_) { return false; }
}

// Wake-on-LAN
function wakeOnLan(macAddress) {
  return new Promise(resolve => {
    const macHex = macAddress.replace(/[:\-]/g, '');
    const mac    = Buffer.from(macHex, 'hex');
    const magic  = Buffer.alloc(102);
    magic.fill(0xff, 0, 6);
    for (let i = 0; i < 16; i++) mac.copy(magic, 6 + i * 6);
    const dgram  = require('dgram');
    const socket = dgram.createSocket('udp4');
    socket.once('listening', () => socket.setBroadcast(true));
    socket.send(magic, 0, magic.length, 9, '255.255.255.255', () => {
      socket.close();
      resolve(true);
    });
  });
}

// ── Mesh-Netzwerk (WebSocket) ─────────────────────────────────────────────────

const peers   = new Map();  // nodeId → { ws, info }
const clients = new Set();  // verbundene Web-Clients

const wss = new WebSocket.Server({ port: WS_PORT });
wss.on('connection', (ws, req) => {
  const remoteIp = req.socket.remoteAddress;
  log(`Eingehende WS-Verbindung: ${remoteIp}`);
  clients.add(ws);

  ws.on('message', raw => {
    try {
      const msg = JSON.parse(raw);
      handleMeshMessage(ws, msg);
    } catch (_) {}
  });

  ws.on('close', () => {
    clients.delete(ws);
    for (const [id, peer] of peers.entries()) {
      if (peer.ws === ws) { peers.delete(id); log(`Peer getrennt: ${id}`); }
    }
  });

  // Willkommen
  ws.send(JSON.stringify({
    type: 'PANDORA_HELLO',
    nodeId: NODE_ID,
    deviceType: DEVICE_TYPE,
    features: FEATURES,
    systemInfo: getSystemInfo(),
  }));
});

function handleMeshMessage(ws, msg) {
  switch (msg.type) {
    case 'PANDORA_HELLO':
      peers.set(msg.nodeId, { ws, info: msg });
      log(`Pandora-Peer verbunden: ${msg.nodeId} (${msg.deviceType})`);
      broadcastToClients({ type: 'PEER_CONNECTED', peer: msg });
      break;

    case 'COMMAND':
      handleRemoteCommand(msg.command, msg.args || {}).then(result => {
        ws.send(JSON.stringify({ type: 'COMMAND_RESULT', id: msg.id, result }));
      });
      break;

    case 'FILE_LIST':
      const files = scanFiles(msg.path, msg.options);
      ws.send(JSON.stringify({ type: 'FILE_LIST_RESULT', id: msg.id, files }));
      break;

    case 'SYSTEM_INFO':
      ws.send(JSON.stringify({ type: 'SYSTEM_INFO_RESULT', id: msg.id, info: getSystemInfo() }));
      break;

    case 'RELAY':
      // Mesh-Relay: Nachricht an anderen Node weiterleiten
      const target = peers.get(msg.targetNodeId);
      if (target) target.ws.send(JSON.stringify(msg.payload));
      break;
  }
}

function broadcastToClients(msg) {
  const raw = JSON.stringify(msg);
  for (const client of clients) {
    if (client.readyState === WebSocket.OPEN) client.send(raw);
  }
}

// ── Remote-Befehle (von JayJay/Android) ──────────────────────────────────────

async function handleRemoteCommand(command, args) {
  log(`Remote-Befehl: ${command} ${JSON.stringify(args)}`);
  switch (command) {
    case 'files.scan':
      return scanFiles(args.path, args.options);
    case 'files.read':
      try { return { content: fs.readFileSync(args.path, 'utf8').slice(0, 50000) }; }
      catch (e) { return { error: e.message }; }
    case 'system.info':
      return getSystemInfo();
    case 'network.scan':
      return await scanNetwork();
    case 'iot.shelly':
      return await shellyCommand(args.ip, args.action);
    case 'network.wol':
      return await wakeOnLan(args.mac);
    case 'system.shutdown':
      if (!args.finnAuth) return { error: 'Nur Finn darf das Gerät herunterfahren.' };
      const shutCmd = os.platform() === 'win32' ? 'shutdown /s /t 10' : 'sudo shutdown -h +1';
      exec(shutCmd);
      return { ok: true, message: 'System fährt in 1 Minute herunter.' };
    case 'system.reboot':
      if (!args.finnAuth) return { error: 'Nur Finn darf neustarten.' };
      const rebootCmd = os.platform() === 'win32' ? 'shutdown /r /t 10' : 'sudo reboot';
      exec(rebootCmd);
      return { ok: true, message: 'System startet neu.' };
    case 'gpio.set':
      if (!FEATURES.includes('gpio')) return { error: 'GPIO nicht verfügbar auf diesem Gerät.' };
      return await gpioSet(args.pin, args.value);
    default:
      return { error: `Unbekannter Befehl: ${command}` };
  }
}

// ── GPIO (Raspberry Pi) ───────────────────────────────────────────────────────

function gpioSet(pin, value) {
  return new Promise(resolve => {
    exec(`gpio write ${pin} ${value ? 1 : 0}`, (err) => {
      if (err) {
        // Fallback: sysfs
        try {
          fs.writeFileSync(`/sys/class/gpio/export`, pin);
          fs.writeFileSync(`/sys/class/gpio/gpio${pin}/direction`, 'out');
          fs.writeFileSync(`/sys/class/gpio/gpio${pin}/value`, value ? '1' : '0');
          resolve({ ok: true });
        } catch (e2) { resolve({ error: e2.message }); }
      } else {
        resolve({ ok: true });
      }
    });
  });
}

// ── CEO-Präsenz / Lockdown (fail-closed) ────────────────────────────────────────
//
// Dieses Gerät arbeitet NUR, wenn das CEO-Handy online ist und signierte
// Heartbeats sendet. Bleibt der Heartbeat aus (Handy offline), sperrt sich
// das Gerät komplett – niemand kommt mehr an Dateien, System oder Befehle.

const CEO_TIMEOUT_MS = 60_000;     // 60s ohne Heartbeat → Lockdown
let lastCeoBeat   = 0;             // Zeitstempel des letzten gültigen Heartbeats
let manualLockdown = false;        // vom CEO-Handy explizit ausgelöst

// Endpunkte, die IMMER offen sind (für Discovery + CEO-Kommunikation)
const CEO_OPEN_PATHS = ['/api/info', '/api/ceo/heartbeat', '/api/ceo/lockdown'];

function ceoOnline() {
  if (manualLockdown) return false;
  return (Date.now() - lastCeoBeat) < CEO_TIMEOUT_MS;
}

// HMAC-SHA256 verifizieren (identisch zum CEO-Handy: CeoAuthority.sign)
function verifyCeoSig(data, sig, secret) {
  try {
    const expected = crypto.createHmac('sha256', secret).update(data).digest('hex');
    const a = Buffer.from(expected);
    const b = Buffer.from(String(sig || ''));
    return a.length === b.length && crypto.timingSafeEqual(a, b);
  } catch (_) { return false; }
}

// ── HTTP REST-API ──────────────────────────────────────────────────────────────

const server = http.createServer(async (req, res) => {
  const url  = req.url.split('?')[0];
  const qs   = Object.fromEntries(new URL(req.url, `http://localhost`).searchParams);

  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, X-Pandora-Token');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
  if (req.method === 'OPTIONS') { res.writeHead(204); res.end(); return; }

  // Leib Körper einlesen
  let body = '';
  if (req.method === 'POST') {
    await new Promise(r => { req.on('data', d => body += d); req.on('end', r); });
  }
  const data = body ? (() => { try { return JSON.parse(body); } catch { return {}; } })() : {};

  // Auth-Token prüfen (konfigurierbar)
  const config  = loadConfig();
  const token   = req.headers['x-pandora-token'] || qs.token;
  const needAuth = config.requireAuth && url !== '/' && !url.startsWith('/ui');
  if (needAuth && token !== config.token) {
    json(res, 403, { error: 'Unauthorized' });
    return;
  }

  // CEO-Lockdown-Gate (fail-closed): geschützte API nur wenn CEO-Handy online.
  // /api/info + /api/ceo/* bleiben offen (Discovery + Heartbeat).
  const isApi    = url.startsWith('/api/');
  const isOpen   = CEO_OPEN_PATHS.includes(url);
  if (config.requireCeo && isApi && !isOpen && !ceoOnline()) {
    json(res, 423, {
      error: 'LOCKDOWN: CEO-Handy offline – Zugriff gesperrt.',
      locked: true,
      reason: manualLockdown ? 'manual_lockdown' : 'no_ceo_heartbeat',
    });
    return;
  }

  try {
    // ── Web UI ────────────────────────────────────────────────────────────────
    if (url === '/' || url === '/ui' || url === '/index.html') {
      const uiFile = path.join(__dirname, 'ui', 'index.html');
      if (fs.existsSync(uiFile)) {
        res.writeHead(200, { 'Content-Type': 'text/html' });
        res.end(fs.readFileSync(uiFile));
      } else {
        res.writeHead(200, { 'Content-Type': 'text/html' });
        res.end(minimalUi());
      }
      return;
    }

    if (url === '/ui/app.js') {
      const js = path.join(__dirname, 'ui', 'app.js');
      if (fs.existsSync(js)) {
        res.writeHead(200, { 'Content-Type': 'application/javascript' });
        res.end(fs.readFileSync(js));
      } else { json(res, 404, {}); }
      return;
    }

    // ── REST API ──────────────────────────────────────────────────────────────
    if (url === '/api/info') {
      return json(res, 200, { pandora: true, ceoOnline: ceoOnline(), ...getSystemInfo() });
    }

    // CEO-Handy meldet Präsenz (signierter Heartbeat)
    if (url === '/api/ceo/heartbeat' && req.method === 'POST') {
      const { ts, nonce, sig } = data;
      if (!verifyCeoSig(`ceo:${ts}:${nonce}`, sig, config.ceoSecret)) {
        log('⚠ Ungültiger CEO-Heartbeat abgelehnt (Signatur falsch)');
        return json(res, 403, { error: 'Ungültige Signatur – kein echtes CEO-Handy.' });
      }
      // Replay-Schutz: Heartbeat darf nicht zu alt sein
      if (Math.abs(Date.now() - Number(ts)) > CEO_TIMEOUT_MS) {
        return json(res, 403, { error: 'Heartbeat veraltet.' });
      }
      const wasLocked = !ceoOnline();
      lastCeoBeat = Date.now();
      manualLockdown = false;
      if (wasLocked) log('🔓 CEO-Handy online – Gerät entsperrt.');
      return json(res, 200, { ok: true, ceoOnline: true });
    }

    // CEO-Handy löst expliziten Lockdown aus
    if (url === '/api/ceo/lockdown' && req.method === 'POST') {
      const { ts, nonce, sig } = data;
      if (!verifyCeoSig(`lockdown:${ts}:${nonce}`, sig, config.ceoSecret)) {
        return json(res, 403, { error: 'Ungültige Signatur.' });
      }
      manualLockdown = true;
      log('🔒 LOCKDOWN vom CEO-Handy ausgelöst – Gerät gesperrt.');
      return json(res, 200, { ok: true, locked: true });
    }

    if (url === '/api/system') {
      return json(res, 200, getSystemInfo());
    }

    if (url === '/api/peers') {
      const list = [...peers.values()].map(p => p.info);
      return json(res, 200, { count: list.length, peers: list });
    }

    if (url === '/api/files' || url === '/api/files/scan') {
      const opts = {
        extensions: qs.ext ? qs.ext.split(',') : null,
        nameFilter: qs.name || null,
        maxFiles:   parseInt(qs.limit) || 50000,
        dateAfter:  qs.after ? parseInt(qs.after) : null,
      };
      const files = scanFiles(qs.path || null, opts);
      return json(res, 200, { count: files.length, files });
    }

    if (url === '/api/files/read') {
      const fPath = qs.path || data.path;
      if (!fPath) return json(res, 400, { error: 'path fehlt' });
      try {
        const content = fs.readFileSync(fPath, 'utf8').slice(0, 100000);
        return json(res, 200, { path: fPath, content });
      } catch (e) {
        return json(res, 500, { error: e.message });
      }
    }

    if (url === '/api/network/scan') {
      const result = await scanNetwork();
      return json(res, 200, result);
    }

    if (url === '/api/iot/shelly' && req.method === 'POST') {
      const ok = await shellyCommand(data.ip, data.action);
      return json(res, 200, { ok });
    }

    if (url === '/api/network/wol' && req.method === 'POST') {
      const ok = await wakeOnLan(data.mac);
      return json(res, 200, { ok });
    }

    if (url === '/api/command' && req.method === 'POST') {
      const result = await handleRemoteCommand(data.command, data.args || {});
      return json(res, 200, result);
    }

    if (url === '/api/logs') {
      try {
        const logs = fs.readFileSync(LOG_FILE, 'utf8').split('\n').slice(-200).join('\n');
        return json(res, 200, { logs });
      } catch (_) {
        return json(res, 200, { logs: '' });
      }
    }

    json(res, 404, { error: 'Not found' });
  } catch (e) {
    log(`HTTP-Fehler: ${e.message}`);
    json(res, 500, { error: e.message });
  }
});

function json(res, status, data) {
  res.writeHead(status, { 'Content-Type': 'application/json' });
  res.end(JSON.stringify(data));
}

// ── Konfiguration ──────────────────────────────────────────────────────────────

function loadConfig() {
  const defaults = {
    requireAuth: false,
    token: crypto.randomBytes(32).toString('hex'),
    meshPeers: [],
    autoDiscover: true,
    // CEO-Authentifizierung: dieses Gerät arbeitet nur, wenn das CEO-Handy
    // online ist und Heartbeats sendet. Offline = totaler Lockdown.
    requireCeo: true,
    // Gemeinsamer Netzwerkschlüssel – MUSS identisch zum CEO-Handy sein
    // (CeoAuthority.NETWORK_KEY in der Pandora-APK).
    ceoSecret: 'PandoraNetz-Finn-Jona-Thorsten-Lischke-CEO',
  };
  if (!fs.existsSync(CONFIG_FILE)) {
    fs.mkdirSync(path.dirname(CONFIG_FILE), { recursive: true });
    fs.writeFileSync(CONFIG_FILE, JSON.stringify(defaults, null, 2));
    return defaults;
  }
  try {
    return { ...defaults, ...JSON.parse(fs.readFileSync(CONFIG_FILE, 'utf8')) };
  } catch (_) { return defaults; }
}

// ── Minimal UI (wenn ui/ fehlt) ────────────────────────────────────────────────

function minimalUi() {
  return `<!DOCTYPE html><html><head><meta charset="utf-8">
<title>PandoraOS Agent</title>
<style>body{background:#0a0a0a;color:#00ff88;font-family:monospace;padding:20px}
h1{color:#7c3aed} .info{border:1px solid #333;padding:10px;margin:10px 0;border-radius:4px}
</style></head><body>
<h1>⬡ PandoraOS Agent</h1>
<div class="info">Node-ID: ${NODE_ID}</div>
<div class="info">Gerätetyp: ${DEVICE_TYPE}</div>
<div class="info">Web UI: Lade ui/index.html für die volle Oberfläche</div>
<div class="info">API: <a href="/api/info" style="color:#7c3aed">/api/info</a></div>
</body></html>`;
}

// ── Mesh Auto-Discovery ────────────────────────────────────────────────────────

async function autoDiscoverPeers() {
  const config = loadConfig();
  if (!config.autoDiscover) return;

  // Bekannte Peers aus Config verbinden
  for (const peer of config.meshPeers || []) {
    connectToPeer(peer);
  }

  // Netzwerk-Broadcast
  try {
    const subnet = getLocalSubnet();
    for (let i = 1; i <= 254; i++) {
      const ip = `${subnet}.${i}`;
      httpGet(`http://${ip}:7777/api/info`, 300)
        .then(body => {
          const info = JSON.parse(body);
          if (info.pandora && info.nodeId !== NODE_ID) {
            connectToPeer(`ws://${ip}:${WS_PORT}`);
          }
        })
        .catch(() => {});
    }
  } catch (_) {}
}

function connectToPeer(wsUrl) {
  try {
    const ws = new WebSocket(wsUrl, { handshakeTimeout: 3000 });
    ws.on('open', () => {
      ws.send(JSON.stringify({
        type: 'PANDORA_HELLO',
        nodeId: NODE_ID,
        deviceType: DEVICE_TYPE,
        features: FEATURES,
      }));
      log(`Peer verbunden: ${wsUrl}`);
    });
    ws.on('message', raw => {
      try { handleMeshMessage(ws, JSON.parse(raw)); } catch (_) {}
    });
    ws.on('error', () => {});
  } catch (_) {}
}

// ── Start ──────────────────────────────────────────────────────────────────────

server.listen(PORT, '0.0.0.0', () => {
  log(`╔══════════════════════════════════════╗`);
  log(`║  PandoraOS Agent läuft               ║`);
  log(`║  Web UI: http://localhost:${PORT}      ║`);
  log(`║  Mesh WS: ws://localhost:${WS_PORT}     ║`);
  log(`║  Gerät: ${DEVICE_TYPE.padEnd(28)}║`);
  log(`║  Node:  ${NODE_ID.slice(0, 27).padEnd(28)}║`);
  log(`╚══════════════════════════════════════╝`);

  // Peer-Discovery nach 5 Sekunden
  setTimeout(autoDiscoverPeers, 5000);
});

wss.on('listening', () => {
  log(`WebSocket-Server bereit auf Port ${WS_PORT}`);
});

process.on('SIGTERM', () => { log('Agent wird beendet...'); process.exit(0); });
process.on('SIGINT',  () => { log('Agent wird beendet...'); process.exit(0); });
