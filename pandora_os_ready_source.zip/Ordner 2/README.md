# ◈ PANDORA

**Version:** 1.0.0  
**CEO:** Finn Jona Lischke · finn.jona.lischke@gmail.com  
**Zielgerät:** Samsung Galaxy S24 Ultra (CEO Host) + beliebige Android-Phones (Clients/Nodes)

---

## Was ist Pandora?

Pandora ist ein OS-artiges Android-System — eine einzige APK, die je nach Modus als **CEO Host**, **Client**, **Mesh-Knoten**, **Sensing-Knoten**, **Compute-Knoten** oder **Relay-Knoten** fungiert.

```
Samsung Galaxy S24 Ultra
    + Pandora.apk (CEO Host Mode)
    + M.2 SSD (exFAT) als zentrale Datenbank
    + JayJay AI (hört nur auf Finn's Stimme)
    + Mesh (BT · WiFi · Onion)
    + Bitcoin Hardware Wallet (Ledger USB-OTG)
    + andere Android-Phones mit Pandora.apk
```

---

## Schnellstart

### 1. APK bauen
```bash
cd pandora-android
./gradlew assembleRelease
# APK: app/build/outputs/apk/release/app-release.apk
```

### 2. Auf Samsung Galaxy S24 Ultra installieren
```bash
adb install app/build/outputs/apk/release/app-release.apk
```

### 3. Ersten Start durchführen
1. App öffnen → **CEO Host Mode** wählen
2. CEO registrieren (Name + PIN)
3. M.2 SSD (exFAT) anschließen und freigeben
4. Pandora erstellt automatisch alle Ordner + Datenbank
5. JayJay Voice-Fingerabdruck einlernen (3 Samples)
6. Sage "**Pandemonium**" → JayJay ist aktiv

### 4. Weitere Geräte koppeln
Andere Android-Phones installieren dieselbe `Pandora.apk` und wählen ihren Modus (Client, Mesh-Node, etc.).

---

## Projektstruktur

```
pandora/
├── pandora-android/          ← Android-App (alle Modi)
│   ├── app/
│   │   ├── build.gradle.kts
│   │   └── src/main/kotlin/com/pandora/
│   │       ├── PandoraApplication.kt
│   │       ├── MainActivity.kt
│   │       ├── api/          ← Ktor eingebetteter Server
│   │       ├── building/     ← 3D Building Overlay
│   │       ├── compute/      ← Compute Mesh
│   │       ├── core/         ← ConfigManager, HostService, BootReceiver
│   │       ├── database/     ← Room + SSD-Manager (exFAT)
│   │       ├── di/           ← Koin DI
│   │       ├── jayjay/       ← JayJay AI + Voice + Learning
│   │       ├── mesh/         ← BT + WiFi + Onion Router
│   │       ├── onion/        ← Tor (Orbot)
│   │       ├── scan/         ← RSSI + CSI + RuView
│   │       ├── security/     ← AES-256 + Token + Biometrie
│   │       ├── ui/           ← Compose Screens
│   │       ├── visibility/   ← HostVisibilityGate
│   │       ├── wallet/       ← Bitcoin BIP39/BIP44 + Ledger
│   │       └── wireguard/    ← WireGuard VPN
│   └── gradle/
│       └── libs.versions.toml
├── docs/
├── scripts/
├── master_config.example.json
└── README.md
```

---

## M.2 SSD (exFAT)

Die SSD ist als **exFAT** formatiert — vollständig kompatibel mit Android SAF.

| Aspekt | Details |
|--------|---------|
| Formatierung | exFAT ✓ |
| Zugriff | Android Storage Access Framework (SAF) |
| SQLite DB | Im internen App-Speicher (ext4) — exFAT unterstützt kein fcntl-Locking |
| Alle anderen Daten | Direkt auf SSD (Config, Receipts, Logs, JayJay-Wissen, Wallet) |
| Backup | Automatisch alle 15 Min → `/Pandora/backups/pandora_YYYYMMDD_HHmm.db` |

---

## JayJay KI

- **Stimme:** Lernt Finn's Stimme (Voice-Print, 3 Samples minimum)
- **Aktivierung:** Sage "**Pandemonium**" auf **jedem** Pandora-Gerät
- **Locked-Screen:** JayJay hört auch wenn Bildschirm gesperrt ist (Foreground Service)
- **Lernen:** "JayJay, recherchiere über [Thema]" → sucht Wikipedia + GPT, speichert auf SSD
- **Befehle lernen:** "JayJay, wenn ich 'X' sage, dann mache Y"
- **Auto-Lernen:** Aktualisiert bekannte Themen stündlich automatisch
- **Nur CEO:** Kein anderer Nutzer kann JayJay Befehle geben

---

## Sicherheit

- **Zero-Trust**: Kein Gerät wird ohne CEO-Freigabe autorisiert
- **HostVisibilityGate**: Host gesperrt wenn CEO nicht aktiv — andere sehen nichts
- **AES-256-GCM**: Alle Daten auf SSD verschlüsselt
- **Android Keystore**: Hardware-backed Schlüsselspeicher (TEE)
- **Tor**: Sensitiver Traffic über Orbot (Onion)
- **WireGuard**: VPN für alle Pandora-Peers

---

## Bitcoin Hardware Wallet

- BIP39/BIP44 HD-Wallet (pure Kotlin, kein @noble/curves)
- Ledger Nano S/X/S+ via USB-OTG (VID 0x2C97)
- Private Keys verlassen den Ledger niemals
- PSBT-Signing + Broadcast via Mempool.space über Tor
- Wallet-Daten auf M.2 SSD (exFAT, AES-256 verschlüsselt)

---

## Rollen

| Rolle | Zugriff |
|-------|---------|
| `ceo` | Vollzugriff · JayJay · Admin · Bitcoin |
| `admin` | Geräte · Produkte · Bestellungen |
| `customer` | Shop · Checkout · Chat |
| `service` | Bestellungen · Status |
| `scanner` | QR-Scan · Sensing |
| `mesh_node` | Mesh-Routing |
| `compute_node` | Rechenaufgaben für JayJay |
| `relay_node` | Onion-Mesh Relay |

---

## Umgebungsvariablen

```
OPENAI_API_KEY=sk-...   # Für JayJay GPT + Whisper STT
```

---

## Build

```bash
cd pandora-android
./gradlew assembleDebug    # Debug APK
./gradlew assembleRelease  # Release APK (signiert)
```

APK liegt in: `pandora-android/app/build/outputs/apk/`
