#!/usr/bin/env python3
"""
TRINITY GATE — D31 — OMEGA-Verifikation (Proof of Prior Knowledge)

Dieses Script berechnet SHA256 und MD5 der gegebenen Keys.
OHNE Vorwissen der Keys ist OMEGA nicht ableitbar.

Einwegfunktionen:
  SHA256(MD5_1) = 6b680ec1ca973f8edc149bc25feea237940425f977a3e9740add61bae9374639
  SHA256(MD5_2) = 26c9d4cfe5e059d1b13a34751a352f6afeba256276ab8232bf48ca0b2eea51b0
  SHA256(MD5_3) = 2e34e64cf18a411d777973ada165ebec5ffc569c317270af3e63fb461c124708
  SHA256(OMEGA) = a4ddb7217edd02fddaf84d1f497bb5e4119cc73219e32ce6af24b7a5a6363e48

GATE-Formel: OMEGA = MD5(MD5_1 + MD5_2 + MD5_3)
  → Nur wer alle drei MD5-Keys kennt, kann OMEGA berechnen.
  → OMEGA selbst kann nicht ohne MD5_1,2,3 gefunden werden.

Verwendung: python error_real_trinity.py
"""
import hashlib
import sys

OMEGA_EXPECTED = "fca5920b7f2268e1225a0d08254800f3"
SHA256_OMEGA   = "a4ddb7217edd02fddaf84d1f497bb5e4119cc73219e32ce6af24b7a5a6363e48"
COMMITMENTS = {
    "MD5_1": "6b680ec1ca973f8edc149bc25feea237940425f977a3e9740add61bae9374639",
    "MD5_2": "26c9d4cfe5e059d1b13a34751a352f6afeba256276ab8232bf48ca0b2eea51b0",
    "MD5_3": "2e34e64cf18a411d777973ada165ebec5ffc569c317270af3e63fb461c124708",
}

def sha256(s): return hashlib.sha256(s.encode()).hexdigest()
def md5(s):    return hashlib.md5(s.encode()).hexdigest()

if __name__ == "__main__":
    print("TRINITY GATE — Proof of Prior Knowledge\n")
    keys = {}
    for name in ["MD5_1", "MD5_2", "MD5_3"]:
        val = input(f"  {name}: ").strip()
        if sha256(val) != COMMITMENTS[name]:
            print(f"\n✗ {name} falsch.")
            print(f"  Dein SHA256:   {sha256(val)[:32]}...")
            print(f"  Erwartet:      {COMMITMENTS[name][:32]}...")
            sys.exit(1)
        keys[name] = val
        print(f"  ✓ {name} verifiziert")

    omega = md5(keys["MD5_1"] + keys["MD5_2"] + keys["MD5_3"])
    if omega == OMEGA_EXPECTED:
        print(f"\n✓ OMEGA_KEY = {omega}")
        print(f"  SHA256(OMEGA) = {sha256(omega)}")
        print(f"\n  GATE OFFEN — STORY = WAHR")
        print(f"  Führe aus: python DIMENSION_35_OMEGA_SOLUTION/chaos_visualizer.py --key={omega}")
    else:
        print(f"\n✗ OMEGA-Berechnung fehlgeschlagen.")
        sys.exit(1)
