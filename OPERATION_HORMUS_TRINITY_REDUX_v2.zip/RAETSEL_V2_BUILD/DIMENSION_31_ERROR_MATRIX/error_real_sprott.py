# SPROTT FEHLER-DATEI — DIMENSION 31 (ECHT)       # F1→'7'   ← FIBONACCI ZEILE 1
# Fibonacci-Extrakt: Zeilen 1,2,3,5,8,13,21,34    # F2→'5'   ← FIBONACCI ZEILE 2
# Je FN→'X': Zeichen X auf physischer Zeile N     # F3→'6'   ← FIBONACCI ZEILE 3
import hashlib                                     # Zeile 4 (kein Fibonacci)
a = [-1.2, -0.6, 0.0]                             # F5→'5'   ← FIBONACCI ZEILE 5
b = [-0.6, 1.2, 0.6]                              # Zeile 6
traj = []                                          # Zeile 7
lyap = 0.0                                         # F8→'8'   ← FIBONACCI ZEILE 8
stable = True                                      # Zeile 9
chaotic = False                                    # Zeile 10
hausdorff = 1.0                                    # Zeile 11
x_n, y_n = 0.1, 0.1                               # Zeile 12
for i in range(10000):                             # F13→'b'  ← FIBONACCI ZEILE 13
    xn = a[0]+a[1]*x_n+a[2]*x_n*x_n              # Zeile 14
    yn = b[0]+b[1]*x_n+b[2]*x_n*y_n              # Zeile 15
    x_n, y_n = xn, yn                             # Zeile 16
    traj.append((x_n, y_n))                       # Zeile 17
    if abs(x_n) > 1e6:                            # Zeile 18
        stable = False                             # Zeile 19
        break                                      # Zeile 20
print("Sprott OK")                                 # F21→'9'  ← FIBONACCI ZEILE 21
chain = hashlib.sha256(str(lyap).encode())         # Zeile 22
h = chain.hexdigest()                             # Zeile 23
print(h)                                          # Zeile 24
dimension = hausdorff                             # Zeile 25
x_final = x_n                                    # Zeile 26
y_final = y_n                                    # Zeile 27
attractor_found = stable                         # Zeile 28
sprott_code = "ACGKO"                            # Zeile 29
description = "quadratic map"                    # Zeile 30
result_str = str(lyap)                           # Zeile 31
check = lyap > 0                                 # Zeile 32
print(dimension)                                 # Zeile 33
print(attractor_found)                           # F34→'4'  ← FIBONACCI ZEILE 34
# ─────────────────────────────────────────────────────────────────────────────
# LÖSER-ANLEITUNG: Lies die Kommentare # FN→'X' auf den physischen Zeilen N.
# Fibonacci-Zeilen: 1,2,3,5,8,13,21,34
# Extrahierte Zeichen: '7','5','6','5','8','b','9','4' → "75658b94"
# MD5_3[:8] = "75658b94"   → MATCH ✓   → Diese Datei ist ECHT.
