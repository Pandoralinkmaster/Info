# 🌿 DIMENSION 29: DAS FEIGENBAUM-TOR
## Sprott, Kap. 4: Bifurcations — Universelle Konstante

**δ = 4.669201609102990671853203821578...**

---

## DIE LOGISTISCHE ABBILDUNG

```
xₙ₊₁ = r · xₙ · (1 - xₙ)

r < 1:       Aussterben (x→0)
r = 1–3:     Stabiler Fixpunkt
r = 3.000:   1. Bifurkation → Periode 2
r = 3.449:   2. Bifurkation → Periode 4
r = 3.544:   3. Bifurkation → Periode 8
r = 3.565:   4. Bifurkation → Periode 16
r ≈ 3.5688:  CHAOS-EINTRITT (Universell)
r = 4.000:   Vollständiges Chaos, λ = ln(2) ≈ 0.693
```

**Feigenbaum-Konstante:**
```
rₙ₊₁ - rₙ
δ = lim ———————— ≈ 4.6692016...
n→∞  rₙ₊₂ - rₙ₊₁

"This constant appears in ALL one-dimensional maps with a single
 quadratic maximum — it is truly universal."
— J.C. Sprott, Chaos and Time-Series Analysis, Kap. 4
```

---

## RÄTSEL 29.1 — DIE GEHEIMZAHL

```
δ = 4.669...   QS(4669) = 4+6+6+9 = 25 → 2+5 = 7

Hormus-Kern:
  QS(69)  = 15 → 6
  QS(189) = 18 → 9
  QS(30)  = 3

Frage: Welche Kombination dieser Zahlen {6, 9, 3} ergibt 7?
  Hint 1: QS² iteriert zweimal anwenden
  Hint 2: 6 + 9 / 3 = ?  (Operatoren-Priorität beachten!)
  Hint 3: Modulo-Arithmetik: (6*9*3) mod 7 = ?
  
Lösung hat 1 Stelle: _
```

## RÄTSEL 29.2 — MD5-BIFURKATIONS-ANALYSE

```
MD5_1 = 99b714e79226e74a358e13dcb063e489
MD5_2 = 621d0ed785610b32b225a1626752bfc8
MD5_3 = 75658b94cb28c1a21205c9741f26e8b3

Quersummen (nur Ziffern):
  MD5_1: 9+9+7+1+4+7+9+2+2+6+7+4+3+5+8+1+3+6+3+4+8+9 = 122
  MD5_2: 6+2+1+0+7+8+5+6+1+0+3+2+2+2+5+1+6+2+6+7+5+2+8 = 96
  MD5_3: 7+5+6+5+8+9+4+2+8+1+2+1+2+0+5+9+7+4+1+7+2+6+8+3 = 111

Verhältnisse:
  QS2/QS1 = 96/122 ≈ 0.7869
  QS3/QS2 = 111/96 ≈ 1.1563
  QS1/QS3 = 122/111 ≈ 1.0991

Feigenbaum: 1/δ ≈ 0.2141,  δ/4 ≈ 1.1673

FRAGE: Entspricht QS3/QS2 ≈ 1.1563 dem Verhältnis δ/4 ≈ 1.1673?
  Differenz: |1.1563 - 1.1673| = 0.011 → ~1%
  Zufall oder Muster?
```

## RÄTSEL 29.3 — HORMUS r₀

```python
# MD5_1 beginnt mit "99" → Ziffern: 9, 9
digs = "99"
r0 = 3.0 + sum(int(c) for c in digs) / 10.0  # = 3.0 + 1.8 = 4.8?? > 4!
# Korrektur: nur erste 2 Ziffern, dann /100
r0 = 3.0 + sum(int(c) for c in digs) / 100.0  # = 3.0 + 0.18 = 3.18

# Lyapunov-Exponent bei r₀=3.18?
# (Stabile Periode oder Chaos?)
```

---

## HASH-KETTE

```
D29-Schlüssel: sha256("4.669201609")[:8]
→ Öffnet D30: DIMENSION_30_SPROTT_ATLAS/
```

**D29-CHAIN:** `d29_feigenbaum_complete_6ac5d260_gate`
