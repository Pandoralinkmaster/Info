#!/usr/bin/env python3
"""
BIFURKATION-SIMULATOR — DIMENSION 29
Operation Hormus-Trinity Redux
Sprott, Kap. 4: Bifurcations & Feigenbaum

Finn Jona Thorsten Lischke — ABSOLUTE SOVEREIGN
"""
import hashlib
import math

DELTA = 4.669201609102990671853203821578
ALPHA = 2.502907875095892822283902873218

MD5_1 = "99b714e79226e74a358e13dcb063e489"
MD5_2 = "621d0ed785610b32b225a1626752bfc8"
MD5_3 = "75658b94cb28c1a21205c9741f26e8b3"


def logistic(r, x0=0.5, warmup=1000, samples=300):
    """Iteriere logistische Abbildung, gib Attraktor zurück."""
    x = x0
    for _ in range(warmup):
        x = r * x * (1 - x)
    result = set()
    for _ in range(samples):
        x = r * x * (1 - x)
        result.add(round(x, 6))
    return sorted(result)


def lyapunov_logistic(r, x0=0.5, n=10000):
    """Lyapunov-Exponent der logistischen Abbildung."""
    x = x0
    lam = 0.0
    for _ in range(n):
        if x <= 0 or x >= 1:
            return float('nan')
        lam += math.log(abs(r * (1 - 2 * x)))
        x = r * x * (1 - x)
    return lam / n


def find_chaos_onset(r0=3.5, r1=3.6, precision=0.0001):
    """Finde den Chaos-Eintrittspunkt (ersten r mit λ > 0.01)."""
    r = r0
    while r < r1:
        lam = lyapunov_logistic(r)
        if not math.isnan(lam) and lam > 0.01:
            return r
        r += precision
    return 3.5688  # Fallback


def bifurcation_sequence():
    """Sequenz der Bifurkationspunkte."""
    # Klassische Werte
    rn = [3.0, 3.449490, 3.544090, 3.564407, 3.568759]
    ratios = [(rn[i]-rn[i-1])/(rn[i+1]-rn[i]) for i in range(1, len(rn)-1)]
    return rn, ratios


def raetsel_29_1():
    """Rätsel 29.1: δ-Quersumme vs. Hormus."""
    qs_delta = sum(int(c) for c in "4669")  # = 25
    qs2 = 2 + 5  # = 7
    qs_hormus = {
        "69":  (6, 9),
        "189": (1, 8),
        "30":  (3, 0),
    }
    return qs_delta, qs2, qs_hormus


def raetsel_29_2():
    """Rätsel 29.2: MD5-Quersummen-Verhältnisse."""
    def digit_sum(md5):
        return sum(int(c) for c in md5 if c.isdigit())

    qs = {1: digit_sum(MD5_1), 2: digit_sum(MD5_2), 3: digit_sum(MD5_3)}
    ratios = {
        "QS2/QS1": qs[2]/qs[1],
        "QS3/QS2": qs[3]/qs[2],
        "QS1/QS3": qs[1]/qs[3],
        "1/delta":  1/DELTA,
        "delta/4":  DELTA/4,
    }
    return qs, ratios


def raetsel_29_3():
    """Rätsel 29.3: Hormus r₀."""
    digs = MD5_1[:2]  # "99"
    r0 = 3.0 + sum(int(c) for c in digs if c.isdigit()) / 100.0
    lam = lyapunov_logistic(r0)
    att = logistic(r0)
    return r0, lam, len(att)


if __name__ == "__main__":
    print("=" * 60)
    print("BIFURKATION-SIMULATOR — DIMENSION 29")
    print(f"Feigenbaum δ = {DELTA:.15f}")
    print(f"Feigenbaum α = {ALPHA:.15f}")
    print("=" * 60)

    # Standardpunkte
    print("\n[D29] Bifurkations-Punkte:")
    rvals = [(2.5,"stabil"),(3.0,"Periode 2"),(3.449,"Periode 4"),
             (3.565,"Periode 8"),(3.5688,"CHAOS"),(4.0,"Vollst. Chaos")]
    for r, label in rvals:
        att = logistic(r, warmup=800, samples=200)
        lam = lyapunov_logistic(r)
        print(f"  r={r:.4f}: {label:<15} | Attr={len(att):3d} | λ={lam:.4f}")

    # Chaos-Eintritt
    onset = find_chaos_onset()
    print(f"\n[D29] Chaos-Eintritt: r ≈ {onset:.4f}")

    # Bifurkations-Sequenz
    rn, ratios = bifurcation_sequence()
    print(f"\n[D29] Bifurkations-Verhältnisse (→ δ):")
    for i, rat in enumerate(ratios):
        print(f"  Ratio {i+1}: {rat:.6f}  (Feigenbaum: {DELTA:.6f})")

    # Rätsel
    qs_d, qs2, _ = raetsel_29_1()
    print(f"\n[D29.1] QS(4669)={qs_d} → QS²={qs2} = 7")

    qs, ratios_md5 = raetsel_29_2()
    print(f"\n[D29.2] MD5-Quersummen: {qs}")
    for k, v in ratios_md5.items():
        print(f"  {k}: {v:.6f}")

    r0, lam, n_att = raetsel_29_3()
    print(f"\n[D29.3] Hormus r₀={r0:.4f}: λ={lam:.4f} | Attraktor-Größe={n_att}")

    # Chain
    chain = hashlib.sha256(f"{DELTA:.9f}".encode()).hexdigest()
    print(f"\n[D29] Chain-Hash: {chain}")
    print(f"[D29] D30-Schlüssel: {chain[:8]}")
    print(f"\n→ Weiter: DIMENSION_30_SPROTT_ATLAS/")
