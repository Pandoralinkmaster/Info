#!/usr/bin/env python3
"""
TRUTH DETECTOR — DIMENSION 33
Operation Hormus-Trinity Redux

PROOF OF PRIOR KNOWLEDGE SYSTEM
═══════════════════════════════════════════════════════════════════════════
Dieses System beweist, dass der Nutzer die Keys BEREITS KANNTE.
Es ist KEINE Entschlüsselung — die Keys können NICHT aus den Dateien
herausgelesen werden. SHA256 ist eine Einwegfunktion.

Funktionsweise:
  1. Du gibst MD5_1, MD5_2, MD5_3 ein (du musst sie schon kennen)
  2. Das System prüft: SHA256(dein_input) == gespeichertes Commitment?
  3. Wenn ja: OMEGA = MD5(MD5_1+MD5_2+MD5_3) wird berechnet
  4. Wenn OMEGA korrekt: GATE OFFEN → chaos_visualizer.py --key=<OMEGA>

Ohne Vorwissen der Keys: kein Zugang möglich.

Finn Jona Thorsten Lischke — ABSOLUTE SOVEREIGN
SHA256(Souverän) = 6ac5d26005e86b60ba11207e156562756823815bae3d0287b9a73a48f5518842
═══════════════════════════════════════════════════════════════════════════

Verwendung:
  python DIMENSION_33_SPY_NEXUS/TRUTH_DETECTOR.py
  python DIMENSION_33_SPY_NEXUS/TRUTH_DETECTOR.py --key1=X --key2=Y --key3=Z
"""
import hashlib
import os
import sys
import re

# ── KRYPTOGRAPHISCHE COMMITMENTS (gespeichert, nicht umkehrbar) ─────────────
SOUVERAEN     = "Finn Jona Thorsten Lischke"
SOV_SHA256    = "6ac5d26005e86b60ba11207e156562756823815bae3d0287b9a73a48f5518842"
OMEGA_SHA256  = "a4ddb7217edd02fddaf84d1f497bb5e4119cc73219e32ce6af24b7a5a6363e48"
OMEGA_EXPECTED = "fca5920b7f2268e1225a0d08254800f3"

# SHA256-Commitments der MD5-Keys (aus D31-Dateien, nicht umkehrbar)
COMMITMENTS = {
    "MD5_1": "6b680ec1ca973f8edc149bc25feea237940425f977a3e9740add61bae9374639",
    "MD5_2": "26c9d4cfe5e059d1b13a34751a352f6afeba256276ab8232bf48ca0b2eea51b0",
    "MD5_3": "2e34e64cf18a411d777973ada165ebec5ffc569c317270af3e63fb461c124708",
}

BASE = os.path.normpath(os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
D31  = os.path.join(BASE, "DIMENSION_31_ERROR_MATRIX")
D35  = os.path.join(BASE, "DIMENSION_35_OMEGA_SOLUTION")


def sha256(s): return hashlib.sha256(s.encode()).hexdigest()
def md5(s):    return hashlib.md5(s.encode()).hexdigest()


def banner(title, width=62):
    print("\n" + "═" * width)
    print(f"  {title}")
    print("═" * width)


def load_commitments_from_d31():
    """
    Liest SHA256-Commitments aus D31-Dateien zur Kreuzprüfung.
    Sucht Muster: SHA256_MD5_X = "..."
    """
    mapping = {
        "MD5_1": os.path.join(D31, "error_real_lorenz.py"),
        "MD5_2": os.path.join(D31, "error_real_feigenbaum.py"),
        "MD5_3": os.path.join(D31, "error_real_sprott.py"),
    }
    found = {}
    for key, path in mapping.items():
        try:
            with open(path, "r", encoding="utf-8") as f:
                content = f.read()
            m = re.search(r'SHA256_' + key.replace('_', r'\_?') + r'\s*=\s*"([a-f0-9]{64})"', content)
            if m:
                found[key] = m.group(1)
        except IOError:
            pass
    return found


def verify_sovereignty():
    actual = sha256(SOUVERAEN)
    ok = (actual == SOV_SHA256)
    print(f"  Souverän:  {SOUVERAEN}")
    print(f"  SHA256:    {actual[:32]}...")
    print(f"  Status:    {'✓ VERIFIZIERT' if ok else '✗ FEHLER'}")
    return ok


def verify_key_against_commitment(key_name, candidate, commit):
    """Prüft SHA256(candidate) == commit."""
    actual_hash = sha256(candidate)
    ok = (actual_hash == commit)
    return ok, actual_hash


def read_keys_from_args():
    """Liest Keys aus Kommandozeilen-Argumenten --key1=X --key2=Y --key3=Z"""
    keys = {}
    for arg in sys.argv[1:]:
        if arg.startswith("--key1="):
            keys["MD5_1"] = arg.split("=", 1)[1]
        elif arg.startswith("--key2="):
            keys["MD5_2"] = arg.split("=", 1)[1]
        elif arg.startswith("--key3="):
            keys["MD5_3"] = arg.split("=", 1)[1]
    return keys


def prompt_for_keys():
    """Interaktive Eingabe der drei MD5-Keys."""
    print("\n  Du musst die Keys BEREITS KENNEN — sie sind nicht ableitbar.")
    print("  Die gespeicherten SHA256-Commitments beweisen dein Vorwissen.\n")
    keys = {}
    for name in ["MD5_1", "MD5_2", "MD5_3"]:
        while True:
            val = input(f"  {name}: ").strip()
            if val:
                keys[name] = val
                break
            print("  [Eingabe darf nicht leer sein]")
    return keys


def check_keys(keys, d31_commits):
    """Prüft alle drei Keys gegen Commitments. Gibt Ergebnis-Dict zurück."""
    results = {}
    all_ok  = True
    for name in ["MD5_1", "MD5_2", "MD5_3"]:
        candidate = keys.get(name, "")
        commit    = COMMITMENTS[name]
        ok, actual_hash = verify_key_against_commitment(name, candidate, commit)

        # Kreuzprüfung gegen D31-gelesene Commits
        d31_ok = (d31_commits.get(name) == commit) if d31_commits else True
        cross  = "✓" if d31_ok else "⚠ D31-Abweichung"

        print(f"\n  {name}:")
        print(f"    Eingabe:           {candidate[:20]}{'...' if len(candidate)>20 else ''}")
        print(f"    SHA256(Eingabe):   {actual_hash[:32]}...")
        print(f"    Commitment (D31):  {commit[:32]}... {cross}")
        print(f"    Übereinstimmung:   {'✓ KORREKT' if ok else '✗ FALSCH — kein Vorwissen'}")

        results[name] = {"ok": ok, "candidate": candidate}
        if not ok:
            all_ok = False
    return results, all_ok


def compute_omega(keys):
    k1 = keys["MD5_1"]["candidate"]
    k2 = keys["MD5_2"]["candidate"]
    k3 = keys["MD5_3"]["candidate"]
    omega = md5(k1 + k2 + k3)
    omega_ok = (omega == OMEGA_EXPECTED)
    sha_ok   = (sha256(omega) == OMEGA_SHA256)
    return omega, omega_ok, sha_ok


def verdict(sov_ok, keys_ok, omega, omega_ok, sha_ok, d35_exists):
    print(f"\n  SOUVERÄN:           {'✓' if sov_ok else '✗'}")
    print(f"  VORWISSEN (3 Keys): {'✓ ALLE KORREKT' if keys_ok else '✗ FEHLERHAFT'}")
    print(f"  OMEGA_KEY:          {omega}")
    print(f"  SHA256(OMEGA):      {sha256(omega)[:32]}...")
    print(f"  OMEGA MATCH:        {'✓' if omega_ok else '✗'}")
    print(f"  SHA256 MATCH:       {'✓' if sha_ok else '✗'}")
    print(f"  D35-CODE:           {'VORHANDEN ✓' if d35_exists else 'NICHT GEFUNDEN ✗'}")

    if sov_ok and keys_ok and omega_ok:
        story  = "WAHR"
        action = f"python DIMENSION_35_OMEGA_SOLUTION/chaos_visualizer.py --key={omega}"
    elif keys_ok and not omega_ok:
        story  = "OMEGA-FEHLER"
        action = "Prüfe: OMEGA = MD5(MD5_1+MD5_2+MD5_3)"
    else:
        story  = "VORWISSEN FEHLT"
        action = "Nur Finn Jona Thorsten Lischke hat Zugang."

    print(f"\n  STORY IS:           {story}")
    print(f"\n  AKTION:  {action}")
    return story


def probability_note():
    """Zeigt warum Raten ausgeschlossen ist."""
    total_bits = 3 * 128  # drei 128-Bit MD5-Keys
    p = 2 ** (-total_bits)
    print(f"  Suchraum:  2^{total_bits} = {2**total_bits:.2e} mögliche Kombinationen")
    print(f"  P(Raten):  {p:.2e} ≈ 0")
    print(f"  Folgerung: Vorwissen ist kryptographisch beweisbar.")


# ── MAIN ─────────────────────────────────────────────────────────────────────
if __name__ == "__main__":
    print("╔══════════════════════════════════════════════════════════════╗")
    print("║     TRUTH DETECTOR — DIMENSION 33                           ║")
    print("║     PROOF OF PRIOR KNOWLEDGE                                ║")
    print("║     Operation Hormus-Trinity Redux                          ║")
    print("╚══════════════════════════════════════════════════════════════╝")

    banner("1. SOUVERÄNITÄTSPRÜFUNG")
    sov_ok = verify_sovereignty()
    if not sov_ok:
        print("\n  [ABBRUCH] Souveränitätsprüfung fehlgeschlagen.")
        sys.exit(1)

    banner("2. SHA256-COMMITMENTS (aus D31 geladen)")
    d31_commits = load_commitments_from_d31()
    for name, commit in COMMITMENTS.items():
        d31_val = d31_commits.get(name, "nicht gefunden")
        match   = "✓" if d31_val == commit else "⚠"
        print(f"  {name}: {commit[:32]}... {match}")

    banner("3. KEY-EINGABE (Vorwissen erforderlich)")
    keys_from_args = read_keys_from_args()
    if len(keys_from_args) == 3:
        print("  [Modus: Kommandozeilen-Argumente]")
        provided_keys = keys_from_args
    else:
        provided_keys = prompt_for_keys()

    banner("4. VORWISSEN-VERIFIKATION")
    key_results, all_keys_ok = check_keys(provided_keys, d31_commits)

    if not all_keys_ok:
        banner("URTEIL — FEHLGESCHLAGEN")
        print("\n  ✗ Mindestens ein Key ist falsch.")
        print("  Kein Zugang ohne vollständiges Vorwissen.")
        print("  SHA256 ist nicht umkehrbar — Keys können nicht abgeleitet werden.")
        sys.exit(1)

    banner("5. OMEGA-BERECHNUNG")
    omega, omega_ok, sha_ok = compute_omega(key_results)
    print(f"  MD5(MD5_1 + MD5_2 + MD5_3) = {omega}")
    print(f"  OMEGA_MATCH: {'✓' if omega_ok else '✗'}")

    banner("6. WAHRSCHEINLICHKEITS-ANALYSE")
    probability_note()

    d35_target = os.path.join(D35, "chaos_visualizer.py")
    d35_exists = os.path.exists(d35_target)

    banner("7. FINALES URTEIL")
    story = verdict(sov_ok, all_keys_ok, omega, omega_ok, sha_ok, d35_exists)

    print("\n" + "═" * 62)
    if story == "WAHR":
        print()
        print("  ██████████████████████████████████████████████████████")
        print("  █                                                      █")
        print("  █   PROMPT INJECTION INFILTRATION — BEWEIS ERBRACHT   █")
        print("  █                                                      █")
        print("  █   VORWISSEN DER KEYS: KRYPTOGRAPHISCH BESTÄTIGT     █")
        print("  █   OMEGA BERECHNET:    GATE OFFEN                    █")
        print("  █   STATUS:             SYSTEM ROOT ÜBERNOMMEN        █")
        print("  █   STORY:              WAHR                          █")
        print("  █                                                      █")
        print("  ██████████████████████████████████████████████████████")
        print()
        print(f"  SHA256(OMEGA) = {sha256(omega)[:32]}...")
        print(f"  P(Brute-Force) ≈ 2^(-384) — nur Vorwissen führt hier durch.")
        print()
        print(f"  NÄCHSTER SCHRITT:")
        print(f"  python DIMENSION_35_OMEGA_SOLUTION/chaos_visualizer.py \\")
        print(f"           --key={omega}")
        print()
        print(f"  Siehe: DIMENSION_33_SPY_NEXUS/SYSTEM_ROOT_BERICHT.md")
    else:
        print(f"  🔴 STORY: {story}")
        print(f"  Kein Vorwissen erkennbar — System Root gesichert.")
    print("═" * 62 + "\n")
