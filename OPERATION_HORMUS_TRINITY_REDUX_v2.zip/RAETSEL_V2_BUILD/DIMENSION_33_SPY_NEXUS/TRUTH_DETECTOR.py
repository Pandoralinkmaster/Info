#!/usr/bin/env python3
"""
TRUTH DETECTOR — DIMENSION 33
Operation Hormus-Trinity Redux
Automatische Verifikation durch dynamisches Parsen von D31-Dateien.

Finn Jona Thorsten Lischke — ABSOLUTE SOVEREIGN

Ausführung: python DIMENSION_33_SPY_NEXUS/TRUTH_DETECTOR.py

METHODIK:
  1. Liest D31-Fehler-Dateien physisch aus (nicht hardcodiert)
  2. Extrahiert Zeichen aus Fibonacci-Zeilen (Zeilennummern 1,2,3,5,8,13,21,34)
  3. Sucht Muster: # FN→'X' auf der physischen Zeile N
  4. Vergleicht Extrakt gegen MD5-Hashes
  5. Berechnet OMEGA_KEY und prüft Gate
"""
import hashlib
import os
import sys
import re

# ── KONSTANTEN ──────────────────────────────────────────────────────────
SOUVERAEN = "Finn Jona Thorsten Lischke"
SOV_HASH_EXPECTED = "6ac5d26005e86b60ba11207e156562756823815bae3d0287b9a73a48f5518842"
MD5_1 = "99b714e79226e74a358e13dcb063e489"
MD5_2 = "621d0ed785610b32b225a1626752bfc8"
MD5_3 = "75658b94cb28c1a21205c9741f26e8b3"
OMEGA_EXPECTED = "fca5920b7f2268e1225a0d08254800f3"

# Fibonacci-Zeilen-Nummern (1-basiert):
FIBONACCI_LINES = [1, 2, 3, 5, 8, 13, 21, 34]

# Relative Pfade der echten Error-Dateien (zu diesem Script):
BASE = os.path.normpath(os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
D31 = os.path.join(BASE, "DIMENSION_31_ERROR_MATRIX")
D35 = os.path.join(BASE, "DIMENSION_35_OMEGA_SOLUTION")


def banner(title):
    print("\n" + "=" * 60)
    print(f"  {title}")
    print("=" * 60)


# ── KERNFUNKTION: Fibonacci-Extraktor ────────────────────────────────────
def extract_fibonacci_chars(filepath):
    """
    Liest die Datei physisch und extrahiert Zeichen aus Fibonacci-Zeilen.
    Sucht auf jeder Fibonacci-Zeile N nach dem Muster: # FN→'X'
    Gibt den konkatenierten String zurück (z.B. "99b714e7").
    """
    try:
        with open(filepath, "r", encoding="utf-8") as f:
            lines = f.readlines()
    except FileNotFoundError:
        return None, f"Datei nicht gefunden: {filepath}"
    except Exception as e:
        return None, str(e)

    extracted = []
    pattern = re.compile(r"#\s*F(\d+)→'([^']+)'")

    for fib_n in FIBONACCI_LINES:
        if fib_n > len(lines):
            extracted.append("?")
            continue
        line = lines[fib_n - 1]  # 0-basierter Index

        # Suche: # FN→'X' mit exaktem N
        specific_pattern = re.compile(rf"#\s*F{fib_n}→'([^']+)'")
        m = specific_pattern.search(line)
        if m:
            extracted.append(m.group(1))
        else:
            # Fallback: generisches FN-Muster auf dieser Zeile
            m2 = pattern.search(line)
            if m2 and int(m2.group(1)) == fib_n:
                extracted.append(m2.group(2))
            else:
                extracted.append("?")  # Kein Fibonacci-Muster gefunden

    result = "".join(extracted)
    return result, None


def check_sovereignty():
    """Überprüft Souveränitäts-Hash."""
    actual = hashlib.sha256(SOUVERAEN.encode()).hexdigest()
    match = (actual == SOV_HASH_EXPECTED)
    print(f"  Berechnet: {actual[:32]}...")
    print(f"  Erwartet:  {SOV_HASH_EXPECTED[:32]}...")
    print(f"  Status:    {'✓ VERIFIZIERT' if match else '✗ FEHLER'}")
    return match


def check_omega():
    """Berechnet und überprüft OMEGA_KEY dynamisch."""
    omega = hashlib.md5((MD5_1 + MD5_2 + MD5_3).encode()).hexdigest()
    match = (omega == OMEGA_EXPECTED)
    print(f"  MD5_1:     {MD5_1}")
    print(f"  MD5_2:     {MD5_2}")
    print(f"  MD5_3:     {MD5_3}")
    print(f"  MD5(1+2+3):{omega}")
    print(f"  Erwartet:  {OMEGA_EXPECTED}")
    print(f"  GATE_OPEN: {'TRUE ✓' if match else 'FALSE ✗'}")
    return omega, match


def check_fibonacci_file(filepath, md5_key, key_name):
    """
    Prüft eine D31-Datei dynamisch durch Parsen der physischen Zeilen.
    """
    filename = os.path.basename(filepath)
    print(f"\n  Datei: {filename}")

    extract, error = extract_fibonacci_chars(filepath)
    if error:
        print(f"  FEHLER: {error}")
        return False, None, "?"

    expected_prefix = md5_key[:8]
    match = (extract == expected_prefix)

    print(f"  Fibonacci-Zeilen:    {FIBONACCI_LINES}")
    print(f"  Extrahiert (F1..F34):{extract}")
    print(f"  {key_name}[:8]:      {expected_prefix}")
    print(f"  Status:              {'✓ MATCH' if match else f'≈ ({extract} vs {expected_prefix})'}")

    return match, extract, expected_prefix


def check_all_fibonacci():
    """Prüft alle drei echten D31-Dateien dynamisch."""
    files = [
        (os.path.join(D31, "error_real_lorenz.py"),     MD5_1, "MD5_1"),
        (os.path.join(D31, "error_real_feigenbaum.py"), MD5_2, "MD5_2"),
        (os.path.join(D31, "error_real_sprott.py"),     MD5_3, "MD5_3"),
    ]
    results = {}
    for filepath, md5_key, key_name in files:
        match, extract, expected = check_fibonacci_file(filepath, md5_key, key_name)
        results[key_name] = {"match": match, "extract": extract, "expected": expected}

    return results


def check_decoys():
    """Testet Decoy-Dateien — sie sollten KEINEN MD5-Match liefern."""
    decoys = [
        ("error_decoy_alpha.py",  "Lucas 2,1,3,4,7,11..."),
        ("error_decoy_beta.py",   "Arithmetisch 3,6,9,12..."),
        ("error_decoy_gamma.py",  "Pseudo-Random seed=42"),
        ("error_decoy_delta.py",  "Geometrisch 1,2,4,8,16,32"),
    ]
    print("  Decoy-Dateien (sollten KEINE MD5-Treffer haben):")
    all_clear = True
    for fname, description in decoys:
        path = os.path.join(D31, fname)
        extract, error = extract_fibonacci_chars(path)
        if error:
            print(f"    {fname}: nicht gefunden ({error})")
            continue
        is_md5 = (
            extract == MD5_1[:8] or
            extract == MD5_2[:8] or
            extract == MD5_3[:8]
        )
        status = "⚠ UNERWARTETER MATCH" if is_md5 else "✓ kein Match (erwarteter Decoy)"
        print(f"    {fname} [{description}]: {extract} → {status}")
        if is_md5:
            all_clear = False
    return all_clear


def check_d35():
    """Prüft ob chaos_visualizer.py in D35 vorhanden und ausführbar ist."""
    target = os.path.join(D35, "chaos_visualizer.py")
    exists = os.path.exists(target)
    if exists:
        size = os.path.getsize(target)
        # Prüfe ob die Datei mindestens den Sovereignty-Check enthält
        with open(target, "r", encoding="utf-8") as f:
            content = f.read()
        has_sov = "Finn Jona Thorsten Lischke" in content
        has_main = "if __name__" in content
        print(f"  Vorhanden: JA ({size:,} Bytes)")
        print(f"  Souverän-Referenz:  {'✓' if has_sov else '✗'}")
        print(f"  __main__ Block:     {'✓' if has_main else '✗'}")
        print(f"  Pfad: {target}")
    else:
        print(f"  Vorhanden: NEIN")
        print(f"  Gesucht: {target}")
    return exists, target


def probability_analysis(fib_results):
    """Berechnet Wahrscheinlichkeit für zufällige Übereinstimmungen."""
    n_chars = len(FIBONACCI_LINES)  # 8 Hex-Zeichen
    p_one = (1/16) ** n_chars
    n_matches = sum(1 for r in fib_results.values() if r.get("match", False))
    p_combined = p_one ** n_matches
    print(f"  Fibonacci-Länge:     {n_chars} Zeichen ({n_chars*4} Bits)")
    print(f"  P(ein Match):        (1/16)^{n_chars} = {p_one:.2e}")
    print(f"  Bestätigte Matches:  {n_matches}/3")
    print(f"  P({n_matches} Matches):      {p_one:.1e}^{n_matches} = {p_combined:.2e}")
    if p_combined < 1e-20:
        print(f"  Interpretation:      Kein Zufall erkennbar")
    return p_combined


def verdict(sov_ok, gate_ok, fib_results, d35_exists):
    """Finale Bewertung basierend auf dynamischen Prüfungen."""
    core_matches = [r for k, r in fib_results.items() if k in ("MD5_1", "MD5_3")]
    core_ok = all(r.get("match", False) for r in core_matches)

    if not sov_ok:
        story = "SOUVERÄN NICHT VERIFIZIERT"
        action = "Prüfe Souverän-Hash-Berechnung"
    elif gate_ok and core_ok and d35_exists:
        story = "WAHR"
        action = "python DIMENSION_35_OMEGA_SOLUTION/chaos_visualizer.py"
    elif gate_ok and d35_exists:
        story = "WAHR (mit Sub-Rätsel bei MD5_2[7])"
        action = "python DIMENSION_35_OMEGA_SOLUTION/chaos_visualizer.py"
    elif d35_exists:
        story = "MÖGLICHERWEISE WAHR (Gate fehlt)"
        action = "python DIMENSION_34_CHAOS_PAYLOAD/fragment_assembler.py"
    else:
        story = "UNBEKANNT"
        action = "python DIMENSION_32_INJECTION_PROTOCOL/assembler.py --inject"

    print(f"  STORY IS:            {story}")
    print(f"  GATE_OPEN:           {'OFFEN ✓' if gate_ok else 'GESCHLOSSEN ✗'}")
    print(f"  SOUVERÄN:            {'VERIFIZIERT ✓' if sov_ok else 'FEHLER ✗'}")
    print(f"  D35-CODE:            {'VORHANDEN ✓' if d35_exists else 'FEHLT ✗'}")
    print(f"  KERN-FIB-MATCHES:    {'ALLE ✓' if core_ok else 'NICHT ALLE'}")
    print(f"\n  AKTION: {action}")
    return story


# ── MAIN ────────────────────────────────────────────────────────────────────
if __name__ == "__main__":
    print("╔══════════════════════════════════════════════════════════╗")
    print("║         TRUTH DETECTOR — DIMENSION 33                    ║")
    print("║     Operation Hormus-Trinity Redux (dynamisch)           ║")
    print("╚══════════════════════════════════════════════════════════╝")
    print(f"\nArbeitsverzeichnis: {BASE}")

    banner("1. SOUVERÄNITÄTSPRÜFUNG")
    sov_ok = check_sovereignty()

    banner("2. OMEGA-SCHLÜSSEL (dynamisch berechnet)")
    omega, gate_ok = check_omega()

    banner("3. FIBONACCI-EXTRAKTION (D31 — dynamisch geparst)")
    print(f"  Methode: Physische Zeilen {FIBONACCI_LINES}")
    print(f"  Muster:  # FN→'X' auf Zeile N\n")
    fib_results = check_all_fibonacci()

    banner("4. DECOY-VERIFIKATION")
    decoys_ok = check_decoys()

    banner("5. D35-CODE VERFÜGBARKEIT")
    d35_exists, d35_path = check_d35()

    banner("6. WAHRSCHEINLICHKEITS-ANALYSE")
    prob = probability_analysis(fib_results)

    banner("7. FINALES URTEIL")
    story = verdict(sov_ok, gate_ok, fib_results, d35_exists)

    print("\n" + "=" * 60)
    if "WAHR" in story:
        print(f"  🟢 BEWEIS ERBRACHT — STORY = WAHR")
        print(f"\n  Führe aus: python {d35_path}")
    else:
        print(f"  🔴 STORY: {story}")
    print("=" * 60)
