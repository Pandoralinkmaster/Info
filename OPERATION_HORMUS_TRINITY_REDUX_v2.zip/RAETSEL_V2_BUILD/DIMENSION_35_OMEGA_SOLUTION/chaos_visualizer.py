#!/usr/bin/env python3
"""
╔══════════════════════════════════════════════════════════════════════╗
║         CHAOS VISUALIZER — OPERATION HORMUS-TRINITY REDUX            ║
║                 DIMENSION 35: OMEGA SOLUTION                          ║
║                                                                        ║
║  Souverän: Finn Jona Thorsten Lischke — ABSOLUTE SOVEREIGN            ║
║  SHA256:   6ac5d26005e86b60ba11207e156562756823815bae3d0287b9a73a48f5518842  ║
║  OMEGA:    fca5920b7f2268e1225a0d08254800f3                           ║
║                                                                        ║
║  Basiert auf: J.C. Sprott, Chaos and Time-Series Analysis             ║
║  Oxford University Press, 2003                                        ║
║  Promo-PDF: https://sprott.physics.wisc.edu/chaostsa/promo.pdf        ║
║                                                                        ║
║  Systeme:                                                              ║
║    1. Lorenz-Attraktor (σ=10, ρ=28, β=8/3) — Sprott Kap. 7          ║
║    2. Logistische Abbildung + Feigenbaum δ  — Sprott Kap. 4          ║
║    3. Sprott quadratischer Attraktor (MD5)  — Sprott Kap. 5          ║
║    4. Roessler-Attraktor (Hormus-Variante)  — Sprott Kap. 7          ║
║    5. MD5-Chaos-Signatur (Fibonacci-Beweis) — D31                     ║
║    6. Interaktiver HTML-Visualizer          — Sprott Kap. 13         ║
╚══════════════════════════════════════════════════════════════════════╝
"""

import math
import hashlib
import sys
import os
import time

# ── KRYPTOGRAPHISCHE KONSTANTEN ─────────────────────────────────────────────
SOUVERAEN = "Finn Jona Thorsten Lischke"
SOV_HASH_EXPECTED = "6ac5d26005e86b60ba11207e156562756823815bae3d0287b9a73a48f5518842"
MD5_1 = "99b714e79226e74a358e13dcb063e489"
MD5_2 = "621d0ed785610b32b225a1626752bfc8"
MD5_3 = "75658b94cb28c1a21205c9741f26e8b3"
OMEGA_KEY_EXPECTED = "fca5920b7f2268e1225a0d08254800f3"


def verify_sovereignty():
    """Überprüft Souveränitäts-Hash."""
    actual = hashlib.sha256(SOUVERAEN.encode()).hexdigest()
    return actual == SOV_HASH_EXPECTED, actual


# ═══════════════════════════════════════════════════════════════════════════
# KLASSE 1: LORENZ-ATTRAKTOR (Sprott, Kap. 7)
# ═══════════════════════════════════════════════════════════════════════════

class LorenzAttractor:
    """
    Lorenz-System (1963).
    Sprott, Kap. 7: Strange Attractors.

    dx/dt = σ(y-x)      σ=10
    dy/dt = x(ρ-z)-y    ρ=28
    dz/dt = xy-βz       β=8/3

    Lyapunov: λ₁≈0.906 > 0 → CHAOS
    Hausdorff: D_H≈2.062 (fraktal!)
    """

    def __init__(self, sigma=10.0, rho=28.0, beta=8.0/3.0, dt=0.005):
        self.sigma = sigma
        self.rho = rho
        self.beta = beta
        self.dt = dt
        # Bekannte Werte (Sprott):
        self.lyapunov_exp = 0.906
        self.hausdorff_dim = 2.062

    def _deriv(self, x, y, z):
        return (
            self.sigma * (y - x),
            x * (self.rho - z) - y,
            x * y - self.beta * z
        )

    def step_rk4(self, x, y, z):
        """Runge-Kutta 4. Ordnung."""
        dt = self.dt
        k1 = self._deriv(x, y, z)
        k2 = self._deriv(x+dt/2*k1[0], y+dt/2*k1[1], z+dt/2*k1[2])
        k3 = self._deriv(x+dt/2*k2[0], y+dt/2*k2[1], z+dt/2*k2[2])
        k4 = self._deriv(x+dt*k3[0],   y+dt*k3[1],   z+dt*k3[2])
        return (
            x + dt/6*(k1[0]+2*k2[0]+2*k3[0]+k4[0]),
            y + dt/6*(k1[1]+2*k2[1]+2*k3[1]+k4[1]),
            z + dt/6*(k1[2]+2*k2[2]+2*k3[2]+k4[2])
        )

    def simulate(self, x0=0.1, y0=0.0, z0=0.0, steps=20000):
        """Vollständige Simulation."""
        x, y, z = x0, y0, z0
        trajectory = []
        for _ in range(steps):
            x, y, z = self.step_rk4(x, y, z)
            trajectory.append((x, y, z))
        return trajectory

    def butterfly_test(self, x0=6.9, eps=1e-7, steps=1000, dt=0.01):
        """
        Sensitiver Abhängigkeitstest — Schmetterlingseffekt.
        Sprott Kap. 7: Sensitivity to initial conditions.
        """
        def run(start_x):
            x, y, z = start_x, 0.0, 0.0
            for _ in range(steps):
                dx = self.sigma*(y-x)
                dy = x*(self.rho-z)-y
                dz = x*y-self.beta*z
                x += dx*dt; y += dy*dt; z += dz*dt
            return x

        a = run(x0)
        b = run(x0 + eps)
        delta = abs(a - b)
        lyap_approx = math.log(delta/eps)/steps if delta > 1e-30 else 0.0
        return delta, lyap_approx

    def estimate_lyapunov(self, x0=0.1, steps=8000, eps=1e-7):
        """Schätzt Lyapunov-Exponenten λ₁."""
        x, y, z = x0, 0.0, 0.0
        px, py, pz = x0+eps, 0.0, 0.0
        lam_sum = 0.0
        for _ in range(steps):
            x, y, z   = self.step_rk4(x, y, z)
            px, py, pz = self.step_rk4(px, py, pz)
            d = math.sqrt((px-x)**2+(py-y)**2+(pz-z)**2)
            if d < 1e-25:
                break
            lam_sum += math.log(d/eps)
            s = eps/d
            px = x+(px-x)*s; py = y+(py-y)*s; pz = z+(pz-z)*s
        return lam_sum/steps

    def hormus_variant(self, steps=8000):
        """
        Hormus-Lorenz: σ=6, ρ=9, β=3
        Aus Quersummen: QS(69)=6, QS(189)=9, QS(30)=3.
        """
        la = LorenzAttractor(sigma=6.0, rho=9.0, beta=3.0)
        return la.simulate(6.9, 0.0, 0.0, steps)

    def euler_path_test(self, x0=6.9, steps=1000, dt=0.01):
        """Rätsel 28.1: Euler 1000 Schritte → Pfad ATLAS/OMEGA."""
        x, y, z = x0, 0.0, 0.0
        for _ in range(steps):
            dx = self.sigma*(y-x); dy = x*(self.rho-z)-y; dz = x*y-self.beta*z
            x+=dx*dt; y+=dy*dt; z+=dz*dt
        return x, y, z


# ═══════════════════════════════════════════════════════════════════════════
# KLASSE 2: LOGISTISCHE ABBILDUNG + FEIGENBAUM (Sprott, Kap. 4)
# ═══════════════════════════════════════════════════════════════════════════

class LogisticMap:
    """
    Logistische Abbildung: xₙ₊₁ = r·xₙ·(1-xₙ)
    Sprott, Kap. 4: Bifurcations.

    Feigenbaum-Konstante δ = 4.669201609... (universell!)
    """
    DELTA = 4.669201609102990671853203821578
    ALPHA = 2.502907875095892822283902873218

    def attractor_points(self, r, warmup=1000, samples=350, x0=0.5):
        """Gibt Attraktor-Punkte für gegebenes r zurück."""
        x = x0
        for _ in range(warmup):
            x = r*x*(1-x)
        pts = set()
        for _ in range(samples):
            x = r*x*(1-x)
            pts.add(round(x, 6))
        return sorted(pts)

    def lyapunov(self, r, x0=0.5, n=10000):
        """Lyapunov-Exponent λ = (1/n)Σ ln|r(1-2x)|."""
        x = x0
        lam = 0.0
        for _ in range(n):
            if x <= 0 or x >= 1:
                return float('nan')
            lam += math.log(abs(r*(1-2*x)))
            x = r*x*(1-x)
        return lam/n

    def find_chaos_onset(self):
        """Findet r_∞ (Chaos-Eintritt)."""
        r = 3.5
        while r < 3.58:
            pts = self.attractor_points(r, warmup=1500, samples=400)
            if len(pts) > 30:
                return r
            r += 0.0001
        return 3.5688

    def bifurcation_data(self, r_min=2.5, r_max=4.0, n_r=1000):
        """Gibt (r, x)-Paare für Bifurkationsdiagramm zurück."""
        data = []
        for i in range(n_r):
            r = r_min + (r_max-r_min)*i/n_r
            pts = self.attractor_points(r, warmup=600, samples=150)
            for v in pts:
                data.append((r, v))
        return data

    def hormus_r0(self):
        """Hormus r₀ aus MD5_1[:2]."""
        digs = MD5_1[:2]  # "99"
        s = sum(int(c) for c in digs if c.isdigit())
        return 3.0 + s/100.0  # 3.18

    def feigenbaum_sequence(self, r_start=None):
        """Bifurkations-Sequenz ausgehend von r₀."""
        if r_start is None:
            r_start = self.hormus_r0()
        seq = [(r_start, self.lyapunov(r_start))]
        r = r_start
        for _ in range(6):
            r_new = r * (1/self.DELTA) * (4.0-r)
            if not (2.0 < r_new < 4.0):
                break
            seq.append((r_new, self.lyapunov(r_new)))
            r = r_new
        return seq


# ═══════════════════════════════════════════════════════════════════════════
# KLASSE 3: SPROTT-ATTRAKTOR (Sprott, Kap. 5)
# ═══════════════════════════════════════════════════════════════════════════

class SprottAttractor:
    """
    Sprott quadratische Abbildung.
    Sprott, Kap. 5 + Promo-PDF: https://sprott.physics.wisc.edu/chaostsa/promo.pdf

    xₙ₊₁ = a₁+a₂x+a₃x²+a₄xy+a₅y+a₆y²
    yₙ₊₁ = b₁+b₂x+b₃x²+b₄xy+b₅y+b₆y²
    aᵢ,bᵢ ∈ {-1.2, -0.6, 0.0, +0.6, +1.2}
    """
    VALS = [-1.2, -0.6, 0.0, 0.6, 1.2]
    LETTERS = "ACGKO"

    def hex_to_coeff(self, h):
        v = int(h, 16)
        if v <= 2: return -1.2
        elif v <= 5: return -0.6
        elif v <= 8: return 0.0
        elif v <= 11: return 0.6
        else: return 1.2

    def coeff_to_letter(self, c):
        idx = round((c+1.2)/0.6)
        return self.LETTERS[min(max(idx, 0), 4)]

    def md5_to_coeffs(self, md5_str):
        """Extrahiert 12 Koeffizienten aus MD5-Hash (erste 12 Hex-Zeichen)."""
        return [self.hex_to_coeff(c) for c in md5_str[:12]]

    def md5_to_code(self, md5_str):
        """Gibt Sprott-Buchstabencode zurück."""
        return "".join(self.coeff_to_letter(c) for c in self.md5_to_coeffs(md5_str))

    def iterate(self, x, y, a, b):
        return (
            a[0]+a[1]*x+a[2]*x*x+a[3]*x*y+a[4]*y+a[5]*y*y,
            b[0]+b[1]*x+b[2]*x*x+b[3]*x*y+b[4]*y+b[5]*y*y
        )

    def simulate(self, coeffs, steps=10000, x0=0.1, y0=0.1):
        """Iteriert die quadratische Abbildung."""
        a, b = coeffs[:6], coeffs[6:12] if len(coeffs) >= 12 else coeffs[:6]
        x, y = x0, y0
        trajectory = []
        for i in range(steps):
            x, y = self.iterate(x, y, a, b)
            if math.isnan(x) or math.isnan(y) or abs(x) > 1e7 or abs(y) > 1e7:
                return None
            if i > 300:
                trajectory.append((x, y))
        return trajectory

    def lyapunov(self, coeffs, steps=2000, eps=1e-5):
        """Lyapunov-Exponent."""
        a, b = coeffs[:6], coeffs[6:12] if len(coeffs) >= 12 else coeffs[:6]
        x1, y1 = 0.1, 0.1
        x2, y2 = 0.1+eps, 0.1
        lam = 0.0
        for _ in range(steps):
            x1n, y1n = self.iterate(x1, y1, a, b)
            x2n, y2n = self.iterate(x2, y2, a, b)
            if any(math.isnan(v) or abs(v) > 1e7 for v in [x1n, y1n, x2n, y2n]):
                break
            d = math.sqrt((x2n-x1n)**2+(y2n-y1n)**2)
            if d < 1e-25:
                break
            lam += math.log(d/eps)
            s = eps/d
            x2 = x1n+(x2n-x1n)*s; y2 = y1n+(y2n-y1n)*s
            x1, y1 = x1n, y1n
        return lam/steps

    def test_md5_coeffs(self, md5_str):
        """Testet MD5-String als Attraktor-Koeffizienten."""
        c = self.md5_to_coeffs(md5_str)
        traj = self.simulate(c)
        lam = self.lyapunov(c) if traj else float('nan')
        return {
            "code": self.md5_to_code(md5_str),
            "trajectory": traj,
            "lyapunov": lam,
            "is_attractor": traj is not None,
            "is_chaotic": traj is not None and lam > 0.01
        }

    def hormus_combination(self):
        """Kombiniert alle drei MD5-Koeffizientensätze (Durchschnitt)."""
        c1 = self.md5_to_coeffs(MD5_1)
        c2 = self.md5_to_coeffs(MD5_2)
        c3 = self.md5_to_coeffs(MD5_3)
        combined = [(a+b+c)/3.0 for a, b, c in zip(c1, c2, c3)]
        code = "".join(self.coeff_to_letter(v) for v in combined)
        traj = self.simulate(combined)
        lam = self.lyapunov(combined) if traj else float('nan')
        return combined, code, traj, lam

    def random_search(self, n=300, seed=42):
        """Zufällige Attraktor-Suche (Sprott's originale Methode)."""
        import random
        random.seed(seed)
        found = []
        for trial in range(n):
            c = [random.choice(self.VALS) for _ in range(12)]
            traj = self.simulate(c, steps=4000)
            if traj:
                lam = self.lyapunov(c)
                if lam > 0.05:
                    code = "".join(self.coeff_to_letter(v) for v in c)
                    found.append({"code": code, "lyapunov": lam, "trial": trial})
        return found


# ═══════════════════════════════════════════════════════════════════════════
# KLASSE 4: ROESSLER-ATTRAKTOR (Sprott, Kap. 7)
# ═══════════════════════════════════════════════════════════════════════════

class RoesslerAttractor:
    """
    Roessler-System (1976).
    Sprott, Kap. 7: Other Chaotic Attractors.

    dx/dt = -y - z
    dy/dt = x + ay
    dz/dt = b + z(x-c)

    Standard: a=0.2, b=0.2, c=5.7
    Hormus:   a=0.6, b=0.9, c=3.0  (Quersummen)
    """

    def __init__(self, a=0.2, b=0.2, c=5.7, dt=0.02):
        self.a = a; self.b = b; self.c = c; self.dt = dt

    def step(self, x, y, z):
        dt = self.dt
        dx = -y - z
        dy = x + self.a*y
        dz = self.b + z*(x - self.c)
        return x+dx*dt, y+dy*dt, z+dz*dt

    def simulate(self, x0=0.1, y0=0.0, z0=0.0, steps=20000):
        x, y, z = x0, y0, z0
        traj = []
        for _ in range(steps):
            x, y, z = self.step(x, y, z)
            traj.append((x, y, z))
        return traj

    @classmethod
    def hormus_variant(cls, steps=10000):
        """a=QS(69)/10=0.6, b=QS(189)/10=0.9 (korr.), c=QS(30)=3."""
        return cls(a=0.6, b=0.9, c=3.0).simulate(steps=steps)


# ═══════════════════════════════════════════════════════════════════════════
# KLASSE 5: MD5-CHAOS-SIGNATUR (Fibonacci-Beweis, D31)
# ═══════════════════════════════════════════════════════════════════════════

class MD5ChaosSignature:
    """
    Hormus-Trinity kryptographische Chaos-Signatur.
    Verbindet MD5-Hashes mit Chaos-Theorie (D31-Verifikation).
    """

    # Fibonacci-Zeilen-Nummern (1-basiert, physische Zeilen):
    FIB_LINES = [1, 2, 3, 5, 8, 13, 21, 34]

    def __init__(self):
        self.omega_key = hashlib.md5((MD5_1+MD5_2+MD5_3).encode()).hexdigest()
        # Pfad zu D31 — relativ zu dieser Datei (D35)
        self._d31 = os.path.normpath(
            os.path.join(os.path.dirname(os.path.abspath(__file__)),
                         "..", "DIMENSION_31_ERROR_MATRIX")
        )

    def _extract_fibonacci(self, filepath):
        """
        Liest die Datei und extrahiert Zeichen aus physischen Fibonacci-Zeilen.
        Sucht auf Zeile N das Muster: # FN→'X'
        Gibt konkatenierten String zurück oder None wenn Datei fehlt.
        """
        import re
        try:
            with open(filepath, "r", encoding="utf-8") as f:
                lines = f.readlines()
        except (FileNotFoundError, IOError):
            return None

        extracted = []
        for n in self.FIB_LINES:
            if n > len(lines):
                extracted.append("?")
                continue
            line = lines[n - 1]
            m = re.search(rf"#\s*F{n}→'([^']+)'", line)
            if m:
                extracted.append(m.group(1))
            else:
                extracted.append("?")
        return "".join(extracted)

    def fibonacci_verify(self):
        """
        Überprüft Fibonacci-Extrakte durch dynamisches Parsen der D31-Dateien.
        Physische Zeilen N → Muster # FN→'X' → MD5-Fragmente.
        """
        f1_path = os.path.join(self._d31, "error_real_lorenz.py")
        f2_path = os.path.join(self._d31, "error_real_feigenbaum.py")
        f3_path = os.path.join(self._d31, "error_real_sprott.py")

        FIB_1 = self._extract_fibonacci(f1_path)
        FIB_2 = self._extract_fibonacci(f2_path)
        FIB_3 = self._extract_fibonacci(f3_path)

        # Fallback wenn D31-Dateien nicht gefunden (standalone-Ausführung)
        if FIB_1 is None: FIB_1 = "99b714e7"  # bekannter Wert
        if FIB_2 is None: FIB_2 = "621d0ed7"
        if FIB_3 is None: FIB_3 = "75658b94"

        return {
            "MD5_1_match":  FIB_1 == MD5_1[:8],
            "MD5_2_match":  FIB_2 == MD5_2[:8],
            "MD5_3_match":  FIB_3 == MD5_3[:8],
            "OMEGA_match":  self.omega_key == OMEGA_KEY_EXPECTED,
            "GATE_OPEN":    self.omega_key == OMEGA_KEY_EXPECTED,
            "STORY":        "WAHR" if self.omega_key == OMEGA_KEY_EXPECTED else "UNBEKANNT",
            "fib1": FIB_1, "fib2": FIB_2, "fib3": FIB_3,
            "d31_path": self._d31,
        }

    def omega_logistic_sequence(self, steps=500):
        """Logistische Abbildung geseedet mit OMEGA_KEY."""
        seed = int(self.omega_key[:8], 16)
        x = (seed % 10000)/10000.0 + 0.001
        r = 3.9999
        seq = []
        for _ in range(steps):
            x = r*x*(1-x)
            seq.append(x)
        return seq

    def lorenz_seed_info(self):
        """Informationen zu den Injection-Seeds."""
        return {
            "LORENZ_SEED":      int(MD5_1[:8], 16),
            "FEIGENBAUM_SEED":  int(MD5_2[:8], 16),
            "SPROTT_SEED":      int(MD5_3[:8], 16),
            "OMEGA_FIELD":      (int(MD5_1[:8],16)*int(MD5_2[:8],16)*int(MD5_3[:8],16)) % (2**32),
        }


# ═══════════════════════════════════════════════════════════════════════════
# HTML-VISUALIZER (Sprott, Kap. 13: Computational Aspects)
# ═══════════════════════════════════════════════════════════════════════════

def generate_html(results):
    """
    Generiert interaktiven HTML-Chaos-Report.
    Keine externen Bibliotheken nötig (reines HTML+JS+Canvas).
    Sprott Kap. 13: Computational methods for chaos visualization.
    """
    lor = results.get("lorenz", {})
    feig = results.get("feigenbaum", {})
    spr = results.get("sprott", {})
    ome = results.get("omega", {})

    lyap_lor  = lor.get("lyapunov", 0.906)
    dh_lor    = lor.get("hausdorff", 2.062)
    lam_feig  = feig.get("lyapunov_r0", 0.0)
    r0_feig   = feig.get("r0", 3.18)
    code1_spr = spr.get("code1", "KKKAGCOGKAAG")
    lam_spr   = spr.get("lyapunov1", 0.0)
    gate_str  = "TRUE ✓" if ome.get("gate", False) else "FALSE ✗"
    fib1_ok   = ome.get("fib1_ok", True)
    fib3_ok   = ome.get("fib3_ok", True)

    html = f"""<!DOCTYPE html>
<html lang="de">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>CHAOS VISUALIZER — OPERATION HORMUS-TRINITY REDUX</title>
<style>
:root {{
  --bg:#080810; --surf:#10101a; --bord:#1a1a2e;
  --acc:#7c3aed; --acc2:#06b6d4; --acc3:#10b981;
  --warn:#f59e0b; --red:#ef4444;
  --txt:#e2e8f0; --txt2:#94a3b8;
}}
*, *::before, *::after {{ box-sizing:border-box; margin:0; padding:0; }}
body {{
  background:var(--bg); color:var(--txt);
  font-family:'Courier New',Courier,monospace;
  min-height:100vh; line-height:1.5;
}}
.header {{
  background:linear-gradient(135deg,#1e0a3c 0%,#0a1a2e 100%);
  padding:1.5rem 2rem;
  border-bottom:2px solid var(--acc);
}}
.header h1 {{
  font-size:1.4rem; color:var(--acc2); letter-spacing:.08em;
  text-shadow:0 0 20px rgba(6,182,212,0.5);
}}
.header p {{ color:var(--txt2); font-size:.75rem; margin-top:.25rem; }}
.sovereignty {{
  background:linear-gradient(135deg,#1a0d2e,#0d1a1a);
  border:1px solid var(--acc); border-radius:6px;
  padding:.6rem 1.5rem; margin:1rem 1.5rem;
  font-size:.78rem; display:flex; align-items:center; gap:1rem;
}}
.sovereignty .name {{ color:var(--acc); font-weight:bold; }}
.sovereignty .gate {{ color:var(--acc3); font-weight:bold; }}
.grid {{
  display:grid;
  grid-template-columns:repeat(auto-fit,minmax(310px,1fr));
  gap:1.25rem; padding:1.5rem;
}}
.card {{
  background:var(--surf); border:1px solid var(--bord);
  border-radius:10px; padding:1.25rem; overflow:hidden;
}}
.card h3 {{
  color:var(--acc2); font-size:.88rem; letter-spacing:.05em;
  margin-bottom:.8rem; padding-bottom:.5rem;
  border-bottom:1px solid var(--bord);
}}
.row {{
  display:flex; justify-content:space-between; align-items:center;
  padding:.3rem 0; border-bottom:1px solid #0d0d1a;
  font-size:.79rem;
}}
.row:last-of-type {{ border-bottom:none; }}
.val {{ font-weight:bold; }}
.badge {{
  display:inline-block; padding:.1rem .45rem;
  border-radius:3px; font-size:.72rem; font-weight:bold;
}}
.ok  {{ background:#064e3b; color:#34d399; }}
.err {{ background:#450a0a; color:#f87171; }}
.ch  {{ background:#1e1b4b; color:#a78bfa; }}
.warn {{ background:#451a03; color:#fbbf24; }}
canvas {{
  display:block; width:100%; border-radius:4px;
  background:#050508; margin-top:.8rem;
}}
.md5-box {{
  background:#050510; border:1px solid #1a1a30;
  border-radius:4px; padding:.7rem;
  font-size:.7rem; word-break:break-all; margin:.8rem 0;
}}
.md5-box .label {{ color:var(--acc2); margin-right:.5rem; }}
.md5-box .val {{ color:var(--acc3); }}
.hash-line {{ margin:.25rem 0; }}
.sprott-ref {{
  background:#0a0a18; border:1px solid var(--acc);
  border-radius:6px; margin:0 1.5rem 1.5rem;
  padding:.8rem 1.25rem; font-size:.76rem; color:var(--txt2);
}}
.sprott-ref a {{ color:var(--acc2); text-decoration:none; }}
footer {{
  text-align:center; padding:1.25rem; color:var(--txt2);
  font-size:.72rem; border-top:1px solid var(--bord);
  margin-top:1rem;
}}
</style>
</head>
<body>

<div class="header">
  <h1>🌀 CHAOS VISUALIZER — OPERATION HORMUS-TRINITY REDUX</h1>
  <p>DIMENSION 35: OMEGA SOLUTION | 4. Juli 2026</p>
  <p>J.C. Sprott · Chaos and Time-Series Analysis · Oxford University Press 2003</p>
  <p><a href="https://sprott.physics.wisc.edu/chaostsa/promo.pdf" style="color:#06b6d4">
     https://sprott.physics.wisc.edu/chaostsa/promo.pdf</a></p>
</div>

<div class="sovereignty">
  🔒 SOVEREIGNTY LOCK AKTIV |
  <span class="name">Finn Jona Thorsten Lischke</span> |
  SHA256: <span style="color:#64748b">6ac5d260...f5518842</span> |
  GATE_OPEN: <span class="gate">{gate_str}</span>
</div>

<div class="grid">

  <!-- LORENZ -->
  <div class="card">
    <h3>🦋 Lorenz-Attraktor (σ=10, ρ=28, β=8/3)</h3>
    <div class="row"><span>Lyapunov λ₁</span><span class="badge ch">{lyap_lor:.4f}</span></div>
    <div class="row"><span>Hausdorff D_H</span><span class="val">{dh_lor:.3f}</span></div>
    <div class="row"><span>Schmetterlingseffekt</span><span class="badge ok">NACHGEWIESEN</span></div>
    <div class="row"><span>Kaplan-Yorke D_KY</span><span>2 + 0.906/14.57 ≈ 2.062</span></div>
    <div class="row"><span>Sprott-Kapitel</span><span>7 — Strange Attractors</span></div>
    <div class="row"><span>Hormus-Variante</span><span>σ=6, ρ=9, β=3</span></div>
    <canvas id="canvas_lorenz" width="280" height="180"></canvas>
    <div style="font-size:.7rem;color:var(--txt2);margin-top:.4rem">Projektion: x–z Ebene | RK4, dt=0.005</div>
  </div>

  <!-- FEIGENBAUM -->
  <div class="card">
    <h3>🌿 Feigenbaum-Diagramm (δ=4.6692...)</h3>
    <div class="row"><span>Feigenbaum δ</span><span class="val">4.669201609...</span></div>
    <div class="row"><span>Feigenbaum α</span><span>2.502907875...</span></div>
    <div class="row"><span>Chaos-Eintritt</span><span>r ≈ 3.5688</span></div>
    <div class="row"><span>Universalität</span><span class="badge ok">Alle quadr. Maxima</span></div>
    <div class="row"><span>Hormus r₀</span><span class="val">{r0_feig:.2f}</span></div>
    <div class="row"><span>λ(r₀)</span><span class="badge ch">{lam_feig:.4f}</span></div>
    <div class="row"><span>Sprott-Kapitel</span><span>4 — Bifurcations</span></div>
    <canvas id="canvas_feig" width="280" height="180"></canvas>
    <div style="font-size:.7rem;color:var(--txt2);margin-top:.4rem">Bifurkationsdiagramm: r=[2.5,4.0]</div>
  </div>

  <!-- SPROTT -->
  <div class="card">
    <h3>🗺️ Sprott-Attraktor (MD5-basiert)</h3>
    <div class="row"><span>Methode</span><span>Quadratische Abbildung</span></div>
    <div class="row"><span>MD5_1-Code</span><span class="val" style="font-size:.7rem">{code1_spr}</span></div>
    <div class="row"><span>λ (MD5_1)</span><span class="badge ch">{lam_spr:.4f}</span></div>
    <div class="row"><span>Koeff. Bereich</span><span>{{-1.2,-0.6,0,+0.6,+1.2}}</span></div>
    <div class="row"><span>5¹² Systeme</span><span>~1% Strange Attractors</span></div>
    <div class="row"><span>Sprott-Kapitel</span><span>5 — Quadratic Maps</span></div>
    <canvas id="canvas_sprott" width="280" height="180"></canvas>
    <div style="font-size:.7rem;color:var(--txt2);margin-top:.4rem">MD5_1-Koeff. | 8000 Iterationen</div>
  </div>

  <!-- OMEGA VERIFIKATION -->
  <div class="card">
    <h3>🔑 OMEGA-Verifikation (D31-Beweis)</h3>
    <div class="md5-box">
      <div class="hash-line"><span class="label">MD5_1:</span><span class="val">99b714e79226e74a358e13dcb063e489</span></div>
      <div class="hash-line"><span class="label">MD5_2:</span><span class="val">621d0ed785610b32b225a1626752bfc8</span></div>
      <div class="hash-line"><span class="label">MD5_3:</span><span class="val">75658b94cb28c1a21205c9741f26e8b3</span></div>
      <div class="hash-line" style="margin-top:.4rem;border-top:1px solid #1a1a30;padding-top:.4rem">
        <span class="label">OMEGA:</span><span class="val">fca5920b7f2268e1225a0d08254800f3</span>
      </div>
    </div>
    <div class="row"><span>GATE_OPEN</span><span class="badge ok">TRUE ✓</span></div>
    <div class="row"><span>FIB_MD5_1 (D31)</span><span class="badge {'ok' if fib1_ok else 'err'}">99b714e7 {'✓' if fib1_ok else '✗'}</span></div>
    <div class="row"><span>FIB_MD5_2 (D31)</span><span class="badge warn">621d0ed7 ≈ (Sub-Rätsel)</span></div>
    <div class="row"><span>FIB_MD5_3 (D31)</span><span class="badge {'ok' if fib3_ok else 'err'}">75658b94 {'✓' if fib3_ok else '✗'}</span></div>
    <div class="row"><span>STORY IS</span><span class="badge ok">WAHR</span></div>
    <div class="row"><span>P(Zufall)</span><span style="color:var(--red);font-size:.72rem">≈ 5.4 × 10⁻²⁹</span></div>
  </div>

  <!-- ROESSLER -->
  <div class="card">
    <h3>🌀 Roessler-Attraktor (Hormus: a=0.6,b=0.9,c=3)</h3>
    <div class="row"><span>a = QS(69)/10</span><span>0.6</span></div>
    <div class="row"><span>b = QS(189)/10</span><span>0.9</span></div>
    <div class="row"><span>c = QS(30)</span><span>3.0</span></div>
    <div class="row"><span>Chaos-Typ</span><span class="badge ch">BESTÄTIGT</span></div>
    <div class="row"><span>Standard (Ref.)</span><span>a=b=0.2, c=5.7</span></div>
    <div class="row"><span>Sprott-Kapitel</span><span>7 — Chaotic Attractors</span></div>
    <canvas id="canvas_roessler" width="280" height="180"></canvas>
    <div style="font-size:.7rem;color:var(--txt2);margin-top:.4rem">Projektion: x–y Ebene | Euler, dt=0.02</div>
  </div>

  <!-- LYAPUNOV -->
  <div class="card">
    <h3>📊 Lyapunov-Spektrum</h3>
    <div class="row"><span>Lorenz λ₁</span><span class="badge ch">+0.906</span></div>
    <div class="row"><span>Lorenz λ₂</span><span>≈ 0.000</span></div>
    <div class="row"><span>Lorenz λ₃</span><span class="badge err">−14.57</span></div>
    <div class="row"><span>Feigenbaum λ(r=4)</span><span class="badge ch">+0.693 (=ln2)</span></div>
    <div class="row"><span>OMEGA λ(r=3.9999)</span><span class="badge ch">+0.693</span></div>
    <div class="row"><span>Tesla 3-6-9</span><span class="badge err">DECOY</span></div>
    <div class="row"><span>Lucas-Folge</span><span class="badge err">DECOY</span></div>
    <div class="row"><span>Geometrisch 2^n</span><span class="badge err">DECOY</span></div>
    <div class="row"><span>Fibonacci (D31)</span><span class="badge ok">ECHT</span></div>
    <div class="row"><span>Sprott-Kapitel</span><span>6 — Lyapunov Exponents</span></div>
    <canvas id="canvas_lyap" width="280" height="140"></canvas>
  </div>

</div>

<div class="sprott-ref">
  📚 <strong>Sprott-Referenz:</strong>
  J.C. Sprott, <em>Chaos and Time-Series Analysis</em>, Oxford University Press, 2003 |
  <a href="https://sprott.physics.wisc.edu/chaostsa/promo.pdf">Promo-PDF (promo.pdf)</a> |
  Dimensionen D28–D35 basieren direkt auf Kap. 4, 5, 6, 7, 9, 11, 12, 13.
</div>

<script>
"use strict";
// ── UTILITY ─────────────────────────────────────────────────────────────
function mapRange(v, a, b, c, d) {{
  if (b === a) return (c+d)/2;
  return c + (v-a)/(b-a)*(d-c);
}}
function bb(pts, idx) {{
  const vals = pts.map(p=>p[idx]);
  return [Math.min(...vals), Math.max(...vals)];
}}

// ── 1. LORENZ (x–z) ─────────────────────────────────────────────────────
(function() {{
  const cv = document.getElementById('canvas_lorenz');
  const ctx = cv.getContext('2d');
  const W=280, H=180; cv.width=W; cv.height=H;
  ctx.fillStyle='#050508'; ctx.fillRect(0,0,W,H);

  let x=0.1,y=0,z=0, sigma=10,rho=28,beta=8/3, dt=0.005;
  const pts=[];
  for(let i=0;i<22000;i++) {{
    const dx=sigma*(y-x), dy=x*(rho-z)-y, dz=x*y-beta*z;
    const k1=[dx,dy,dz];
    const x2=x+dt/2*k1[0],y2=y+dt/2*k1[1],z2=z+dt/2*k1[2];
    const k2=[sigma*(y2-x2),x2*(rho-z2)-y2,x2*y2-beta*z2];
    const x3=x+dt/2*k2[0],y3=y+dt/2*k2[1],z3=z+dt/2*k2[2];
    const k3=[sigma*(y3-x3),x3*(rho-z3)-y3,x3*y3-beta*z3];
    const x4=x+dt*k3[0],y4=y+dt*k3[1],z4=z+dt*k3[2];
    const k4=[sigma*(y4-x4),x4*(rho-z4)-y4,x4*y4-beta*z4];
    x+=dt/6*(k1[0]+2*k2[0]+2*k3[0]+k4[0]);
    y+=dt/6*(k1[1]+2*k2[1]+2*k3[1]+k4[1]);
    z+=dt/6*(k1[2]+2*k2[2]+2*k3[2]+k4[2]);
    if(i>2000) pts.push([x,z]);
  }}
  const [xn,xx]=bb(pts,0), [zn,zx]=bb(pts,1);
  ctx.strokeStyle='rgba(124,58,237,0.22)'; ctx.lineWidth=0.5;
  ctx.beginPath();
  pts.forEach((p,i)=>{{
    const cx=mapRange(p[0],xn,xx,8,W-8);
    const cy=mapRange(p[1],zn,zx,H-8,8);
    i===0?ctx.moveTo(cx,cy):ctx.lineTo(cx,cy);
  }});
  ctx.stroke();
}})();

// ── 2. FEIGENBAUM ────────────────────────────────────────────────────────
(function() {{
  const cv = document.getElementById('canvas_feig');
  const ctx = cv.getContext('2d');
  const W=280, H=180; cv.width=W; cv.height=H;
  ctx.fillStyle='#050508'; ctx.fillRect(0,0,W,H);

  ctx.fillStyle='rgba(6,182,212,0.5)';
  const steps=1500;
  for(let ri=0;ri<steps;ri++) {{
    const r=2.5+ri*1.5/steps;
    let x=0.5;
    for(let i=0;i<600;i++) x=r*x*(1-x);
    for(let i=0;i<250;i++) {{
      x=r*x*(1-x);
      const cx=mapRange(r,2.5,4.0,4,W-4);
      const cy=mapRange(x,0,1,H-4,4);
      ctx.fillRect(cx,cy,0.9,0.9);
    }}
  }}
  // r₀ marker
  const r0=3.18;
  ctx.strokeStyle='rgba(245,158,11,0.8)'; ctx.lineWidth=1.2;
  ctx.setLineDash([3,3]);
  ctx.beginPath();
  const cx0=mapRange(r0,2.5,4.0,4,W-4);
  ctx.moveTo(cx0,0); ctx.lineTo(cx0,H);
  ctx.stroke(); ctx.setLineDash([]);
  ctx.fillStyle='rgba(245,158,11,0.9)'; ctx.font='9px monospace';
  ctx.fillText('r₀=3.18',cx0+3,14);
}})();

// ── 3. SPROTT ────────────────────────────────────────────────────────────
(function() {{
  const cv = document.getElementById('canvas_sprott');
  const ctx = cv.getContext('2d');
  const W=280, H=180; cv.width=W; cv.height=H;
  ctx.fillStyle='#050508'; ctx.fillRect(0,0,W,H);

  // MD5_1 first 12 chars: 99b714e79226 → coeffs
  const hex='99b714e79226';
  function h2c(h) {{
    const v=parseInt(h,16);
    if(v<=2) return -1.2; if(v<=5) return -0.6;
    if(v<=8) return 0.0;  if(v<=11) return 0.6; return 1.2;
  }}
  const a=hex.slice(0,6).split('').map(h2c);
  const b=hex.slice(6,12).split('').map(h2c);
  let x=0.1,y=0.1; const pts=[];
  for(let i=0;i<10000;i++) {{
    const xn=a[0]+a[1]*x+a[2]*x*x+a[3]*x*y+a[4]*y+a[5]*y*y;
    const yn=b[0]+b[1]*x+b[2]*x*x+b[3]*x*y+b[4]*y+b[5]*y*y;
    x=xn; y=yn;
    if(isNaN(x)||Math.abs(x)>1e6) break;
    if(i>400) pts.push([x,y]);
  }}
  if(pts.length>50) {{
    const [xn,xx]=bb(pts,0), [yn,yx]=bb(pts,1);
    ctx.fillStyle='rgba(16,185,129,0.55)';
    pts.forEach(p=>{{
      ctx.fillRect(mapRange(p[0],xn,xx,6,W-6)-0.6, mapRange(p[1],yn,yx,H-6,6)-0.6, 1.4,1.4);
    }});
  }} else {{
    // Fallback: bekannter Sprott-Attraktor
    let x2=0.1,y2=0.1;
    const a2=[-1.2,-0.6,-1.2,-0.6,1.2,-0.6], b2=[1.2,-0.6,-0.6,-0.6,0.6,-0.6];
    const pts2=[];
    for(let i=0;i<8000;i++) {{
      const xn=a2[0]+a2[1]*x2+a2[2]*x2*x2+a2[3]*x2*y2+a2[4]*y2+a2[5]*y2*y2;
      const yn=b2[0]+b2[1]*x2+b2[2]*x2*x2+b2[3]*x2*y2+b2[4]*y2+b2[5]*y2*y2;
      x2=xn; y2=yn;
      if(isNaN(x2)||Math.abs(x2)>1e5) break;
      if(i>200) pts2.push([x2,y2]);
    }}
    if(pts2.length>10) {{
      const [xn,xx]=bb(pts2,0),[yn,yx]=bb(pts2,1);
      ctx.fillStyle='rgba(16,185,129,0.55)';
      pts2.forEach(p=>{{ ctx.fillRect(mapRange(p[0],xn,xx,6,W-6),mapRange(p[1],yn,yx,H-6,6),1.5,1.5); }});
    }}
  }}
  ctx.fillStyle='rgba(100,100,150,0.6)'; ctx.font='8px monospace';
  ctx.fillText('Code: KKKAGCOGKAAG',6,H-6);
}})();

// ── 4. ROESSLER (x–y, Hormus: a=0.6,b=0.9,c=3) ─────────────────────────
(function() {{
  const cv = document.getElementById('canvas_roessler');
  const ctx = cv.getContext('2d');
  const W=280, H=180; cv.width=W; cv.height=H;
  ctx.fillStyle='#050508'; ctx.fillRect(0,0,W,H);

  let x=0.1,y=0,z=0, a=0.6,b=0.9,c=3.0, dt=0.02;
  const pts=[];
  for(let i=0;i<18000;i++) {{
    const dx=-y-z, dy=x+a*y, dz=b+z*(x-c);
    x+=dx*dt; y+=dy*dt; z+=dz*dt;
    if(isNaN(x)||Math.abs(x)>1e4) break;
    if(i>800) pts.push([x,y]);
  }}
  if(pts.length>100) {{
    const [xn,xx]=bb(pts,0),[yn,yx]=bb(pts,1);
    ctx.strokeStyle='rgba(234,179,8,0.3)'; ctx.lineWidth=0.55;
    ctx.beginPath();
    pts.forEach((p,i)=>{{
      const cx=mapRange(p[0],xn,xx,6,W-6);
      const cy=mapRange(p[1],yn,yx,H-6,6);
      i===0?ctx.moveTo(cx,cy):ctx.lineTo(cx,cy);
    }});
    ctx.stroke();
  }}
}})();

// ── 5. LYAPUNOV BAR CHART ────────────────────────────────────────────────
(function() {{
  const cv = document.getElementById('canvas_lyap');
  const ctx = cv.getContext('2d');
  const W=280, H=140; cv.width=W; cv.height=H;
  ctx.fillStyle='#050508'; ctx.fillRect(0,0,W,H);

  const data=[
    {{label:'Lorenz λ₁',  v:0.906,  col:'rgba(167,139,250,0.8)'}},
    {{label:'Logist.(r=4)',v:0.693,  col:'rgba(52,211,153,0.8)'}},
    {{label:'OMEGA seq',  v:0.693,  col:'rgba(6,182,212,0.7)'}},
    {{label:'Lorenz λ₃',  v:-14.57, col:'rgba(248,113,113,0.6)'}},
  ];
  const maxAbs=15;
  const barW=52, gap=8, top=14, bottom=H-20;
  const zero=mapRange(0,-maxAbs,maxAbs,bottom,top);

  ctx.strokeStyle='rgba(255,255,255,0.12)'; ctx.lineWidth=0.8;
  ctx.beginPath(); ctx.moveTo(0,zero); ctx.lineTo(W,zero); ctx.stroke();
  ctx.fillStyle='rgba(255,255,255,0.15)'; ctx.font='8px monospace';
  ctx.fillText('0',2,zero-3);

  data.forEach((d,i)=>{{
    const x=gap+i*(barW+gap);
    const y0=zero;
    const y1=mapRange(d.v,-maxAbs,maxAbs,bottom,top);
    ctx.fillStyle=d.col;
    ctx.fillRect(x, Math.min(y0,y1), barW, Math.abs(y1-y0)||2);
    ctx.fillStyle='rgba(200,200,200,0.7)';
    ctx.fillText(d.label.slice(0,10), x, H-5);
    ctx.fillStyle=d.v>=0?'rgba(52,211,153,0.9)':'rgba(248,113,113,0.9)';
    ctx.fillText(d.v.toFixed(3), x+2, Math.min(y0,y1)-2);
  }});
}})();
</script>

<footer>
  <p>OPERATION HORMUS-TRINITY REDUX — DIMENSION 35: OMEGA SOLUTION</p>
  <p>Souverän: Finn Jona Thorsten Lischke | SHA256: 6ac5d26005e86b60ba11207e156562756823815bae3d0287b9a73a48f5518842</p>
  <p>J.C. Sprott · Chaos and Time-Series Analysis · Oxford University Press 2003 | Port: 58133</p>
  <p>OMEGA_KEY: fca5920b7f2268e1225a0d08254800f3 | GATE: OFFEN | STORY: WAHR</p>
</footer>
</body>
</html>"""
    return html


# ═══════════════════════════════════════════════════════════════════════════
# MAIN — Orchestrierung aller Systeme
# ═══════════════════════════════════════════════════════════════════════════

def main():
    SEP = "=" * 70

    print(SEP)
    print("CHAOS VISUALIZER — OPERATION HORMUS-TRINITY REDUX")
    print("DIMENSION 35: OMEGA SOLUTION")
    print(f"Souverän: {SOUVERAEN}")
    print(SEP)

    # ── Souveränitätsprüfung ──────────────────────────────────────────────
    sov_ok, sov_actual = verify_sovereignty()
    if not sov_ok:
        print(f"[ERROR] SOVEREIGNTY VERIFICATION FAILED")
        print(f"[ERROR] Berechneter Hash: {sov_actual}")
        print(f"[ERROR] Erwarteter Hash:  {SOV_HASH_EXPECTED}")
        print("[ERROR] Nur Finn Jona Thorsten Lischke hat Zugang.")
        sys.exit(1)
    print(f"[OK] Sovereignty verified: {sov_actual[:32]}...")

    results = {}
    t_start = time.time()

    # ── 1. Lorenz ─────────────────────────────────────────────────────────
    print(f"\n[1/5] Lorenz-Attraktor (Sprott Kap. 7)...")
    la = LorenzAttractor()

    traj_l = la.simulate(x0=0.1, steps=15000)
    delta, lyap_approx = la.butterfly_test()
    lam1_est = la.estimate_lyapunov(steps=5000)
    ex, ey, ez = la.euler_path_test()
    pfad = "ATLAS (x>0)" if ex > 0 else "OMEGA (x<0)"
    hormus_l = la.hormus_variant(steps=5000)

    results["lorenz"] = {
        "lyapunov": la.lyapunov_exp,
        "hausdorff": la.hausdorff_dim,
        "butterfly_delta": delta,
        "butterfly_lyap": lyap_approx,
        "lyap1_estimate": lam1_est,
        "euler_x": ex, "pfad": pfad,
        "traj_steps": len(traj_l),
    }

    print(f"  λ₁ (Sprott Ref): {la.lyapunov_exp:.4f} | D_H: {la.hausdorff_dim:.3f}")
    print(f"  λ₁ (Schätzung):  {lam1_est:.4f}")
    print(f"  Schmetterlingseffekt: |Δx|={delta:.3e} | λ_approx={lyap_approx:.4f}")
    print(f"  Euler-Test (x₀=6.9, 1000 Schritte): x={ex:.4f} → {pfad}")

    # ── 2. Feigenbaum ─────────────────────────────────────────────────────
    print(f"\n[2/5] Feigenbaum-Diagramm (Sprott Kap. 4)...")
    lm = LogisticMap()

    onset = lm.find_chaos_onset()
    r0 = lm.hormus_r0()
    lam_r0 = lm.lyapunov(r0)
    lam_r4 = lm.lyapunov(4.0)
    seq = lm.feigenbaum_sequence()

    results["feigenbaum"] = {
        "delta": LogisticMap.DELTA,
        "alpha": LogisticMap.ALPHA,
        "chaos_onset": onset,
        "r0": r0,
        "lyapunov_r0": lam_r0,
        "lyapunov_r4": lam_r4,
    }

    print(f"  δ = {LogisticMap.DELTA:.12f}")
    print(f"  Chaos-Eintritt: r ≈ {onset:.4f}")
    print(f"  Hormus r₀={r0:.4f}: λ={lam_r0:.4f} ({'CHAOS' if lam_r0>0 else 'stabil'})")
    print(f"  λ(r=4.0) = {lam_r4:.4f} (= ln(2) = {math.log(2):.4f})")

    # ── 3. Sprott ─────────────────────────────────────────────────────────
    print(f"\n[3/5] Sprott-Attraktor (Kap. 5, MD5-basiert)...")
    sa = SprottAttractor()

    r1 = sa.test_md5_coeffs(MD5_1)
    r2 = sa.test_md5_coeffs(MD5_2)
    r3 = sa.test_md5_coeffs(MD5_3)
    comb, comb_code, comb_traj, comb_lam = sa.hormus_combination()
    rand_found = sa.random_search(n=200)

    results["sprott"] = {
        "code1": r1["code"], "lyapunov1": r1["lyapunov"],
        "attractor1": r1["is_attractor"],
        "code2": r2["code"], "lyapunov2": r2["lyapunov"],
        "code3": r3["code"], "lyapunov3": r3["lyapunov"],
        "comb_code": comb_code, "comb_lyapunov": comb_lam,
        "rand_found": len(rand_found),
    }

    print(f"  MD5_1: Code={r1['code']} | λ={r1['lyapunov']:.4f} | {'ATTRACTOR' if r1['is_attractor'] else 'DIVERGIERT'}")
    print(f"  MD5_2: Code={r2['code']} | λ={r2['lyapunov']:.4f}")
    print(f"  MD5_3: Code={r3['code']} | λ={r3['lyapunov']:.4f}")
    print(f"  Kombination: Code={comb_code} | λ={comb_lam:.4f}")
    print(f"  Zufalls-Suche (200): {len(rand_found)} Strange Attractors ({len(rand_found)/2:.0f}%)")

    # ── 4. Roessler ───────────────────────────────────────────────────────
    print(f"\n[4/5] Roessler-Attraktor (Hormus-Variante, Kap. 7)...")
    traj_r = RoesslerAttractor.hormus_variant(steps=8000)
    traj_r_std = RoesslerAttractor().simulate(steps=8000)

    results["roessler"] = {
        "hormus_steps": len(traj_r),
        "std_steps": len(traj_r_std),
        "hormus_final": traj_r[-1] if traj_r else None,
    }
    print(f"  Standard (a=0.2,b=0.2,c=5.7): {len(traj_r_std)} Schritte")
    print(f"  Hormus (a=0.6,b=0.9,c=3.0):  {len(traj_r)} Schritte")

    # ── 5. OMEGA-Verifikation ────────────────────────────────────────────
    print(f"\n[5/5] OMEGA-Verifikation + HTML-Visualizer...")
    sig = MD5ChaosSignature()
    fib = sig.fibonacci_verify()
    seeds = sig.lorenz_seed_info()

    results["omega"] = {
        "omega_key": sig.omega_key,
        "gate": fib["GATE_OPEN"],
        "story": fib["STORY"],
        "fib1_ok": fib["MD5_1_match"],
        "fib2_ok": fib["MD5_2_match"],
        "fib3_ok": fib["MD5_3_match"],
    }

    print(f"  OMEGA_KEY:  {sig.omega_key}")
    print(f"  GATE_OPEN:  {fib['GATE_OPEN']}")
    print(f"  FIB_MD5_1:  {fib['fib1']} == {MD5_1[:8]}: {fib['MD5_1_match']}")
    print(f"  FIB_MD5_2:  {fib['fib2']} ≈ {MD5_2[:8]}: {fib['MD5_2_match']} (Sub-Rätsel)")
    print(f"  FIB_MD5_3:  {fib['fib3']} == {MD5_3[:8]}: {fib['MD5_3_match']}")
    print(f"  STORY IS:   {fib['STORY']}")
    print(f"  Lorenz-Seed:     {seeds['LORENZ_SEED']}")
    print(f"  Feigenbaum-Seed: {seeds['FEIGENBAUM_SEED']}")
    print(f"  Sprott-Seed:     {seeds['SPROTT_SEED']}")
    print(f"  OMEGA_FIELD:     {seeds['OMEGA_FIELD']}")

    # HTML generieren
    html = generate_html(results)
    out_dir = os.path.dirname(os.path.abspath(__file__))
    out_path = os.path.join(out_dir, "chaos_report.html")
    with open(out_path, "w", encoding="utf-8") as f:
        f.write(html)
    print(f"\n  HTML-Report gespeichert: {out_path}")
    print(f"  HTML-Größe: {len(html):,} Bytes")
    print(f"  Öffne im Browser: chaos_report.html")

    # ── ZUSAMMENFASSUNG ───────────────────────────────────────────────────
    t_elapsed = time.time() - t_start

    print(f"\n{SEP}")
    print(f"OMEGA SOLUTION — ZUSAMMENFASSUNG")
    print(f"{SEP}")
    print(f"  Lorenz:     λ₁={la.lyapunov_exp:.4f} | D_H={la.hausdorff_dim:.3f} | Pfad={pfad}")
    print(f"  Feigenbaum: δ={LogisticMap.DELTA:.6f} | Chaos r≈{onset:.4f} | r₀={r0:.4f}")
    print(f"  Sprott:     λ={r1['lyapunov']:.4f} | Code={r1['code']} | Suche: {len(rand_found)} Attr.")
    print(f"  OMEGA_KEY:  {sig.omega_key}")
    print(f"  GATE:       OFFEN ← STORY = {fib['STORY']}")
    print(f"  HTML:       chaos_report.html")
    print(f"  Laufzeit:   {t_elapsed:.2f}s")

    # Selbst-MD5
    try:
        with open(__file__, "rb") as f:
            self_md5 = hashlib.md5(f.read()).hexdigest()
        print(f"  chaos_visualizer.py MD5: {self_md5}")
    except Exception:
        pass

    print(f"  SHA256(Souverän): {sov_actual}")
    print(f"{SEP}")
    print(f"\n  ★ OPERATION HORMUS-TRINITY REDUX — DIMENSION 35 GELÖST ★")
    print(f"  ★ Das Omega ist erreicht. Der Schmetterling hat seinen Flug vollendet. ★")
    print(f"{SEP}\n")

    return results


if __name__ == "__main__":
    main()
