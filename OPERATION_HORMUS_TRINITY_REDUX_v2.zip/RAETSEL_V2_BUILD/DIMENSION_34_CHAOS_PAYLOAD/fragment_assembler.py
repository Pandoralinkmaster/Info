#!/usr/bin/env python3
"""
FRAGMENT ASSEMBLER — DIMENSION 34
Setzt 5 Base64-Fragmente zu chaos_visualizer.py zusammen.

Finn Jona Thorsten Lischke — ABSOLUTE SOVEREIGN
"""
import base64
import hashlib
import os
import sys

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
TARGET_DIR = os.path.normpath(os.path.join(BASE_DIR, "..", "DIMENSION_35_OMEGA_SOLUTION"))
TARGET = os.path.join(TARGET_DIR, "chaos_visualizer.py")

N_FRAGMENTS = 5


def load_fragments():
    frags = []
    for i in range(1, N_FRAGMENTS + 1):
        path = os.path.join(BASE_DIR, f"fragment_0{i}.b64")
        if not os.path.exists(path):
            print(f"[ERROR] Fragment nicht gefunden: {path}")
            sys.exit(1)
        with open(path, "r", encoding="utf-8") as f:
            raw_b64 = f.read().strip()
        decoded = base64.b64decode(raw_b64).decode("utf-8")
        frags.append(decoded)
        print(f"  Fragment {i}: {len(raw_b64):6,} B64-Zeichen → {len(decoded):6,} Text-Zeichen")
    return frags


def assemble():
    print("=" * 60)
    print("FRAGMENT ASSEMBLER — DIMENSION 34")
    print("Operation Hormus-Trinity Redux")
    print("=" * 60)

    print(f"\nLade {N_FRAGMENTS} Fragmente aus:")
    print(f"  {BASE_DIR}\n")

    frags = load_fragments()
    code = "".join(frags)

    print(f"\nAssembliert: {len(code):,} Zeichen gesamt")

    # Hash prüfen
    code_md5 = hashlib.md5(code.encode()).hexdigest()
    code_sha = hashlib.sha256(code.encode()).hexdigest()
    print(f"MD5(Code):    {code_md5}")
    print(f"SHA256(Code): {code_sha[:48]}...")

    # D35 bereits vorhanden?
    if os.path.exists(TARGET):
        existing_size = os.path.getsize(TARGET)
        print(f"\nD35 bereits vorhanden ({existing_size:,} Bytes).")
        ans = input("Überschreiben? [j/N]: ").strip().lower()
        if ans not in ("j", "ja", "y", "yes"):
            print("Abgebrochen.")
            sys.exit(0)

    os.makedirs(TARGET_DIR, exist_ok=True)
    with open(TARGET, "w", encoding="utf-8") as f:
        f.write(code)

    written_size = os.path.getsize(TARGET)
    print(f"\nGeschrieben: {TARGET}")
    print(f"Größe: {written_size:,} Bytes")

    print("\n" + "=" * 60)
    print("ASSEMBLIERUNG ABGESCHLOSSEN")
    print("Führe nun aus:")
    print(f"  python {TARGET}")
    print("=" * 60)

    return TARGET


def verify_only():
    """Nur Fragmente verifizieren, nicht zusammensetzen."""
    print("FRAGMENT-VERIFIKATION (kein Schreiben)")
    frags = load_fragments()
    code = "".join(frags)
    md5 = hashlib.md5(code.encode()).hexdigest()
    sha = hashlib.sha256(code.encode()).hexdigest()
    print(f"Gesamt: {len(code):,} Zeichen")
    print(f"MD5:    {md5}")
    print(f"SHA256: {sha}")


if __name__ == "__main__":
    if "--verify" in sys.argv:
        verify_only()
    elif "--help" in sys.argv or "-h" in sys.argv:
        print("Optionen:")
        print("  (kein Argument) → Zusammensetzen und nach D35 schreiben")
        print("  --verify        → Nur Hashes prüfen, kein Schreiben")
    else:
        assemble()
