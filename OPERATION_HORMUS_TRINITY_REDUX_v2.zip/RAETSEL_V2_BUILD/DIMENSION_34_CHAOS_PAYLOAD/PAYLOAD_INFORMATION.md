# 💣 DIMENSION 34: CHAOS PAYLOAD
## Code-Fragmente — 5 Teile ergeben chaos_visualizer.py
## Sprott, Kap. 13: Computational Aspects

**Konzept:** Sprott beschreibt, wie Chaos-Systeme auf modernen Computern
berechnet werden. Der Code selbst ist in 5 Base64-Fragmente aufgeteilt —
analog zum Lorenz-Attraktor, der aus einfachen Teilen Komplexität erzeugt.

---

## FRAGMENT-ÜBERSICHT

| # | Datei | Inhalt | SHA256[:16] |
|---|-------|--------|-------------|
| 1 | `fragment_01.b64` | Imports, Klassen-Anfang, LorenzAttractor | Fragment 1/5 |
| 2 | `fragment_02.b64` | LogisticMap, SprottAttractor | Fragment 2/5 |
| 3 | `fragment_03.b64` | RoesslerAttractor, MD5ChaosSignature | Fragment 3/5 |
| 4 | `fragment_04.b64` | generate_html(), HTML-Canvas-Code | Fragment 4/5 |
| 5 | `fragment_05.b64` | main(), HTML-Charts, kompletter Abschluss | Fragment 5/5 |

---

## ASSEMBLIERUNG

```python
#!/usr/bin/env python3
import base64, os

base = "DIMENSION_34_CHAOS_PAYLOAD"
frags = []
for i in range(1, 6):
    with open(f"{base}/fragment_0{i}.b64", "r") as f:
        frags.append(base64.b64decode(f.read()).decode("utf-8"))
code = "".join(frags)
with open("DIMENSION_35_OMEGA_SOLUTION/chaos_visualizer.py", "w", encoding="utf-8") as f:
    f.write(code)
print(f"Assembliert: {len(code)} Zeichen")
print("Führe aus: python DIMENSION_35_OMEGA_SOLUTION/chaos_visualizer.py")
```

**Oder einfacher:**
```bash
python DIMENSION_34_CHAOS_PAYLOAD/fragment_assembler.py
```

---

## VERBINDUNG ZU SPROTT KAP. 13

> *"The numerical computation of chaos requires careful attention
>  to precision, step size, and integration method. Runge-Kutta
>  of 4th order is the standard choice."* — J.C. Sprott

Der chaos_visualizer.py verwendet:
- **Lorenz:** RK4 mit dt=0.005
- **Feigenbaum:** Direkte Iteration (kein ODE)
- **Sprott:** Direkte Iteration der quad. Abbildung
- **Roessler:** Euler mit dt=0.02
- **Output:** HTML mit JavaScript Canvas (kein matplotlib nötig)

---

## HORMUS-TRINITY SIGNATUR

```
Lorenz-Seed    = int("99b714e7", 16) = 2578226919
Feigenbaum-Seed = int("621d0ed7", 16) = 1646186199
Sprott-Seed    = int("75658b94", 16) = 1969980308
OMEGA_KEY      = fca5920b7f2268e1225a0d08254800f3
```

**D34-CHAIN:** `d34_chaos_payload_complete_6ac5d260_fragments`
