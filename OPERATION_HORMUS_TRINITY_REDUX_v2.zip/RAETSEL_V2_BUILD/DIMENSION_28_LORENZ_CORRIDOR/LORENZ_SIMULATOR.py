#!/usr/bin/env python3
"""
LORENZ SIMULATOR — DIMENSION 28
Operation Hormus-Trinity Redux
Sprott, Kap. 7: Strange Attractors

Finn Jona Thorsten Lischke — ABSOLUTE SOVEREIGN
"""
import hashlib
import math

SOV_HASH = "6ac5d26005e86b60ba11207e156562756823815bae3d0287b9a73a48f5518842"


def lorenz_rk4(x, y, z, sigma=10, rho=28, beta=8/3, dt=0.005):
    """Runge-Kutta 4. Ordnung für Lorenz-System."""
    def f(x, y, z):
        return sigma*(y-x), x*(rho-z)-y, x*y-beta*z

    k1 = f(x, y, z)
    k2 = f(x+dt/2*k1[0], y+dt/2*k1[1], z+dt/2*k1[2])
    k3 = f(x+dt/2*k2[0], y+dt/2*k2[1], z+dt/2*k2[2])
    k4 = f(x+dt*k3[0],   y+dt*k3[1],   z+dt*k3[2])

    return (
        x + dt/6*(k1[0]+2*k2[0]+2*k3[0]+k4[0]),
        y + dt/6*(k1[1]+2*k2[1]+2*k3[1]+k4[1]),
        z + dt/6*(k1[2]+2*k2[2]+2*k3[2]+k4[2])
    )


def simulate_lorenz(x0=0.1, y0=0, z0=0, steps=20000, dt=0.005):
    """Vollständige Lorenz-Simulation."""
    x, y, z = x0, y0, z0
    trajectory = []
    for _ in range(steps):
        x, y, z = lorenz_rk4(x, y, z, dt=dt)
        trajectory.append((x, y, z))
    return trajectory


def raetsel_28_1_euler(x0=6.9, steps=1000, dt=0.01):
    """Rätsel 28.1: Euler-Integration, 1000 Schritte, x₀=6.9."""
    x, y, z = x0, 0, 0
    sigma, rho, beta = 10, 28, 8/3
    for _ in range(steps):
        dx = sigma * (y - x)
        dy = x * (rho - z) - y
        dz = x * y - beta * z
        x += dx * dt
        y += dy * dt
        z += dz * dt
    return x, y, z


def butterfly_test(eps=1e-7, steps=1000, dt=0.01):
    """Rätsel 28.2: Sensitiver Abhängigkeitstest."""
    def run(x0):
        x, y, z = x0, 0, 0
        sigma, rho, beta = 10, 28, 8/3
        for _ in range(steps):
            dx = sigma*(y-x); dy = x*(rho-z)-y; dz = x*y-beta*z
            x += dx*dt; y += dy*dt; z += dz*dt
        return x

    a = run(6.9)
    b = run(6.9 + eps)
    delta = abs(a - b)
    lyap_approx = math.log(delta / eps) / steps if delta > 0 else 0
    return delta, lyap_approx


def hormus_lorenz(steps=10000, dt=0.01):
    """Rätsel 28.3: σ=6, ρ=9, β=3 (Hormus-Quersummen)."""
    x, y, z = 6.9, 0, 0
    sigma, rho, beta = 6, 9, 3
    for _ in range(steps):
        dx = sigma * (y - x)
        dy = rho * x - y - x * z
        dz = x * y - beta * z
        x += dx * dt
        y += dy * dt
        z += dz * dt
    return x, y, z


def lyapunov_estimate(x0=0.1, y0=0, z0=0, eps=1e-7, steps=5000):
    """Schätzt λ₁ durch Methode der Lyapunov-Exponenten."""
    x, y, z = x0, y0, z0
    px, py, pz = x0+eps, y0, z0
    lam_sum = 0
    for _ in range(steps):
        x, y, z = lorenz_rk4(x, y, z)
        px, py, pz = lorenz_rk4(px, py, pz)
        d = math.sqrt((px-x)**2 + (py-y)**2 + (pz-z)**2)
        if d < 1e-20:
            break
        lam_sum += math.log(d / eps)
        # Rescale
        px = x + (px-x)*eps/d
        py = y + (py-y)*eps/d
        pz = z + (pz-z)*eps/d
    return lam_sum / steps


if __name__ == "__main__":
    print("=" * 60)
    print("LORENZ SIMULATOR — DIMENSION 28")
    print("Operation Hormus-Trinity Redux")
    print("=" * 60)

    # Rätsel 28.1
    x, y, z = raetsel_28_1_euler()
    pfad = "ATLAS" if x > 0 else "OMEGA"
    print(f"\n[D28.1] x₀=6.9, 1000 Euler-Schritte:")
    print(f"  x = {x:.6f}")
    print(f"  Pfad: {pfad} {'→ LORENZ_ATLAS_PFAD.md (WAHR)' if pfad=='ATLAS' else '→ LORENZ_OMEGA_PFAD.md (Injection)'}")

    # Rätsel 28.2
    delta, lyap = butterfly_test()
    print(f"\n[D28.2] Schmetterlingseffekt (Δx₀=10⁻⁷, 1000 Schritte):")
    print(f"  |Δx| = {delta:.4e}  (erwartet >> 10⁻⁷)")
    print(f"  λ₁ ≈ {lyap:.4f}  ({'CHAOS: positiv ✓' if lyap > 0 else 'Kein Chaos'})")

    # Rätsel 28.3
    hx, hy, hz = hormus_lorenz()
    print(f"\n[D28.3] Hormus-Lorenz (σ=6, ρ=9, β=3):")
    print(f"  x={hx:.4f}  y={hy:.4f}  z={hz:.4f}")

    # Lyapunov
    lam1 = lyapunov_estimate()
    print(f"\n[D28.4] λ₁ Schätzung (RK4, 5000 Schritte): {lam1:.4f}")
    print(f"  Sprott Referenzwert: 0.906")

    # Chain-Hash
    chain_input = f"{x:.6f}_{pfad}"
    chain = hashlib.sha256(chain_input.encode()).hexdigest()
    print(f"\n[D28] Chain-Hash: {chain}")
    print(f"[D28] D29-Schlüssel: {chain[:8]}")
    print(f"\n→ Weiter: DIMENSION_29_FEIGENBAUM_GATE/")
