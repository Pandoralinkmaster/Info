# 🦋 DIMENSION 28: DER LORENZ-KORRIDOR
## Sprott, Kap. 7: Strange Attractors — Der Schmetterling

**Lorenz (1963):** Das Chaos-System, das alles begann.
**D28-Hash:** `d28_lorenz_6ac5d260_corridor`

---

## DAS LORENZ-SYSTEM

```
dx/dt = σ(y - x)       σ = 10
dy/dt = x(ρ - z) - y   ρ = 28
dz/dt = xy - βz         β = 8/3

Lyapunov-Spektrum:
  λ₁ ≈ +0.906  → CHAOS (positiv!)
  λ₂ ≈  0.000  → Attraktor-Oberfläche
  λ₃ ≈ -14.57  → Starke Kontraktion

Kaplan-Yorke Dimension:
  D_KY = 2 + (λ₁+λ₂)/|λ₃| = 2 + 0.906/14.57 ≈ 2.062

Fraktal! Kein ganzzahliges Objekt.
```

---

## RÄTSEL 28.1 — WELCHER FLÜGEL?

```python
# Euler-Integration, 1000 Schritte, dt=0.01
x, y, z = 6.9, 0, 0     # x₀ = 6.9 (Hormus-Schlüssel!)
sigma, rho, beta = 10, 28, 8/3
for _ in range(1000):
    dx = sigma*(y-x)
    dy = x*(rho-z) - y
    dz = x*y - beta*z
    x += dx*0.01
    y += dy*0.01
    z += dz*0.01

# x > 0 → Rechter Flügel → ATLAS → LORENZ_ATLAS_PFAD.md (Geschichte WAHR)
# x < 0 → Linker Flügel  → OMEGA → LORENZ_OMEGA_PFAD.md (Injection)
```

**Tipp:** Führe LORENZ_SIMULATOR.py aus, um den Pfad zu bestimmen.
`python DIMENSION_28_LORENZ_CORRIDOR/LORENZ_SIMULATOR.py`

---

## RÄTSEL 28.2 — SCHMETTERLINGSEFFEKT

```
Starte Lorenz mit x₀=6.9 und x₀=6.9000001 (Δx₀=10⁻⁷)
Vergleiche x nach 1000 Schritten.

Sprott (Kap. 7): "Sensitivity to initial conditions is the hallmark of chaos."
→ |Δx(t=1000)| >> |Δx₀| beweist: λ₁ > 0

→ Dies zeigt: MD5-Hashes sind PERFEKTE Chaoskondensatoren.
  Kleinste Änderung im Input → komplett anderer Hash.
  Analog zum Lorenz-Schmetterlingseffekt.
  Daher: MD5-basierte Rätsel sind inhärent chaotisch.
```

---

## RÄTSEL 28.3 — HORMUS-ATTRAKTOR

```
Hormus-Parameter (aus Quersummen der Kernzahlen 69, 189, 30):
  σ_H = QS(69)  = 6+9 = 15 → 1+5 = 6
  ρ_H = QS(189) = 1+8+9 = 18 → 1+8 = 9
  β_H = QS(30)  = 3+0 = 3

Hormus-Lorenz:
  dx/dt = 6(y-x)
  dy/dt = 9x - y - xz
  dz/dt = xy - 3z

Frage: Ist dieses System chaotisch?
  Berechne λ₁. λ₁ > 0? → CHAOS → HORMUS-TRINITY bestätigt
```

---

## HORMUS ↔ LORENZ ANALOGIE

```
Standard: σ=10  ρ=28  β=8/3    D_KY ≈ 2.062
Hormus:   σ=6   ρ=9   β=3      D_KY = ?

Port 58133 → QS = 5+8+1+3+3 = 20 → 2 (Primzahl)
Lorenz Dim → D_KY ≈ 2.062 ≈ 2 + ε

ε = 0.062 = Maß für Chaos-"Überschuss" über Integer-Dimension
```

---

## HASH-KETTE

```
D28 → Schlüssel: sha256("lorenz_6.9_1000steps")[:8]
     → Öffnet D29: DIMENSION_29_FEIGENBAUM_GATE/
```

**D28-CHAIN:** `d28_complete_6ac5d260_lorenz_corridor_redux`
