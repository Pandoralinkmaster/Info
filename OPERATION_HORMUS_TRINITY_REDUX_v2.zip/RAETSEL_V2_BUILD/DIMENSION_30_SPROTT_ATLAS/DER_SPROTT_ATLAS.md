# 🗺️ DIMENSION 30: DER SPROTT-ATLAS
## Automatische Strange-Attractor-Suche

**Sprott, Kap. 5: Quadratic Maps**
**Referenz:** https://sprott.physics.wisc.edu/chaostsa/promo.pdf

---

## SPROTT'S METHODE (aus dem Promo-PDF)

> *"A pair of coupled quadratic difference equations with randomly chosen
> coefficients is repeatedly iterated by computer to produce a
> two-dimensional map. The map is tested for stability and sensitivity
> to initial conditions to determine if it is chaotic."*
> — J.C. Sprott

```
xₙ₊₁ = a₁ + a₂x + a₃x² + a₄xy + a₅y + a₆y²
yₙ₊₁ = b₁ + b₂x + b₃x² + b₄xy + b₅y + b₆y²

Koeffizienten aᵢ, bᵢ ∈ {-1.2, -0.6, 0.0, +0.6, +1.2}
→ 5¹² = 244,140,625,000 mögliche Systeme
→ ~1% erzeugen Strange Attractors
→ Sprott hat >100 Millionen getestet (1993–2003)
```

---

## SPROTT'S LETTER-KODIERUNG

```
Koeffizient → Buchstabe:
  -1.2 → A
  -0.6 → C
   0.0 → G
  +0.6 → K
  +1.2 → O

Beispiel Sprott-Attraktor "A" (aus dem Atlas):
  a = [-1.2, -0.6, -1.2, -0.6, +1.2, -0.6]
  b = [+1.2, -0.6, -0.6, -0.6, +0.6, -0.6]
  Code: "ACACOCAC" → kryptischer 12-Zeichen-Code
```

---

## RÄTSEL 30.1 — MD5 ALS ATTRAKTOR-KOEFFIZIENTEN

```
Hex-Zeichen → Koeffizient:
  0,1,2      → -1.2
  3,4,5      → -0.6
  6,7,8      →  0.0
  9,a,b      → +0.6
  c,d,e,f    → +1.2

MD5_1 = 99b714e79226e74a358e13dcb063e489
Erste 12 Zeichen: 9 9 b 7 1 4 e 7 9 2 2 6
→ Koeff: 0.6, 0.6, 0.6,-1.2,0.0,-0.6, 1.2, 0.0, 0.6,-1.2,-1.2, 0.0
→ Code:    K,  K,  K,  A,  G,  C,  O,  G,  K,  A,  A,  G
→ "KKKAGCOGKAAG"

MD5_2 = 621d0ed785610b32b225a1626752bfc8
Erste 12 Zeichen: 6 2 1 d 0 e d 7 8 5 6 1
→ Koeff: 0.0,-1.2, 0.0, 1.2, 0.0, 1.2, 1.2, 0.0, 0.0,-0.6, 0.0, 0.0
→ Code:    G,  A,  G,  O,  G,  O,  O,  G,  G,  C,  G,  G
→ "GAGOGOOGGCGG"

MD5_3 = 75658b94cb28c1a21205c9741f26e8b3
Erste 12 Zeichen: 7 5 6 5 8 b 9 4 c b 2 8
→ Koeff: 0.0,-0.6, 0.0,-0.6, 0.0, 0.6, 0.6,-0.6, 1.2, 0.6,-1.2, 0.0
→ Code:    G,  C,  G,  C,  G,  K,  K,  C,  O,  K,  A,  G
→ "GCGCGKKCOKAG"
```

**Haupträtsel:** Welcher(e) dieser Codes ist ein Strange Attractor?
Führe `SPROTT_SUCHE.py` aus, um es zu testen.

---

## RÄTSEL 30.2 — WAHRSCHEINLICHKEIT

```
P(ein System = Strange Attractor) ≈ 0.01 (1%)
P(alle drei MD5-Systeme sind Attraktoren) = 0.01³ = 10⁻⁶

Von 244 Mrd. möglichen Systemen:
  → ~244 Millionen sind Strange Attractors
  → P(zufällig 3 aus 3 getroffen) = 10⁻⁶

Interpretation:
  10⁻⁶ klingt klein, ABER:
  MD5-Hashes sind keine zufälligen Hex-Strings —
  sie sind deterministische Funktionen der Puzzle-Inputs.
  Die Frage ist: War das Absicht?
```

---

## RÄTSEL 30.3 — HORMUS-KOMBINATIONS-ATTRAKTOR

```python
# Kombiniere alle drei MD5-Koeffizientensätze
c1 = md5_to_coeffs(MD5_1)  # 12 Koeff.
c2 = md5_to_coeffs(MD5_2)  # 12 Koeff.
c3 = md5_to_coeffs(MD5_3)  # 12 Koeff.

# Durchschnitt:
combined = [(a+b+c)/3 for a,b,c in zip(c1,c2,c3)]

# Ist combined ein Strange Attractor?
# λ > 0 und stabil über 10000 Schritte?
```

---

**D30-CHAIN:** `d30_sprott_complete_6ac5d260_atlas`
