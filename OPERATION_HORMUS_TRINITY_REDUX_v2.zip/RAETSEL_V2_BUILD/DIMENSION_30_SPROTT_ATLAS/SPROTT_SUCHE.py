#!/usr/bin/env python3
"""
SPROTT ATTRAKTOR-SUCHE — DIMENSION 30
Operation Hormus-Trinity Redux
Basiert auf: J.C. Sprott, Chaos and Time-Series Analysis, Kap. 5
Promo-PDF: https://sprott.physics.wisc.edu/chaostsa/promo.pdf

Finn Jona Thorsten Lischke — ABSOLUTE SOVEREIGN
"""
import hashlib
import math
import random

MD5_KEYS = [
    "99b714e79226e74a358e13dcb063e489",  # MD5_1
    "621d0ed785610b32b225a1626752bfc8",  # MD5_2
    "75658b94cb28c1a21205c9741f26e8b3",  # MD5_3
]

LETTERS = "ACGKO"
VALS = [-1.2, -0.6, 0.0, 0.6, 1.2]


def hex_to_coeff(h):
    """Konvertiert Hex-Zeichen zu Sprott-Koeffizient."""
    v = int(h, 16)
    if v <= 2:  return -1.2
    elif v <= 5: return -0.6
    elif v <= 8: return 0.0
    elif v <= 11: return 0.6
    else: return 1.2


def coeff_to_letter(c):
    """Konvertiert Koeffizient zu Sprott-Buchstabe."""
    idx = round((c + 1.2) / 0.6)
    return LETTERS[min(max(idx, 0), 4)]


def md5_to_coeffs(md5):
    """Extrahiert 12 Koeffizienten aus MD5-Hash."""
    return [hex_to_coeff(c) for c in md5[:12]]


def qmap(x, y, a, b):
    """Quadratische Abbildung."""
    xn = a[0]+a[1]*x+a[2]*x*x+a[3]*x*y+a[4]*y+a[5]*y*y
    yn = b[0]+b[1]*x+b[2]*x*x+b[3]*x*y+b[4]*y+b[5]*y*y
    return xn, yn


def simulate_sprott(coeffs, steps=12000, x0=0.1, y0=0.1):
    """Iteriert die quadratische Abbildung."""
    a, b = coeffs[:6], coeffs[6:12]
    x, y = x0, y0
    trajectory = []
    for i in range(steps):
        x, y = qmap(x, y, a, b)
        if math.isnan(x) or math.isnan(y) or abs(x) > 1e7 or abs(y) > 1e7:
            return None  # Divergiert
        if i > 300:
            trajectory.append((x, y))
    return trajectory


def lyapunov_sprott(coeffs, steps=2500, eps=1e-5):
    """Lyapunov-Exponent der quadratischen Abbildung."""
    a, b = coeffs[:6], coeffs[6:12]
    x1, y1 = 0.1, 0.1
    x2, y2 = 0.1+eps, 0.1
    lam = 0.0
    for _ in range(steps):
        x1n, y1n = qmap(x1, y1, a, b)
        x2n, y2n = qmap(x2, y2, a, b)
        if any(math.isnan(v) or abs(v) > 1e7 for v in [x1n, y1n, x2n, y2n]):
            break
        d = math.sqrt((x2n-x1n)**2 + (y2n-y1n)**2)
        if d < 1e-20:
            break
        lam += math.log(d / eps)
        # Rescale
        s = eps / d
        x2 = x1n + (x2n-x1n)*s
        y2 = y1n + (y2n-y1n)*s
        x1, y1 = x1n, y1n
    return lam / steps


def test_md5_attractors():
    """Testet alle drei MD5-Hashes als Attraktor-Koeffizienten."""
    results = []
    for i, md5 in enumerate(MD5_KEYS, 1):
        coeffs = md5_to_coeffs(md5)
        code = "".join(coeff_to_letter(c) for c in coeffs)

        # Test: a=[0:6], b=[6:12]
        # (Wir haben nur 12 Koeff → a=first6, b=next6)
        traj = simulate_sprott(coeffs)
        is_attractor = traj is not None

        lam = lyapunov_sprott(coeffs) if is_attractor else float('nan')
        is_chaotic = is_attractor and lam > 0.01

        status = "STRANGE ATTRACTOR" if is_chaotic else ("STABIL" if is_attractor else "DIVERGIERT")
        results.append({
            "md5": md5[:16]+"...",
            "code": code,
            "attractor": is_attractor,
            "chaotic": is_chaotic,
            "lyapunov": lam,
            "status": status
        })
    return results


def hormus_combination():
    """Kombiniert alle drei MD5-Koeffizientensätze."""
    c1 = md5_to_coeffs(MD5_KEYS[0])
    c2 = md5_to_coeffs(MD5_KEYS[1])
    c3 = md5_to_coeffs(MD5_KEYS[2])
    combined = [(a+b+c)/3.0 for a, b, c in zip(c1, c2, c3)]
    code = "".join(coeff_to_letter(c) for c in combined)
    traj = simulate_sprott(combined)
    lam = lyapunov_sprott(combined) if traj else float('nan')
    return combined, code, traj is not None, lam


def random_search(n=500, seed=42):
    """Zufällige Attraktor-Suche (wie Sprott's originale Methode)."""
    random.seed(seed)
    found = []
    for trial in range(n):
        coeffs = [random.choice(VALS) for _ in range(12)]
        traj = simulate_sprott(coeffs, steps=5000)
        if traj:
            lam = lyapunov_sprott(coeffs)
            if lam > 0.05:
                code = "".join(coeff_to_letter(c) for c in coeffs)
                found.append({"code": code, "lyapunov": lam, "trial": trial})
    return found


if __name__ == "__main__":
    print("=" * 65)
    print("SPROTT ATTRAKTOR-SUCHE — DIMENSION 30")
    print("Sprott, Kap. 5: Quadratic Maps")
    print("=" * 65)

    # Test MD5-Koeffizienten
    print("\n[D30.1] MD5 als Attraktor-Koeffizienten:")
    results = test_md5_attractors()
    for i, r in enumerate(results, 1):
        print(f"  MD5_{i}: Code={r['code']} | λ={r['lyapunov']:.4f} | {r['status']}")

    # Hormus-Kombination
    comb, code, is_att, lam = hormus_combination()
    print(f"\n[D30.3] Hormus-Kombination: Code={code} | λ={lam:.4f} | {'ATTRACTOR' if is_att else 'DIVERGIERT'}")

    # Zufällige Suche (Sprott-Methode)
    print(f"\n[D30] Sprott-Methode: 500 Zufalls-Systeme testen...")
    found = random_search(500)
    print(f"  Gefundene Strange Attractors: {len(found)} ({len(found)/5:.1f}%)")
    if found:
        best = max(found, key=lambda x: x['lyapunov'])
        print(f"  Stärkster Attraktor: Code={best['code']} | λ={best['lyapunov']:.4f}")

    chain = hashlib.sha256("_".join(r['code'] for r in results).encode()).hexdigest()
    print(f"\n[D30] Chain-Hash: {chain}")
    print(f"[D30] D31-Schlüssel: {chain[:8]}")
    print(f"\n→ Weiter: DIMENSION_31_ERROR_MATRIX/")
