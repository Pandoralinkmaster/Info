# master_ssd_legal_project – Übergabe aus aktuellem Chat

## 1. Erkannter Projektname

**Projektname:** `master_ssd_legal_project`

**Quelle:** aus Chat erkannt: mehrere erzeugte ZIP-Dateien und README-/Paketnamen beginnen mit master_ssd_legal_project; Drive-Kontext zusätzlich Pandora.link

Zusätzlich wurde aus dem Drive-Kontext der Name **Pandora.link** erkannt. Dieser Name wurde als Projekt-/App-Registry-Kontext behandelt, während die erzeugten ZIP-Dateien und Paketnamen im Chat überwiegend `master_ssd_legal_project...` verwenden.

## 2. Projektziel

Ziel ist ein legales Projektpaket für eine Android-/SSD-Key-basierte App-Plattform:

- Samsung Galaxy S24 Ultra läuft weiterhin mit normalem Android/One UI.
- Eine externe M.2-SSD dient als Hardware-Key und Datenträger.
- Master-/Admin-Funktionen werden nur innerhalb der eigenen App freigeschaltet.
- OpenAI ist als KI-System vorgesehen, ohne API-Schlüssel im ZIP zu speichern.
- Shop-, Wissens-, Backup-, Audit-, Link-, Post- und App-Registry-Module sind als Quellcode-/Projektstruktur vorbereitet.
- Sichtbare Drive-Metadaten wurden legal als DriveArchive-/ArchiveImport-Module integriert.

## 3. Aktueller Stand aus diesem Chat

In diesem Chat wurden mehrere Projekt-ZIPs erzeugt:

- `master_ssd_legal_project.zip`
- `master_ssd_legal_project_v2.zip`
- `master_ssd_legal_project_v3_full.zip`
- `master_ssd_legal_project_v4_openai_apps.zip`
- `master_ssd_legal_project_v5_drive_integrated.zip`

Die aktuellste Version ist:

`master_ssd_legal_project_v5_drive_integrated.zip`

Diese Übergabe-ZIP enthält die erzeugten ZIPs, die verfügbaren Screenshots/Bilder und eine extrahierte Kopie der aktuellen v5-Dateien unter:

`generated/latest_v5_extracted/`

## 4. Wichtige Entscheidungen

- Hacking, Fremdzugriff, Umgehung fremder Logins oder Übernahme fremder Systeme wurden ausgeschlossen.
- Die SSD wird als Hardware-Key + Datenspeicher umgesetzt, nicht als bootbares Samsung-Betriebssystem.
- Es wird keine Samsung-Firmware und keine One-UI-Kopie verteilt.
- OpenAI ist als KI-System vorgesehen, aber Zugangsdaten werden nicht in der App oder in dieser Übergabe gespeichert.
- KYC/Ausweisprüfung ist für den Start nicht nötig und bleibt nur als spätere optionale Erweiterung vorbereitet.
- Der Drive-Ordner wurde als `Pandora.link` erkannt und enthält sichtbare ZIP-Segmente wie `.000`, `.001`, `.002`; der Inneninhalt konnte hier nicht entpackt werden.
- Legale Drive-Integration erfolgte über Metadaten, Dateinamenmuster und App-Modulableitungen.

## 5. Vorhandene Dateien und Bedeutung

Wichtige Übergabedateien im Wurzelordner:

- `README.md`: diese Einstiegsdatei
- `project_identity.json`: maschinenlesbare Projektidentität
- `chat_summary.md`: strukturierte Chat-Zusammenfassung
- `file_manifest.json`: vollständiges Datei-Manifest
- `file_manifest.csv`: Manifest als CSV
- `technical_notes.md`: technische Details und Befehle
- `known_issues.md`: bekannte Probleme und Workarounds
- `todos.md`: offene Aufgaben
- `security_notes.md`: Sicherheitsnotizen
- `next_chat_instructions.md`: Arbeitsanweisung für neuen Chat

Weitere Ordner:

- `originals/images/`: im Chat hochgeladene Screenshots/Bilder
- `generated/zips/`: im Chat erzeugte ZIP-Pakete
- `generated/latest_v5_extracted/`: extrahierter Inhalt der neuesten v5-ZIP
- `exports/`: zentrale Exportkopie der neuesten v5-ZIP
- `notes/`: zusätzliche Notizen

## 6. Offene Aufgaben

Die wichtigsten offenen Aufgaben sind in `todos.md` zusammengefasst. Kurzfassung:

- v5-Projekt lokal entpacken und prüfen.
- Android-Projekt in Android Studio öffnen und bauen.
- SSD als exFAT formatieren und `MASTER_KEY/` + `DATA/` auf die SSD kopieren.
- OpenAI-Zugang über sichere Backend-Konfiguration ergänzen.
- Alle Drive-ZIP-Segmente lokal herunterladen und mit 7-Zip zusammensetzen.
- Nach lokalem Entpacken des Drive-Archivs dessen Inhalte erneut analysieren und legal integrieren.

## 7. Bekannte Probleme

Siehe `known_issues.md`. Hauptproblem:

Der Drive-Ordner enthält ein gesplittetes ZIP-Archiv. In dieser Chat-Umgebung konnten die Rohsegmente nicht vollständig heruntergeladen, zusammengesetzt und entpackt werden. Es wurde daher nur mit zugänglichen Metadaten gearbeitet.

## 8. Technische Details

Siehe `technical_notes.md`.

Kurzüberblick:

- Android/Kotlin-Projekt unter `generated/latest_v5_extracted/.../app_android/`
- Python-Backend unter `generated/latest_v5_extracted/.../backend_python/`
- SQLite-Schema unter `database/`
- OpenAI-Adapter unter `backend_python/openai_adapter.py`
- App-Registry unter `config/app_registry.json`
- Drive-Analyse unter `drive_analysis/`
- Segmentprüfer unter `scripts/check_zip_segments.py`

## 9. Sicherheitsnotizen

Siehe `security_notes.md`.

Wichtig: Diese Übergabe enthält Originaldateien und generierte ZIPs aus dem aktuellen Chat. Vor Weitergabe an Dritte sollten insbesondere Konfigurationsdateien, SSD-Key-Demo-Dateien und ZIP-Inhalte geprüft werden.

## 10. Anleitung für einen neuen Chat

Ein neuer Chat sollte:

1. Diese ZIP entpacken.
2. `README.md`, `project_identity.json`, `chat_summary.md`, `file_manifest.json` und `security_notes.md` lesen.
3. Die neueste Projektversion in `generated/latest_v5_extracted/` prüfen.
4. Keine Annahmen über nicht enthaltene oder nicht zugängliche Dateien treffen.
5. Mit `todos.md` weiterarbeiten.

## 11. Nicht zugängliche Daten

Nicht zugänglich bzw. nicht vollständig auswertbar waren:

- alte Chats außerhalb dieses aktuellen Verlaufs
- nicht hochgeladene lokale Dateien
- der echte Inneninhalt des gesplitteten Drive-ZIP-Archivs
- private externe Projektbereiche außerhalb der sichtbaren Drive-Metadaten
- OpenAI-Zugangsdaten oder produktive Schlüssel

Diese Einschränkungen sind bewusst dokumentiert, damit im nächsten Chat keine falschen Annahmen getroffen werden.
