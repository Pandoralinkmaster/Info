# Anleitung für den nächsten Chat

Bitte diese ZIP als vollständige Übergabe aus dem vorherigen Chat behandeln.

## Vorgehen

1. ZIP entpacken.
2. `README.md` lesen.
3. `project_identity.json` prüfen.
4. `chat_summary.md` lesen.
5. `file_manifest.json` oder `file_manifest.csv` verwenden, um alle Dateien zu verstehen.
6. Danach relevante Originaldateien analysieren.
7. Die neueste Projektversion unter `generated/latest_v5_extracted/` prüfen.
8. Keine Behauptungen über Dateien, alte Chats oder externe Projektbereiche aufstellen, die nicht in dieser ZIP enthalten sind.
9. Sicherheitsnotizen beachten.
10. Mit den offenen TODOs fortfahren.

## Regeln

- Keine Annahmen über nicht vorhandene Dateien treffen.
- Fehlende Informationen ehrlich benennen.
- Sensible Inhalte nicht unnötig in Antworten wiederholen.
- Originaldateien nicht verändern, wenn der Nutzer nicht ausdrücklich eine bereinigte Version verlangt.
- Keine geheimen Werte aus Originaldateien in neue Zusammenfassungen kopieren.
- Projektname aus `project_identity.json` verwenden.
- Drive-Inhalte nur als vollständig analysiert behandeln, wenn die ZIP-Segmente lokal entpackt wurden.

## Empfohlene nächste Schritte

1. Im v5-Projekt `scripts/validate_project.py` ausführen.
2. Alle Drive-Segmente lokal herunterladen.
3. Segmentvollständigkeit prüfen:
   `python scripts/check_zip_segments.py <download_ordner>`
4. Wenn vollständig, Archiv mit 7-Zip ab `.000` entpacken.
5. Entpackte Inhalte erneut analysieren.
6. Nur legale und eigene/erlaubte Funktionen integrieren.
7. Android-Projekt in Android Studio bauen.
8. OpenAI über sicheres Backend anbinden.
