# TODOs

## Offen

- [ ] Übergabe-ZIP entpacken und `README.md` lesen.
- [ ] `project_identity.json`, `chat_summary.md`, `file_manifest.json` und `security_notes.md` prüfen.
- [ ] Neueste v5-Version unter `generated/latest_v5_extracted/` prüfen.
- [ ] Im v5-Projekt `python scripts/validate_project.py` ausführen.
- [ ] Android-Projekt `app_android/` in Android Studio öffnen.
- [ ] Eigene SSD als exFAT formatieren.
- [ ] `MASTER_KEY/` und `DATA/` auf die SSD kopieren.
- [ ] Produktiven SSD-Key erzeugen.
- [ ] Eigene OpenAI-Backend-Konfiguration erstellen, ohne Schlüssel in Android-Code zu speichern.
- [ ] Alle Drive-ZIP-Segmente lokal herunterladen.
- [ ] `scripts/check_zip_segments.py <download_ordner>` auf lokalem Drive-Download ausführen.
- [ ] Wenn vollständig, Drive-Archiv lokal entpacken.
- [ ] Entpackte Drive-Inhalte erneut analysieren und legal integrieren.
- [ ] Android UI weiter ausbauen.
- [ ] Produktive Vault-Verschlüsselung ergänzen.
- [ ] Später KYC/Payment nur über offizielle Anbieter anbinden.

## Optional

- [ ] Einheitliche App-Namensstrategie festlegen: `master_ssd_legal_project` vs. `Pandora.link`.
- [ ] CI/CD für Android und Python einrichten.
- [ ] Tests für Kotlin-Module ergänzen.
- [ ] Nutzeroberfläche für Pandora.app, Link.app, Post.app und DriveArchive.app ausbauen.
- [ ] Dokumentation ins Englische übersetzen.
- [ ] Projekt in ein Git-Repository überführen.

## Erledigt aus diesem Chat

- [x] Gefährliche oder nicht erlaubte Anforderungen in legale Alternativen überführt.
- [x] SSD-Key-Konzept dokumentiert.
- [x] Android-Quellstruktur erstellt.
- [x] Python-Backend erstellt.
- [x] OpenAI-Adapter vorbereitet.
- [x] KYC als später optional markiert.
- [x] Pandora.app, Link.app und Post.app als Module integriert.
- [x] Drive-Metadaten analysiert und DriveArchive-/ArchiveImport-Module ergänzt.
- [x] Mehrere Projekt-ZIPs erstellt.
- [x] v5-Projekt-ZIP erstellt und validiert.
- [x] Übergabe-ZIP mit Manifesten und Zusammenfassungen erstellt.
