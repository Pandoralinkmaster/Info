# Sicherheitsnotizen

## Allgemeine Hinweise

Diese ZIP enthält Originaldateien und generierte Dateien aus dem aktuellen Chat. Originaldateien wurden nicht absichtlich gekürzt oder bereinigt. Vor Weitergabe an Dritte sollte der Inhalt geprüft werden.

Keine Passwörter, Tokens, API-Keys oder privaten Zugangsdaten wurden absichtlich zusätzlich in diese neu erstellten Übergabedokumente geschrieben.

## Potenziell sensible Dateien

Die folgenden Dateitypen oder Pfade können projektspezifische oder sensible Konfiguration enthalten und sollten vor Veröffentlichung geprüft werden:

- `generated/zips/*.zip`: Enthält komplette generierte Projektpakete aus dem Chat.
- `exports/*.zip`: Exportkopie der aktuellen v5-Version.
- `generated/latest_v5_extracted/**/MASTER_KEY/ssd_identity.json`: Kann Demo-Key-/SSD-Key-Informationen enthalten.
- `generated/latest_v5_extracted/**/MASTER_KEY/public_fingerprint.txt`: Enthält Fingerprint-Daten.
- `generated/latest_v5_extracted/**/config/*.json`: Kann projektspezifische Konfiguration enthalten.
- `generated/latest_v5_extracted/**/BUILD_RESULT.json`: Enthält Build-/Testinformationen.
- `originals/images/*`: Screenshots können sichtbare UI-, Chat- oder Fehlermeldungsinformationen enthalten.

## OpenAI

OpenAI wurde als KI-System vorgesehen. Diese Übergabe enthält keinen produktiven OpenAI-API-Key. Falls später ein Key ergänzt wird, darf er nicht in öffentlichen ZIPs, App-Quellcode oder Screenshots geteilt werden.

## Dateinamen

Dateinamen wurden nicht verändert. Falls Dateinamen selbst sensible Informationen enthalten, sollten sie vor Weitergabe geprüft werden.

## Nicht geprüft oder nicht zugänglich

Nicht geprüft werden konnten:

- alte Chats außerhalb dieses Verlaufs
- nicht hochgeladene lokale Dateien
- externe Projektbereiche außerhalb des sichtbaren Drive-Ordners
- der Inneninhalt des gesplitteten Drive-ZIP-Archivs
- private OpenAI-/KYC-/Payment-Zugänge

## Hinweis zu Originaldateien

Die generierten Original-ZIPs wurden vollständig aufgenommen, soweit sie in dieser Chat-Umgebung verfügbar waren. Diese Zips können ihrerseits Dateien enthalten, die vor Weitergabe geprüft werden sollten.
