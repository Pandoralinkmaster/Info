INSERT OR IGNORE INTO users(email, role, two_factor_enabled, identity_verified, created_at)
VALUES('finn.jona.lischke@gmail.com', 'OWNER', 0, 0, '2026-05-29T05:21:15+00:00');

INSERT OR IGNORE INTO products(id, name, description, price_cents, currency, active, created_at, updated_at)
VALUES('p_demo_1', 'Demo Produkt', 'Beispielprodukt für den Shop', 999, 'EUR', 1, '2026-05-29T05:21:15+00:00', '2026-05-29T05:21:15+00:00');
