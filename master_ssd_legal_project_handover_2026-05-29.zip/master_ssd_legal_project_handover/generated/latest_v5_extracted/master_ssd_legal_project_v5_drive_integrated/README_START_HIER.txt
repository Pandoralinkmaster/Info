MASTER SSD LEGAL PROJECT v4 OPENAI + APPS
Erstellt: 2026-05-29T05:31:28+00:00

Diese Version ergänzt v3 um:
- OpenAI als vorgesehenes KI-System
- OpenAI-Adapter im Backend
- OpenAI-Service-Struktur in der Android-App
- App-Registry für Pandora.app, Link.app, Post.app und weitere Module
- KYC/Ausweisprüfung bleibt am Anfang deaktiviert und wird später als Erweiterung vorbereitet
- Drive-Informationen werden legal als Modulnamen/Projektstruktur integriert, soweit sichtbar und umsetzbar

Wichtig:
Die App enthält keine geheimen OpenAI-Zugangsdaten.
Der OpenAI-Zugang muss später sicher durch dich in der App/Backend-Konfiguration hinterlegt werden.
Ohne OpenAI-Zugang arbeitet das Wissensmodul lokal weiter.

Start:
1. docs/13_OPENAI_INTEGRATION.txt lesen
2. docs/14_APP_REGISTRY_PANDORA_LINK_POST.txt lesen
3. scripts/validate_project.py ausführen
4. backend_python/safe_backend.py testen
5. backend_python/openai_adapter.py optional testen, nachdem du OpenAI-Zugang konfiguriert hast
6. app_android/ in Android Studio öffnen


v5 DRIVE INTEGRATED:
- Drive-Zusammenfassung ergänzt
- Segmentmanifest .000-.064 ergänzt
- DriveArchive.app und ArchiveImport.app ergänzt
- Backend-Services für Drive-Manifest, Segmentprüfung und lokalen Import ergänzt
- Android-Module für Drive-Archiv und Importplanung ergänzt
- Scripts für Segmentprüfung ergänzt

Schnellprüfung:
python scripts/validate_project.py
python scripts/test_drive_modules.py
python scripts/check_zip_segments.py <lokaler_download_ordner>
