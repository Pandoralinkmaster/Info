from pathlib import Path
import sys

EXPECTED_COUNT = 65
BASE = "Ordner 1 (1).zip (1)"

def expected_names():
    return [f"{BASE}.{i:03d}" for i in range(EXPECTED_COUNT)]

def main():
    folder = Path(sys.argv[1]) if len(sys.argv) > 1 else Path(".")
    expected = set(expected_names())
    present = {p.name for p in folder.iterdir()} if folder.exists() else set()
    matching = {name for name in present if name.startswith(BASE + ".")}
    missing = sorted(expected - matching)
    extra = sorted(matching - expected)

    print(f"Ordner: {folder}")
    print(f"Erwartet: {len(expected)}")
    print(f"Gefunden: {len(matching & expected)}")
    print(f"Vollständig: {not missing}")
    if missing:
        print("Fehlende Teile:")
        for name in missing[:20]:
            print(" -", name)
        if len(missing) > 20:
            print(f" ... weitere {len(missing) - 20}")
    if extra:
        print("Unerwartete Teile:")
        for name in extra:
            print(" -", name)

    return 0 if not missing else 1

if __name__ == "__main__":
    raise SystemExit(main())
