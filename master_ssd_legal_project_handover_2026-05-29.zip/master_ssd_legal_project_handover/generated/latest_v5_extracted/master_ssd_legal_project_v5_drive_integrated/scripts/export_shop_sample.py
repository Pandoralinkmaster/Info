import json
from pathlib import Path
from datetime import datetime, UTC

ROOT = Path(__file__).resolve().parents[1]
products = json.loads((ROOT / "DATA" / "sample_products.json").read_text(encoding="utf-8"))
out_dir = ROOT / "DATA" / "shop_exports"
out_dir.mkdir(parents=True, exist_ok=True)
out = out_dir / "products_export.json"
out.write_text(json.dumps({
    "created_at": datetime.now(UTC).isoformat(),
    "products": products
}, ensure_ascii=False, indent=2), encoding="utf-8")
print("OK:", out)
