import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "backend_python"))

from drive_manifest_service import DriveManifestService
from zip_segment_validator import expected_segment_names, parse_segment_index
from archive_import_service import ArchiveImportService

def main():
    svc = DriveManifestService()
    assert len(svc.expected_filenames()) == 65
    assert svc.expected_filenames()[0].endswith(".000")
    assert svc.expected_filenames()[-1].endswith(".064")
    assert parse_segment_index("Ordner 1 (1).zip (1).000") == 0
    assert parse_segment_index("Ordner 1 (1).zip (1).064") == 64
    assert expected_segment_names()[10].endswith(".010")
    importer = ArchiveImportService()
    assert importer.scan_extracted_folder("__not_existing__") == []
    print("OK: Drive modules passed")

if __name__ == "__main__":
    main()
