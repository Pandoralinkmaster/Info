import zipfile, hashlib
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT.parent / "master_ssd_legal_project_v3_full.zip"

with zipfile.ZipFile(OUT, "w", zipfile.ZIP_DEFLATED) as z:
    for p in sorted(ROOT.rglob("*")):
        if p.is_file():
            z.write(p, p.relative_to(ROOT.parent))

print("ZIP:", OUT)
print("SIZE:", OUT.stat().st_size)
print("SHA256:", hashlib.sha256(OUT.read_bytes()).hexdigest())
