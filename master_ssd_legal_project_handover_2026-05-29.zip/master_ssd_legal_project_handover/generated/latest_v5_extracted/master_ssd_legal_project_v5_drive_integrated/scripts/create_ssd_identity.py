import json, secrets, hashlib
from pathlib import Path
from datetime import datetime, UTC

OWNER_EMAIL = "finn.jona.lischke@gmail.com"

def main():
    secret = secrets.token_hex(32)
    fingerprint = hashlib.sha256(secret.encode()).hexdigest()
    out_dir = Path("MASTER_KEY")
    out_dir.mkdir(exist_ok=True)
    payload = {
        "project": "Master SSD Legal Project",
        "version": "3.0.0",
        "owner_email": OWNER_EMAIL,
        "created_at": datetime.now(UTC).isoformat(),
        "key_type": "external_ssd_app_key",
        "private_secret": secret,
        "public_fingerprint": fingerprint
    }
    (out_dir / "ssd_identity.json").write_text(json.dumps(payload, indent=2), encoding="utf-8")
    (out_dir / "public_fingerprint.txt").write_text(fingerprint + "\n", encoding="utf-8")
    print("OK: SSD identity created")
    print("Fingerprint:", fingerprint)

if __name__ == "__main__":
    main()
