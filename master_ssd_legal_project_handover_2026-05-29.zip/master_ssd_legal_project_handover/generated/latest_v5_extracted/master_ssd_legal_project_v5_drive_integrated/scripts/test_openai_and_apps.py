import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "backend_python"))

from openai_adapter import OpenAIAdapter, OpenAIConfig
from app_registry import AppRegistry

def main():
    adapter = OpenAIAdapter(OpenAIConfig(enabled=False))
    assert "OpenAI ist vorbereitet" in adapter.summarize_local_note("Testnotiz")
    registry = AppRegistry()
    assert registry.find("pandora.app")
    assert registry.find("link.app")
    assert registry.find("post.app")
    print("OK: OpenAI adapter and app registry test passed")

if __name__ == "__main__":
    main()
