import json, sqlite3, subprocess, sys, zipfile, re
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

REQUIRED = [
    "README_START_HIER.txt",
    "GRUNDIDEE.txt",
    "MASTER_KEY/ssd_identity.json",
    "MASTER_KEY/public_fingerprint.txt",
    "config/app_config.json",
    "config/features_manifest.json",
    "config/legal_mode_config.json",
    "database/schema.sql",
    "database/seed.sql",
    "backend_python/safe_backend.py",
    "app_android/settings.gradle.kts",
    "app_android/build.gradle.kts",
    "app_android/app/build.gradle.kts",
    "app_android/app/src/main/AndroidManifest.xml",
    "app_android/app/src/main/java/com/example/masterssdlegal/MainActivity.kt",
    "drive_analysis/drive_folder_summary.json",
    "drive_analysis/inferred_zip_segments_manifest.json",
    "drive_analysis/DRIVE_ZUSAMMENFASSUNG.txt",
    "config/drive_integration_config.json",
    "backend_python/drive_manifest_service.py",
    "backend_python/zip_segment_validator.py",
    "backend_python/archive_import_service.py",
    "scripts/check_zip_segments.py",
    "scripts/test_drive_modules.py",
    "app_android/app/src/main/java/com/example/masterssdlegal/drive/DriveArchiveManifest.kt",
    "app_android/app/src/main/java/com/example/masterssdlegal/drive/ZipSegmentValidator.kt",
    "app_android/app/src/main/java/com/example/masterssdlegal/drive/ArchiveImportPlanner.kt",
    "config/openai_config.example.json",
    "config/app_registry.json",
    "backend_python/openai_adapter.py",
    "backend_python/app_registry.py",
    "app_android/app/src/main/java/com/example/masterssdlegal/ai/OpenAIService.kt",
    "app_android/app/src/main/java/com/example/masterssdlegal/apps/AppRegistry.kt",

]

RISKY_PATTERNS = [
    r"\bhacken\b",
    r"\bhack\b",
    r"fremde accounts übernehmen",
    r"token auslesen",
    r"schadsoftware",
    r"credential extraction",
]

def add(errors, message):
    errors.append(message)

def check_required(errors):
    for rel in REQUIRED:
        if not (ROOT / rel).exists():
            add(errors, f"missing: {rel}")

def check_json(errors):
    for p in ROOT.rglob("*.json"):
        try:
            json.loads(p.read_text(encoding="utf-8"))
        except Exception as e:
            add(errors, f"json error {p.relative_to(ROOT)}: {e}")

def check_sql(errors):
    try:
        con = sqlite3.connect(":memory:")
        con.executescript((ROOT / "database/schema.sql").read_text(encoding="utf-8"))
        con.executescript((ROOT / "database/seed.sql").read_text(encoding="utf-8"))
        con.close()
    except Exception as e:
        add(errors, f"sql error: {e}")

def check_text(errors):
    for p in ROOT.rglob("*"):
        if not p.is_file():
            continue
        if p.name == "validate_project.py":
            continue
        if p.suffix.lower() not in [".txt", ".json", ".kt", ".py", ".sql", ".xml", ".kts", ".properties"]:
            continue
        text = p.read_text(encoding="utf-8", errors="ignore").lower()
        for pat in RISKY_PATTERNS:
            if re.search(pat, text):
                add(errors, f"risky wording in {p.relative_to(ROOT)}: {pat}")

def check_backend(errors):
    proc = subprocess.run([sys.executable, str(ROOT / "backend_python/safe_backend.py")],
                          cwd=str(ROOT / "backend_python"),
                          capture_output=True, text=True)
    if proc.returncode != 0:
        add(errors, "backend failed: " + proc.stdout + proc.stderr)

def main():
    errors = []
    check_required(errors)
    check_json(errors)
    check_sql(errors)
    check_text(errors)
    check_backend(errors)

    report = ROOT / "VALIDATION_REPORT.txt"
    if errors:
        report.write_text("VALIDATION FAILED\n" + "\n".join(errors) + "\n", encoding="utf-8")
        print(report.read_text(encoding="utf-8"))
        return 1
    report.write_text("VALIDATION PASSED\nNo errors detected by available static/runtime checks.\n", encoding="utf-8")
    print(report.read_text(encoding="utf-8"))
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
