from __future__ import annotations

from dataclasses import dataclass
from typing import List

@dataclass
class AppModule:
    id: str
    name: str
    enabled: bool
    description: str

class AppRegistry:
    def __init__(self):
        self.modules: List[AppModule] = [
            AppModule(
                id="pandora.app",
                name="Pandora.app",
                enabled=True,
                description="Haupt-App für SSD-Key, Admin, Shop, OpenAI-KI, Backup und Erweiterungen."
            ),
            AppModule(
                id="link.app",
                name="Link.app",
                enabled=True,
                description="Verwaltung eigener und erlaubter Links."
            ),
            AppModule(
                id="post.app",
                name="Post.app",
                enabled=True,
                description="Entwürfe, Produkttexte und eigene Posts."
            ),
        ]

    def list_enabled(self) -> List[AppModule]:
        return [m for m in self.modules if m.enabled]

    def find(self, module_id: str) -> AppModule | None:
        return next((m for m in self.modules if m.id == module_id), None)

def demo() -> None:
    registry = AppRegistry()
    assert registry.find("pandora.app")
    for module in registry.list_enabled():
        print(f"{module.id}: {module.name}")

if __name__ == "__main__":
    demo()
