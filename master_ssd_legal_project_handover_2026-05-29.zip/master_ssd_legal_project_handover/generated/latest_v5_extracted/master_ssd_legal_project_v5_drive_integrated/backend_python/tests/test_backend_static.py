import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import safe_backend as b

def test_backend_demo_functions():
    b.init_db()
    b.add_product(b.Product("test_product", "Test", "Beschreibung", 100))
    products = b.list_products()
    assert any(p["id"] == "test_product" for p in products)
    b.add_knowledge("Testwissen", "", "Beschreibung", "test")
    assert b.search_knowledge("Testwissen")
