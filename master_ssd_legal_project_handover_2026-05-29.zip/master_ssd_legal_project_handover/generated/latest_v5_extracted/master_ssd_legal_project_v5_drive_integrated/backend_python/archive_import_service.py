from __future__ import annotations

from pathlib import Path
import hashlib
import json
from datetime import datetime, UTC

ROOT = Path(__file__).resolve().parents[1]
IMPORT_LOG = ROOT / "DATA" / "archive_import_log.json"

class ArchiveImportService:
    """
    Imports metadata for files that the user has legally extracted locally.
    This service does not unpack the Drive archive by itself.
    """

    def scan_extracted_folder(self, folder: str | Path) -> list[dict]:
        folder = Path(folder)
        results = []
        if not folder.exists():
            return results
        for path in sorted(folder.rglob("*")):
            if path.is_file():
                digest = hashlib.sha256(path.read_bytes()).hexdigest()
                results.append({
                    "relative_path": str(path.relative_to(folder)),
                    "size_bytes": path.stat().st_size,
                    "sha256": digest
                })
        return results

    def write_import_log(self, folder: str | Path) -> Path:
        items = self.scan_extracted_folder(folder)
        payload = {
            "created_at": datetime.now(UTC).isoformat(),
            "source_folder": str(folder),
            "file_count": len(items),
            "items": items
        }
        IMPORT_LOG.parent.mkdir(parents=True, exist_ok=True)
        IMPORT_LOG.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
        return IMPORT_LOG

def demo() -> None:
    svc = ArchiveImportService()
    print("OK: archive import service ready")
    print("Files in missing demo folder:", len(svc.scan_extracted_folder("__not_existing__")))

if __name__ == "__main__":
    demo()
