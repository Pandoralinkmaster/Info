BACKEND

Start:
cd backend_python
python safe_backend.py

Erzeugt:
- backend_python/data/project.sqlite
- DATA/backups/backup_*.json
- Audit-Einträge
