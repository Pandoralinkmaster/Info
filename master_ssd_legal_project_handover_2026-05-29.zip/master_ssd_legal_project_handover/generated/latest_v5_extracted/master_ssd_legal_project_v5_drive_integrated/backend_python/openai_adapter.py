from __future__ import annotations

from dataclasses import dataclass
from typing import Optional

@dataclass
class OpenAIConfig:
    enabled: bool
    model: str = "gpt-5.5"
    api_key: Optional[str] = None

class OpenAIAdapter:
    """
    OpenAI adapter placeholder.

    This file intentionally does not contain a secret.
    Productive use should route Android -> your backend -> OpenAI.
    """

    def __init__(self, config: OpenAIConfig):
        self.config = config

    def is_ready(self) -> bool:
        return bool(self.config.enabled and self.config.api_key)

    def summarize_local_note(self, note: str) -> str:
        if not note.strip():
            raise ValueError("note required")
        if not self.is_ready():
            return (
                "OpenAI ist vorbereitet, aber noch nicht verbunden. "
                "Lokale Kurzfassung: " + note.strip()[:240]
            )
        # Productive implementation:
        # send note to OpenAI Responses API through a secure backend call.
        return "OpenAI response placeholder"

    def generate_product_text(self, product_name: str, facts: str) -> str:
        if not product_name.strip():
            raise ValueError("product_name required")
        if not self.is_ready():
            return f"{product_name}: Produkttext-Platzhalter. Fakten: {facts[:240]}"
        return "OpenAI product text placeholder"

def demo() -> None:
    adapter = OpenAIAdapter(OpenAIConfig(enabled=False))
    print(adapter.summarize_local_note("SSD-Key aktiviert eigene App-Funktionen."))
    print(adapter.generate_product_text("Demo Produkt", "Beispiel, lokal, legal."))

if __name__ == "__main__":
    demo()
