from __future__ import annotations

import json
from pathlib import Path
from dataclasses import dataclass

ROOT = Path(__file__).resolve().parents[1]
MANIFEST_PATH = ROOT / "drive_analysis" / "inferred_zip_segments_manifest.json"

@dataclass
class SegmentStatus:
    expected_count: int
    present_count: int
    missing: list[str]
    extra: list[str]

class DriveManifestService:
    def load_manifest(self) -> dict:
        return json.loads(MANIFEST_PATH.read_text(encoding="utf-8"))

    def expected_filenames(self) -> list[str]:
        manifest = self.load_manifest()
        return [s["filename"] for s in manifest["segments"]]

    def summarize(self) -> str:
        manifest = self.load_manifest()
        return (
            f"{manifest['folder']}: {manifest['segment_count']} erwartete ZIP-Segmente "
            f"für {manifest['archive_base_name']}."
        )

    def compare_local_folder(self, folder: str | Path) -> SegmentStatus:
        folder = Path(folder)
        expected = set(self.expected_filenames())
        present = {p.name for p in folder.iterdir()} if folder.exists() else set()
        relevant_present = {name for name in present if name.startswith("Ordner 1 (1).zip (1).")}
        return SegmentStatus(
            expected_count=len(expected),
            present_count=len(relevant_present & expected),
            missing=sorted(expected - relevant_present),
            extra=sorted(relevant_present - expected)
        )

def demo() -> None:
    svc = DriveManifestService()
    print(svc.summarize())
    assert len(svc.expected_filenames()) == 65

if __name__ == "__main__":
    demo()
