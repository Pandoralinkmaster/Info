from __future__ import annotations

import re
from pathlib import Path

PATTERN = re.compile(r"^Ordner 1 \(1\)\.zip \(1\)\.(\d{3})$")

def parse_segment_index(filename: str) -> int | None:
    match = PATTERN.match(filename)
    if not match:
        return None
    return int(match.group(1))

def expected_segment_names(count: int = 65) -> list[str]:
    return [f"Ordner 1 (1).zip (1).{i:03d}" for i in range(count)]

def validate_folder(folder: str | Path, count: int = 65) -> dict:
    folder = Path(folder)
    expected = set(expected_segment_names(count))
    present = {p.name for p in folder.iterdir()} if folder.exists() else set()
    matching = {name for name in present if parse_segment_index(name) is not None}
    return {
        "expected_count": len(expected),
        "matching_count": len(matching & expected),
        "missing": sorted(expected - matching),
        "unexpected": sorted(matching - expected),
        "complete": expected.issubset(matching)
    }

def demo() -> None:
    names = expected_segment_names()
    assert names[0].endswith(".000")
    assert names[-1].endswith(".064")
    print("OK: ZIP segment validator ready")

if __name__ == "__main__":
    demo()
