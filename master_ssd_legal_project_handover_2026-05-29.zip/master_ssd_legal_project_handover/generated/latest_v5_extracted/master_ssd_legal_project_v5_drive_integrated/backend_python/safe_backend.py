from __future__ import annotations

import json
import hashlib
import sqlite3
from dataclasses import dataclass, asdict
from pathlib import Path
from datetime import datetime, UTC

ROOT = Path(__file__).resolve().parents[1]
DB_PATH = Path(__file__).parent / "data" / "project.sqlite"
DB_PATH.parent.mkdir(parents=True, exist_ok=True)

def utc_now() -> str:
    return datetime.now(UTC).isoformat()

def connect() -> sqlite3.Connection:
    con = sqlite3.connect(DB_PATH)
    con.row_factory = sqlite3.Row
    return con

def init_db() -> None:
    schema = (ROOT / "database" / "schema.sql").read_text(encoding="utf-8")
    seed = (ROOT / "database" / "seed.sql").read_text(encoding="utf-8")
    with connect() as con:
        con.executescript(schema)
        con.executescript(seed)
        con.commit()

@dataclass
class Product:
    id: str
    name: str
    description: str
    price_cents: int
    currency: str = "EUR"
    active: bool = True

def add_product(product: Product) -> None:
    if not product.id.strip():
        raise ValueError("product id required")
    if not product.name.strip():
        raise ValueError("product name required")
    if product.price_cents < 0:
        raise ValueError("price must be non-negative")
    with connect() as con:
        con.execute("""
            INSERT OR REPLACE INTO products
            (id, name, description, price_cents, currency, active, created_at, updated_at)
            VALUES (?, ?, ?, ?, ?, ?, COALESCE((SELECT created_at FROM products WHERE id=?), ?), ?)
        """, (
            product.id, product.name, product.description, product.price_cents,
            product.currency, 1 if product.active else 0,
            product.id, utc_now(), utc_now()
        ))
        con.commit()

def list_products() -> list[dict]:
    with connect() as con:
        rows = con.execute("SELECT * FROM products ORDER BY name").fetchall()
        return [dict(r) for r in rows]

def add_knowledge(title: str, source_url: str, summary: str, tags: str = "") -> None:
    if not title.strip():
        raise ValueError("title required")
    if not summary.strip():
        raise ValueError("summary required")
    with connect() as con:
        con.execute("""
            INSERT INTO knowledge_items(title, source_url, summary, tags, created_at)
            VALUES (?, ?, ?, ?, ?)
        """, (title.strip(), source_url.strip(), summary.strip(), tags.strip(), utc_now()))
        con.commit()

def search_knowledge(query: str) -> list[dict]:
    q = f"%{query.strip()}%"
    with connect() as con:
        rows = con.execute("""
            SELECT * FROM knowledge_items
            WHERE title LIKE ? OR summary LIKE ? OR tags LIKE ?
            ORDER BY id DESC
        """, (q, q, q)).fetchall()
        return [dict(r) for r in rows]

def audit(actor_email: str, action: str, details: str = "") -> None:
    if "@" not in actor_email:
        raise ValueError("actor email invalid")
    if not action.strip():
        raise ValueError("action required")
    with connect() as con:
        con.execute("""
            INSERT INTO audit_log(actor_email, action, details, created_at)
            VALUES (?, ?, ?, ?)
        """, (actor_email, action, details, utc_now()))
        con.commit()

def create_backup() -> Path:
    backup_dir = ROOT / "DATA" / "backups"
    backup_dir.mkdir(parents=True, exist_ok=True)
    payload = {
        "created_at": utc_now(),
        "products": list_products(),
        "knowledge": search_knowledge(""),
    }
    raw = json.dumps(payload, indent=2, ensure_ascii=False).encode("utf-8")
    digest = hashlib.sha256(raw).hexdigest()
    out = backup_dir / f"backup_{digest[:12]}.json"
    out.write_bytes(raw)
    (backup_dir / f"backup_{digest[:12]}.sha256").write_text(digest + "\n", encoding="utf-8")
    audit("system@local", "backup_created", out.name)
    return out

def demo() -> None:
    init_db()
    add_product(Product("p_demo_backend", "Backend Demo", "Lokales Beispielprodukt", 1299))
    add_knowledge("Lokales Wissensmodul", "", "Speichert bestätigte Notizen und Zusammenfassungen.", "wissen, lokal")
    audit("system@local", "demo_run", "Backend demo completed")
    backup = create_backup()
    assert backup.exists()
    assert list_products()
    assert search_knowledge("lokal")
    print("OK: backend demo passed")
    print("DB:", DB_PATH)
    print("Backup:", backup)

if __name__ == "__main__":
    demo()
