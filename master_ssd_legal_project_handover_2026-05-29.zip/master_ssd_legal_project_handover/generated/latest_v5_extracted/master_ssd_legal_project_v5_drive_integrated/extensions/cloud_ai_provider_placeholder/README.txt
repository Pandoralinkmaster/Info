cloud_ai_provider_placeholder

Status:
Vorbereitet, aber nicht aktiv.

Aktivierung:
Erst konfigurieren, prüfen und dann in config/features_manifest.json aktivieren.
