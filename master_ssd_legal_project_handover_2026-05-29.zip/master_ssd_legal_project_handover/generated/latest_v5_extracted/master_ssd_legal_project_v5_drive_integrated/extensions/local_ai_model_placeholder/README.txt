local_ai_model_placeholder

Status:
Vorbereitet, aber nicht aktiv.

Aktivierung:
Erst konfigurieren, prüfen und dann in config/features_manifest.json aktivieren.
