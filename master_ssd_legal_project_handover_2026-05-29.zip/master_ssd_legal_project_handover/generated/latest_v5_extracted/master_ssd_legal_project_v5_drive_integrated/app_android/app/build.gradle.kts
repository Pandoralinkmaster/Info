plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.example.masterssdlegal"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.example.masterssdlegal"
        minSdk = 26
        targetSdk = 35
        versionCode = 3
        versionName = "0.3.0-full"
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
}
