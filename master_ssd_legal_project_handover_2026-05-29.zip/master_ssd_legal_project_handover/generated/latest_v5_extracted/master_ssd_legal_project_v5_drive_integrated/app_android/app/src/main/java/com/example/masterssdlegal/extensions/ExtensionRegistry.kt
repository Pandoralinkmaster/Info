package com.example.masterssdlegal.extensions

data class ExtensionInfo(
    val id: String,
    val name: String,
    val enabled: Boolean,
    val note: String
)

class ExtensionRegistry {
    private val extensions = mutableListOf<ExtensionInfo>()

    fun register(info: ExtensionInfo) {
        require(info.id.isNotBlank()) { "Extension id required" }
        require(info.name.isNotBlank()) { "Extension name required" }
        extensions += info
    }

    fun list(): List<ExtensionInfo> = extensions.toList()
}
