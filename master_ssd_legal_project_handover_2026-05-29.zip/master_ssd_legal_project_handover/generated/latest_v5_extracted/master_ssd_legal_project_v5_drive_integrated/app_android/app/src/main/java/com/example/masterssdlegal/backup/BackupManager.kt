package com.example.masterssdlegal.backup

import java.security.MessageDigest

data class BackupResult(
    val ok: Boolean,
    val message: String,
    val checksum: String?
)

class BackupManager {
    fun createBackupPreview(payload: String): BackupResult {
        if (payload.isBlank()) {
            return BackupResult(false, "Kein Inhalt für Backup.", null)
        }
        val digest = MessageDigest.getInstance("SHA-256")
            .digest(payload.toByteArray())
            .joinToString("") { "%02x".format(it) }
        return BackupResult(true, "Backup-Vorschau erstellt.", digest)
    }
}
