package com.example.masterssdlegal.vault

data class VaultStatus(
    val ready: Boolean,
    val message: String
)

class VaultPlaceholder {
    fun status(): VaultStatus {
        return VaultStatus(
            ready = false,
            message = "Produktive Verschlüsselung ist als nächster Schritt vorgesehen."
        )
    }
}
