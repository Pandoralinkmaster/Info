package com.example.masterssdlegal.drive

class ZipSegmentValidator {
    fun missingSegments(presentFilenames: Set<String>): List<String> {
        return DriveArchiveManifest()
            .expectedSegments()
            .map { it.filename }
            .filter { it !in presentFilenames }
    }

    fun isComplete(presentFilenames: Set<String>): Boolean {
        return missingSegments(presentFilenames).isEmpty()
    }
}
