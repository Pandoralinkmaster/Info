package com.example.masterssdlegal.audit

import java.time.Instant

data class AuditEntry(
    val actorEmail: String,
    val action: String,
    val details: String,
    val createdAt: String = Instant.now().toString()
)

class AuditLog {
    private val entries = mutableListOf<AuditEntry>()

    fun record(entry: AuditEntry) {
        require(entry.actorEmail.contains("@")) { "Valid actor email required" }
        require(entry.action.isNotBlank()) { "Action required" }
        entries += entry
    }

    fun list(): List<AuditEntry> = entries.toList()
}
