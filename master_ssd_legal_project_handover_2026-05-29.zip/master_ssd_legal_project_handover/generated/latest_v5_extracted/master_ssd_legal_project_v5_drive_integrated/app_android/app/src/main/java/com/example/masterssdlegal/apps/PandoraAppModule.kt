package com.example.masterssdlegal.apps

class PandoraAppModule {
    fun info(): AppModule {
        return AppModule(
            id = "pandora.app",
            name = "Pandora.app",
            enabled = true,
            description = "Haupt-App für SSD-Key, Admin, Shop, OpenAI-KI, Backup und Erweiterungen."
        )
    }
}
