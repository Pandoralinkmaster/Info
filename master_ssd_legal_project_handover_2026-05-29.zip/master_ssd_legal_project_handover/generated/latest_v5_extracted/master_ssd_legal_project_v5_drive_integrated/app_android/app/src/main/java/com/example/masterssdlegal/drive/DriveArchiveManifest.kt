package com.example.masterssdlegal.drive

data class DriveArchiveSegment(
    val index: Int,
    val suffix: String,
    val filename: String,
    val present: Boolean = false
)

class DriveArchiveManifest {
    fun expectedSegments(): List<DriveArchiveSegment> {
        return (0..64).map { index ->
            val suffix = index.toString().padStart(3, '0')
            DriveArchiveSegment(
                index = index,
                suffix = suffix,
                filename = "Ordner 1 (1).zip (1).$suffix"
            )
        }
    }

    fun summary(): String {
        val segments = expectedSegments()
        return "Pandora.link Archiv: ${segments.size} erwartete ZIP-Segmente, Bereich .000 bis .064."
    }
}
