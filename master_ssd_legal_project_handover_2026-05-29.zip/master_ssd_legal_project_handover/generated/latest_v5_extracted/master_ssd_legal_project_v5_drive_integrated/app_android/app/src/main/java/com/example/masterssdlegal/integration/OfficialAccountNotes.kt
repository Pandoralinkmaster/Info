package com.example.masterssdlegal.integration

data class OfficialAccountNote(
    val serviceName: String,
    val officialUrl: String,
    val note: String
)

class OfficialAccountNotes {
    fun supercellNote(): OfficialAccountNote {
        return OfficialAccountNote(
            serviceName = "Supercell ID / Brawl Stars",
            officialUrl = "https://supercell.com/",
            note = "Nur eigene offizielle Kontonotizen und Links speichern."
        )
    }
}
