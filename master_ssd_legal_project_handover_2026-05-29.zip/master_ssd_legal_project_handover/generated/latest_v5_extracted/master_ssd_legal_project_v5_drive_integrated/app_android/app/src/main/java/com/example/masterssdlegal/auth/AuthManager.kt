package com.example.masterssdlegal.auth

enum class Role { OWNER, ADMIN, EDITOR, VIEWER }

data class User(
    val email: String,
    val role: Role,
    val twoFactorOk: Boolean,
    val identityVerified: Boolean
)

class AuthManager {
    private val ownerEmail = "finn.jona.lischke@gmail.com"

    fun canOpenMasterArea(user: User, hardwareKeyOk: Boolean): Boolean {
        return user.email.equals(ownerEmail, ignoreCase = true) &&
            user.role == Role.OWNER &&
            user.twoFactorOk &&
            user.identityVerified &&
            hardwareKeyOk
    }

    fun canEditShop(user: User): Boolean {
        return user.role == Role.OWNER || user.role == Role.ADMIN || user.role == Role.EDITOR
    }

    fun canViewAudit(user: User): Boolean {
        return user.role == Role.OWNER || user.role == Role.ADMIN
    }
}
