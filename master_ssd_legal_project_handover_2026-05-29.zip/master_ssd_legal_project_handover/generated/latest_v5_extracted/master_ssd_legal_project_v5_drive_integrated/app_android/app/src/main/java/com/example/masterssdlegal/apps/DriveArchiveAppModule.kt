package com.example.masterssdlegal.apps

class DriveArchiveAppModule {
    fun info(): AppModule {
        return AppModule(
            id = "drivearchive.app",
            name = "DriveArchive.app",
            enabled = true,
            description = "Verwaltet Drive-ZIP-Segmentmetadaten und lokale Rekonstruktionshinweise."
        )
    }
}
