package com.example.masterssdlegal.settings

class LocalSettings {
    private val values = mutableMapOf<String, String>()

    fun set(key: String, value: String) {
        require(key.isNotBlank()) { "Key required" }
        values[key] = value
    }

    fun get(key: String): String? = values[key]

    fun all(): Map<String, String> = values.toMap()
}
