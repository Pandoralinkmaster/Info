package com.example.masterssdlegal.storage

data class StoragePaths(
    val masterKeyDir: String = "MASTER_KEY",
    val vaultDir: String = "DATA/vault",
    val backupDir: String = "DATA/backups",
    val knowledgeDir: String = "DATA/ai_knowledge",
    val shopExportDir: String = "DATA/shop_exports",
    val auditExportDir: String = "DATA/audit_exports"
)
