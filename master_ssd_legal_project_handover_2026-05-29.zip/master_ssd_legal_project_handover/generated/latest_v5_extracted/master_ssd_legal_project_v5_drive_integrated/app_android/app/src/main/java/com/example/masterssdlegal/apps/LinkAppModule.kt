package com.example.masterssdlegal.apps

class LinkAppModule {
    fun info(): AppModule {
        return AppModule(
            id = "link.app",
            name = "Link.app",
            enabled = true,
            description = "Verwaltet eigene und erlaubte Links, Ressourcen und Support-Verweise."
        )
    }
}
