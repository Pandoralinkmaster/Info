package com.example.masterssdlegal.shop

class ShopRepository {
    private val products = linkedMapOf<String, Product>()

    fun upsert(product: Product) {
        require(product.id.isNotBlank()) { "Product id required" }
        require(product.name.isNotBlank()) { "Product name required" }
        require(product.priceCents >= 0) { "Price must be zero or positive" }
        products[product.id] = product
    }

    fun list(activeOnly: Boolean = false): List<Product> {
        return products.values.filter { !activeOnly || it.active }
    }

    fun find(id: String): Product? = products[id]

    fun deactivate(id: String) {
        val existing = products[id] ?: return
        products[id] = existing.copy(active = false)
    }
}
