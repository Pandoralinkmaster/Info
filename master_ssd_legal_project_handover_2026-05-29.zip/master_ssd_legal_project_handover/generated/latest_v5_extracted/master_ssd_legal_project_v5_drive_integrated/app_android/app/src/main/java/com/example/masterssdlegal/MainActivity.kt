package com.example.masterssdlegal

import android.app.Activity
import android.os.Bundle
import android.widget.TextView
import com.example.masterssdlegal.auth.AuthManager
import com.example.masterssdlegal.auth.Role
import com.example.masterssdlegal.auth.User
import com.example.masterssdlegal.security.HardwareKeyManager

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val configuredFingerprint = "DEMO_CONFIGURED_BY_APP_CONFIG"
        val detectedFingerprint: String? = null
        val keyStatus = HardwareKeyManager().checkKey(configuredFingerprint, detectedFingerprint)

        val demoUser = User(
            email = "finn.jona.lischke@gmail.com",
            role = Role.OWNER,
            twoFactorOk = false,
            identityVerified = false
        )
        val masterReady = AuthManager().canOpenMasterArea(demoUser, keyStatus.connected)

        val status = listOf(
            "Master SSD Legal App v0.3",
            "",
            "SSD-Key: ${keyStatus.message}",
            "Masterbereich bereit: $masterReady",
            "",
            "Nächste Schritte:",
            "1. SSD anschließen",
            "2. MASTER_KEY freigeben",
            "3. Sicherheitsprüfung aktivieren",
            "4. Shop und Wissen nutzen",
            "5. Backup erstellen"
        ).joinToString("\n")

        setContentView(TextView(this).apply {
            text = status
            textSize = 18f
            setPadding(32, 48, 32, 32)
        })
    }
}
