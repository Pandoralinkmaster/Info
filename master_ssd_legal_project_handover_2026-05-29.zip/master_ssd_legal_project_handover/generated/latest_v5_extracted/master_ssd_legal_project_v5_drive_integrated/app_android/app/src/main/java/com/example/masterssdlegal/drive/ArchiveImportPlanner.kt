package com.example.masterssdlegal.drive

data class ArchiveImportPlan(
    val ready: Boolean,
    val message: String
)

class ArchiveImportPlanner {
    fun planImport(allSegmentsPresent: Boolean): ArchiveImportPlan {
        return if (allSegmentsPresent) {
            ArchiveImportPlan(true, "Archivteile vollständig. Lokales Entpacken und Import möglich.")
        } else {
            ArchiveImportPlan(false, "Noch nicht alle Archivteile vorhanden. Erst alle Segmente lokal herunterladen.")
        }
    }
}
