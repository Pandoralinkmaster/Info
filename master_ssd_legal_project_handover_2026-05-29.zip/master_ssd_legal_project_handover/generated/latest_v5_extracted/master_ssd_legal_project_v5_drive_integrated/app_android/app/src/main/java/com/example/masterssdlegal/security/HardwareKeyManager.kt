package com.example.masterssdlegal.security

data class HardwareKeyStatus(
    val connected: Boolean,
    val fingerprint: String?,
    val message: String
)

class HardwareKeyManager {
    fun checkKey(configuredFingerprint: String?, detectedFingerprint: String?): HardwareKeyStatus {
        if (configuredFingerprint.isNullOrBlank()) {
            return HardwareKeyStatus(false, null, "Kein erlaubter Fingerprint konfiguriert.")
        }
        if (detectedFingerprint.isNullOrBlank()) {
            return HardwareKeyStatus(false, null, "SSD-Key noch nicht ausgewählt.")
        }
        val ok = configuredFingerprint == detectedFingerprint
        return HardwareKeyStatus(
            connected = ok,
            fingerprint = detectedFingerprint,
            message = if (ok) "SSD-Key gültig." else "SSD-Key passt nicht."
        )
    }
}
