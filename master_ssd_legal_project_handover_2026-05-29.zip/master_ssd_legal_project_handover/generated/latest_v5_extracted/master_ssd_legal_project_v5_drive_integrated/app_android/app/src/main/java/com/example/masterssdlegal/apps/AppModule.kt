package com.example.masterssdlegal.apps

data class AppModule(
    val id: String,
    val name: String,
    val enabled: Boolean,
    val description: String
)
