package com.example.masterssdlegal.apps

class PostAppModule {
    fun info(): AppModule {
        return AppModule(
            id = "post.app",
            name = "Post.app",
            enabled = true,
            description = "Verwaltet eigene Posts, Produkttexte, Notizen und Entwürfe."
        )
    }
}
