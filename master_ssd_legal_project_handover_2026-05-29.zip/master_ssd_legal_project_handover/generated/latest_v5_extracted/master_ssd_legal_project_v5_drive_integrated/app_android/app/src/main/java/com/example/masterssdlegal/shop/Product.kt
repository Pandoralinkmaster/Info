package com.example.masterssdlegal.shop

data class Product(
    val id: String,
    val name: String,
    val description: String,
    val priceCents: Int,
    val currency: String = "EUR",
    val active: Boolean = true
)
