package com.example.masterssdlegal.apps

class AppRegistry {
    private val modules = linkedMapOf<String, AppModule>()

    init {
        register(PandoraAppModule().info())
        register(LinkAppModule().info())
        register(PostAppModule().info())
        register(DriveArchiveAppModule().info())
        register(ArchiveImportAppModule().info())
    }

    fun register(module: AppModule) {
        require(module.id.isNotBlank()) { "Module id required" }
        require(module.name.isNotBlank()) { "Module name required" }
        modules[module.id] = module
    }

    fun listEnabled(): List<AppModule> {
        return modules.values.filter { it.enabled }
    }

    fun find(id: String): AppModule? = modules[id]
}
