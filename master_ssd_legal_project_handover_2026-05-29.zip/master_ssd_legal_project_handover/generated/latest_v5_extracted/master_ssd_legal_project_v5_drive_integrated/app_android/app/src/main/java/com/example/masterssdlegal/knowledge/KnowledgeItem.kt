package com.example.masterssdlegal.knowledge

data class KnowledgeItem(
    val title: String,
    val sourceUrl: String?,
    val summary: String,
    val tags: List<String>
)
