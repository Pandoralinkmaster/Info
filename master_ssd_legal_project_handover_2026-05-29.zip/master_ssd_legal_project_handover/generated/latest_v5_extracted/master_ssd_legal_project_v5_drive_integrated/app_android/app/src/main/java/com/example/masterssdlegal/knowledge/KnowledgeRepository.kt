package com.example.masterssdlegal.knowledge

class KnowledgeRepository {
    private val items = mutableListOf<KnowledgeItem>()

    fun add(item: KnowledgeItem) {
        require(item.title.isNotBlank()) { "Title required" }
        require(item.summary.isNotBlank()) { "Summary required" }
        items += item
    }

    fun search(query: String): List<KnowledgeItem> {
        val q = query.trim()
        if (q.isEmpty()) return items.toList()
        return items.filter {
            it.title.contains(q, ignoreCase = true) ||
            it.summary.contains(q, ignoreCase = true) ||
            it.tags.any { tag -> tag.contains(q, ignoreCase = true) }
        }
    }
}
