package com.example.masterssdlegal.ai

data class OpenAIServiceConfig(
    val enabled: Boolean = false,
    val model: String = "gpt-5.5",
    val backendRoute: String = "backend_proxy_recommended"
)

data class AIResult(
    val ok: Boolean,
    val text: String
)

class OpenAIService(
    private val config: OpenAIServiceConfig = OpenAIServiceConfig()
) {
    fun isReady(): Boolean {
        return config.enabled
    }

    fun summarizeLocalFallback(input: String): AIResult {
        if (input.isBlank()) {
            return AIResult(false, "Kein Text übergeben.")
        }
        if (!isReady()) {
            return AIResult(
                ok = true,
                text = "OpenAI ist vorbereitet, aber noch nicht verbunden. Lokale Vorschau: " + input.take(240)
            )
        }
        return AIResult(
            ok = true,
            text = "OpenAI-Service-Aufruf wird produktiv über ein sicheres Backend ausgeführt."
        )
    }
}
