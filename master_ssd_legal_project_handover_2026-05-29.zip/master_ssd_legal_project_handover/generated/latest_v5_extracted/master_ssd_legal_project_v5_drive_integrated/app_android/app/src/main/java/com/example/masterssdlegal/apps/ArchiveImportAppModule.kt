package com.example.masterssdlegal.apps

class ArchiveImportAppModule {
    fun info(): AppModule {
        return AppModule(
            id = "archiveimport.app",
            name = "ArchiveImport.app",
            enabled = true,
            description = "Importiert später lokal entpackte, erlaubte Dateien."
        )
    }
}
