# Bekannte Probleme

## Problem 1: Drive-ZIP konnte nicht vollständig entpackt werden
- Beschreibung: Der Drive-Ordner enthält segmentierte ZIP-Dateien wie `.000`, `.001`, `.002`, aber die Rohsegmente konnten in dieser Umgebung nicht vollständig heruntergeladen, zusammengesetzt und entpackt werden.
- Betroffene Dateien: Externe Drive-Dateien; in der Übergabe dokumentiert unter `drive_analysis/` in der extrahierten v5-Version.
- Ursache, falls bekannt: Zugriff über den aktuellen Connector lieferte Metadaten, aber keine vollständige lokale Segmentrekonstruktion.
- Lösung oder Workaround: Alle Teile lokal aus Drive herunterladen, in denselben Ordner legen und mit 7-Zip ab `.000` entpacken. Danach die entpackten Dateien erneut hochladen oder bereitstellen.
- Status: Offen.

## Problem 2: Keine fertige signierte Android-APK
- Beschreibung: Das Projekt enthält Android-Quellcode, aber keine produktiv signierte APK.
- Betroffene Dateien: `app_android/`
- Ursache, falls bekannt: Signieren muss mit einem eigenen Keystore/Entwickler-Setup erfolgen.
- Lösung oder Workaround: In Android Studio öffnen und APK mit eigenem Schlüssel bauen.
- Status: Offen.

## Problem 3: OpenAI noch nicht produktiv verbunden
- Beschreibung: OpenAI ist als KI-Anbieter vorgesehen, aber ohne Schlüssel oder Serverkonfiguration.
- Betroffene Dateien: `backend_python/openai_adapter.py`, `config/openai_config.example.json`, Android `OpenAIService.kt`
- Ursache, falls bekannt: Keine geheimen API-Schlüssel sollen in Übergabe- oder App-Dateien gespeichert werden.
- Lösung oder Workaround: Eigenes Backend konfigurieren und OpenAI-Zugang dort sicher speichern.
- Status: Offen.

## Problem 4: KYC, Payment und Vault-Verschlüsselung sind Platzhalter
- Beschreibung: Diese Funktionen sind vorbereitet, aber nicht produktiv aktiviert.
- Betroffene Dateien: `extensions/`, `docs/`, `config/features_manifest.json`
- Ursache, falls bekannt: Externe Anbieterzugänge und rechtliche Prüfung erforderlich.
- Lösung oder Workaround: Später offizielle Anbieter anbinden.
- Status: Optional/offen.

## Problem 5: Screenshots enthalten UI-Fehlermeldungen und Chat-Kontext
- Beschreibung: Die hochgeladenen Bilder können sichtbare App-/Chat-Inhalte enthalten.
- Betroffene Dateien: `originals/images/`
- Ursache, falls bekannt: Im Chat hochgeladene Screenshots wurden vollständig übernommen.
- Lösung oder Workaround: Vor Weitergabe prüfen.
- Status: Hinweis.
