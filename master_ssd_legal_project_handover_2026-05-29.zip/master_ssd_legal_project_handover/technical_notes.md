# Technische Notizen

## Technologien und Frameworks

Aus dem Chat und den erzeugten Projektdateien:

- Android / Kotlin
- Gradle / Android Studio
- Python 3
- SQLite
- JSON / CSV / Markdown
- OpenAI als geplanter KI-Anbieter
- exFAT als empfohlene SSD-Formatierung
- ZIP/7-Zip für Archivteile

## Erkannte Ordnerstruktur der aktuellen v5-Version

Die extrahierte v5-Version liegt in dieser Übergabe unter:

`generated/latest_v5_extracted/master_ssd_legal_project_v5_drive_integrated/`

Wichtige Unterordner:

- `app_android/`: Android-Studio-Projekt
- `backend_python/`: lokales Python-Backend und Services
- `config/`: Konfigurationen und App-Registry
- `database/`: SQLite-Schema und Seed-Daten
- `drive_analysis/`: Drive-Zusammenfassung und Segmentmanifest
- `docs/`: Projektdokumentation
- `extensions/`: Erweiterungsplatzhalter
- `MASTER_KEY/`: Demo-SSD-Key-Dateien
- `DATA/`: Datenordnerstruktur
- `scripts/`: Validierung, Segmentprüfung, Export-/Hilfsscripts

## Build-Befehle

### Python-Backend testen

```bash
cd generated/latest_v5_extracted/master_ssd_legal_project_v5_drive_integrated
python scripts/validate_project.py
python backend_python/safe_backend.py
python scripts/test_drive_modules.py
```

### ZIP-Segmente lokal prüfen

```bash
python scripts/check_zip_segments.py <lokaler_download_ordner>
```

### Android-App bauen

1. Android Studio öffnen.
2. Ordner `app_android/` öffnen.
3. Gradle Sync abwarten.
4. Samsung Galaxy S24 Ultra per USB verbinden.
5. Entwickleroptionen und USB-Debugging aktivieren.
6. Run drücken oder APK bauen.

## Installationshinweise

### SSD

- SSD als exFAT formatieren.
- `MASTER_KEY/` und `DATA/` auf SSD kopieren.
- Produktiv sollte ein neuer SSD-Key erzeugt werden:

```bash
python scripts/create_ssd_identity.py
```

### OpenAI

- Kein API-Key ist in dieser Übergabe gespeichert.
- Empfohlene Architektur: Android-App → eigenes Backend → OpenAI.
- OpenAI-Konfiguration nur sicher in Backend-/Serverumgebung speichern.

## Wichtige Architekturentscheidungen

- App statt extern bootendem System.
- SSD als Hardware-Key statt vollständiges Betriebssystem.
- OpenAI-Adapter vorbereitet, aber ohne Schlüssel.
- KYC/Payment als spätere Erweiterung.
- Drive-Archiv nur als Metadaten integriert, weil Rohinhalt nicht entpackbar war.

## Hinweise zu generierten Dateien

- Die neueste Projekt-ZIP ist `master_ssd_legal_project_v5_drive_integrated.zip`.
- Sie wurde zusätzlich in `generated/latest_v5_extracted/` entpackt.
- Alle Manifestdateien in dieser Übergabe beziehen sich auf die Übergabe-ZIP, nicht nur auf v5.

## Fehlende technische Details

- Es gibt keine produktiv signierte APK.
- Es gibt keine produktive OpenAI-Serverkonfiguration.
- Es gibt keine echte KYC-/Payment-Anbindung.
- Der Inneninhalt des Drive-Split-ZIPs wurde nicht analysiert.
