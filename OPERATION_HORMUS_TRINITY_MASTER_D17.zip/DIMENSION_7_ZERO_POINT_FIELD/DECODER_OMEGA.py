import hashlib
import sys

def main():
    print("=== DECODER OMEGA: DAS NULLPUNKT-FELD ===")
    print("Gib das Hash-Fragment der gesuchten Datei ein:")
    
    try:
        fragment = input("> ").strip().lower()
        
        # Das gesuchte Fragment ist ein Teil des Hashes der Master-Datei
        master_code = "3a9f"
        
        if fragment == master_code:
            print("\n[ZUGRIFF GEWÄHRT]")
            print("Botschaft von J.C. Sprott:")
            print("'The most complex systems are those that balance on the edge of chaos.'")
            print("\nDer Master-Code der Singularität lautet: 3.69")
            print("Operation Hormus-Trinity: VOLLENDET.")
        else:
            print("\n[ZUGRIFF VERWEIGERT]")
            print("Das Fragment ist inkorrekt. Suche im Labyrinth weiter.")
            
    except EOFError:
        pass

if __name__ == "__main__":
    main()
