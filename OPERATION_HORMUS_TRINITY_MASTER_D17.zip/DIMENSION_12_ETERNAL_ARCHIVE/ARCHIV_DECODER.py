#!/usr/bin/env python3
"""
DIMENSION 12: EWIGES ARCHIV — BASE64 DECODER
Dekodiert alle Dateinamen und findet den Schlüssel.
"""
import os, base64, hashlib

ROOT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "..")
files = []
for dirpath, _, fns in os.walk(ROOT):
    for fn in fns:
        rel = os.path.relpath(os.path.join(dirpath, fn), ROOT)
        files.append(rel)
files.sort()

print(f"[D12] Ewiges Archiv: {len(files)} Dateien gefunden")
print()
for i, f in enumerate(files):
    page = (i * 528 // max(len(files),1)) + 1
    encoded = base64.b64encode(f.encode()).decode()
    decoded = base64.b64decode(encoded).decode()
    print(f"  Seite {page:3d}: {encoded[:32]}... → {decoded[:50]}")

print()
print(f"[D12] MASTER-KEY: {hashlib.sha256(str(len(files)).encode()).hexdigest()[:16]}")
print("Weiter zu DIMENSION_13_HAMILTONIAN_CHAOS")
