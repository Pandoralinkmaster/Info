import numpy as np
from PIL import Image

def get_parameters_from_image(image_path):
    img = Image.open(image_path)
    pixels = np.array(img)
    # Extrahiere r, sigma, beta aus den Durchschnittswerten der RGB-Kanäle
    r = 3.5 + (np.mean(pixels[:,:,0]) % 0.5)
    sigma = 10 + (np.mean(pixels[:,:,1]) % 5)
    beta = 8/3 + (np.mean(pixels[:,:,2]) % 1)
    return r, sigma, beta

def simulate_logistic_map(r, iterations=100):
    x = 0.5
    results = []
    for _ in range(iterations):
        x = r * x * (1 - x)
        results.append(x)
    return results

print("=== CHAOS LABORATORY: RECURSIVE FEEDBACK ===")
image_path = "../CHAOS_VISUALISIERUNG_ROOT.png"
try:
    r, s, b = get_parameters_from_image(image_path)
    print(f"Parameter aus Bild extrahiert: r={r:.4f}, sigma={s:.4f}, beta={b:.4f}")
    print("Simulation läuft...")
    data = simulate_logistic_map(r)
    print(f"Finale Konvergenz: {data[-1]:.6f}")
    print("\nBotschaft: Das Bild steuert die Mathematik.")
except:
    print("Fehler: Bild nicht im Root-Verzeichnis gefunden.")
