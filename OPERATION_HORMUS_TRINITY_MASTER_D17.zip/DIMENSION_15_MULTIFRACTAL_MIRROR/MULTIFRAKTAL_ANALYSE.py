#!/usr/bin/env python3
"""
DIMENSION 15: MULTIFRAKTAL-ANALYSE
Vigenère Double-Layer Decoder + Multifraktal-Spektrum
"""
import os, hashlib

def vigenere_decrypt(text, key):
    key = key.upper()
    out, ki = [], 0
    for c in text:
        if c.isalpha():
            shift = ord(key[ki%len(key)])-ord('A')
            b = ord('A') if c.isupper() else ord('a')
            out.append(chr((ord(c)-b-shift)%26+b))
            ki += 1
        else: out.append(c)
    return ''.join(out)

ENCRYPTED = "SKM SVYFXTAETSB IPCCNDKHRD"
print(f"[D15] Doppelt verschlüsselt: {ENCRYPTED}")
step1 = vigenere_decrypt(ENCRYPTED, "HORMUS")
print(f"[D15] Nach Stufe 1 (HORMUS): {step1}")
step2 = vigenere_decrypt(step1, "SPROTT")
print(f"[D15] Nach Stufe 2 (SPROTT): {step2}")
print()
print(f"[D15] FRAGMENT: {hashlib.sha256(step2.encode()).hexdigest()[:8]}")
print("Weiter zu DIMENSION_16_SPATIOTEMPORAL_NEXUS")
