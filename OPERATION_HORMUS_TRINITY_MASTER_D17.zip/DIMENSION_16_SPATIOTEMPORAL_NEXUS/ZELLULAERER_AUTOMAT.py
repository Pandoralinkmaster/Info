#!/usr/bin/env python3
"""
DIMENSION 16: ZELLULÄRER AUTOMAT
Sprott, Kap. 15: Rule 30 / Rule 90 Implementation

Demonstriert spatiotemporales Chaos durch einen 1D
zellulären Automaten — wie in Sprott beschrieben.
"""
import hashlib

def rule30(cells):
    n = len(cells)
    new = [0]*n
    for i in range(n):
        l = cells[(i-1)%n]
        c = cells[i]
        r = cells[(i+1)%n]
        pattern = l*4 + c*2 + r
        new[i] = (30 >> pattern) & 1
    return new

# Initialer Zustand aus Dateianzahl-Seed
N = 40
seed_hex = "ecf016d938"
cells = [int(b,16)%2 for b in [seed_hex[i:i+2] for i in range(0,len(seed_hex),2)]]
cells = (cells * (N//len(cells)+1))[:N]

print("[D16] Zellulärer Automat (Rule 30) — 20 Generationen:")
print()
for gen in range(20):
    row = ''.join(['█' if c else '░' for c in cells])
    print(f"  Gen {gen:2d}: {row}")
    cells = rule30(cells)

final_state = ''.join(str(c) for c in cells)
key_val = int(final_state,2) % (2**16)
print()
print(f"[D16] Finaler Zustand (binär): {final_state[:20]}...")
print(f"[D16] Schlüssel-Wert: {key_val}")
print(f"[D16] FRAGMENT: {hashlib.sha256(str(key_val).encode()).hexdigest()[:8]}")
print()
print("Weiter zu DIMENSION_17_QUANTUM_COLLAPSE")
