#!/usr/bin/env python3
"""
DIMENSION 13: HAMILTON-SIMULATOR
Sprott, Kap. 8: Henon-Heiles System

Simuliert das Henon-Heiles-System — ein klassisches
Beispiel für Hamiltonsches Chaos.
"""
import math

def henon_heiles(q1, q2, p1, p2, dt=0.01, steps=1000):
    """
    H = 0.5*(p1²+p2²) + 0.5*(q1²+q2²) + q1²*q2 - q2³/3
    """
    results = []
    for _ in range(steps):
        # Kraftkomponenten
        F1 = -(q1 + 2*q1*q2)
        F2 = -(q2 + q1**2 - q2**2)
        # Leapfrog-Integration
        p1 += F1 * dt/2
        p2 += F2 * dt/2
        q1 += p1 * dt
        q2 += p2 * dt
        F1 = -(q1 + 2*q1*q2)
        F2 = -(q2 + q1**2 - q2**2)
        p1 += F1 * dt/2
        p2 += F2 * dt/2
        H = 0.5*(p1**2+p2**2) + 0.5*(q1**2+q2**2) + q1**2*q2 - q2**3/3
        results.append((q1, q2, p1, p2, H))
    return results

# Initiale Bedingungen aus dem Labyrinth-Samen
SEED = '597b023c'
q1 = int(SEED[:2],16)/256 * 0.5
q2 = int(SEED[2:4],16)/256 * 0.5
p1 = int(SEED[4:6],16)/256 * 0.3
p2 = int(SEED[6:8],16)/256 * 0.3

print(f"[D13] Hamilton-System: q1={q1:.4f}, q2={q2:.4f}, p1={p1:.4f}, p2={p2:.4f}")
traj = henon_heiles(q1, q2, p1, p2)
H_initial = traj[0][4]
H_final   = traj[-1][4]
print(f"[D13] Energie initial: {H_initial:.8f}")
print(f"[D13] Energie final:   {H_final:.8f}")
print(f"[D13] Energieerhaltung: {abs(H_final-H_initial)<1e-4}")
print()
print("Weiter zu DIMENSION_14_TIME_SERIES_ORACLE")
