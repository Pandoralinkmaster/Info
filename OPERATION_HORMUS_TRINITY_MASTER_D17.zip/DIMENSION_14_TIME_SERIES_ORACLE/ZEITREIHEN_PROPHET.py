#!/usr/bin/env python3
"""
DIMENSION 14: ZEITREIHEN-PROPHET
Sprott, Kap. 10: Nonlinear Prediction and Noise Reduction

Implementiert die Methode der nächsten Nachbarn (Nearest Neighbors)
für nichtlineare Vorhersage — exakt wie in Sprott beschrieben.
"""
import os, math, hashlib

ROOT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "..")
files = sorted(
    os.path.relpath(os.path.join(d,f), ROOT)
    for d,_,fs in os.walk(ROOT) for f in fs
)

# Zeitreihe = Dateinamen-Längen mod 100
series = [len(f)*7%100 for f in files]
print(f"[D14] Zeitreihe ({len(series)} Punkte): {series[:10]}...")

# Einfache 1-NN-Vorhersage
def predict_nn(series, t, tau=2, embed=3):
    vec = [series[max(0,t-i*tau)] for i in range(embed)]
    best_dist, best_val = float('inf'), series[t]
    for i in range(embed, t-1):
        candidate = [series[max(0,i-j*tau)] for j in range(embed)]
        dist = math.sqrt(sum((a-b)**2 for a,b in zip(vec,candidate)))
        if dist < best_dist and dist > 0:
            best_dist = dist
            best_val = series[min(i+1,len(series)-1)]
    return best_val

if len(series) > 10:
    pred = predict_nn(series, len(series)//2)
    actual = series[len(series)//2 + 1] if len(series)//2+1 < len(series) else 0
    print(f"[D14] Vorhersage bei t={len(series)//2}: {pred}")
    print(f"[D14] Tatsächlicher Wert:           {actual}")
    diff = abs(pred - actual)
    key_char = chr(ord('A') + int(diff) % 26)
    print(f"[D14] Schlüssel-Zeichen: {key_char}")
    print(f"[D14] FRAGMENT: {hashlib.sha256(str(diff).encode()).hexdigest()[:8]}")

print()
print("Weiter zu DIMENSION_15_MULTIFRACTAL_MIRROR")
