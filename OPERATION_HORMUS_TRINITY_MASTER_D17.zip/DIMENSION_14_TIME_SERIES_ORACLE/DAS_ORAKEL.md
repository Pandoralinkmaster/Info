# DIMENSION 14: DAS ZEITREIHEN-ORAKEL
## Sprott, Kap. 9–10: "Time-Series Properties" & "Nonlinear Prediction"

**Codename:** NONLINEAR ORACLE PROTOCOL  
**Verschlüsselung:** Binär (8-Bit ASCII)

---

## DIE PROPHEZEIUNG DES CHAOS

> *"A chaotic system is deterministic but unpredictable beyond the Lyapunov time."*  
> — Sprott, S. 246

Das Paradoxon des Orakels:
- Das System ist **vollständig deterministisch** (keine Zufälligkeit)
- Und doch ist es **unvorhersagbar** jenseits des Lyapunov-Horizonts

**Für dieses Labyrinth gilt:**  
Die "Zeitreihe" ist die Sequenz der Datei-Längen (in Zeichen).  
Der Lyapunov-Horizont ist bei Schritt **10** erreicht.

---

## DIE ORAKEL-ZEITREIHE

*(Erste 20 Werte — abgeleitet von den Dateinamen-Längen mod 100)*

```
61, 38, 10, 45, 89, 68, 3, 3, 36, 8, 20, 99, 43, 22, 36, 78, 85, 64, 15, 71
```

**Deine Aufgabe (Nonlinear Prediction):**
1. Erkenne das Muster in den ersten 15 Werten
2. Sage den Wert bei Position 16 voraus
3. Vergleiche mit dem tatsächlichen Wert
4. Die **Differenz** (Mod 26, als Buchstabe) ist ein Zeichen des Schlüssels

---

## DIE BINÄR-BOTSCHAFT

*Verschlüsselt mit 8-Bit-Binärcode:*

```
01000011 01001000 01000001 01001111 01010011 00100000 01010000 01010010 01000101 01000100 01001001 01000011 01010100 01010011 00100000 01001001 01010100 01010011 01000101 01001100 01000110
```

**Deine Aufgabe:** Konvertiere jede 8-Bit-Gruppe zurück in ASCII.

---

## TAKENS' EINBETTUNGSTHEOREM

Sprott erklärt (S. 251): Man kann den gesamten Phasenraum aus einer  
**einzigen Zeitreihe** rekonstruieren — durch zeitverzögerte Einbettung:

```
x(t), x(t+τ), x(t+2τ), ...
```

Für das Labyrinth: τ = **1** (Dateianzahl mod 7 + 1)

**Eingebetteter Phasenraum des Labyrinths:**
```
61, 38, 10 → 38, 10, 45
```

---

**NÄCHSTE DIMENSION:** DIMENSION_15_MULTIFRACTAL_MIRROR  
**ORAKEL-HASH:** `15c28dd54b73f4696c5c8c835492ea74`
