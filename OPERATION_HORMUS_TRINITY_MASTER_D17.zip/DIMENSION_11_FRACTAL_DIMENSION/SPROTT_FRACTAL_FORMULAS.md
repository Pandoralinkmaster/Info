# SPROTT FRAKTAL-FORMELN: DIMENSION 11
## Direkt aus "Chaos and Time-Series Analysis"

---

## DIE BOX-COUNTING-DIMENSION

```
D_B = lim[ε→0] log(N(ε)) / log(1/ε)
```

Wobei:
- `N(ε)` = Anzahl der Boxen der Größe ε, die das Objekt bedecken
- Für das Hormus-Labyrinth: D_B ≈ **1.585**

## DIE LYAPUNOV-DIMENSION (Kaplan-Yorke)

```
D_L = j + Σλᵢ / |λⱼ₊₁|
```

Im Kontext dieses Rätsels:
- j = Anzahl positiver Lyapunov-Exponenten
- Die Antwort ist versteckt in der Datei: `DIMENSION_4_LYAPUNOV/SYNTHESE.md`

## DAS FRAKTALE SELBSTÄHNLICHKEITS-RÄTSEL

Beobachte die Struktur der Dateinamen:
```
ANTITHESE.md → ANTITHESE (1).md → ...
```

Dies ist KEINE Redundanz. Es ist **fraktale Selbstähnlichkeit auf Dateiebene**.  
Die Hausdorff-Dimension der Duplikate = log(N) / log(r)

**Frage:** Wie viele Duplikate gibt es? Was ist deren fraktale Dimension?

---

**Vigenère-Verschlüsselung (Schlüssel: SPROTT):**
```
Klartext:  CHAOS IS ORDER
Verschlüsselt: UWRCL BK DIRXK
```

**XOR-Kodierung (Schlüssel: 42):**
```
108|120|107|105|126|107|102|10|110|99|103|111|100|121|99|101|100|10|111|102|111|124|111|100
```

---

**STATUS: FRAKTALE DIMENSION AKTIVIERT**  
`0daeafd3dfba8e2b0c03e8b785aa6813`
