#!/usr/bin/env python3
"""
DIMENSION 11: SELBSTÄHNLICHKEITS-DECODER
Sprott, Kap. 12: Fractal Dimension Calculation

Dieses Skript berechnet die Box-Counting-Dimension
des gesamten Datei-Labyrinths.
"""

import os, hashlib, math

def box_count(name_lengths, epsilon):
    """Simuliere Box-Counting auf Dateinamen-Längen."""
    min_l, max_l = min(name_lengths), max(name_lengths)
    span = max_l - min_l
    if span == 0: return 1
    boxes = set(int((l - min_l) / epsilon) for l in name_lengths)
    return len(boxes)

def fractal_dimension(name_lengths):
    epsilons = [0.5, 1.0, 2.0, 4.0, 8.0]
    counts = [box_count(name_lengths, e) for e in epsilons]
    # Linear regression: log(N) = D * log(1/ε) + const
    xs = [math.log(1/e) for e in epsilons]
    ys = [math.log(c) for c in counts if c > 0]
    if len(ys) < 2: return 1.0
    n = min(len(xs), len(ys))
    xs, ys = xs[:n], ys[:n]
    x_mean = sum(xs)/n
    y_mean = sum(ys)/n
    num = sum((xs[i]-x_mean)*(ys[i]-y_mean) for i in range(n))
    den = sum((xs[i]-x_mean)**2 for i in range(n))
    return num/den if den != 0 else 1.0

ROOT = os.path.dirname(os.path.abspath(__file__))
ARCHIVE_ROOT = os.path.join(ROOT, "..", "..")

all_names = []
for dirpath, _, files in os.walk(ARCHIVE_ROOT):
    for fn in files:
        all_names.append(len(fn))

D = fractal_dimension(all_names)
print(f"[D11] Fraktale Dimension des Labyrinths: {D:.4f}")
print(f"[D11] Erwartungswert nach Sprott: 1.5850 (log2/log3)")
print(f"[D11] SCHLÜSSEL-FRAGMENT: {hashlib.sha256(str(round(D,2)).encode()).hexdigest()[:8]}")
print()
print("Weiter zu DIMENSION_12_ETERNAL_ARCHIVE")
