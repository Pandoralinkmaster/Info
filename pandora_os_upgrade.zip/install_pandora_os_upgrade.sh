#!/bin/sh
set -e

PROJECT_DIR="${1:-$PWD}"
SCRIPT_DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)"
cd "$PROJECT_DIR"

if [ ! -f "app/build.gradle" ]; then
  echo "Bitte im Android-Projektordner ausführen, z.B.: cd ~/pandora-android"
  exit 1
fi

cp -r "$SCRIPT_DIR/files/"* .
chmod +x gradlew

# Gradle/Android Build-Fixes
sed -i 's/compileSdk [0-9][0-9]*/compileSdk 36/' app/build.gradle
sed -i 's/targetSdk [0-9][0-9]*/targetSdk 36/' app/build.gradle
sed -i "s/classpath 'com.android.tools.build:gradle:[^']*'/classpath 'com.android.tools.build:gradle:8.7.3'/" build.gradle
if ! grep -q 'androidx.documentfile:documentfile' app/build.gradle; then
  sed -i "/androidx.work:work-runtime-ktx/a\    implementation 'androidx.documentfile:documentfile:1.0.1'" app/build.gradle
fi
for x in "META-INF/DEPENDENCIES" "META-INF/LICENSE" "META-INF/LICENSE.txt" "META-INF/NOTICE" "META-INF/NOTICE.txt"; do
  grep -q "$x" app/build.gradle || sed -i "/META-INF\/io.netty.versions.properties/a\            excludes += '$x'" app/build.gradle
done

grep -q 'android.suppressUnsupportedCompileSdk=36' gradle.properties || echo 'android.suppressUnsupportedCompileSdk=36' >> gradle.properties
grep -q 'org.gradle.workers.max=1' gradle.properties || echo 'org.gradle.workers.max=1' >> gradle.properties
sed -i 's/org.gradle.parallel=true/org.gradle.parallel=false/' gradle.properties
sed -i 's/zxing = "4\.3\.0"/zxing = "3.5.3"/' gradle/libs.versions.toml 2>/dev/null || true

# Manifest/Icon/Theme
sed -i 's/@mipmap\/ic_launcher_round/@drawable\/ic_launcher/g' app/src/main/AndroidManifest.xml
sed -i 's/@mipmap\/ic_launcher/@drawable\/ic_launcher/g' app/src/main/AndroidManifest.xml
sed -i 's/parent="android:Theme.Material.NoTitleBar"/parent="@android:style\/Theme.Material.NoActionBar"/' app/src/main/res/values/themes.xml

# Room-Konflikt Room -> PandoraRoom
sed -i 's/data class Room(/data class PandoraRoom(/' app/src/main/kotlin/com/pandora/database/entity/CoreEntities.kt
sed -i 's/Floor::class, Room::class, Zone::class/Floor::class, PandoraRoom::class, Zone::class/' app/src/main/kotlin/com/pandora/database/PandoraDatabase.kt
sed -i 's/Room.databaseBuilder/androidx.room.Room.databaseBuilder/g' app/src/main/kotlin/com/pandora/database/PandoraDatabase.kt
sed -i 's/List<Room>/List<PandoraRoom>/g' app/src/main/kotlin/com/pandora/database/dao/CoreDaos.kt
sed -i 's/upsertRoom(r: Room)/upsertRoom(r: PandoraRoom)/g' app/src/main/kotlin/com/pandora/database/dao/CoreDaos.kt

# API/JayJay fixes
sed -i 's/call.respond(ApiResponse(true, gate.clientStatus()))/call.respond(ApiResponse<Map<String, String>>(success = true, data = gate.clientStatus()))/' app/src/main/kotlin/com/pandora/api/PandoraApiServer.kt
sed -i 's/ApiResponse(false, error =/ApiResponse<Unit>(false, error =/g' app/src/main/kotlin/com/pandora/api/PandoraApiServer.kt
F="app/src/main/kotlin/com/pandora/jayjay/JayJayLearningEngine.kt"
sed -i 's/val lastAutoLearnAt: Long = 0L/var lastAutoLearnAt: Long = 0L/' "$F"
grep -q 'MediaType.Companion.toMediaType' "$F" || sed -i '/import okhttp3.Request/a\import okhttp3.MediaType.Companion.toMediaType\nimport okhttp3.RequestBody.Companion.toRequestBody' "$F"
sed -i 's#\.post(okhttp3.RequestBody.create(okhttp3.MediaType.parse("application/json"), body))#.post(body.toRequestBody("application/json".toMediaType()))#g' "$F"

# Admin coroutine launch fix
grep -q 'import kotlinx.coroutines.launch' app/src/main/kotlin/com/pandora/ui/screens/AdminScreen.kt || sed -i '/import com.pandora.database.entity.Device/a\import kotlinx.coroutines.launch' app/src/main/kotlin/com/pandora/ui/screens/AdminScreen.kt
sed -i 's/kotlinx.coroutines.GlobalScope.launch(kotlinx.coroutines.Dispatchers.IO)/scope.launch/g' app/src/main/kotlin/com/pandora/ui/screens/AdminScreen.kt

echo "Pandora OS Upgrade installiert. Jetzt bauen:"
echo "./gradlew assembleDebug --no-daemon --console=plain"
