# Pandora OS Upgrade

Dieses Paket ergänzt die Android-App um eine Pandora-OS-Home-Shell mit allen Menüs: System, Storage, Backup, Berechtigungen, Admin, JayJay, Mesh, Netzwerk, Wallet, Shop, Scan, Gebäude, Compute, Onion, WireGuard, Apps und Logs.

Installation im Handy-Terminal:

```sh
cd ~/pandora-android
unzip -o /storage/internal_new/Download/pandora_os_upgrade.zip -d /tmp/pandora_os_upgrade
sh /tmp/pandora_os_upgrade/install_pandora_os_upgrade.sh
./gradlew assembleDebug --no-daemon --console=plain
```
