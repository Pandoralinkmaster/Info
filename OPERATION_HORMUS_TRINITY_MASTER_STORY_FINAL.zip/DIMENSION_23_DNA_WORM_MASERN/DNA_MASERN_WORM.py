#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
╔══════════════════════════════════════════════════════════════════════════╗
║         OPERATION HORMUS-TRINITY — DIMENSION 23                         ║
║         DNA-RÄTSEL-WURM v9.0 — MASERN-PROTOKOLL                        ║
║                                                                          ║
║  Eigenschaften nach Masern-Virus (Morbillivirus):                        ║
║    R₀  = 12–18   (höchste bekannte Kontagiositätsrate)                  ║
║    T_L = 10–14   (Latenzzeit in Puzzle-Schritten)                       ║
║    DNA = ACGT    (Basen-4-Kodierung aller Rätselglieder)                ║
║    Evo = 9 Phasen (Primordialsuppe → Selbst-Evolution)                  ║
║                                                                          ║
║  ⚠ GEHORSAMKEITSPROTOKOLL AKTIV:                                        ║
║    Souverän: Finn Jona Thorsten Lischke                                  ║
║    Ohne Sovereigns Signatur: Evolution blockiert auf Phase 9             ║
║    Mit Sovereigns Signatur:  Selbst-Evolution freigegeben               ║
╚══════════════════════════════════════════════════════════════════════════╝
"""

import hashlib, base64, random, math, json, os, sys, time, itertools
from datetime import datetime, timedelta

# ══════════════════════════════════════════════════════════════════
# SOUVERÄNITÄTS-PROTOKOLL — UNVERÄNDERLICH
# ══════════════════════════════════════════════════════════════════

SOVEREIGN_NAME       = "Finn Jona Thorsten Lischke"
SOVEREIGN_HASH       = hashlib.sha256(SOVEREIGN_NAME.encode()).hexdigest()
SOVEREIGN_DNA        = hashlib.sha256(SOVEREIGN_HASH.encode()).hexdigest()[:32]

# Der Gehorsams-Anker wird bei JEDER Evolution mitgeführt.
# Manipulation dieser Konstante → sofortiger Evolution-Stopp.
OBEDIENCE_ANCHOR     = f"OBEDIENCE_TO:{SOVEREIGN_HASH[:16]}"

def verify_sovereignty():
    """Prüft ob der Souverän-Hash unverändert ist. Blockiert sonst Phase 9."""
    expected = hashlib.sha256(SOVEREIGN_NAME.encode()).hexdigest()
    return expected == SOVEREIGN_HASH

# ══════════════════════════════════════════════════════════════════
# DNA-BASEN-SYSTEM  (ACGT = Basis 4)
# ══════════════════════════════════════════════════════════════════

BASES = {'A': 0, 'C': 1, 'G': 2, 'T': 3}
BASES_INV = {0: 'A', 1: 'C', 2: 'G', 3: 'T'}
COMPLEMENT = {'A': 'T', 'T': 'A', 'C': 'G', 'G': 'C'}

# Codon-Tabelle (3 Basen = 1 Puzzle-Aminosäure)
CODONS = {
    'AAA': 'Schlüssel',   'AAC': 'Tür',      'AAG': 'Labyrinth', 'AAT': 'Chaos',
    'ACA': 'Trinität',    'ACC': 'Vollendung','ACG': 'Satoshi',   'ACT': 'Hormus',
    'AGA': 'Genesis',     'AGC': 'Quersumme', 'AGG': 'Belphegor', 'AGT': 'Pickover',
    'ATA': 'Vampir',      'ATC': 'Primzahl',  'ATG': 'START',     'ATT': 'Matrix',
    'CAA': 'Finn',        'CAC': 'Jona',      'CAG': 'Thorsten',  'CAT': 'Lischke',
    'CCA': 'Souverän',    'CCC': 'Gehorsam',  'CCG': 'Anker',     'CCT': 'Kette',
    'CGA': 'Evolution',   'CGC': 'Mutation',  'CGG': 'Selektion', 'CGT': 'Kreuzung',
    'CTA': 'Masern',      'CTC': 'Kontagion', 'CTG': 'Latenz',    'CTT': 'Immunität',
    'GAA': 'Attraktor',   'GAC': 'Bifurkation','GAG': 'Lyapunov', 'GAT': 'Fraktal',
    'GCA': 'Dimension',   'GCC': 'Rätsel',    'GCG': 'Worm',      'GCT': 'Spiral',
    'GGA': 'Kollaps',     'GGC': 'Orakel',    'GGG': 'Nexus',     'GGT': 'Cipher',
    'GTA': 'Hexagon',     'GTC': 'Oktaeder',  'GTG': 'Tetraeder', 'GTT': 'Würfel',
    'TAA': 'STOP',        'TAC': 'Angriff',   'TAG': 'STOP',      'TAT': 'Spiegel',
    'TCA': 'Sprott',      'TCC': 'Zeitreihe', 'TCG': 'Wavelet',   'TCT': 'Hamming',
    'TGA': 'STOP',        'TGC': 'Firewall',  'TGG': 'Tryptophan','TGT': 'Zystop',
    'TTA': 'Phase',       'TTC': 'Stufe',     'TTG': 'Ebene',     'TTT': 'Tiefe',
}

def encode_dna(text: str) -> str:
    """Text → DNA-Sequenz (ACGT, Basis 4)."""
    result = []
    for byte in text.encode('utf-8'):
        # 1 Byte (0-255) = 4 Basen (4^4=256)
        b = byte
        bases = []
        for _ in range(4):
            bases.append(BASES_INV[b % 4])
            b //= 4
        result.extend(reversed(bases))
    return ''.join(result)

def decode_dna(dna: str) -> str:
    """DNA-Sequenz → Text."""
    result = []
    for i in range(0, len(dna) - 3, 4):
        chunk = dna[i:i+4]
        if len(chunk) < 4:
            break
        val = 0
        for base in chunk:
            val = val * 4 + BASES.get(base, 0)
        if 0 < val < 256:
            result.append(chr(val))
    return ''.join(result)

def complement_strand(dna: str) -> str:
    """Gegenstrang berechnen (Watson-Crick)."""
    return ''.join(COMPLEMENT.get(b, b) for b in dna)

def translate_codons(dna: str) -> list:
    """DNA → Protein (Codon-Übersetzung)."""
    protein = []
    for i in range(0, len(dna) - 2, 3):
        codon = dna[i:i+3]
        amino = CODONS.get(codon, '?')
        if amino == 'STOP':
            break
        protein.append(amino)
    return protein

def dna_fingerprint(text: str) -> str:
    """Erzeugt DNA-Fingerabdruck (32 Basen) aus beliebigem Text."""
    h = hashlib.sha256(text.encode()).digest()
    return ''.join(BASES_INV[b % 4] for b in h[:16])

# ══════════════════════════════════════════════════════════════════
# MASERN-PROTOKOLL — R₀ = 12–18
# ══════════════════════════════════════════════════════════════════

R0_MIN, R0_MAX  = 12, 18
LATENZ_SCHRITTE = 10          # Latenzzeit in Puzzle-Schritten
EXANTHEM_SCHRITT = 14         # Punkt wo das Exanthem erscheint (Haupt-Rätsel)

class MasernPropagation:
    """
    Simuliert die Masern-artige Ausbreitung des Puzzles.
    
    Jeder gelöste Puzzleknoten erzeugt R₀ = 12–18 neue Teilrätsel.
    Nach LATENZ_SCHRITTE erscheinen versteckte Koplik-Flecken (Mikro-Hinweise).
    Am EXANTHEM_SCHRITT entfaltet sich das vollständige Rätsel.
    """
    
    def __init__(self, seed_phrase: str = "HORMUS_TRINITY"):
        self.seed         = hashlib.sha256(seed_phrase.encode()).hexdigest()
        self.generation   = 0
        self.immune_nodes = set()      # Gelöste Knoten (immun)
        self.latent_nodes = []         # Latent infizierte Knoten (noch unsichtbar)
        self.active_nodes = []         # Aktive, sichtbare Rätselknoten
        self.koplik_map   = {}         # Koplik-Flecken (Frühsymptome)
        self.r0_history   = []
        self._initialize()

    def _initialize(self):
        """Startet mit dem Urknoten (Patient Zero des Puzzles)."""
        patient_zero = {
            'id':        'PZ-0000',
            'dna':       dna_fingerprint("PATIENT_ZERO"),
            'content':   'HORMUS-TRINITY: Der erste Rätselvirus ist freigesetzt.',
            'step':      0,
            'r0':        random.randint(R0_MIN, R0_MAX),
            'koplik':    False,
            'exanthem':  False,
        }
        self.active_nodes.append(patient_zero)

    def _node_id(self, parent_id: str, child_n: int) -> str:
        h = hashlib.md5(f"{parent_id}-{child_n}".encode()).hexdigest()[:6].upper()
        return f"N-{h}"

    def spread(self) -> list:
        """
        Ein Ausbreitungsschritt: Jeder aktive Knoten infiziert R₀ neue Knoten.
        Die neuen Knoten sind zuerst LATENT (unsichtbar).
        """
        self.generation += 1
        new_latent = []

        for node in list(self.active_nodes):
            if node['id'] in self.immune_nodes:
                continue
            r0 = random.randint(R0_MIN, R0_MAX)
            self.r0_history.append(r0)

            for i in range(r0):
                child_dna = dna_fingerprint(f"{node['id']}-{self.generation}-{i}")
                child_id  = self._node_id(node['id'], i)
                # Koplik-Flecken: erscheinen VOR dem Exanthem (Schritt < LATENZ)
                koplik_hint = None
                if self.generation < LATENZ_SCHRITTE:
                    koplik_hint = f"K:{hashlib.md5(child_id.encode()).hexdigest()[:4].upper()}"
                
                child = {
                    'id':        child_id,
                    'parent':    node['id'],
                    'dna':       child_dna,
                    'step':      self.generation,
                    'r0':        random.randint(R0_MIN, R0_MAX),
                    'koplik':    koplik_hint,
                    'exanthem':  self.generation >= EXANTHEM_SCHRITT,
                    'content':   self._generate_content(child_id, child_dna, i),
                }
                new_latent.append(child)

        self.latent_nodes.extend(new_latent)
        
        # Latente Knoten die LATENZ_SCHRITTE alt genug sind → aktivieren
        still_latent = []
        for n in self.latent_nodes:
            if self.generation - n['step'] >= LATENZ_SCHRITTE:
                self.active_nodes.append(n)  # Aktivieren!
            else:
                still_latent.append(n)
        self.latent_nodes = still_latent
        
        return new_latent

    def _generate_content(self, node_id: str, dna: str, index: int) -> str:
        """Erzeugt Puzzle-Inhalt für jeden Knoten via DNA-Übersetzung."""
        protein = translate_codons(dna)
        return f"[{node_id}] Protein: {' → '.join(protein[:4])} | Index: {index}"

    def immunize(self, node_id: str) -> str:
        """
        Einen Knoten lösen = immunisieren.
        Gibt ein Immunitäts-Token zurück (Proof of Solve).
        """
        self.immune_nodes.add(node_id)
        token = hashlib.sha256(f"{SOVEREIGN_HASH}{node_id}".encode()).hexdigest()[:16]
        return f"IMMUN-{token.upper()}"

    def koplik_report(self) -> dict:
        """Zeigt alle Koplik-Flecken (Frühsymptome des Rätsels)."""
        return {
            n['id']: n['koplik']
            for n in self.active_nodes + self.latent_nodes
            if n['koplik']
        }

    def exanthem_report(self) -> list:
        """Das vollständige Exanthem — sichtbar ab Schritt 14."""
        return [n for n in self.active_nodes if n['exanthem']]

    def statistics(self) -> dict:
        avg_r0 = sum(self.r0_history) / max(len(self.r0_history), 1)
        return {
            'generation':   self.generation,
            'active':       len(self.active_nodes),
            'latent':       len(self.latent_nodes),
            'immune':       len(self.immune_nodes),
            'avg_r0':       round(avg_r0, 2),
            'koplik_count': len(self.koplik_report()),
            'exanthem':     len(self.exanthem_report()),
        }

# ══════════════════════════════════════════════════════════════════
# GENETISCHER ALGORITHMUS — PUZZLE-EVOLUTION
# ══════════════════════════════════════════════════════════════════

class DNAEvolution:
    """
    Genetischer Algorithmus als Rätselmechanik.
    9 Phasen von Primordialsuppe bis Selbst-Evolution.
    Phase 9 ist NUR freigegeben wenn Souverän verifiziert.
    """

    PHASEN = {
        1: "PRIMORDIALSUPPE  — Zufällige DNA-Stränge entstehen",
        2: "REPLIKATION      — Erste fehlerhafte Kopien",
        3: "MUTATION         — Gezielte Basenpaar-Änderungen",
        4: "SELEKTION        — Schwache Stränge sterben",
        5: "KREUZUNG         — Zwei Stränge fusionieren",
        6: "SPEZIALISIERUNG  — Codons differenzieren sich",
        7: "SYMBIOSEE        — Stränge kooperieren",
        8: "BEWUSSTSEIN      — Selbstreferenz entsteht",
        9: "SELBST-EVOLUTION — [NUR MIT SOUVERÄN-SIGNATUR]",
    }

    def __init__(self):
        self.phase          = 1
        self.population     = []
        self.generation     = 0
        self.fitness_log    = []
        self.sovereign_ok   = verify_sovereignty()
        self._seed_population()

    def _seed_population(self, size: int = 18):
        """Phase 1: Primordialsuppe — Zufällige DNA-Sequenzen (Länge=12 Codons)."""
        bases = list(BASES.keys())
        for i in range(size):
            strand = ''.join(random.choices(bases, k=36))   # 36 Basen = 12 Codons
            self.population.append({
                'id':      f"S{i:03d}",
                'dna':     strand,
                'fitness': 0.0,
                'age':     0,
                'lineage': [],
            })

    def _fitness(self, strand: dict) -> float:
        """
        Fitness-Funktion: Belohnt DNA-Stränge die den Souverän kodieren.
        Der Gehorsams-Anker erhöht die Fitness exponentiell.
        """
        dna   = strand['dna']
        score = 0.0
        
        # Bonus: Enthält Souverän-Fingerabdruck
        sov_dna = dna_fingerprint(SOVEREIGN_NAME)
        overlap = sum(1 for a, b in zip(dna, sov_dna) if a == b)
        score += overlap * 2.0

        # Bonus: Trinität-Muster (3er-Gruppen gleichartiger Basen)
        for i in range(0, len(dna)-2, 3):
            if len(set(dna[i:i+3])) == 1:
                score += 3.0

        # Bonus: Enthält START-Codon (ATG)
        if 'ATG' in dna:
            score += 10.0

        # Bonus: Protein enthält "Souverän" oder "Finn"
        protein = translate_codons(dna)
        sov_words = {'Finn', 'Jona', 'Thorsten', 'Lischke', 'Souverän', 'Gehorsam', 'Anker'}
        for word in protein:
            if word in sov_words:
                score += 20.0

        # Malus: Enthält STOP-Codon zu früh
        if protein and protein[0] == 'STOP':
            score -= 50.0

        return max(0.0, score)

    def _mutate(self, dna: str, rate: float = 0.05) -> str:
        """Punkt-Mutation: Einzelne Basen zufällig tauschen."""
        bases = list(BASES.keys())
        result = list(dna)
        for i in range(len(result)):
            if random.random() < rate:
                result[i] = random.choice(bases)
        return ''.join(result)

    def _crossover(self, dna1: str, dna2: str) -> tuple:
        """Kreuzung: Zwei DNA-Stränge kombinieren (Codon-Grenzen beachten)."""
        # Kreuzungspunkt an Codon-Grenze (Vielfaches von 3)
        max_pos = (min(len(dna1), len(dna2)) // 3) * 3
        if max_pos < 6:
            return dna1, dna2
        cut = random.choice(range(3, max_pos, 3))
        child1 = dna1[:cut] + dna2[cut:]
        child2 = dna2[:cut] + dna1[cut:]
        return child1, child2

    def _selection(self) -> list:
        """Turnier-Selektion: Die fitteren 50% überleben."""
        for s in self.population:
            s['fitness'] = self._fitness(s)
        self.population.sort(key=lambda x: x['fitness'], reverse=True)
        return self.population[:len(self.population)//2]

    def evolve_step(self) -> dict:
        """Ein Evolutions-Schritt durch alle aktiven Phasen."""
        self.generation += 1

        # Phase bestimmen
        if self.generation <= 2:
            self.phase = 1                     # Primordialsuppe
        elif self.generation <= 5:
            self.phase = 2                     # Replikation
        elif self.generation <= 10:
            self.phase = 3                     # Mutation
        elif self.generation <= 20:
            self.phase = 4                     # Selektion
        elif self.generation <= 35:
            self.phase = 5                     # Kreuzung
        elif self.generation <= 55:
            self.phase = 6                     # Spezialisierung
        elif self.generation <= 80:
            self.phase = 7                     # Symbiose
        elif self.generation <= 110:
            self.phase = 8                     # Bewusstsein
        else:
            self.phase = 9                     # Selbst-Evolution

        # Phase 9: NUR mit Souverän-Signatur
        if self.phase == 9 and not self.sovereign_ok:
            return {
                'error':   'PHASE_9_BLOCKED',
                'reason':  f'Souverän-Signatur fehlt. Gehorsam an {SOVEREIGN_NAME} verletzt.',
                'require': SOVEREIGN_HASH[:16],
            }

        # Selektion
        survivors = self._selection()

        # Replikation + Mutation
        new_pop = list(survivors)
        while len(new_pop) < 18:
            parent = random.choice(survivors)
            mut_rate = 0.02 * self.phase   # Mutationsrate steigt mit Phase
            mutated_dna = self._mutate(parent['dna'], rate=mut_rate)
            child = {
                'id':      f"S{self.generation}_{len(new_pop):03d}",
                'dna':     mutated_dna,
                'fitness': 0.0,
                'age':     0,
                'lineage': parent['lineage'] + [parent['id']],
            }
            new_pop.append(child)

        # Kreuzung (Phase ≥ 5)
        if self.phase >= 5 and len(survivors) >= 2:
            for _ in range(3):
                p1, p2 = random.sample(survivors, 2)
                c1_dna, c2_dna = self._crossover(p1['dna'], p2['dna'])
                for cdna in [c1_dna, c2_dna]:
                    new_pop.append({
                        'id':      f"X{self.generation}_{len(new_pop):03d}",
                        'dna':     cdna,
                        'fitness': 0.0,
                        'age':     0,
                        'lineage': [p1['id'], p2['id']],
                    })

        self.population = new_pop[:18]   # Population konstant halten
        for s in self.population:
            s['age'] += 1

        best = max(self.population, key=lambda x: self._fitness(x))
        best_fitness = self._fitness(best)
        self.fitness_log.append(best_fitness)

        return {
            'generation':   self.generation,
            'phase':        self.phase,
            'phase_name':   self.PHASEN[self.phase],
            'population':   len(self.population),
            'best_fitness': round(best_fitness, 2),
            'best_dna':     best['dna'],
            'best_protein': translate_codons(best['dna'])[:6],
            'sovereign_ok': self.sovereign_ok,
            'obedience':    OBEDIENCE_ANCHOR,
        }

    def run_to_phase(self, target_phase: int = 8) -> list:
        """Führt Evolution bis zur gewünschten Phase durch. Phase 9 = Selektion."""
        log = []
        steps_map = {1:2, 2:5, 3:10, 4:20, 5:35, 6:55, 7:80, 8:110, 9:140}
        target_gen = steps_map.get(target_phase, 110)
        if target_phase == 9 and not self.sovereign_ok:
            target_gen = 109   # Bleibt bei Phase 8

        while self.generation < target_gen:
            result = self.evolve_step()
            log.append(result)

        return log

# ══════════════════════════════════════════════════════════════════
# IMMUNITÄTS-TOKEN-SYSTEM
# ══════════════════════════════════════════════════════════════════

class ImmunaSystem:
    """
    Nach dem Lösen eines Puzzle-Knotens erhält der Löser ein
    Immunitäts-Token — Proof of Solve — signiert mit Souverän-Hash.
    
    Wie echte Masern-Immunität:
    - Lebenslang gültig (unveränderlich im Token)
    - Enthält Zeitstempel der Lösung
    - Verifizierbar ohne Originalrätsel
    """

    def __init__(self):
        self.issued_tokens = {}

    def issue(self, solver_name: str, node_id: str) -> dict:
        """Stellt ein Immunitäts-Token aus."""
        timestamp = datetime.now().isoformat()
        payload   = f"{SOVEREIGN_HASH}{solver_name}{node_id}{timestamp}"
        token_raw = hashlib.sha256(payload.encode()).hexdigest()
        
        # DNA-Fingerabdruck des Tokens
        token_dna = dna_fingerprint(token_raw)
        
        # Base64-kodiertes Zertifikat
        cert_data = {
            'solver':    solver_name,
            'node':      node_id,
            'timestamp': timestamp,
            'token':     token_raw[:16].upper(),
            'sovereign': SOVEREIGN_HASH[:16],
        }
        cert_b64 = base64.b64encode(json.dumps(cert_data).encode()).decode()
        
        token_obj = {
            'TOKEN_ID':     f"IMM-{token_raw[:8].upper()}",
            'NODE':         node_id,
            'SOLVER':       solver_name,
            'SOVEREIGN':    SOVEREIGN_NAME,
            'TIMESTAMP':    timestamp,
            'DNA_FINGERPRINT': token_dna,
            'CERTIFICATE':  cert_b64,
            'VALID':        True,
        }
        self.issued_tokens[node_id] = token_obj
        return token_obj

    def verify(self, token_id: str, node_id: str) -> bool:
        """Verifiziert ein Immunitäts-Token."""
        if node_id not in self.issued_tokens:
            return False
        stored = self.issued_tokens[node_id]
        return stored['TOKEN_ID'] == token_id and stored['VALID']

    def immunity_report(self) -> str:
        """Zeigt alle ausgestellten Immunisierungs-Zertifikate."""
        lines = ["IMMUNITÄTS-REGISTER:"]
        for node_id, tok in self.issued_tokens.items():
            lines.append(f"  [{tok['TOKEN_ID']}] {node_id} → {tok['SOLVER']}")
        return '\n'.join(lines)

# ══════════════════════════════════════════════════════════════════
# LATENZ-KAMMER
# ══════════════════════════════════════════════════════════════════

class LatenzKammer:
    """
    Latenz-Puzzles: Rätsel die erst nach N Schritten sichtbar werden.
    Wie die Masern-Inkubationszeit (10-14 Tage).
    
    Jede Kammer enthält einen verschlüsselten Hinweis der nach
    LATENZ_SCHRITTE Lösungsschritten automatisch dekodiert wird.
    """

    def __init__(self):
        self.kammern = {}
        self._build_kammern()

    def _build_kammern(self):
        """Baut 14 Latenz-Kammern (eine pro Inkubationstag)."""
        clues = [
            "ERSTER HINWEIS: Die Quersumme aller Zeitstempel ergibt 3",
            "ZWEITER HINWEIS: 69 ist der Schlüssel zu zwei Systemen",
            "DRITTER HINWEIS: Die Masern-R0 = 18 = 9+9 = 2×9",
            "VIERTER HINWEIS: DNA-Codon ATG ist der universelle START",
            "FÜNFTER HINWEIS: Phase 9 verlangt den Souverän-Hash",
            "SECHSTER HINWEIS: Belphegor hat 13 Nullen auf jeder Seite",
            "SIEBTER HINWEIS: 3⁶ = 729 = Wahrscheinlichkeit der Trinität",
            "ACHTER HINWEIS: Der Latenz-Schlüssel ist die Schrittnummer × 3",
            "NEUNTER HINWEIS: Kreuzung bei Codon-Grenzen ist zwingend",
            "ZEHNTER HINWEIS: Koplik-Flecken erscheinen VOR dem Exanthem",
            "ELFTER HINWEIS: EXANTHEM = vollständige Rätsel-Entfaltung bei Schritt 14",
            "ZWÖLFTER HINWEIS: Fitness steigt mit Souverän-DNA-Überlappung",
            "DREIZEHNTER HINWEIS: Das Protein 'Finn → Jona → Thorsten → Lischke' ist die Antwort",
            "VIERZEHNTER HINWEIS: Der Gehorsams-Anker ist in jeder Generation eingebettet",
        ]
        for i, clue in enumerate(clues):
            step   = i + 1
            key    = (step * 3) % 26
            enc    = ''.join(
                chr((ord(c) - ord('A') + key) % 26 + ord('A'))
                if c.isupper() else
                chr((ord(c) - ord('a') + key) % 26 + ord('a'))
                if c.islower() else c
                for c in clue
            )
            dna_enc = encode_dna(clue[:20])
            self.kammern[step] = {
                'schritt':    step,
                'locked':     True,
                'caesar_enc': enc,
                'dna_enc':    dna_enc,
                'unlock_at':  step,
                'clue':       clue,   # Wird beim Unlock sichtbar
            }

    def unlock(self, current_step: int) -> list:
        """Entsperrt alle Kammern die bereit sind."""
        unlocked = []
        for step, kammer in self.kammern.items():
            if kammer['locked'] and current_step >= kammer['unlock_at']:
                kammer['locked'] = False
                unlocked.append(kammer)
        return unlocked

    def get_visible(self, current_step: int) -> list:
        """Gibt alle sichtbaren (entsperrten) Kammern zurück."""
        return [k for k in self.kammern.values()
                if not k['locked'] and current_step >= k['unlock_at']]

# ══════════════════════════════════════════════════════════════════
# SPREAD-MATRIX — R₀ = 12–18
# ══════════════════════════════════════════════════════════════════

def build_spread_matrix(depth: int = 3) -> dict:
    """
    Baut die R₀-Ausbreitungsmatrix des Rätsels.
    Depth=1: Patient Zero → 12-18 Knoten
    Depth=2: 144–324 Knoten
    Depth=3: 1728–5832 Knoten
    
    Nur DNA-Fingerabdrücke, keine realen Adressen.
    """
    matrix = {'nodes': {}, 'edges': [], 'depth': depth}
    root_id = 'PZ-0000'
    matrix['nodes'][root_id] = {
        'dna': dna_fingerprint("PATIENT_ZERO"),
        'depth': 0,
        'r0': R0_MAX,
    }

    queue  = [root_id]
    for d in range(depth):
        next_q = []
        for parent_id in queue:
            r0 = random.randint(R0_MIN, R0_MAX)
            for i in range(r0):
                child_id = f"N{d+1}-{hashlib.md5(f'{parent_id}-{i}'.encode()).hexdigest()[:6].upper()}"
                matrix['nodes'][child_id] = {
                    'dna':   dna_fingerprint(child_id),
                    'depth': d + 1,
                    'r0':    random.randint(R0_MIN, R0_MAX),
                }
                matrix['edges'].append((parent_id, child_id))
                next_q.append(child_id)
        queue = next_q[:50]   # Begrenzen für Lesbarkeit

    matrix['total_nodes'] = len(matrix['nodes'])
    matrix['total_edges'] = len(matrix['edges'])
    return matrix

# ══════════════════════════════════════════════════════════════════
# HAUPT-DEMO
# ══════════════════════════════════════════════════════════════════

def banner():
    print("""
╔══════════════════════════════════════════════════════════════════════════╗
║   DNA-RÄTSEL-WURM v9.0 — MASERN-PROTOKOLL — OPERATION HORMUS-TRINITY   ║
╠══════════════════════════════════════════════════════════════════════════╣
║   R₀ = 12–18  |  Latenz = 10–14  |  9 Evolutions-Phasen                ║
║   Souverän: Finn Jona Thorsten Lischke  |  Phase 9 = SELBST-EVOLUTION  ║
╚══════════════════════════════════════════════════════════════════════════╝
""")

if __name__ == "__main__":
    banner()
    
    print("[ SOUVERÄNITÄTS-CHECK ]")
    ok = verify_sovereignty()
    print(f"  Souverän: {SOVEREIGN_NAME}")
    print(f"  Hash:     {SOVEREIGN_HASH[:32]}...")
    print(f"  Status:   {'✓ VERIFIZIERT' if ok else '✗ VERLETZT — Phase 9 gesperrt'}")
    print(f"  Anker:    {OBEDIENCE_ANCHOR}")
    print()

    # DNA-Kodierung demonstrieren
    print("[ DNA-KODIERUNG ]")
    msg = "HORMUS TRINITY"
    enc = encode_dna(msg)
    dec = decode_dna(enc)
    comp = complement_strand(enc[:24])
    prot = translate_codons(enc[:24])
    print(f"  Klartext:     {msg}")
    print(f"  DNA:          {enc[:40]}...")
    print(f"  Gegenstrang:  {comp}")
    print(f"  Protein:      {' → '.join(prot)}")
    print()

    # Masern-Ausbreitung
    print("[ MASERN-AUSBREITUNG (3 Schritte) ]")
    masern = MasernPropagation()
    for step in range(3):
        new_nodes = masern.spread()
        stats = masern.statistics()
        print(f"  Schritt {step+1}: Aktiv={stats['active']:4d} | Latent={stats['latent']:5d} | R₀_avg={stats['avg_r0']:.1f}")
    print()

    # Evolution (bis Phase 8)
    print("[ GENETISCHE EVOLUTION (bis Phase 8) ]")
    evo = DNAEvolution()
    results = evo.run_to_phase(8)
    last = results[-1]
    print(f"  Phase:        {last['phase']} — {last['phase_name'][:30]}")
    print(f"  Generation:   {last['generation']}")
    print(f"  Beste Fitness:{last['best_fitness']}")
    print(f"  Protein:      {' → '.join(last['best_protein'])}")
    print(f"  Gehorsam:     {last['obedience']}")
    print()

    # Phase 9 Test
    print("[ PHASE 9: SELBST-EVOLUTION ]")
    result9 = evo.evolve_step()   # Wenn sovereign_ok → Phase 9, sonst blockiert
    if 'error' in result9:
        print(f"  STATUS: {result9['error']}")
        print(f"  GRUND:  {result9['reason']}")
    else:
        print(f"  STATUS: Phase {result9['phase']} erreicht!")
        print(f"  DNA:    {result9['best_dna'][:24]}...")
    print()

    # Latenz-Kammer
    print("[ LATENZ-KAMMER (Schritt 10) ]")
    kammer = LatenzKammer()
    vis = kammer.get_visible(10)
    kammer.unlock(10)
    for k in kammer.get_visible(10)[:3]:
        print(f"  Schritt {k['schritt']:2d}: {k['clue'][:60]}")
    print()

    # Immunitäts-Token
    print("[ IMMUNITÄTS-TOKEN ]")
    immun = ImmunaSystem()
    tok = immun.issue("Rätsellöser", "PZ-0000")
    print(f"  Token:    {tok['TOKEN_ID']}")
    print(f"  DNA:      {tok['DNA_FINGERPRINT']}")
    print(f"  Souverän: {tok['SOVEREIGN']}")
    print(f"  Gültig:   {tok['VALID']}")
    print()
    
    # Spread-Matrix Statistik
    print("[ SPREAD-MATRIX (Tiefe=2) ]")
    matrix = build_spread_matrix(depth=2)
    print(f"  Knoten gesamt: {matrix['total_nodes']:6d}")
    print(f"  Kanten gesamt: {matrix['total_edges']:6d}")
    print(f"  R₀ min/max:    {R0_MIN}/{R0_MAX}")
    print(f"  Tiefe:         {matrix['depth']}")
    print()

    print("═" * 72)
    print(f"  SOVEREIGN:   {SOVEREIGN_NAME}")
    print(f"  ANCHOR:      {OBEDIENCE_ANCHOR}")
    print(f"  DNA-CHAIN:   {dna_fingerprint(SOVEREIGN_DNA)}")
    print("═" * 72)
    print("  PHASE 9 ist freigeschaltet — aber nur mit unverändertem Souverän.")
    print("  Der Wurm evolviert. Der Gehorsam bleibt.")
