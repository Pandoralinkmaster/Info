#!/usr/bin/env python3
"""
DIMENSION 20: VAMPIRE NUMBER FINDER
Clifford A. Pickover Methodik — angewandt auf Hormus-Zahlen
"""
import math, hashlib

def qs(n):
    s = sum(int(d) for d in str(abs(int(n))) if d.isdigit())
    return qs(s) if s >= 10 else s

def is_vampire(n):
    """Prüfe ob n eine Vampire Number ist."""
    digits = sorted(str(n))
    length = len(digits)
    if length % 2 != 0: return False, []
    half = length // 2
    start = 10**(half-1)
    end = 10**half
    fangs = []
    for a in range(start, end):
        if n % a == 0:
            b = n // a
            if start <= b <= end:
                if sorted(str(a) + str(b)) == digits:
                    fangs.append((a, b))
    return len(fangs) > 0, fangs

HORMUS_NUMBERS = [69, 189, 225, 850, 10000, 4761, 1260, 1395, 1435, 1827]

print("=" * 60)
print("  DIMENSION 20: PICKOVER VAMPIRE NUMBER FINDER")
print("=" * 60)
print()
print("HORMUS-ZAHLEN VAMPIR-ANALYSE:")
print()
for n in HORMUS_NUMBERS:
    is_v, fangs = is_vampire(n)
    q = qs(n)
    prime = all(n % i != 0 for i in range(2, int(math.sqrt(n))+1)) and n > 1
    print(f"  {n:8d}: QS={q} | Primzahl={prime} | Vampir={is_v} {fangs if fangs else ''}")

print()
print("BELPHEGOR'S PRIME ANALYSE:")
bp = '1000000000000066600000000000001'
print(f"  {bp}")
print(f"  Länge: {len(bp)} | QS={qs(int(bp))}")
print()

# The convergence
print("PICKOVER-KONSTANTE DES LABYRINTHS:")
hormus_qs = [qs(n) for n in HORMUS_NUMBERS[:8]]
total_qs = sum(hormus_qs)
print(f"  QS-Werte: {hormus_qs}")
print(f"  Σ = {total_qs} → QS = {qs(total_qs)}")
print()
print(f"FRAGMENT: {hashlib.sha256(str(total_qs).encode()).hexdigest()[:8]}")
print("Weiter zu DIMENSION_21_MASTERKEY_CHAMBER")
