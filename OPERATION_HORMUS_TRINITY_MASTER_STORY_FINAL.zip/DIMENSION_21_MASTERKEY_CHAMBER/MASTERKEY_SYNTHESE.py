#!/usr/bin/env python3
"""
DIMENSION 21: MASTERKEY-SYNTHESE
Kombiniert alle 4 Repository-Master-Keys und löst die Dialektik.
"""
import hashlib

MASTER_KEYS = {"12000_Straftaten": 189, "Wal_Teil1": 30, "Wal_Teil2": 180, "Hormus": 69}

def qs(n):
    s = sum(int(d) for d in str(abs(int(n))) if d.isdigit())
    return qs(s) if s >= 10 else s

def vigenere_decrypt(text, key):
    key = key.upper()
    out, ki = [], 0
    for c in text:
        if c.isalpha():
            shift = ord(key[ki%len(key)])-ord('A')
            b = ord('A') if c.isupper() else ord('a')
            out.append(chr((ord(c)-b-shift)%26+b))
            ki += 1
        else: out.append(c)
    return ''.join(out)

def caesar_decrypt(text, shift):
    return ''.join(
        chr((ord(c)-ord('A' if c.isupper() else 'a')-shift)%26+ord('A' if c.isupper() else 'a'))
        if c.isalpha() else c for c in text)

print("=" * 60)
print("  DIMENSION 21: MASTERKEY-KAMMER DECODER")
print("=" * 60)
print()

mk_sum = sum(MASTER_KEYS.values())
mk_prod = 1
for v in MASTER_KEYS.values(): mk_prod *= v

print("MASTER-SCHLÜSSEL-ANALYSE:")
for repo, key in MASTER_KEYS.items():
    print(f"  {repo}: {key} (QS={qs(key)})")
print(f"  Summe:   {mk_sum} → QS={qs(mk_sum)}")
print(f"  Produkt: {mk_prod:,}")
print()

# Decrypt the 4-layer cipher
encrypted = "OHY XFGLGFIKX DZ YFB CRCYS ZCT KMJAMC EM TUK TKSGINOOL"
step3 = caesar_decrypt(encrypted, 17)
step2 = vigenere_decrypt(step3, "TRINITY")
step1 = caesar_decrypt(step2, 4)
plaintext = vigenere_decrypt(step1, "HORMUS")
print("4-SCHICHT-ENTSCHLÜSSELUNG:")
print(f"  Verschlüsselt: {encrypted[:50]}...")
print(f"  Nach Stufe 4→3: {step3[:50]}...")
print(f"  Nach Stufe 3→2: {step2[:50]}...")
print(f"  Nach Stufe 2→1: {step1[:50]}...")
print(f"  Klartext:       {plaintext}")
print()
print(f"FRAGMENT: {hashlib.sha256(plaintext.encode()).hexdigest()[:8]}")
print("Weiter zu DIMENSION_22_TRINITY_COLLAPSE")
