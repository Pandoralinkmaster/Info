#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
╔══════════════════════════════════════════════════════════════════╗
║  OPERATION HORMUS-TRINITY — ARSENAL TOOL ALPHA-IMP-023
║  Kategorie:  Implants
║  Risk-Level: MEDIUM  (Cipher-Shift = 5)
║  Methode:    Vigenère(key=ALPHAIMP023)
║  Quelle:     alpha-backend/arsenal/exploits/alpha-exp-017.sh
║  Souverän:   Finn Jona Thorsten Lischke
╚══════════════════════════════════════════════════════════════════╝
"""
import hashlib, base64, sys, json

TOOL_ID       = "ALPHA-IMP-023"
TOOL_NUM      = 23
RISK_LEVEL    = "MEDIUM"
CIPHER_SHIFT  = 5
SOURCE_FILE   = "alpha-backend/arsenal/exploits/alpha-exp-017.sh"
SOURCE_TAG    = "arsenal"
SOURCE_HASH   = "3f0ac5987bb91a639fc3ee3e2549f43951ac6ac019e34b4d3b795aea85a2563e"
DNA_FINGERPRINT = "GTTGTGTCTAAGTATC"
SOVEREIGN     = "Finn Jona Thorsten Lischke"
SOV_HASH      = "6ac5d26005e86b60ba11207e156562756823815bae3d0287b9a73a48f5518842"
CHAIN         = "0f6ca04c9c67729b40f2df6c2ce675fb"
NEXT_TOOL     = "ALPHA-IMP-024"

# ── Echter Quell-Code (Rätsel-Material) ─────────────────────────
SOURCE_CODE = """
# ID: ALPHA-EXP-017
# Category: Exploits
# Description: Advanced Exploit for Project Alpha v7.0. Targeted at system optimization and security auditing.
echo "Executing Exploit Tool 17 (ALPHA-EXP-017)..."
case "Exploits" in
    "Exploits")
        echo "Performing vulnerability scan for Exploit Tool 17..."
        echo "Checking for outdated software versions..."
        echo "Scanning for common misconfigurations..."
        echo "Result: No critical vulnerabilities detected by Exploit Tool 17."
    "Implants")
        echo "Simulating persistence for Exploit Tool 17..."
"""

# ── Kodiertes Ergebnis ───────────────────────────────────────────
ENCODED = """# IO: PSPPM-TXA-017
# Rhtmsdrj: Teptaxtd
# Slskdxpexvn: Ipkayrld Mjelzxa fwd Erzylcb Mapsp c7.0. Tidveetk ab ensett oxfxmtohtqac ays zekggien huluiiyv.
lcpa "Txprbtqzv Eiesoqf Ioza 17 (HLXTP-EIE-017)..."
jaaq "Txaavibe" xn
    "Pmwlwuis")
        proo "Xqgfzgtivs kuwclrinxltif skmc fzg Lxxxdie Ivot 17..."
        qrhz "Roekwxnr uvr wgidlild aauthpye dqgstdus..."
        mowo "Drhnvucg qdy cwyboy b"""

# ── Encoding Functions ───────────────────────────────────────────
def caesar(text, shift):
    out = []
    for c in text:
        if c.isupper(): out.append(chr((ord(c)-65+shift)%26+65))
        elif c.islower(): out.append(chr((ord(c)-97+shift)%26+97))
        else: out.append(c)
    return ''.join(out)

def caesar_decrypt(text, shift): return caesar(text, -shift)

def vigenere_decrypt(text, key):
    key = ''.join(c for c in key.upper() if c.isalpha()) or 'ALPHA'
    out, ki = [], 0
    for c in text:
        if c.isalpha():
            shift = ord(key[ki % len(key)]) - 65
            b = 65 if c.isupper() else 97
            out.append(chr((ord(c)-b-shift)%26+b))
            ki += 1
        else: out.append(c)
    return ''.join(out)

def xor_decrypt(b64_text, key):
    raw = base64.b64decode(b64_text)
    return bytes(b ^ (key % 256) for b in raw).decode('utf-8','replace')

BASES = {'A':0,'C':1,'G':2,'T':3}
def dna_decode(dna):
    result = []
    for i in range(0, len(dna)-3, 4):
        chunk = dna[i:i+4]
        val = 0
        for base in chunk: val = val*4 + BASES.get(base,0)
        if 0 < val < 256: result.append(chr(val))
    return ''.join(result)

def tool_hash():
    payload = TOOL_ID + SOURCE_HASH + SOV_HASH
    return hashlib.sha256(payload.encode()).hexdigest()

def verify_sovereign():
    return hashlib.sha256(SOVEREIGN.encode()).hexdigest() == SOV_HASH

# ── MAIN ─────────────────────────────────────────────────────────
if __name__ == "__main__":
    print("=" * 62)
    print(f"  ARSENAL TOOL {TOOL_ID}")
    print(f"  Kategorie: Implants | Risk: {RISK_LEVEL} | Methode: Vigenère(key=ALPHAIMP023)")
    print("=" * 62)
    print()

    print(f"SOUVERÄN-CHECK: {'✓ OK' if verify_sovereign() else '✗ VERLETZT'}")
    print(f"TOOL-HASH:      {tool_hash()[:16]}")
    print(f"QUELL-DATEI:    {SOURCE_FILE}")
    print(f"QUELL-HASH:     {SOURCE_HASH[:16]}")
    print(f"DNA-FINGERPRINT:{DNA_FINGERPRINT}")
    print()

    # Decode attempt
    print("ENCODED SNIPPET (erste 120 Zeichen):")
    print(f"  {ENCODED[:120]}")
    print()

    # Decode hint
    print(f"ENTSCHLÜSSELUNGS-HINWEIS: vigenere_decrypt(ciphertext, key='ALPHAIMP023')")
    print(f"NÄCHSTES TOOL:  {NEXT_TOOL}")
    print()

    # Output as puzzle fragment
    fragment = {
        "tool_id":      TOOL_ID,
        "source_file":  SOURCE_FILE,
        "source_hash":  SOURCE_HASH[:16],
        "dna":          DNA_FINGERPRINT,
        "tool_hash":    tool_hash()[:16],
        "cipher":       "Vigenère(key=ALPHAIMP023)",
        "next_tool":    NEXT_TOOL,
        "sovereign_ok": verify_sovereign(),
    }
    print("PUZZLE-FRAGMENT (JSON):")
    print(json.dumps(fragment, indent=2))
