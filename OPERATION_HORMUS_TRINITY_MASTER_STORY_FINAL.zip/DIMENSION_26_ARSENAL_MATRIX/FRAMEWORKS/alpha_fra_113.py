#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
╔══════════════════════════════════════════════════════════════════╗
║  OPERATION HORMUS-TRINITY — ARSENAL TOOL ALPHA-FRA-113
║  Kategorie:  Frameworks
║  Risk-Level: MEDIUM  (Cipher-Shift = 5)
║  Methode:    DNA(20 Basen) + Morse
║  Quelle:     alpha-backend/arsenal/utilities/alpha-uti-092.sh
║  Souverän:   Finn Jona Thorsten Lischke
╚══════════════════════════════════════════════════════════════════╝
"""
import hashlib, base64, sys, json

TOOL_ID       = "ALPHA-FRA-113"
TOOL_NUM      = 113
RISK_LEVEL    = "MEDIUM"
CIPHER_SHIFT  = 5
SOURCE_FILE   = "alpha-backend/arsenal/utilities/alpha-uti-092.sh"
SOURCE_TAG    = "arsenal"
SOURCE_HASH   = "664ccb4db0ae684685a40f39fe004bcb6f91f494275b5dc7a8d54eeab07d24ae"
DNA_FINGERPRINT = "AAGGTTTGGGCGAATG"
SOVEREIGN     = "Finn Jona Thorsten Lischke"
SOV_HASH      = "6ac5d26005e86b60ba11207e156562756823815bae3d0287b9a73a48f5518842"
CHAIN         = "0f6ca04c9c67729b40f2df6c2ce675fb"
NEXT_TOOL     = "ALPHA-FRA-114"

# ── Echter Quell-Code (Rätsel-Material) ─────────────────────────
SOURCE_CODE = """
# ID: ALPHA-UTI-092
# Category: Utilities
# Description: Advanced Utilitie for Project Alpha v7.0. Targeted at system optimization and security auditing.
echo "Executing Utilitie Tool 92 (ALPHA-UTI-092)..."
case "Utilities" in
    "Exploits")
        echo "Performing vulnerability scan for Utilitie Tool 92..."
        echo "Checking for outdated software versions..."
        echo "Scanning for common misconfigurations..."
        echo "Result: No critical vulnerabilities detected by Utilitie Tool 92."
    "Implants")
        echo "Simulating persistence for Utilitie Tool 92..."
"""

# ── Kodiertes Ergebnis ───────────────────────────────────────────
ENCODED = """DNA: AGATAGAACAGCCACAATGG
MORSE: ? .. -.. ? .- .-.. .--. .... .- ? ..- - .."""

# ── Encoding Functions ───────────────────────────────────────────
def caesar(text, shift):
    out = []
    for c in text:
        if c.isupper(): out.append(chr((ord(c)-65+shift)%26+65))
        elif c.islower(): out.append(chr((ord(c)-97+shift)%26+97))
        else: out.append(c)
    return ''.join(out)

def caesar_decrypt(text, shift): return caesar(text, -shift)

def vigenere_decrypt(text, key):
    key = ''.join(c for c in key.upper() if c.isalpha()) or 'ALPHA'
    out, ki = [], 0
    for c in text:
        if c.isalpha():
            shift = ord(key[ki % len(key)]) - 65
            b = 65 if c.isupper() else 97
            out.append(chr((ord(c)-b-shift)%26+b))
            ki += 1
        else: out.append(c)
    return ''.join(out)

def xor_decrypt(b64_text, key):
    raw = base64.b64decode(b64_text)
    return bytes(b ^ (key % 256) for b in raw).decode('utf-8','replace')

BASES = {'A':0,'C':1,'G':2,'T':3}
def dna_decode(dna):
    result = []
    for i in range(0, len(dna)-3, 4):
        chunk = dna[i:i+4]
        val = 0
        for base in chunk: val = val*4 + BASES.get(base,0)
        if 0 < val < 256: result.append(chr(val))
    return ''.join(result)

def tool_hash():
    payload = TOOL_ID + SOURCE_HASH + SOV_HASH
    return hashlib.sha256(payload.encode()).hexdigest()

def verify_sovereign():
    return hashlib.sha256(SOVEREIGN.encode()).hexdigest() == SOV_HASH

# ── MAIN ─────────────────────────────────────────────────────────
if __name__ == "__main__":
    print("=" * 62)
    print(f"  ARSENAL TOOL {TOOL_ID}")
    print(f"  Kategorie: Frameworks | Risk: {RISK_LEVEL} | Methode: DNA(20 Basen) + Morse")
    print("=" * 62)
    print()

    print(f"SOUVERÄN-CHECK: {'✓ OK' if verify_sovereign() else '✗ VERLETZT'}")
    print(f"TOOL-HASH:      {tool_hash()[:16]}")
    print(f"QUELL-DATEI:    {SOURCE_FILE}")
    print(f"QUELL-HASH:     {SOURCE_HASH[:16]}")
    print(f"DNA-FINGERPRINT:{DNA_FINGERPRINT}")
    print()

    # Decode attempt
    print("ENCODED SNIPPET (erste 120 Zeichen):")
    print(f"  {ENCODED[:120]}")
    print()

    # Decode hint
    print(f"ENTSCHLÜSSELUNGS-HINWEIS: DNA→bytes (4 Basen = 1 Byte), dann Morse")
    print(f"NÄCHSTES TOOL:  {NEXT_TOOL}")
    print()

    # Output as puzzle fragment
    fragment = {
        "tool_id":      TOOL_ID,
        "source_file":  SOURCE_FILE,
        "source_hash":  SOURCE_HASH[:16],
        "dna":          DNA_FINGERPRINT,
        "tool_hash":    tool_hash()[:16],
        "cipher":       "DNA(20 Basen) + Morse",
        "next_tool":    NEXT_TOOL,
        "sovereign_ok": verify_sovereign(),
    }
    print("PUZZLE-FRAGMENT (JSON):")
    print(json.dumps(fragment, indent=2))
