#!/usr/bin/env python3
"""
DIMENSION 18: BITCOIN-GENESIS-DECODER
Verbindet Operation Hormus-Trinity mit dem Satoshi-Prinzip.

Genesis Block Hash:
000000000019d6689c085ae165831e934ff763ae46a2a6c172b3f1b60a8ce26f

Master-Schlüssel der 4 Repositories: 189, 30, 180, 69
"""
import hashlib, base64

GENESIS_HASH = "000000000019d6689c085ae165831e934ff763ae46a2a6c172b3f1b60a8ce26f"
MASTER_KEYS = {"12000_Straftaten": 189, "Wal_Teil1": 30, "Wal_Teil2": 180, "Hormus": 69}
ARTICLE_ID = "69c61eccaf187d606b8148a0"

def qs(n):
    """Quersumme berechnen."""
    s = sum(int(d) for d in str(n) if d.isdigit())
    return qs(s) if s >= 10 else s

def caesar(text, shift):
    out = []
    for c in text:
        if c.isalpha():
            b = ord('A') if c.isupper() else ord('a')
            out.append(chr((ord(c)-b+shift)%26+b))
        else: out.append(c)
    return ''.join(out)

print("=" * 60)
print("  DIMENSION 18: SATOSHI-ORAKEL DECODER")
print("=" * 60)
print()

# Genesis Block Analysis
genesis_qs = qs(int("03012009"))
print(f"Genesis Block: 000000000019d6689c08...")
print(f"Leading Zeros: {GENESIS_HASH.count('0', 0, GENESIS_HASH.index(next(c for c in GENESIS_HASH if c != '0')))}")
print(f"Genesis Datum QS: 03/01/2009 → {genesis_qs} (GENESIS-SCHLÜSSEL)")
print()

# Master Key Analysis
print("MASTER-SCHLÜSSEL ALLER REPOSITORIES:")
total = 0
for repo, key in MASTER_KEYS.items():
    q = qs(key)
    print(f"  {repo}: {key} (QS={q})")
    total += key
print(f"  KOMBINATION: {total} → QS={qs(total)}")
print()

# Hex Article ID
print(f"ARTIKEL-ID: {ARTICLE_ID}")
bytes_list = [ARTICLE_ID[i:i+2] for i in range(0, len(ARTICLE_ID), 2)]
qs_list = [qs(int(b, 16)) for b in bytes_list if b]
qs_six = sum(1 for q in qs_list if q == 6)
qs_three = sum(1 for q in qs_list if q == 3)
print(f"  Hex-Bytes mit QS=6: {qs_six}")
print(f"  Hex-Bytes mit QS=3: {qs_three}")
print(f"  ARTIKEL-ID Fragment: {hashlib.sha256(ARTICLE_ID.encode()).hexdigest()[:8]}")
print()

# Decrypt the oracle
encrypted = "ZNK SGYZKX QKE OY ZNK ZXOTOZE UL ZOSK"
decrypted = caesar(encrypted, -genesis_qs)
print(f"ORAKEL-ENTSCHLÜSSELUNG (Shift={genesis_qs}):")
print(f"  Verschlüsselt: {encrypted}")
print(f"  Entschlüsselt: {decrypted}")
print()
print(f"CHAIN: {hashlib.sha256((ARTICLE_ID + str(total)).encode()).hexdigest()[:16]}")
print("Weiter zu DIMENSION_19_LIVETICKER_MATRIX")
