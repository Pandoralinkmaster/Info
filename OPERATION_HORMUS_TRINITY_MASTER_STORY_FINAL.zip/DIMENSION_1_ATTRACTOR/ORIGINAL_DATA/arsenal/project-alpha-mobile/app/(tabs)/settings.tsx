import {
  ScrollView,
  Text,
  View,
  TouchableOpacity,
  TextInput,
  ActivityIndicator,
  Alert,
} from "react-native";
import { useState, useEffect, useCallback } from "react";
import { useRouter } from "expo-router";
import { ScreenContainer } from "@/components/screen-container";
import { useAuthContext } from "@/lib/auth-context";
import { useColors } from "@/hooks/use-colors";

export default function SettingsScreen() {
  const router = useRouter();
  const { apiClient, logout, setApiConfig } = useAuthContext();
  const colors = useColors();

  const [baseURL, setBaseURL] = useState("");
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [isTesting, setIsTesting] = useState(false);
  const [testResult, setTestResult] = useState<string | null>(null);

  useEffect(() => {
    if (apiClient) {
      const config = apiClient.getConfig();
      setBaseURL(config.baseURL);
      setUsername(config.username);
      setPassword(config.password);
    }
  }, [apiClient]);

  const handleTestConnection = useCallback(async () => {
    if (!baseURL.trim()) {
      Alert.alert("Error", "Server URL is required");
      return;
    }

    setIsTesting(true);
    setTestResult(null);

    try {
      const response = await fetch(`${baseURL}/api/health`, {
        headers: {
          Authorization: `Basic ${Buffer.from(`${username}:${password}`).toString(
            "base64"
          )}`,
        },
      });

      if (response.ok) {
        const data = await response.json();
        setTestResult(`✓ Connection successful\nStatus: ${data.stat}`);
      } else {
        setTestResult(`✗ Connection failed\nStatus: ${response.status}`);
      }
    } catch (err) {
      const errorMsg = err instanceof Error ? err.message : "Connection failed";
      setTestResult(`✗ Error: ${errorMsg}`);
    } finally {
      setIsTesting(false);
    }
  }, [baseURL, username, password]);

  const handleSaveSettings = useCallback(async () => {
    if (!baseURL.trim() || !username.trim() || !password.trim()) {
      Alert.alert("Error", "All fields are required");
      return;
    }

    try {
      setIsLoading(true);
      setApiConfig({
        baseURL,
        username,
        password,
      });
      Alert.alert("Success", "Settings saved successfully");
    } catch (err) {
      Alert.alert("Error", "Failed to save settings");
    } finally {
      setIsLoading(false);
    }
  }, [baseURL, username, password, setApiConfig]);

  const handleLogout = () => {
    Alert.alert("Logout", "Are you sure you want to logout?", [
      { text: "Cancel", style: "cancel" },
      {
        text: "Logout",
        style: "destructive",
        onPress: async () => {
          await logout();
          router.replace("/login");
        },
      },
    ]);
  };

  return (
    <ScreenContainer className="bg-background p-4">
      <ScrollView
        contentContainerStyle={{ flexGrow: 1 }}
        showsVerticalScrollIndicator={false}
      >
        {/* Header */}
        <View className="mb-6">
          <Text className="text-2xl font-bold text-foreground mb-1">
            Settings
          </Text>
          <Text className="text-sm text-muted">Configuration & Preferences</Text>
        </View>

        {/* Server Configuration Section */}
        <View className="mb-6">
          <Text className="text-foreground font-semibold text-sm mb-4">
            Server Configuration
          </Text>

          {/* Server URL */}
          <View className="mb-4">
            <Text className="text-muted text-sm mb-2 font-medium">
              Server URL
            </Text>
            <TextInput
              className="bg-surface border border-border rounded-lg px-4 py-3 text-foreground"
              placeholderTextColor={colors.muted}
              placeholder="http://localhost:58133"
              value={baseURL}
              onChangeText={setBaseURL}
              editable={!isLoading && !isTesting}
              autoCapitalize="none"
              keyboardType="url"
            />
          </View>

          {/* Username */}
          <View className="mb-4">
            <Text className="text-muted text-sm mb-2 font-medium">
              Username
            </Text>
            <TextInput
              className="bg-surface border border-border rounded-lg px-4 py-3 text-foreground"
              placeholderTextColor={colors.muted}
              placeholder="admin"
              value={username}
              onChangeText={setUsername}
              editable={!isLoading && !isTesting}
              autoCapitalize="none"
            />
          </View>

          {/* Password */}
          <View className="mb-6">
            <Text className="text-muted text-sm mb-2 font-medium">
              Password
            </Text>
            <TextInput
              className="bg-surface border border-border rounded-lg px-4 py-3 text-foreground"
              placeholderTextColor={colors.muted}
              placeholder="••••••••"
              value={password}
              onChangeText={setPassword}
              editable={!isLoading && !isTesting}
              secureTextEntry
            />
          </View>

          {/* Test Connection Button */}
          <TouchableOpacity
            onPress={handleTestConnection}
            disabled={isTesting || isLoading}
            className="bg-primary rounded-lg py-3 items-center mb-4"
          >
            {isTesting ? (
              <ActivityIndicator color={colors.background} size="small" />
            ) : (
              <Text className="text-background font-semibold">
                Test Connection
              </Text>
            )}
          </TouchableOpacity>

          {/* Test Result */}
          {testResult && (
            <View
              className={`rounded-lg p-4 mb-4 border ${
                testResult.includes("✓")
                  ? "bg-success/10 border-success"
                  : "bg-error/10 border-error"
              }`}
            >
              <Text
                className={`text-sm ${
                  testResult.includes("✓") ? "text-success" : "text-error"
                }`}
              >
                {testResult}
              </Text>
            </View>
          )}

          {/* Save Settings Button */}
          <TouchableOpacity
            onPress={handleSaveSettings}
            disabled={isLoading || isTesting}
            className="bg-primary rounded-lg py-3 items-center"
          >
            {isLoading ? (
              <ActivityIndicator color={colors.background} size="small" />
            ) : (
              <Text className="text-background font-semibold">
                Save Settings
              </Text>
            )}
          </TouchableOpacity>
        </View>

        {/* App Information Section */}
        <View className="mb-6">
          <Text className="text-foreground font-semibold text-sm mb-4">
            App Information
          </Text>

          <View className="bg-surface border border-border rounded-lg p-4 gap-3">
            <View className="pb-3 border-b border-border">
              <Text className="text-muted text-xs mb-1">App Name</Text>
              <Text className="text-foreground text-sm">Project Alpha</Text>
            </View>

            <View className="pb-3 border-b border-border">
              <Text className="text-muted text-xs mb-1">Version</Text>
              <Text className="text-foreground text-sm">1.0.0</Text>
            </View>

            <View className="pb-3 border-b border-border">
              <Text className="text-muted text-xs mb-1">Platform</Text>
              <Text className="text-foreground text-sm">React Native + Expo</Text>
            </View>

            <View>
              <Text className="text-muted text-xs mb-1">Build</Text>
              <Text className="text-foreground text-sm">Production Ready</Text>
            </View>
          </View>
        </View>

        {/* About Section */}
        <View className="mb-6">
          <Text className="text-foreground font-semibold text-sm mb-4">
            About
          </Text>

          <View className="bg-surface border border-border rounded-lg p-4">
            <Text className="text-muted text-xs leading-relaxed">
              Project Alpha v7.0 — IoT Device Management Platform
            </Text>
            <Text className="text-muted text-xs leading-relaxed mt-3">
              Finn Jona Thorsten Lischke — Principal Researcher
            </Text>
            <Text className="text-muted text-xs leading-relaxed mt-3">
              © 2026 Project Alpha. All rights reserved.
            </Text>
          </View>
        </View>

        {/* Logout Button */}
        <TouchableOpacity
          onPress={handleLogout}
          className="bg-error/10 border border-error rounded-lg py-3 items-center"
        >
          <Text className="text-error font-semibold">Logout</Text>
        </TouchableOpacity>
      </ScrollView>
    </ScreenContainer>
  );
}
