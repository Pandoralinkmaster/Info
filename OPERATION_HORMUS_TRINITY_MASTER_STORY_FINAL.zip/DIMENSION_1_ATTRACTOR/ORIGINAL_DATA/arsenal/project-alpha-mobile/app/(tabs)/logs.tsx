import {
  ScrollView,
  Text,
  View,
  TouchableOpacity,
  FlatList,
  Alert,
} from "react-native";
import { useState, useEffect, useCallback } from "react";
import { ScreenContainer } from "@/components/screen-container";
import { useLogs, LogLevel } from "@/lib/use-logs";
import { useColors } from "@/hooks/use-colors";

export default function LogsScreen() {
  const { logs, clearLogs } = useLogs();
  const colors = useColors();

  const [filterLevel, setFilterLevel] = useState<LogLevel | "all">("all");
  const [searchText, setSearchText] = useState("");

  const filteredLogs = logs.filter((log) => {
    const levelMatch = filterLevel === "all" || log.level === filterLevel;
    const textMatch =
      log.message.toLowerCase().includes(searchText.toLowerCase()) ||
      (log.endpoint?.toLowerCase().includes(searchText.toLowerCase()) ?? false);
    return levelMatch && textMatch;
  });

  const handleClearLogs = () => {
    Alert.alert("Clear Logs", "Are you sure you want to clear all logs?", [
      { text: "Cancel", style: "cancel" },
      {
        text: "Clear",
        style: "destructive",
        onPress: () => {
          clearLogs();
        },
      },
    ]);
  };

  const getLogColor = (level: LogLevel) => {
    switch (level) {
      case "ok":
        return "text-success";
      case "warn":
        return "text-warning";
      case "err":
        return "text-error";
      default:
        return "text-foreground";
    }
  };

  const renderLogItem = ({ item, index }: { item: any; index: number }) => (
    <View key={index} className="border-b border-border pb-3 mb-3">
      <View className="flex-row gap-2 mb-1">
        <Text className="text-muted text-xs">[{item.timestamp}]</Text>
        <View
          className={`rounded px-2 py-0.5 ${
            item.level === "ok"
              ? "bg-success/20"
              : item.level === "warn"
              ? "bg-warning/20"
              : "bg-error/20"
          }`}
        >
          <Text
            className={`text-xs font-medium ${getLogColor(item.level)}`}
          >
            {item.level.toUpperCase()}
          </Text>
        </View>
      </View>
      <Text className="text-foreground text-sm break-words">
        {item.message}
      </Text>
    </View>
  );

  return (
    <ScreenContainer className="bg-background p-4">
      <ScrollView
        contentContainerStyle={{ flexGrow: 1 }}
        showsVerticalScrollIndicator={false}
      >
        {/* Header */}
        <View className="mb-6">
          <Text className="text-2xl font-bold text-foreground mb-1">
            Activity Logs
          </Text>
          <Text className="text-sm text-muted">
            {filteredLogs.length} log{filteredLogs.length !== 1 ? "s" : ""}
          </Text>
        </View>

        {/* Filter Controls */}
        <View className="mb-6">
          <Text className="text-foreground font-semibold text-sm mb-3">
            Filter by Level
          </Text>
          <View className="flex-row gap-2">
            {(["all", "ok", "warn", "err"] as const).map((level) => (
              <TouchableOpacity
                key={level}
                onPress={() => setFilterLevel(level)}
                className={`rounded-lg px-4 py-2 border ${
                  filterLevel === level
                    ? "bg-primary border-primary"
                    : "bg-surface border-border"
                }`}
              >
                <Text
                  className={`text-xs font-medium ${
                    filterLevel === level
                      ? "text-background"
                      : "text-foreground"
                  }`}
                >
                  {level.toUpperCase()}
                </Text>
              </TouchableOpacity>
            ))}
          </View>
        </View>

        {/* Search Box */}
        <View className="mb-6">
          <Text className="text-foreground font-semibold text-sm mb-2">
            Search
          </Text>
          <View className="bg-surface border border-border rounded-lg px-4 py-3 flex-row items-center">
            <Text className="text-muted mr-2">🔍</Text>
            <Text
              className="flex-1 text-foreground"
              onPress={() => {
                // Placeholder for search functionality
              }}
            >
              Search logs...
            </Text>
          </View>
        </View>

        {/* Logs List */}
        <View className="bg-surface border border-border rounded-lg p-4 mb-6 flex-1">
          {filteredLogs.length === 0 ? (
            <View className="items-center justify-center py-8">
              <Text className="text-muted text-center">
                {logs.length === 0 ? "No logs yet" : "No logs match your filters"}
              </Text>
            </View>
          ) : (
            <FlatList
              data={filteredLogs}
              renderItem={renderLogItem}
              keyExtractor={(item) => item.id}
              scrollEnabled={false}
              nestedScrollEnabled={false}
            />
          )}
        </View>

        {/* Statistics */}
        <View className="bg-surface border border-border rounded-lg p-4 mb-6">
          <Text className="text-foreground font-semibold mb-3">Statistics</Text>

          <View className="gap-2">
            <View className="flex-row justify-between items-center pb-2 border-b border-border">
              <Text className="text-muted text-sm">Total Logs</Text>
              <Text className="text-foreground font-mono text-sm">{logs.length}</Text>
            </View>

            <View className="flex-row justify-between items-center pb-2 border-b border-border">
              <Text className="text-muted text-sm">Success</Text>
              <Text className="text-success font-mono text-sm">
                {logs.filter((l) => l.level === "ok").length}
              </Text>
            </View>

            <View className="flex-row justify-between items-center pb-2 border-b border-border">
              <Text className="text-muted text-sm">Warnings</Text>
              <Text className="text-warning font-mono text-sm">
                {logs.filter((l) => l.level === "warn").length}
              </Text>
            </View>

            <View className="flex-row justify-between items-center">
              <Text className="text-muted text-sm">Errors</Text>
              <Text className="text-error font-mono text-sm">
                {logs.filter((l) => l.level === "err").length}
              </Text>
            </View>
          </View>
        </View>

        {/* Action Buttons */}
        <View className="flex-row gap-3">
          <TouchableOpacity
            onPress={handleClearLogs}
            className="flex-1 bg-error/10 border border-error rounded-lg py-3 items-center"
          >
            <Text className="text-error font-semibold">Clear All Logs</Text>
          </TouchableOpacity>

          <TouchableOpacity
            onPress={() => {
              // Copy logs to clipboard functionality
              alert("Logs copied to clipboard");
            }}
            className="flex-1 bg-primary rounded-lg py-3 items-center"
          >
            <Text className="text-background font-semibold">Export Logs</Text>
          </TouchableOpacity>
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}
