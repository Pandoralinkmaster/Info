import {
  ScrollView,
  Text,
  View,
  TouchableOpacity,
  ActivityIndicator,
  FlatList,
  Modal,
  TextInput,
  Alert,
  RefreshControl,
} from "react-native";
import { useState, useEffect, useCallback } from "react";
import { ScreenContainer } from "@/components/screen-container";
import { useAuthContext } from "@/lib/auth-context";
import { useColors } from "@/hooks/use-colors";

interface DeviceNode {
  id: string;
  type: string;
  ts: string;
}

export default function MobileNodesScreen() {
  const { apiClient } = useAuthContext();
  const colors = useColors();

  const [nodes, setNodes] = useState<DeviceNode[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [showModal, setShowModal] = useState(false);
  const [deviceId, setDeviceId] = useState("");
  const [deviceType, setDeviceType] = useState("mobile");
  const [isRegistering, setIsRegistering] = useState(false);

  useEffect(() => {
    loadNodes();
  }, []);

  const loadNodes = useCallback(async () => {
    if (!apiClient) return;

    try {
      setIsLoading(true);
      const response = await apiClient.getMobileNodes();
      setNodes(response.nodes);
    } catch (err) {
      console.error("Failed to load nodes:", err);
      Alert.alert("Error", "Failed to load mobile nodes");
    } finally {
      setIsLoading(false);
    }
  }, [apiClient]);

  const onRefresh = useCallback(async () => {
    setIsRefreshing(true);
    await loadNodes();
    setIsRefreshing(false);
  }, [loadNodes]);

  const handleRegisterDevice = useCallback(async () => {
    if (!deviceId.trim()) {
      Alert.alert("Error", "Device ID is required");
      return;
    }

    if (!apiClient) return;

    try {
      setIsRegistering(true);
      const response = await apiClient.registerDevice({
        id: deviceId,
        type: deviceType,
      });

      if (response.reg) {
        Alert.alert("Success", `Device ${deviceId} registered successfully`);
        setDeviceId("");
        setDeviceType("mobile");
        setShowModal(false);
        await loadNodes();
      }
    } catch (err) {
      const errorMsg = err instanceof Error ? err.message : "Registration failed";
      Alert.alert("Error", errorMsg);
    } finally {
      setIsRegistering(false);
    }
  }, [deviceId, deviceType, apiClient, loadNodes]);

  if (isLoading) {
    return (
      <ScreenContainer className="bg-background items-center justify-center">
        <ActivityIndicator color={colors.primary} size="large" />
      </ScreenContainer>
    );
  }

  return (
    <ScreenContainer className="bg-background p-4">
      <ScrollView
        contentContainerStyle={{ flexGrow: 1 }}
        showsVerticalScrollIndicator={false}
        refreshControl={
          <RefreshControl
            refreshing={isRefreshing}
            onRefresh={onRefresh}
            tintColor={colors.primary}
          />
        }
      >
        {/* Header */}
        <View className="mb-6">
          <Text className="text-2xl font-bold text-foreground mb-1">
            Mobile Nodes
          </Text>
          <Text className="text-sm text-muted">
            {nodes.length} device{nodes.length !== 1 ? "s" : ""} registered
          </Text>
        </View>

        {/* Register Button */}
        <TouchableOpacity
          onPress={() => setShowModal(true)}
          className="bg-primary rounded-lg py-3 items-center mb-6"
        >
          <Text className="text-background font-semibold">
            + Register New Device
          </Text>
        </TouchableOpacity>

        {/* Devices List */}
        {nodes.length === 0 ? (
          <View className="bg-surface border border-border rounded-lg p-6 items-center">
            <Text className="text-muted text-center">No devices registered yet</Text>
          </View>
        ) : (
          <View className="gap-3">
            {nodes.map((node, idx) => (
              <View
                key={idx}
                className="bg-surface border border-border rounded-lg p-4"
              >
                <View className="flex-row justify-between items-start mb-3">
                  <View className="flex-1">
                    <Text className="text-foreground font-semibold text-sm mb-1">
                      {node.id}
                    </Text>
                    <View className="flex-row gap-2 items-center">
                      <View className="bg-success/20 rounded px-2 py-1">
                        <Text className="text-success text-xs font-medium">
                          {node.type}
                        </Text>
                      </View>
                      <Text className="text-muted text-xs">
                        Online
                      </Text>
                    </View>
                  </View>
                </View>

                <View className="border-t border-border pt-3">
                  <Text className="text-muted text-xs">
                    Registered: {new Date(node.ts).toLocaleString("de-DE")}
                  </Text>
                </View>
              </View>
            ))}
          </View>
        )}

        {/* Register Modal */}
        <Modal
          visible={showModal}
          transparent
          animationType="slide"
          onRequestClose={() => setShowModal(false)}
        >
          <View className="flex-1 bg-black/50 justify-end">
            <View className="bg-background rounded-t-2xl p-6">
              <View className="mb-6">
                <Text className="text-2xl font-bold text-foreground mb-2">
                  Register Device
                </Text>
                <Text className="text-muted text-sm">
                  Add a new mobile node to the system
                </Text>
              </View>

              {/* Device ID Input */}
              <View className="mb-4">
                <Text className="text-muted text-sm mb-2 font-medium">
                  Device ID
                </Text>
                <TextInput
                  className="bg-surface border border-border rounded-lg px-4 py-3 text-foreground"
                  placeholderTextColor={colors.muted}
                  placeholder="e.g., DEVICE-001"
                  value={deviceId}
                  onChangeText={setDeviceId}
                  editable={!isRegistering}
                />
              </View>

              {/* Device Type Input */}
              <View className="mb-6">
                <Text className="text-muted text-sm mb-2 font-medium">
                  Device Type
                </Text>
                <View className="flex-row gap-2">
                  {["mobile", "node", "gateway"].map((type) => (
                    <TouchableOpacity
                      key={type}
                      onPress={() => setDeviceType(type)}
                      className={`flex-1 rounded-lg py-3 items-center border ${
                        deviceType === type
                          ? "bg-primary border-primary"
                          : "bg-surface border-border"
                      }`}
                    >
                      <Text
                        className={`font-medium text-sm ${
                          deviceType === type
                            ? "text-background"
                            : "text-foreground"
                        }`}
                      >
                        {type}
                      </Text>
                    </TouchableOpacity>
                  ))}
                </View>
              </View>

              {/* Action Buttons */}
              <View className="flex-row gap-3">
                <TouchableOpacity
                  onPress={() => setShowModal(false)}
                  disabled={isRegistering}
                  className="flex-1 bg-surface border border-border rounded-lg py-3 items-center"
                >
                  <Text className="text-foreground font-semibold">Cancel</Text>
                </TouchableOpacity>

                <TouchableOpacity
                  onPress={handleRegisterDevice}
                  disabled={isRegistering}
                  className="flex-1 bg-primary rounded-lg py-3 items-center"
                >
                  {isRegistering ? (
                    <ActivityIndicator color={colors.background} size="small" />
                  ) : (
                    <Text className="text-background font-semibold">Register</Text>
                  )}
                </TouchableOpacity>
              </View>
            </View>
          </View>
        </Modal>
      </ScrollView>
    </ScreenContainer>
  );
}
