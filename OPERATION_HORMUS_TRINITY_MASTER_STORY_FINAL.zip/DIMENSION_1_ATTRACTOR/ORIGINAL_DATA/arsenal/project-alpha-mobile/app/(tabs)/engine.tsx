import { ScrollView, Text, View, TouchableOpacity, ActivityIndicator, RefreshControl } from "react-native";
import { useState, useEffect, useCallback } from "react";
import { ScreenContainer } from "@/components/screen-container";
import { useAuthContext } from "@/lib/auth-context";
import { useColors } from "@/hooks/use-colors";

interface EvolutionEntry {
  gen: number;
  mut: number;
  old: string;
  new: string;
  ts: string;
}

export default function EngineStatusScreen() {
  const { apiClient } = useAuthContext();
  const colors = useColors();

  const [engineStatus, setEngineStatus] = useState<any>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [isRefreshing, setIsRefreshing] = useState(false);

  useEffect(() => {
    loadEngineStatus();
  }, []);

  const loadEngineStatus = useCallback(async () => {
    if (!apiClient) return;

    try {
      setIsLoading(true);
      const status = await apiClient.getEngineStatus();
      setEngineStatus(status);
    } catch (err) {
      console.error("Failed to load engine status:", err);
    } finally {
      setIsLoading(false);
    }
  }, [apiClient]);

  const onRefresh = useCallback(async () => {
    setIsRefreshing(true);
    await loadEngineStatus();
    setIsRefreshing(false);
  }, [loadEngineStatus]);

  if (isLoading) {
    return (
      <ScreenContainer className="bg-background items-center justify-center">
        <ActivityIndicator color={colors.primary} size="large" />
      </ScreenContainer>
    );
  }

  return (
    <ScreenContainer className="bg-background p-4">
      <ScrollView
        contentContainerStyle={{ flexGrow: 1 }}
        showsVerticalScrollIndicator={false}
        refreshControl={
          <RefreshControl
            refreshing={isRefreshing}
            onRefresh={onRefresh}
            tintColor={colors.primary}
          />
        }
      >
        {/* Header */}
        <View className="mb-6">
          <Text className="text-2xl font-bold text-foreground mb-1">
            Engine Status
          </Text>
          <Text className="text-sm text-muted">System Information</Text>
        </View>

        {engineStatus && (
          <>
            {/* Core Metrics */}
            <View className="bg-surface border border-border rounded-lg p-4 mb-6">
              <Text className="text-foreground font-semibold mb-4">Core Metrics</Text>

              <View className="gap-3">
                <View className="flex-row justify-between items-center pb-3 border-b border-border">
                  <Text className="text-muted text-sm">Version</Text>
                  <Text className="text-foreground font-mono text-sm">
                    {engineStatus.ver}
                  </Text>
                </View>

                <View className="flex-row justify-between items-center pb-3 border-b border-border">
                  <Text className="text-muted text-sm">Generation</Text>
                  <Text className="text-foreground font-mono text-sm">
                    {engineStatus.gen}
                  </Text>
                </View>

                <View className="flex-row justify-between items-center pb-3 border-b border-border">
                  <Text className="text-muted text-sm">Mutations</Text>
                  <Text className="text-foreground font-mono text-sm">
                    {engineStatus.mut}
                  </Text>
                </View>

                <View className="flex-row justify-between items-center pb-3 border-b border-border">
                  <Text className="text-muted text-sm">Confidence</Text>
                  <Text className="text-success font-mono text-sm">
                    {engineStatus.conf.toFixed(1)}%
                  </Text>
                </View>

                <View className="flex-row justify-between items-center pb-3 border-b border-border">
                  <Text className="text-muted text-sm">Status</Text>
                  <Text className="text-success font-mono text-sm">
                    {engineStatus.stat}
                  </Text>
                </View>

                <View className="flex-row justify-between items-center">
                  <Text className="text-muted text-sm">Uptime</Text>
                  <Text className="text-foreground font-mono text-sm">
                    {engineStatus.upf}
                  </Text>
                </View>
              </View>
            </View>

            {/* DNA Information */}
            <View className="bg-surface border border-border rounded-lg p-4 mb-6">
              <Text className="text-foreground font-semibold mb-3">DNA</Text>
              <View className="bg-background rounded p-3 border border-border">
                <Text className="text-success font-mono text-xs break-words">
                  {engineStatus.dna}
                </Text>
              </View>
            </View>

            {/* System Information */}
            <View className="bg-surface border border-border rounded-lg p-4 mb-6">
              <Text className="text-foreground font-semibold mb-4">System</Text>

              <View className="gap-3">
                <View className="flex-row justify-between items-center pb-3 border-b border-border">
                  <Text className="text-muted text-sm">System ID</Text>
                  <Text className="text-foreground font-mono text-xs">
                    {engineStatus.sys.substring(0, 20)}...
                  </Text>
                </View>

                <View className="flex-row justify-between items-center pb-3 border-b border-border">
                  <Text className="text-muted text-sm">Instances</Text>
                  <Text className="text-foreground font-mono text-sm">
                    {engineStatus.inst}
                  </Text>
                </View>

                <View className="flex-row justify-between items-center pb-3 border-b border-border">
                  <Text className="text-muted text-sm">Nodes</Text>
                  <Text className="text-foreground font-mono text-sm">
                    {engineStatus.nodes}
                  </Text>
                </View>

                <View className="flex-row justify-between items-center pb-3 border-b border-border">
                  <Text className="text-muted text-sm">Devices</Text>
                  <Text className="text-foreground font-mono text-sm">
                    {engineStatus.devs}
                  </Text>
                </View>

                <View className="flex-row justify-between items-center">
                  <Text className="text-muted text-sm">Vectors</Text>
                  <Text className="text-foreground font-mono text-sm">
                    {engineStatus.vcount}
                  </Text>
                </View>
              </View>
            </View>

            {/* Vectors */}
            <View className="bg-surface border border-border rounded-lg p-4 mb-6">
              <Text className="text-foreground font-semibold mb-3">Vectors</Text>
              <View className="flex-row flex-wrap gap-2">
                {engineStatus.vecs.map((vec: string, idx: number) => (
                  <View
                    key={idx}
                    className="bg-background border border-border rounded px-3 py-1"
                  >
                    <Text className="text-muted text-xs">{vec}</Text>
                  </View>
                ))}
              </View>
            </View>

            {/* Statistics */}
            <View className="bg-surface border border-border rounded-lg p-4 mb-6">
              <Text className="text-foreground font-semibold mb-4">Statistics</Text>

              <View className="gap-3">
                <View className="flex-row justify-between items-center pb-3 border-b border-border">
                  <Text className="text-muted text-sm">Evolution History</Text>
                  <Text className="text-foreground font-mono text-sm">
                    {engineStatus.eh}
                  </Text>
                </View>

                <View className="flex-row justify-between items-center pb-3 border-b border-border">
                  <Text className="text-muted text-sm">Recognition Logs</Text>
                  <Text className="text-foreground font-mono text-sm">
                    {engineStatus.rl}
                  </Text>
                </View>

                <View className="flex-row justify-between items-center">
                  <Text className="text-muted text-sm">Replication Logs</Text>
                  <Text className="text-foreground font-mono text-sm">
                    {engineStatus.rpl}
                  </Text>
                </View>
              </View>
            </View>

            {/* Refresh Button */}
            <TouchableOpacity
              onPress={onRefresh}
              disabled={isRefreshing}
              className="bg-primary rounded-lg py-3 items-center mb-6"
            >
              <Text className="text-background font-semibold">
                {isRefreshing ? "Refreshing..." : "Refresh Status"}
              </Text>
            </TouchableOpacity>
          </>
        )}
      </ScrollView>
    </ScreenContainer>
  );
}
