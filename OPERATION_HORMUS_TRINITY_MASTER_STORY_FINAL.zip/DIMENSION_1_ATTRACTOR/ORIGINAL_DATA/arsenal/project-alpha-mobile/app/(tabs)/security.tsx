import {
  ScrollView,
  Text,
  View,
  TouchableOpacity,
  ActivityIndicator,
  RefreshControl,
} from "react-native";
import { useState, useEffect, useCallback } from "react";
import { ScreenContainer } from "@/components/screen-container";
import { useAuthContext } from "@/lib/auth-context";
import { useColors } from "@/hooks/use-colors";

interface SecurityCatalog {
  total: number;
  cats: string[];
  note: string[];
  stat: string;
  int: string;
}

export default function SecurityCatalogScreen() {
  const { apiClient } = useAuthContext();
  const colors = useColors();

  const [catalog, setCatalog] = useState<SecurityCatalog | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [expandedCategory, setExpandedCategory] = useState<string | null>(null);

  useEffect(() => {
    loadCatalog();
  }, []);

  const loadCatalog = useCallback(async () => {
    if (!apiClient) return;

    try {
      setIsLoading(true);
      const response = await apiClient.getSecurityCatalog();
      setCatalog(response);
    } catch (err) {
      console.error("Failed to load security catalog:", err);
    } finally {
      setIsLoading(false);
    }
  }, [apiClient]);

  const onRefresh = useCallback(async () => {
    setIsRefreshing(true);
    await loadCatalog();
    setIsRefreshing(false);
  }, [loadCatalog]);

  if (isLoading) {
    return (
      <ScreenContainer className="bg-background items-center justify-center">
        <ActivityIndicator color={colors.primary} size="large" />
      </ScreenContainer>
    );
  }

  return (
    <ScreenContainer className="bg-background p-4">
      <ScrollView
        contentContainerStyle={{ flexGrow: 1 }}
        showsVerticalScrollIndicator={false}
        refreshControl={
          <RefreshControl
            refreshing={isRefreshing}
            onRefresh={onRefresh}
            tintColor={colors.primary}
          />
        }
      >
        {/* Header */}
        <View className="mb-6">
          <Text className="text-2xl font-bold text-foreground mb-1">
            Security Catalog
          </Text>
          <Text className="text-sm text-muted">Arsenal & Tools</Text>
        </View>

        {catalog && (
          <>
            {/* Overview Cards */}
            <View className="gap-3 mb-6">
              <View className="bg-surface border border-border rounded-lg p-4">
                <Text className="text-muted text-sm mb-2">Total Tools</Text>
                <Text className="text-3xl font-bold text-foreground">
                  {catalog.total}
                </Text>
              </View>

              <View className="flex-row gap-3">
                <View className="flex-1 bg-surface border border-border rounded-lg p-4">
                  <Text className="text-muted text-xs mb-2">Status</Text>
                  <Text className="text-success font-semibold text-sm">
                    {catalog.stat}
                  </Text>
                </View>

                <View className="flex-1 bg-surface border border-border rounded-lg p-4">
                  <Text className="text-muted text-xs mb-2">Integration</Text>
                  <Text className="text-success font-semibold text-sm">
                    {catalog.int}
                  </Text>
                </View>
              </View>
            </View>

            {/* Categories */}
            <View className="mb-6">
              <Text className="text-foreground font-semibold mb-3">
                Categories ({catalog.cats.length})
              </Text>

              <View className="gap-2">
                {catalog.cats.map((category, idx) => (
                  <TouchableOpacity
                    key={idx}
                    onPress={() =>
                      setExpandedCategory(
                        expandedCategory === category ? null : category
                      )
                    }
                    className="bg-surface border border-border rounded-lg p-4"
                  >
                    <View className="flex-row justify-between items-center">
                      <Text className="text-foreground font-medium text-sm">
                        {category}
                      </Text>
                      <Text className="text-muted">
                        {expandedCategory === category ? "−" : "+"}
                      </Text>
                    </View>

                    {expandedCategory === category && (
                      <View className="mt-3 pt-3 border-t border-border">
                        <Text className="text-muted text-xs">
                          {category.toUpperCase()} tools are available in this
                          category
                        </Text>
                      </View>
                    )}
                  </TouchableOpacity>
                ))}
              </View>
            </View>

            {/* Notable Tools */}
            {catalog.note.length > 0 && (
              <View className="mb-6">
                <Text className="text-foreground font-semibold mb-3">
                  Notable Tools
                </Text>

                <View className="gap-2">
                  {catalog.note.map((tool, idx) => (
                    <View
                      key={idx}
                      className="bg-surface border border-warning rounded-lg p-3"
                    >
                      <Text className="text-warning font-mono text-xs">
                        {tool}
                      </Text>
                    </View>
                  ))}
                </View>
              </View>
            )}

            {/* Load Arsenal Button */}
            <TouchableOpacity
              onPress={async () => {
                try {
                  await apiClient?.loadSecurityArsenal();
                  alert("Security arsenal loaded successfully");
                } catch (err) {
                  alert("Failed to load arsenal");
                }
              }}
              className="bg-warning rounded-lg py-3 items-center mb-6"
            >
              <Text className="text-background font-semibold">
                Load Security Arsenal
              </Text>
            </TouchableOpacity>

            {/* Statistics */}
            <View className="bg-surface border border-border rounded-lg p-4">
              <Text className="text-foreground font-semibold mb-4">
                Information
              </Text>

              <View className="gap-3">
                <View className="pb-3 border-b border-border">
                  <Text className="text-muted text-xs mb-1">Catalog Status</Text>
                  <Text className="text-foreground text-sm">{catalog.stat}</Text>
                </View>

                <View className="pb-3 border-b border-border">
                  <Text className="text-muted text-xs mb-1">Integration Level</Text>
                  <Text className="text-foreground text-sm">{catalog.int}</Text>
                </View>

                <View>
                  <Text className="text-muted text-xs mb-1">Total Categories</Text>
                  <Text className="text-foreground text-sm">
                    {catalog.cats.length}
                  </Text>
                </View>
              </View>
            </View>
          </>
        )}
      </ScrollView>
    </ScreenContainer>
  );
}
