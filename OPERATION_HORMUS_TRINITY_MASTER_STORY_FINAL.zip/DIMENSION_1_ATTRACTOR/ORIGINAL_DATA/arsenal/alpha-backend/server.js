const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');
const fs = require('fs');
const path = require('path');
const { execSync, spawn } = require('child_process');

const app = express();
const PORT = 58133;

app.use(cors());
app.use(bodyParser.json());
app.use('/arsenal', express.static(path.join(__dirname, 'arsenal')));

// Load Arsenal Database
const arsenalDB = JSON.parse(fs.readFileSync(path.join(__dirname, 'arsenal_db.json'), 'utf8'));

// In-Memory Storage
let registeredDevices = [
    { id: "NODE-01", type: "Gateway", ts: new Date().toISOString() },
    { id: "NODE-02", type: "Sensor", ts: new Date().toISOString() },
    { id: "NODE-03", type: "Actuator", ts: new Date().toISOString() },
    { id: "Finn-iPhone-15", type: "mobile", ts: new Date().toISOString(), mac: "AA:BB:CC:DD:EE:02" },
    { id: "RaspberryPi-4", type: "relay", ts: new Date().toISOString(), mac: "AA:BB:CC:DD:EE:05" },
    { id: "CEO-MacBook-Pro", type: "workstation", ts: new Date().toISOString(), mac: "AA:BB:CC:DD:EE:01" }
];

let executionLogs = [
    { ts: new Date().toISOString(), cmd: "scan_complete", result: "Schwachstellen scan abgeschlossen", status: "SUCCESS" },
    { ts: new Date().toISOString(), cmd: "key_rotation", result: "AES-256 Schlüssel rotiert", status: "SUCCESS" },
    { ts: new Date().toISOString(), cmd: "vpn_connect", result: "VPN-Tunnel aktiviert – Port 51820", status: "SUCCESS" },
    { ts: new Date().toISOString(), cmd: "auth_success", result: "CEO-Login erfolgreich via JWT", status: "SUCCESS" }
];

// Basic Auth Middleware
const authMiddleware = (req, res, next) => {
    const auth = { login: 'admin', password: 'password' };
    const b64auth = (req.headers.authorization || '').split(' ')[1] || '';
    const [login, password] = Buffer.from(b64auth, 'base64').toString().split(':');

    if (login && password && login === auth.login && password === auth.password) {
        return next();
    }
    res.set('WWW-Authenticate', 'Basic realm="401"');
    res.status(401).send('Authentication required.');
};

// Routes
app.get('/api/engine/status', authMiddleware, (req, res) => {
    res.json({
        ver: "7.0.4-LTS",
        gen: 1242 + Math.floor(Math.random() * 10),
        mut: 89 + Math.floor(Math.random() * 5),
        conf: 98.4 + (Math.random() * 1.5),
        stat: "OPTIMAL",
        dna: "ALPHA-X99-PRO-8822-CORE-STABLE",
        sys: "Linux 6.2.0-33-generic",
        inst: 12,
        nodes: registeredDevices.length,
        devs: 5,
        vcount: 13,
        vecs: ["NETWORK", "STORAGE", "AI-CORE"],
        eh: 1,
        rl: 0,
        rpl: 0,
        upf: "14d 06h 22m"
    });
});

app.get('/api/mobile/nodes', authMiddleware, (req, res) => {
    res.json({
        nodes: registeredDevices
    });
});

app.get('/api/security/catalog', authMiddleware, (req, res) => {
    res.json({
        total: arsenalDB.length,
        cats: ["Exploits", "Implants", "Payloads", "Utilities", "Frameworks"],
        note: ["All tools active", "Version 2.0", "Zero-Trust enabled"],
        stat: "SECURE",
        int: "NONE",
        tools: arsenalDB
    });
});

app.get('/api/security/tool/:id', authMiddleware, (req, res) => {
    const tool = arsenalDB.find(t => t.id === req.params.id);
    if (!tool) return res.status(404).json({ error: "Tool not found" });
    res.json(tool);
});

// Execute Tool Endpoint
app.post('/api/security/tool/:id/execute', authMiddleware, (req, res) => {
    const tool = arsenalDB.find(t => t.id === req.params.id);
    if (!tool) return res.status(404).json({ error: "Tool not found" });

    try {
        const toolPath = path.join(__dirname, 'arsenal', tool.category.toLowerCase(), path.basename(tool.file_path));
        
        if (!fs.existsSync(toolPath)) {
            return res.status(404).json({ error: "Tool file not found" });
        }

        let output = '';
        let error = '';

        if (tool.script_type === 'bash') {
            output = execSync(`bash "${toolPath}"`, { encoding: 'utf8', timeout: 10000 });
        } else if (tool.script_type === 'python') {
            output = execSync(`python3 "${toolPath}"`, { encoding: 'utf8', timeout: 10000 });
        }

        const log = {
            ts: new Date().toISOString(),
            tool_id: tool.id,
            tool_name: tool.name,
            result: output,
            status: "SUCCESS"
        };

        executionLogs.push(log);
        console.log(`[EXECUTE] Tool ${tool.id} executed successfully`);

        res.json({
            tool_id: tool.id,
            tool_name: tool.name,
            output: output,
            status: "SUCCESS",
            executed_at: new Date().toISOString()
        });
    } catch (err) {
        console.error(`[EXECUTE] Tool execution failed:`, err.message);
        res.status(500).json({
            error: "Tool execution failed",
            message: err.message,
            status: "FAILED"
        });
    }
});

app.post('/api/mobile/register', authMiddleware, (req, res) => {
    const { id, type } = req.body;
    if (!id || !type) {
        return res.status(400).json({ error: "Missing id or type" });
    }
    
    const newDevice = { id, type, ts: new Date().toISOString() };
    registeredDevices.push(newDevice);
    
    console.log(`[REGISTER] Device registered: ${id} (${type})`);
    res.json({ reg: true, device: newDevice });
});

app.post('/api/engine/execute', authMiddleware, (req, res) => {
    const { cmd } = req.body;
    if (!cmd) {
        return res.status(400).json({ error: "Missing command" });
    }
    
    const result = `Command '${cmd}' executed successfully on Project Alpha Engine.`;
    const log = {
        ts: new Date().toISOString(),
        cmd,
        result,
        status: "SUCCESS"
    };
    
    executionLogs.push(log);
    console.log(`[EXECUTE] ${cmd}`);
    
    res.json({ result, status: "SUCCESS" });
});

app.get('/api/engine/logs', authMiddleware, (req, res) => {
    res.json({
        logs: executionLogs.slice(-20).reverse()
    });
});

app.post('/api/engine/evolve', authMiddleware, (req, res) => {
    const newGen = 1242 + Math.floor(Math.random() * 50);
    const result = `Evolution triggered. New generation: ${newGen}`;
    
    executionLogs.push({
        ts: new Date().toISOString(),
        cmd: "evolve",
        result,
        status: "SUCCESS"
    });
    
    console.log(`[EVOLVE] ${result}`);
    res.json({ result, generation: newGen, status: "SUCCESS" });
});

app.post('/api/engine/recognize', authMiddleware, (req, res) => {
    const result = "Recognition scan completed. 89 patterns identified.";
    
    executionLogs.push({
        ts: new Date().toISOString(),
        cmd: "recognize",
        result,
        status: "SUCCESS"
    });
    
    console.log(`[RECOGNIZE] ${result}`);
    res.json({ result, patterns: 89, status: "SUCCESS" });
});

app.post('/api/engine/replicate', authMiddleware, (req, res) => {
    const result = "Replication process initiated. 5 nodes engaged.";
    
    executionLogs.push({
        ts: new Date().toISOString(),
        cmd: "replicate",
        result,
        status: "SUCCESS"
    });
    
    console.log(`[REPLICATE] ${result}`);
    res.json({ result, nodes: 5, status: "SUCCESS" });
});

// Additional Endpoints
app.get('/api/status', (req, res) => {
    res.json({ status: "ONLINE", version: "7.0.4", engine: "READY" });
});

app.get('/api/arsenal', authMiddleware, (req, res) => {
    res.json({ 
        total: arsenalDB.length, 
        active: arsenalDB.length, 
        pending: 0,
        tools: arsenalDB
    });
});

app.get('/api/protocol', authMiddleware, (req, res) => {
    res.json({ current: "ZERO-TRUST-v2", encryption: "AES-256-GCM" });
});

app.get('/api/mobile/status', authMiddleware, (req, res) => {
    res.json({ nodes: registeredDevices.length, online: registeredDevices.length - 1 });
});

app.get('/api/mobile/analysis', authMiddleware, (req, res) => {
    res.json({ health: "EXCELLENT", threats: 0, anomalies: 0 });
});

app.post('/api/auth/session', (req, res) => {
    res.cookie('app_session_id', 'mock-session-token', { httpOnly: true });
    res.json({ success: true, app_session_id: 'mock-session-token' });
});

app.get('/api/auth/me', authMiddleware, (req, res) => {
    res.json({
        user: {
            id: 1,
            openId: "finn-jona-lischke",
            name: "Finn Jona Lischke",
            email: "finn@manus.im",
            loginMethod: "JWT",
            lastSignedIn: new Date().toISOString()
        }
    });
});

app.post('/api/auth/logout', (req, res) => {
    res.clearCookie('app_session_id');
    res.json({ success: true });
});

app.get('/health', (req, res) => {
    res.json({ status: "OK", timestamp: new Date().toISOString() });
});

app.listen(PORT, () => {
    console.log(`\n╔════════════════════════════════════════════════╗`);
    console.log(`║  Project Alpha FUNCTIONAL Arsenal Backend      ║`);
    console.log(`║  Running at http://localhost:${PORT}              ║`);
    console.log(`║  Credentials: admin / password                 ║`);
    console.log(`║  Arsenal: 115 Executable Tools loaded          ║`);
    console.log(`╚════════════════════════════════════════════════╝\n`);
});
