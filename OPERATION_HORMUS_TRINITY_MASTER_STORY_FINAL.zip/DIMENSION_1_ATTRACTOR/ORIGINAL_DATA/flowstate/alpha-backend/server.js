const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');

const app = express();
const PORT = 58133;

app.use(cors());
app.use(bodyParser.json());

// In-Memory Storage
let registeredDevices = [
    { id: "NODE-01", type: "Gateway", ts: new Date().toISOString() },
    { id: "NODE-02", type: "Sensor", ts: new Date().toISOString() },
    { id: "NODE-03", type: "Actuator", ts: new Date().toISOString() }
];

let executionLogs = [];

// Basic Auth Middleware
const authMiddleware = (req, res, next) => {
    const auth = { login: 'admin', password: 'password' };
    const b64auth = (req.headers.authorization || '').split(' ')[1] || '';
    const [login, password] = Buffer.from(b64auth, 'base64').toString().split(':');

    if (login && password && login === auth.login && password === auth.password) {
        return next();
    }
    res.set('WWW-Authenticate', 'Basic realm="401"');
    res.status(401).send('Authentication required.');
};

// Routes
app.get('/api/engine/status', authMiddleware, (req, res) => {
    res.json({
        ver: "7.0.4-LTS",
        gen: 1242 + Math.floor(Math.random() * 10),
        mut: 89 + Math.floor(Math.random() * 5),
        conf: 98.4 + (Math.random() * 1.5),
        stat: "OPTIMAL",
        dna: "ALPHA-X99-PRO-8822-CORE-STABLE",
        sys: "Linux 6.2.0-33-generic",
        inst: 12,
        nodes: registeredDevices.length,
        devs: 5,
        vcount: 13,
        vecs: ["NETWORK", "STORAGE", "AI-CORE"],
        eh: 1,
        rl: 0,
        rpl: 0,
        upf: "14d 06h 22m"
    });
});

app.get('/api/mobile/nodes', authMiddleware, (req, res) => {
    res.json({
        nodes: registeredDevices
    });
});

app.get('/api/security/catalog', authMiddleware, (req, res) => {
    res.json({
        total: 115,
        cats: ["Exploits", "Implants", "Payloads", "Utilities", "Frameworks"],
        note: ["All tools active", "Version 2.0", "Zero-Trust enabled"],
        stat: "SECURE",
        int: "NONE"
    });
});

app.post('/api/mobile/register', authMiddleware, (req, res) => {
    const { id, type } = req.body;
    if (!id || !type) {
        return res.status(400).json({ error: "Missing id or type" });
    }
    
    const newDevice = { id, type, ts: new Date().toISOString() };
    registeredDevices.push(newDevice);
    
    console.log(`[REGISTER] Device registered: ${id} (${type})`);
    res.json({ reg: true, device: newDevice });
});

app.post('/api/engine/execute', authMiddleware, (req, res) => {
    const { cmd } = req.body;
    if (!cmd) {
        return res.status(400).json({ error: "Missing command" });
    }
    
    const result = `Command '${cmd}' executed successfully on Project Alpha Engine.`;
    const log = {
        ts: new Date().toISOString(),
        cmd,
        result,
        status: "SUCCESS"
    };
    
    executionLogs.push(log);
    console.log(`[EXECUTE] ${cmd}`);
    
    res.json({ result, status: "SUCCESS" });
});

app.get('/api/engine/logs', authMiddleware, (req, res) => {
    res.json({
        logs: executionLogs.slice(-20).reverse()
    });
});

app.post('/api/engine/evolve', authMiddleware, (req, res) => {
    const newGen = 1242 + Math.floor(Math.random() * 50);
    const result = `Evolution triggered. New generation: ${newGen}`;
    
    executionLogs.push({
        ts: new Date().toISOString(),
        cmd: "evolve",
        result,
        status: "SUCCESS"
    });
    
    console.log(`[EVOLVE] ${result}`);
    res.json({ result, generation: newGen, status: "SUCCESS" });
});

app.post('/api/engine/recognize', authMiddleware, (req, res) => {
    const result = "Recognition scan completed. 89 patterns identified.";
    
    executionLogs.push({
        ts: new Date().toISOString(),
        cmd: "recognize",
        result,
        status: "SUCCESS"
    });
    
    console.log(`[RECOGNIZE] ${result}`);
    res.json({ result, patterns: 89, status: "SUCCESS" });
});

app.post('/api/engine/replicate', authMiddleware, (req, res) => {
    const result = "Replication process initiated. 5 nodes engaged.";
    
    executionLogs.push({
        ts: new Date().toISOString(),
        cmd: "replicate",
        result,
        status: "SUCCESS"
    });
    
    console.log(`[REPLICATE] ${result}`);
    res.json({ result, nodes: 5, status: "SUCCESS" });
});

app.get('/health', (req, res) => {
    res.json({ status: "OK", timestamp: new Date().toISOString() });
});

app.listen(PORT, () => {
    console.log(`\n╔════════════════════════════════════════════════╗`);
    console.log(`║  Project Alpha Mock Backend                    ║`);
    console.log(`║  Running at http://localhost:${PORT}              ║`);
    console.log(`║  Credentials: admin / password                 ║`);
    console.log(`╚════════════════════════════════════════════════╝\n`);
});
