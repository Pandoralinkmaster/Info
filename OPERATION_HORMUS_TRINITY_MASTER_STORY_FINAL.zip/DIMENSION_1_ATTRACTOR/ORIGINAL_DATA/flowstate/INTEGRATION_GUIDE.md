# FlowState Next & Project Alpha Integration Guide

## Überblick

Dieses Paket bietet eine vollständige Integration zwischen **FlowState Next** (Web-Dashboard) und **Project Alpha Mobile** (Mobile-App), mit einem Mock-Backend für lokale Entwicklung und Tests.

---

## Architektur

```
┌─────────────────────────────────────────────────────────┐
│                   FlowState Next (Web)                  │
│  - React + Vite + TypeScript                            │
│  - Dashboard mit Mesh-Netzwerk, Wallet, Security        │
│  - Project Alpha Integration                            │
└─────────────────┬───────────────────────────────────────┘
                  │
                  │ HTTP/REST
                  │
┌─────────────────▼───────────────────────────────────────┐
│          Project Alpha Mock Backend                      │
│  - Node.js + Express                                    │
│  - API Endpoints für Engine, Nodes, Security            │
│  - Basic Auth (admin/password)                          │
└─────────────────┬───────────────────────────────────────┘
                  │
                  │ HTTP/REST
                  │
┌─────────────────▼───────────────────────────────────────┐
│            Project Alpha Mobile (React Native)           │
│  - Expo + React Native + TypeScript                     │
│  - iOS/Android Support                                  │
│  - Same API Integration                                 │
└─────────────────────────────────────────────────────────┘
```

---

## Setup & Installation

### 1. Backend starten

```bash
cd alpha-backend
npm install
npm start
```

Das Backend läuft auf `http://localhost:58133`.

**Credentials:**
- Username: `admin`
- Password: `password`

### 2. FlowState Next starten

```bash
cd flowstate-next
npm install
npm run dev
```

Öffne `http://localhost:5173` im Browser.

### 3. Project Alpha Mobile starten

```bash
cd project-alpha-mobile
npm install
npx expo start
```

Scannen Sie den QR-Code mit Expo Go oder starten Sie in einem Emulator.

---

## API Endpoints

### Engine Status
```http
GET /api/engine/status
Authorization: Basic admin:password

Response:
{
  "ver": "7.0.4-LTS",
  "gen": 1242,
  "mut": 89,
  "conf": 98.4,
  "stat": "OPTIMAL",
  "dna": "ALPHA-X99-PRO-8822-CORE-STABLE",
  "nodes": 3,
  "upf": "14d 06h 22m"
}
```

### Mobile Nodes
```http
GET /api/mobile/nodes
Authorization: Basic admin:password

Response:
{
  "nodes": [
    { "id": "NODE-01", "type": "Gateway", "ts": "2026-07-03T20:30:00Z" },
    { "id": "NODE-02", "type": "Sensor", "ts": "2026-07-03T20:30:00Z" }
  ]
}
```

### Security Catalog
```http
GET /api/security/catalog
Authorization: Basic admin:password

Response:
{
  "total": 115,
  "cats": ["Exploits", "Implants", "Payloads", "Utilities", "Frameworks"],
  "stat": "SECURE"
}
```

### Register Device
```http
POST /api/mobile/register
Authorization: Basic admin:password
Content-Type: application/json

{
  "id": "NODE-04",
  "type": "Relay"
}

Response:
{
  "reg": true,
  "device": { "id": "NODE-04", "type": "Relay", "ts": "..." }
}
```

### Execute Command
```http
POST /api/engine/execute
Authorization: Basic admin:password
Content-Type: application/json

{
  "cmd": "evolve"
}

Response:
{
  "result": "Command executed successfully",
  "status": "SUCCESS"
}
```

### Engine Commands
- **evolve**: Startet Evolution-Prozess
- **recognize**: Führt Pattern-Recognition durch
- **replicate**: Startet Replikation auf Nodes

---

## Frontend Integration

### FlowState Next

Die Web-App integriert sich über `src/lib/apiIntegration.ts`:

```typescript
import { alphaAPI } from './lib/apiIntegration';

// Konfigurieren
alphaAPI.setConfig({
  baseURL: 'http://localhost:58133',
  username: 'admin',
  password: 'password'
});

// Daten abrufen
const engineStatus = await alphaAPI.getEngineStatus();
const nodes = await alphaAPI.getMobileNodes();
const catalog = await alphaAPI.getSecurityCatalog();
```

### Project Alpha Mobile

Die Mobile-App nutzt die gleiche API-Integration über `lib/api-client.ts`.

---

## Features

### FlowState Next
- ✅ Dashboard mit Live-Statistiken
- ✅ Mesh-Netzwerk-Verwaltung
- ✅ JayJay KI (Sprachassistent-Mockup)
- ✅ Bitcoin Wallet Simulation
- ✅ Security Log & Monitoring
- ✅ Storage Management
- ✅ Project Alpha Engine Integration
- ✅ Dark Mode / Matrix Theme
- ✅ Export/Import State

### Project Alpha Mobile
- ✅ Login/Authentication
- ✅ Dashboard mit Engine-Status
- ✅ Mobile Nodes Verwaltung
- ✅ Security Catalog
- ✅ Live Logs
- ✅ Settings & Configuration
- ✅ Offline-Modus (lokales Caching)

---

## Konfiguration

### Backend-Konfiguration

Bearbeiten Sie `alpha-backend/server.js`:

```javascript
const PORT = 58133; // Port ändern
const auth = { login: 'admin', password: 'password' }; // Credentials ändern
```

### Frontend-Konfiguration

**FlowState Next** (`src/settings`):
- API Base URL
- Theme (Dark/Matrix)
- Wake-Word für KI

**Project Alpha Mobile** (`lib/api-client.ts`):
- Server URL
- Authentifizierung
- Timeout-Einstellungen

---

## Entwicklung & Erweiterung

### Neuen Endpoint hinzufügen

1. **Backend** (`alpha-backend/server.js`):
```javascript
app.get('/api/custom/endpoint', authMiddleware, (req, res) => {
    res.json({ data: 'your data' });
});
```

2. **Frontend** (`flowstate-next/src/lib/apiIntegration.ts`):
```typescript
async getCustomData(): Promise<CustomType> {
    const response = await fetch(`${this.config.baseURL}/api/custom/endpoint`, {
        headers: { Authorization: this.getAuthHeader() }
    });
    return response.json();
}
```

### Neue Mobile-Komponente

1. Erstelle Komponente in `project-alpha-mobile/app/screens/`
2. Nutze `useAuth()` für Authentication
3. Verwende `api-client.ts` für API-Calls

---

## Troubleshooting

### Backend antwortet nicht
```bash
# Prüfe ob Port 58133 frei ist
lsof -i :58133

# Starte Backend neu
cd alpha-backend
npm start
```

### CORS-Fehler
Backend hat CORS aktiviert. Falls Fehler auftritt:
- Prüfe `cors()` Middleware in `server.js`
- Stelle sicher, dass Frontend-URL erlaubt ist

### Authentifizierung fehlgeschlagen
- Credentials: `admin` / `password`
- Prüfe Base64-Encoding in `apiIntegration.ts`

---

## Production Deployment

### Backend
```bash
# Mit PM2
npm install -g pm2
pm2 start alpha-backend/server.js --name "alpha-backend"

# Mit Docker
docker build -t alpha-backend .
docker run -p 58133:58133 alpha-backend
```

### Frontend
```bash
# Build
npm run build

# Deploy zu Vercel/Netlify
vercel deploy
```

---

## Lizenz & Credits

Erstellt mit Manus AI. Alle Komponenten sind lokal ausführbar und vollständig dokumentiert.
