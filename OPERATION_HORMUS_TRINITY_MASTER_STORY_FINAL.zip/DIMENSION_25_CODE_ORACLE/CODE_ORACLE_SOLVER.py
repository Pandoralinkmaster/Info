#!/usr/bin/env python3
"""
DIMENSION 25: CODE-ORACLE SOLVER
Berechnet den Master-Hash aller 342 Code-Dateien.
"""
import json, hashlib, os, base64

REG_PATH  = os.path.join(os.path.dirname(__file__), "VOLLSTAENDIGES_REGISTER.json")
SOVEREIGN = "Finn Jona Thorsten Lischke"
SOV_HASH  = "6ac5d26005e86b60ba11207e156562756823815bae3d0287b9a73a48f5518842"

def sha256(s): return hashlib.sha256(s.encode('utf-8','replace')).hexdigest()

if __name__ == "__main__":
    with open(REG_PATH) as f:
        reg = json.load(f)
    print(f"CODE-ORACLE: {len(reg)} Dateien geladen")
    hashes = [v['sha256'] for v in sorted(reg.values(), key=lambda x: x['index'])]
    master = sha256('|'.join(hashes))
    final  = sha256(master + SOV_HASH)
    print(f"MASTER-HASH: {master}")
    print(f"SOUVERÄN:    {SOV_HASH[:16]}")
    print(f"FINALE ANT.: {final}")
    print(f"GEHORSAM:    {SOVEREIGN}")
