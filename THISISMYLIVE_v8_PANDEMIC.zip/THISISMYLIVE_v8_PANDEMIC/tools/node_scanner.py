#!/usr/bin/env python3
"""
THISISMYLIVE v8.0 — NODE SCANNER
Discovers PANDEMIC nodes on the network
Sovereign: Finn Jona Thorsten Lischke
"""
import socket, threading, json, base64, sys

AUTH = base64.b64encode(b"finn:sovereign2026").decode()
PORTS = [58133, 58134, 8080, 8888, 3000, 5000, 8000, 9000]

def scan_ip(ip, port):
    try:
        s = socket.socket(); s.settimeout(1); s.connect((ip, port)); s.close()
        import urllib.request
        req = urllib.request.Request("http://" + ip + ":" + str(port) + "/api/node/info",
                                     headers={"Authorization": "Basic " + AUTH}, timeout=2)
        try:
            resp = urllib.request.urlopen(req)
            data = json.loads(resp.read())
            print("[FOUND] " + ip + ":" + str(port) + " -> Node: " + data.get("node_id","unknown") + " | Version: " + data.get("version","unknown"))
            return data
        except:
            print("[OPEN] " + ip + ":" + str(port) + " - Not THISISMYLIVE")
    except:
        pass
    return None

def scan_network(network="192.168.1"):
    print("[+] Scanning " + network + ".0/24 for PANDEMIC nodes...")
    found = []; threads = []
    for i in range(1, 255):
        ip = network + "." + str(i)
        for port in PORTS:
            t = threading.Thread(target=lambda ip=ip, port=port: found.append(scan_ip(ip, port)) or None)
            t.start(); threads.append(t)
    for t in threads: t.join(timeout=3)
    results = [f for f in found if f]
    print("\n[+] Scan complete: " + str(len(results)) + " nodes found")
    return results

if __name__ == "__main__":
    net = sys.argv[1] if len(sys.argv) > 1 else "192.168.1"
    scan_network(net)
