#!/bin/bash
# THISISMYLIVE v8.0 — TUNNEL SCRIPT
# Creates public tunnels via localtunnel, ngrok, or pinggy

PORT="${1:-58133}"

echo "[+] THISISMYLIVE v8.0 PANDEMIC Tunnel"
echo "    Port: $PORT"
echo ""

# Try localtunnel
if command -v npx &> /dev/null; then
    echo "[+] Starting localtunnel..."
    npx localtunnel --port $PORT &
    LT_PID=$!
    sleep 5
    if kill -0 $LT_PID 2>/dev/null; then
        echo "    ✓ Localtunnel running (PID: $LT_PID)"
    fi
fi

# Try ngrok
if command -v ngrok &> /dev/null; then
    echo "[+] Starting ngrok..."
    ngrok http $PORT &
    NG_PID=$!
    sleep 5
    if kill -0 $NG_PID 2>/dev/null; then
        echo "    ✓ Ngrok running (PID: $NG_PID)"
    fi
fi

# Try pinggy (SSH-based)
if command -v ssh &> /dev/null; then
    echo "[+] Starting Pinggy..."
    ssh -p 443 -R0:localhost:$PORT a.pinggy.io &
    PG_PID=$!
    sleep 5
    if kill -0 $PG_PID 2>/dev/null; then
        echo "    ✓ Pinggy running (PID: $PG_PID)"
    fi
fi

echo ""
echo "[+] Tunnels active. Check URLs above."
echo "    Press Ctrl+C to stop all tunnels."
wait
