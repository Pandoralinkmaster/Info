#!/bin/bash
# THISISMYLIVE v8.0 — WATCHDOG
# Checks server health every 60 seconds and restarts if down

SCRIPT_DIR="$(dirname "$(readlink -f "$0")")/.."
SERVER_DIR="$SCRIPT_DIR/server"
LOG="$SCRIPT_DIR/logs/watchdog.log"
PORT="${THISISMYLIVE_PORT:-58133}"

mkdir -p "$SCRIPT_DIR/logs"

if ! python3 -c "import socket; s=socket.socket(); s.settimeout(2); r=s.connect_ex(('127.0.0.1',$PORT)); s.close(); exit(r)" 2>/dev/null; then
    echo "[$(date)] Server down on port $PORT — restarting..." >> "$LOG"
    pkill -9 -f "THISISMYLIVE.*server.py" 2>/dev/null
    sleep 2
    cd "$SERVER_DIR" && nohup python3 server.py > "$SCRIPT_DIR/logs/server.log" 2>&1 &
    echo "[$(date)] Server restarted (PID: $!)" >> "$LOG"
else
    echo "[$(date)] Server healthy on port $PORT" >> "$LOG"
fi
