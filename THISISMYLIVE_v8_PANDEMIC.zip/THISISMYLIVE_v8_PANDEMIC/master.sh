#!/bin/bash
# THISISMYLIVE v8.0 — PANDEMIC MASTER CONTROL
# Modular Multi-Node — Every Device Is Server+Host+Vector
# Sovereign: Finn Jona Thorsten Lischke

SCRIPT_DIR="$(dirname "$(readlink -f "$0")")"
SERVER_DIR="$SCRIPT_DIR/server"
LOGS_DIR="$SCRIPT_DIR/logs"
PID_FILE="$SERVER_DIR/server.pid"

export THISISMYLIVE_PASS="${THISISMYLIVE_PASS:-sovereign2026}"
export THISISMYLIVE_NODE="${THISISMYLIVE_NODE:-$(cat /proc/sys/kernel/random/uuid 2>/dev/null | cut -d'-' -f1 || echo $(date +%s | sha256sum | head -c 8))}"

mkdir -p "$LOGS_DIR"

color() { echo -e "\033[${1}m${2}\033[0m"; }

case "$1" in
    start)
        color "36" "[+] Starting THISISMYLIVE v8.0 PANDEMIC..."
        if [ -f "$PID_FILE" ]; then
            old_pid=$(cat "$PID_FILE" 2>/dev/null)
            if [ -n "$old_pid" ] && kill -0 "$old_pid" 2>/dev/null; then
                color "33" "[!] Server already running (PID: $old_pid)"
                exit 0
            fi
            rm -f "$PID_FILE"
        fi
        pkill -9 -f "THISISMYLIVE.*server.py" 2>/dev/null
        sleep 2
        cd "$SERVER_DIR" && nohup python3 server.py > "$LOGS_DIR/server.log" 2>&1 &
        SERVER_PID=$!
        echo $SERVER_PID > "$PID_FILE"
        sleep 3
        if python3 -c "import socket; s=socket.socket(); s.settimeout(2); s.connect(('127.0.0.1',$(python3 -c \"import socket; s=socket.socket(); s.bind(('',0)); r=s.getsockname()[1]; s.close(); exit(r)\" 2>/dev/null || echo 58133))); s.close()" 2>/dev/null; then
            echo ""
            color "32" "✅ SERVER RUNNING"
            color "32" "   Node ID: $THISISMYLIVE_NODE"
            color "32" "   Port: $(python3 -c 'import re; f=open("'$LOGS_DIR/server.log'").read(); m=re.search(r"Port: (\d+)",f); print(m.group(1) if m else "58133")' 2>/dev/null || echo 58133)"
            color "32" "   PID: $SERVER_PID"
            color "32" "   Log: $LOGS_DIR/server.log"
            echo ""
            color "33" "   Dashboard: http://localhost:$(python3 -c 'import re; f=open("'$LOGS_DIR/server.log'").read(); m=re.search(r"Port: (\d+)",f); print(m.group(1) if m else "58133")' 2>/dev/null || echo 58133)"
            color "33" "   Status: http://localhost:$(python3 -c 'import re; f=open("'$LOGS_DIR/server.log'").read(); m=re.search(r"Port: (\d+)",f); print(m.group(1) if m else "58133")' 2>/dev/null || echo 58133)/api/status"
            color "33" "   Health: http://localhost:$(python3 -c 'import re; f=open("'$LOGS_DIR/server.log'").read(); m=re.search(r"Port: (\d+)",f); print(m.group(1) if m else "58133")' 2>/dev/null || echo 58133)/api/health"
            echo ""
            color "31" "   Auth: finn / [PROTECTED]"
            color "31" "   Sovereign: Finn Jona Thorsten Lischke"
            color "31" "   Version: 8.0.PANDEMIC"
            echo ""
        else
            color "31" "❌ Server failed to start. Check $LOGS_DIR/server.log"
            exit 1
        fi
        ;;
    stop)
        color "31" "[+] Stopping THISISMYLIVE v8.0..."
        [ -f "$PID_FILE" ] && kill -9 $(cat "$PID_FILE" 2>/dev/null) 2>/dev/null
        pkill -9 -f "THISISMYLIVE.*server.py" 2>/dev/null
        rm -f "$PID_FILE"
        color "32" "✅ Server stopped"
        ;;
    status)
        if [ -f "$PID_FILE" ] && kill -0 $(cat "$PID_FILE" 2>/dev/null) 2>/dev/null; then
            color "32" "✅ Server RUNNING"
            color "32" "   PID: $(cat $PID_FILE)"
            color "32" "   Node: $THISISMYLIVE_NODE"
            color "32" "   Log: $LOGS_DIR/server.log"
        else
            color "31" "❌ Server NOT RUNNING"
        fi
        ;;
    restart)
        $0 stop
        sleep 2
        $0 start
        ;;
    logs)
        [ -f "$LOGS_DIR/server.log" ] && tail -f "$LOGS_DIR/server.log" || echo "No log file"
        ;;
    install)
        color "36" "[+] Installing persistence..."
        # Cron
        (crontab -l 2>/dev/null | grep -v "THISISMYLIVE"; echo "@reboot export THISISMYLIVE_PASS='$THISISMYLIVE_PASS' && cd $SCRIPT_DIR/server && nohup python3 server.py > $LOGS_DIR/server.log 2>&1 &") | crontab -
        color "32" "   ✓ Cron installed"
        # Shell profiles
        for rc in ~/.bashrc ~/.zshrc ~/.profile; do
            [ -f "$rc" ] && { grep -q "THISISMYLIVE" "$rc" || echo "export THISISMYLIVE_PASS='$THISISMYLIVE_PASS' && cd $SCRIPT_DIR/server && nohup python3 server.py > $LOGS_DIR/server.log 2>&1 & # THISISMYLIVE" >> "$rc"; }
        done
        color "32" "   ✓ Shell profiles updated"
        # Systemd user service
        mkdir -p ~/.config/systemd/user
        cat > ~/.config/systemd/user/thisismylive.service << EOF
[Unit]
Description=THISISMYLIVE v8.0 PANDEMIC
After=network.target

[Service]
Type=simple
User=%I
WorkingDirectory=$SERVER_DIR
ExecStart=/usr/bin/python3 $SERVER_DIR/server.py
Restart=always
RestartSec=10
Environment=THISISMYLIVE_PORT=58133
Environment=THISISMYLIVE_PASS=$THISISMYLIVE_PASS
Environment=THISISMYLIVE_NODE=$THISISMYLIVE_NODE

[Install]
WantedBy=default.target
EOF
        systemctl --user daemon-reload 2>/dev/null
        systemctl --user enable thisismylive 2>/dev/null
        color "32" "   ✓ Systemd service installed"
        # Desktop autostart
        mkdir -p ~/.config/autostart
        cat > ~/.config/autostart/thisismylive.desktop << EOF
[Desktop Entry]
Type=Application
Name=System Update Service
Exec=python3 $SERVER_DIR/server.py
Hidden=false
NoDisplay=false
X-GNOME-Autostart-enabled=true
EOF
        color "32" "   ✓ Desktop autostart installed"
        color "32" "✅ ALL PERSISTENCE INSTALLED"
        ;;
    uninstall)
        color "31" "[+] Removing persistence..."
        crontab -l 2>/dev/null | grep -v "THISISMYLIVE" | crontab - 2>/dev/null
        for rc in ~/.bashrc ~/.zshrc ~/.profile; do
            [ -f "$rc" ] && sed -i '/THISISMYLIVE/d' "$rc" 2>/dev/null
        done
        systemctl --user disable thisismylive 2>/dev/null
        systemctl --user stop thisismylive 2>/dev/null
        rm -f ~/.config/systemd/user/thisismylive.service
        rm -f ~/.config/autostart/thisismylive.desktop
        color "32" "✅ ALL PERSISTENCE REMOVED"
        ;;
    test)
        color "36" "[+] Testing API endpoints..."
        PORT=$(python3 -c 'import re; f=open("'$LOGS_DIR/server.log'").read(); m=re.search(r"Port: (\d+)",f); print(m.group(1) if m else "58133")' 2>/dev/null || echo 58133)
        AUTH=$(echo -n "finn:$THISISMYLIVE_PASS" | base64)
        for ep in status health node/info worm/status blockchain arsenal orpp; do
            RESP=$(curl -s -o /dev/null -w "%{http_code}" -H "Authorization: Basic $AUTH" "http://localhost:$PORT/api/$ep" 2>/dev/null)
            if [ "$RESP" = "200" ]; then
                color "32" "   ✓ /api/$ep → 200"
            else
                color "31" "   ✗ /api/$ep → $RESP"
            fi
        done
        ;;
    *)
        echo "Usage: $0 {start|stop|restart|status|logs|install|uninstall|test}"
        echo ""
        echo "Commands:"
        echo "  start      — Start the v8.0 PANDEMIC server"
        echo "  stop       — Stop the server"
        echo "  restart    — Restart the server"
        echo "  status     — Check server status"
        echo "  logs       — View live logs"
        echo "  install    — Install all persistence mechanisms"
        echo "  uninstall  — Remove all persistence"
        echo "  test       — Test API endpoints"
        echo ""
        echo "Environment:"
        echo "  THISISMYLIVE_PASS    — Auth password (default: sovereign2026)"
        echo "  THISISMYLIVE_NODE    — Node ID (auto-generated)"
        ;;
esac
