/**
 * API Integration für Flowstate Next
 * Verbindet Flowstate mit Project Alpha Backend
 */

export interface ProjectAlphaConfig {
  baseURL: string;
  username: string;
  password: string;
}

export interface AlphaEngineStatus {
  ver: string;
  gen: number;
  mut: number;
  conf: number;
  stat: string;
  dna: string;
  sys: string;
  inst: number;
  nodes: number;
  devs: number;
  vcount: number;
  vecs: string[];
  eh: number;
  rl: number;
  rpl: number;
  upf: string;
}

export interface AlphaMobileNode {
  id: string;
  type: string;
  ts: string;
}

export interface AlphaSecurityCatalog {
  total: number;
  cats: string[];
  note: string[];
  stat: string;
  int: string;
}

class ProjectAlphaAPI {
  private config: ProjectAlphaConfig | null = null;

  setConfig(config: ProjectAlphaConfig) {
    this.config = config;
  }

  private getAuthHeader(): string {
    if (!this.config) throw new Error("API not configured");
    const credentials = `${this.config.username}:${this.config.password}`;
    return `Basic ${Buffer.from(credentials).toString("base64")}`;
  }

  async getEngineStatus(): Promise<AlphaEngineStatus> {
    if (!this.config) throw new Error("API not configured");

    const response = await fetch(`${this.config.baseURL}/api/engine/status`, {
      headers: { Authorization: this.getAuthHeader() },
    });

    if (!response.ok) throw new Error(`API error: ${response.status}`);
    return response.json();
  }

  async getMobileNodes(): Promise<{ nodes: AlphaMobileNode[] }> {
    if (!this.config) throw new Error("API not configured");

    const response = await fetch(`${this.config.baseURL}/api/mobile/nodes`, {
      headers: { Authorization: this.getAuthHeader() },
    });

    if (!response.ok) throw new Error(`API error: ${response.status}`);
    return response.json();
  }

  async getSecurityCatalog(): Promise<AlphaSecurityCatalog> {
    if (!this.config) throw new Error("API not configured");

    const response = await fetch(`${this.config.baseURL}/api/security/catalog`, {
      headers: { Authorization: this.getAuthHeader() },
    });

    if (!response.ok) throw new Error(`API error: ${response.status}`);
    return response.json();
  }

  async registerDevice(device: { id: string; type: string }): Promise<{ reg: boolean }> {
    if (!this.config) throw new Error("API not configured");

    const response = await fetch(`${this.config.baseURL}/api/mobile/register`, {
      method: "POST",
      headers: {
        Authorization: this.getAuthHeader(),
        "Content-Type": "application/json",
      },
      body: JSON.stringify(device),
    });

    if (!response.ok) throw new Error(`API error: ${response.status}`);
    return response.json();
  }

  async executeCommand(command: string): Promise<{ result: string }> {
    if (!this.config) throw new Error("API not configured");

    const response = await fetch(`${this.config.baseURL}/api/engine/execute`, {
      method: "POST",
      headers: {
        Authorization: this.getAuthHeader(),
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ cmd: command }),
    });

    if (!response.ok) throw new Error(`API error: ${response.status}`);
    return response.json();
  }
}

export const alphaAPI = new ProjectAlphaAPI();
