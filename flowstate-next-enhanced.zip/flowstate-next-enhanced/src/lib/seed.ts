import { AppState } from '../types';

export const initialState: AppState = {
  devices: [
    { id: 'd1', name: 'CEO-MacBook-Pro', mac: 'AA:BB:CC:DD:EE:01', status: 'online', type: 'ceo', signal: 91, floor: '1. OG', battery: 84, lastSeen: 'vor 2 Sek.' },
    { id: 'd2', name: 'Finn-iPhone-15', mac: 'AA:BB:CC:DD:EE:02', status: 'online', type: 'mobile', signal: 76, floor: 'Erdgeschoss', battery: 61, lastSeen: 'vor 4 Sek.' },
    { id: 'd3', name: 'Relay-Node-01', mac: 'AA:BB:CC:DD:EE:03', status: 'online', type: 'relay', signal: 88, floor: '2. OG', lastSeen: 'vor 9 Sek.' },
    { id: 'd4', name: 'Guest-Laptop', mac: 'AA:BB:CC:DD:EE:04', status: 'offline', type: 'guest', signal: 18, floor: 'Erdgeschoss', lastSeen: 'vor 2 Std.' },
    { id: 'd5', name: 'RaspberryPi-4', mac: 'AA:BB:CC:DD:EE:05', status: 'online', type: 'server', signal: 57, floor: 'Erdgeschoss', lastSeen: 'vor 13 Sek.' },
  ],
  securityLogs: [
    { id: 's1', category: 'Schwachstellen', code: 'scan_complete', severity: 'info', source: 'MeshScanner', message: 'RSSI-Scan abgeschlossen: 5 Geräte gefunden', createdAt: '2026-07-03 08:15' },
    { id: 's2', category: 'Info', code: 'key_rotation', severity: 'info', source: 'KeyManager', message: 'AES-256 Schlüssel rotiert (alle 24h)', createdAt: '2026-07-03 08:02' },
    { id: 's3', category: 'Info', code: 'vpn_connect', severity: 'info', source: 'WireGuard', message: 'VPN-Tunnel aktiviert – Port 51820', createdAt: '2026-07-03 07:58' },
    { id: 's4', category: 'Info', code: 'auth_success', severity: 'info', source: '192.168.1.1', message: 'CEO-Login erfolgreich via JWT', createdAt: '2026-07-03 07:57' },
    { id: 's5', category: 'Warnung', code: 'threat_detected', severity: 'resolved', source: '192.168.1.99', message: 'Unbekanntes Gerät versucht Mesh-Beitritt', createdAt: '2026-07-03 07:55' },
    { id: 's6', category: 'Kritisch', code: 'port_probe', severity: 'warning', source: '203.0.113.77', message: 'Port-Scan auf API Server erkannt und blockiert', createdAt: '2026-07-03 07:21' },
  ],
  transactions: [
    { id: 'tx1', direction: 'out', amount: 0.005, label: 'VPN Service', status: 'pending', confirmations: 0, createdAt: '2026-07-03 08:05' },
    { id: 'tx2', direction: 'out', amount: 0.005, label: 'Node Hardware', status: 'pending', confirmations: 0, createdAt: '2026-07-03 08:01' },
    { id: 'tx3', direction: 'in', amount: 0.05, label: 'Initial Transfer', status: 'confirmed', confirmations: 6, createdAt: '2026-07-02 22:10' },
    { id: 'tx4', direction: 'out', amount: 0.01, label: 'VPN Service', status: 'confirmed', confirmations: 3, createdAt: '2026-07-02 17:41' },
    { id: 'tx5', direction: 'in', amount: 0.025, label: 'Hardware Purchase', status: 'pending', confirmations: 0, createdAt: '2026-07-01 11:54' },
  ],
  alphaNodes: [
    { id: 'n1', name: 'Alpha Scout', zone: 'Erdgeschoss', status: 'active', battery: 72, tasks: 12 },
    { id: 'n2', name: 'Alpha Relay', zone: '1. OG', status: 'active', battery: 88, tasks: 7 },
    { id: 'n3', name: 'Alpha Watch', zone: 'Server-Raum', status: 'idle', battery: 54, tasks: 3 },
  ],
  storageFiles: [
    { id: 'f1', name: 'backup-node-mesh.enc', encrypted: true, sizeMb: 314, type: 'backup', updatedAt: '2026-07-03 06:10' },
    { id: 'f2', name: 'wireguard-config.sec', encrypted: true, sizeMb: 2.1, type: 'config', updatedAt: '2026-07-03 05:48' },
    { id: 'f3', name: 'incident-report-q3.pdf', encrypted: false, sizeMb: 17.4, type: 'report', updatedAt: '2026-07-02 22:44' },
    { id: 'f4', name: 'cold-wallet-keyslot.bin', encrypted: true, sizeMb: 0.7, type: 'key', updatedAt: '2026-07-02 21:15' },
  ],
  settings: {
    apiClient: '',
    ceoName: 'Finn Jona Lischke',
    wakeWord: 'Pandemonium',
    theme: 'dark',
    autoRotateKeys: true,
    alertThreshold: 60,
  },
  securityCatalog: [
    { id: 'c1', title: 'Mesh-Infiltration', vector: 'Rogue Join Request', risk: 'hoch', mitigation: 'Allowlist, JWT-Gerätebindung, QR-Pairing' },
    { id: 'c2', title: 'API Token Replay', vector: 'Abgefangene Access Tokens', risk: 'kritisch', mitigation: 'Kurze TTL, Rotation, Fingerprint Binding' },
    { id: 'c3', title: 'Cold Wallet Exposure', vector: 'Unsichere Offline-Sicherung', risk: 'mittel', mitigation: 'Shamir Backup, Hardware-Only Signing' },
  ],
  alphaApiLogs: [
    { id: 'a1', level: 'INFO', endpoint: '/mesh/scan', latencyMs: 84, message: 'Scan erfolgreich gestartet', createdAt: '2026-07-03 08:11' },
    { id: 'a2', level: 'WARN', endpoint: '/nodes/register', latencyMs: 212, message: 'Rate-Limit nahe Schwelle', createdAt: '2026-07-03 07:40' },
    { id: 'a3', level: 'ERROR', endpoint: '/engine/evolve', latencyMs: 0, message: 'Kein API-Client konfiguriert', createdAt: '2026-07-03 07:02' },
  ],
  aiTranscript: [
    'Hallo CEO. Ich bin JayJay, dein KI-Assistent.',
    'Wake-Word: Pandemonium.',
    'Heute laufen alle Kernmodule stabil. Zwei ausgehende BTC-Transaktionen warten noch auf Bestätigung.',
  ],
};