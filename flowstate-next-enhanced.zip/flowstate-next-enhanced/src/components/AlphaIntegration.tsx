import React, { useState, useEffect } from 'react';
import { alphaAPI, type AlphaEngineStatus, type AlphaMobileNode, type AlphaSecurityCatalog } from '../lib/apiIntegration';

interface AlphaIntegrationProps {
  baseURL: string;
  username: string;
  password: string;
}

export function AlphaIntegration({ baseURL, username, password }: AlphaIntegrationProps) {
  const [engineStatus, setEngineStatus] = useState<AlphaEngineStatus | null>(null);
  const [mobileNodes, setMobileNodes] = useState<AlphaMobileNode[]>([]);
  const [securityCatalog, setSecurityCatalog] = useState<AlphaSecurityCatalog | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    alphaAPI.setConfig({ baseURL, username, password });
    loadData();
  }, [baseURL, username, password]);

  const loadData = async () => {
    setIsLoading(true);
    setError(null);

    try {
      const [engine, nodes, catalog] = await Promise.all([
        alphaAPI.getEngineStatus(),
        alphaAPI.getMobileNodes(),
        alphaAPI.getSecurityCatalog(),
      ]);

      setEngineStatus(engine);
      setMobileNodes(nodes.nodes);
      setSecurityCatalog(catalog);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unknown error');
    } finally {
      setIsLoading(false);
    }
  };

  if (isLoading) {
    return <div className="p-4 text-center">Loading Project Alpha data...</div>;
  }

  if (error) {
    return <div className="p-4 text-red-500">Error: {error}</div>;
  }

  return (
    <div className="space-y-6">
      {/* Engine Status */}
      {engineStatus && (
        <div className="bg-slate-900 border border-slate-700 rounded-lg p-6">
          <h3 className="text-lg font-semibold text-green-400 mb-4">Engine Status</h3>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <div className="text-sm text-slate-400">Version</div>
              <div className="text-white font-mono">{engineStatus.ver}</div>
            </div>
            <div>
              <div className="text-sm text-slate-400">Generation</div>
              <div className="text-white font-mono">{engineStatus.gen}</div>
            </div>
            <div>
              <div className="text-sm text-slate-400">Mutations</div>
              <div className="text-white font-mono">{engineStatus.mut}</div>
            </div>
            <div>
              <div className="text-sm text-slate-400">Confidence</div>
              <div className="text-green-400 font-mono">{engineStatus.conf.toFixed(1)}%</div>
            </div>
            <div>
              <div className="text-sm text-slate-400">Status</div>
              <div className="text-green-400 font-mono">{engineStatus.stat}</div>
            </div>
            <div>
              <div className="text-sm text-slate-400">Uptime</div>
              <div className="text-white font-mono">{engineStatus.upf}</div>
            </div>
          </div>
          <div className="mt-4 p-3 bg-slate-800 rounded border border-slate-700">
            <div className="text-sm text-slate-400 mb-2">DNA</div>
            <div className="text-green-400 font-mono text-xs break-all">{engineStatus.dna}</div>
          </div>
        </div>
      )}

      {/* Mobile Nodes */}
      {mobileNodes.length > 0 && (
        <div className="bg-slate-900 border border-slate-700 rounded-lg p-6">
          <h3 className="text-lg font-semibold text-green-400 mb-4">Mobile Nodes ({mobileNodes.length})</h3>
          <div className="space-y-2">
            {mobileNodes.map((node) => (
              <div key={node.id} className="bg-slate-800 rounded p-3 border border-slate-700">
                <div className="flex justify-between items-center">
                  <div>
                    <div className="text-white font-mono text-sm">{node.id}</div>
                    <div className="text-slate-400 text-xs">{node.type}</div>
                  </div>
                  <div className="text-green-400 text-xs">Online</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Security Catalog */}
      {securityCatalog && (
        <div className="bg-slate-900 border border-slate-700 rounded-lg p-6">
          <h3 className="text-lg font-semibold text-green-400 mb-4">Security Catalog</h3>
          <div className="grid grid-cols-2 gap-4 mb-4">
            <div className="bg-slate-800 rounded p-3">
              <div className="text-sm text-slate-400">Total Tools</div>
              <div className="text-2xl font-bold text-white">{securityCatalog.total}</div>
            </div>
            <div className="bg-slate-800 rounded p-3">
              <div className="text-sm text-slate-400">Categories</div>
              <div className="text-2xl font-bold text-white">{securityCatalog.cats.length}</div>
            </div>
          </div>
          <div className="space-y-2">
            <div className="text-sm text-slate-400">Categories:</div>
            <div className="flex flex-wrap gap-2">
              {securityCatalog.cats.map((cat) => (
                <span key={cat} className="bg-slate-800 text-green-400 text-xs px-2 py-1 rounded">
                  {cat}
                </span>
              ))}
            </div>
          </div>
        </div>
      )}

      <button
        onClick={loadData}
        className="w-full bg-green-600 hover:bg-green-700 text-white font-semibold py-2 rounded"
      >
        Refresh Data
      </button>
    </div>
  );
}
