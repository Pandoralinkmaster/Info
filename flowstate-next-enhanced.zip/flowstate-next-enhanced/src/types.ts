export type Severity = 'info' | 'warning' | 'critical' | 'resolved';

export interface MeshDevice {
  id: string;
  name: string;
  mac: string;
  status: 'online' | 'offline';
  type: 'ceo' | 'relay' | 'guest' | 'server' | 'mobile';
  signal: number;
  floor: 'Erdgeschoss' | '1. OG' | '2. OG';
  battery?: number;
  lastSeen: string;
}

export interface SecurityLog {
  id: string;
  category: string;
  code: string;
  severity: Severity;
  source: string;
  message: string;
  createdAt: string;
}

export interface Transaction {
  id: string;
  direction: 'in' | 'out';
  amount: number;
  label: string;
  status: 'confirmed' | 'pending';
  confirmations: number;
  createdAt: string;
}

export interface AlphaNode {
  id: string;
  name: string;
  zone: string;
  status: 'active' | 'idle' | 'offline';
  battery: number;
  tasks: number;
}

export interface StorageFile {
  id: string;
  name: string;
  encrypted: boolean;
  sizeMb: number;
  type: 'backup' | 'report' | 'key' | 'config';
  updatedAt: string;
}

export interface SystemSettings {
  apiClient: string;
  ceoName: string;
  wakeWord: string;
  theme: 'dark' | 'matrix';
  autoRotateKeys: boolean;
  alertThreshold: number;
}

export interface SecurityCatalogItem {
  id: string;
  title: string;
  vector: string;
  risk: 'niedrig' | 'mittel' | 'hoch' | 'kritisch';
  mitigation: string;
}

export interface AlphaApiLog {
  id: string;
  level: 'INFO' | 'WARN' | 'ERROR';
  endpoint: string;
  latencyMs: number;
  message: string;
  createdAt: string;
}

export interface AppState {
  devices: MeshDevice[];
  securityLogs: SecurityLog[];
  transactions: Transaction[];
  alphaNodes: AlphaNode[];
  storageFiles: StorageFile[];
  settings: SystemSettings;
  securityCatalog: SecurityCatalogItem[];
  alphaApiLogs: AlphaApiLog[];
  aiTranscript: string[];
}
