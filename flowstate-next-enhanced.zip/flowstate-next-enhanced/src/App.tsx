import { useMemo, useRef, useState, type ChangeEvent, type Dispatch, type ReactNode, type SetStateAction } from 'react';
import {
  Activity,
  AlertTriangle,
  ArrowDownLeft,
  ArrowUpRight,
  Bot,
  Box,
  BrainCircuit,
  Building2,
  ChevronRight,
  Cpu,
  Download,
  HardDrive,
  Home,
  KeyRound,
  Lock,
  Network,
  Radio,
  Save,
  ScanLine,
  ScrollText,
  Settings,
  Shield,
  ShieldCheck,
  Smartphone,
  Terminal,
  Upload,
  Wallet,
  Wifi,
  Zap,
} from 'lucide-react';
import {
  Area,
  AreaChart,
  Bar,
  BarChart,
  CartesianGrid,
  Cell,
  Pie,
  PieChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from 'recharts';
import { NavLink, Route, Routes } from 'react-router-dom';
import { initialState } from './lib/seed';
import { useLocalStorage } from './lib/useLocalStorage';
import {
  AlphaApiLog,
  AlphaNode,
  AppState,
  MeshDevice,
  SecurityCatalogItem,
  SecurityLog,
  StorageFile,
  Transaction,
} from './types';

type AppActions = {
  setState: Dispatch<SetStateAction<AppState>>;
  addSecurityLog: (log: Omit<SecurityLog, 'id'>) => void;
  addTransaction: (tx: Omit<Transaction, 'id'>) => void;
  addAlphaNode: (node: Omit<AlphaNode, 'id'>) => void;
  addStorageFile: (file: Omit<StorageFile, 'id'>) => void;
  addCatalogItem: (item: Omit<SecurityCatalogItem, 'id'>) => void;
  addApiLog: (log: Omit<AlphaApiLog, 'id'>) => void;
  pushAiMessage: (text: string) => void;
  reset: () => void;
};

const navItems = [
  { to: '/', label: 'Home', icon: Home },
  { to: '/mesh', label: 'Mesh', icon: Network },
  { to: '/jayjay', label: 'KI', icon: Bot },
  { to: '/wallet', label: 'BTC', icon: Wallet },
  { to: '/security', label: 'Security', icon: Shield },
  { to: '/storage', label: 'Storage', icon: HardDrive },
  { to: '/engine', label: 'Engine', icon: Cpu },
  { to: '/alpha-nodes', label: 'Alpha Nodes', icon: Smartphone },
  { to: '/security-catalog', label: 'Catalog', icon: ScrollText },
  { to: '/alpha-logs', label: 'API Logs', icon: Terminal },
  { to: '/building', label: 'Building', icon: Building2 },
  { to: '/settings', label: 'Settings', icon: Settings },
];

const money = new Intl.NumberFormat('de-DE', {
  style: 'currency',
  currency: 'EUR',
  maximumFractionDigits: 2,
});

function uid(prefix: string) {
  return `${prefix}_${Math.random().toString(36).slice(2, 9)}`;
}

function formatBtc(value: number) {
  return `${value >= 0 ? '+' : ''}${value.toFixed(8)} BTC`;
}

function formatSeverityClass(value: string) {
  return {
    info: 'tag-blue',
    warning: 'tag-amber',
    critical: 'tag-red',
    resolved: 'tag-green',
    active: 'tag-green',
    idle: 'tag-amber',
    offline: 'tag-slate',
    confirmed: 'tag-green',
    pending: 'tag-amber',
  }[value] ?? 'tag-slate';
}

function exportState(state: AppState) {
  const blob = new Blob([JSON.stringify(state, null, 2)], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = 'flowstate-next-export.json';
  link.click();
  URL.revokeObjectURL(url);
}

function App() {
  const [state, setState] = useLocalStorage<AppState>('flowstate-next-state', initialState);

  const actions: AppActions = {
    setState,
    addSecurityLog: (log) => setState((current) => ({ ...current, securityLogs: [{ id: uid('sec'), ...log }, ...current.securityLogs] })),
    addTransaction: (tx) => setState((current) => ({ ...current, transactions: [{ id: uid('tx'), ...tx }, ...current.transactions] })),
    addAlphaNode: (node) => setState((current) => ({ ...current, alphaNodes: [{ id: uid('node'), ...node }, ...current.alphaNodes] })),
    addStorageFile: (file) => setState((current) => ({ ...current, storageFiles: [{ id: uid('file'), ...file }, ...current.storageFiles] })),
    addCatalogItem: (item) => setState((current) => ({ ...current, securityCatalog: [{ id: uid('cat'), ...item }, ...current.securityCatalog] })),
    addApiLog: (log) => setState((current) => ({ ...current, alphaApiLogs: [{ id: uid('api'), ...log }, ...current.alphaApiLogs] })),
    pushAiMessage: (text) => setState((current) => ({ ...current, aiTranscript: [...current.aiTranscript, text] })),
    reset: () => setState(initialState),
  };

  return (
    <div className={`app-shell ${state.settings.theme === 'matrix' ? 'theme-matrix' : ''}`}>
      <aside className="sidebar">
        <div>
          <div className="brand-card">
            <div className="brand-badge">PANDORA</div>
            <h1>FlowState Next</h1>
            <p>rekonstruiert, erweitert, voll lokal ausführbar</p>
          </div>
          <nav className="nav-stack">
            {navItems.map(({ to, label, icon: Icon }) => (
              <NavLink
                key={to}
                to={to}
                className={({ isActive }) => `nav-item ${isActive ? 'active' : ''}`}
              >
                <Icon size={18} />
                <span>{label}</span>
                <ChevronRight size={14} className="nav-chevron" />
              </NavLink>
            ))}
          </nav>
        </div>
        <Panel title="System" eyebrow="Live">
          <div className="stack-sm">
            <InlineMetric icon={<ShieldCheck size={16} />} label="Security Level" value="MAX" />
            <InlineMetric icon={<Lock size={16} />} label="Verschlüsselung" value="AES-256-GCM" />
            <InlineMetric icon={<BrainCircuit size={16} />} label="Wake-Word" value={state.settings.wakeWord} />
          </div>
        </Panel>
      </aside>

      <main className="content-area">
        <Routes>
          <Route path="/" element={<DashboardPage state={state} actions={actions} />} />
          <Route path="/mesh" element={<MeshPage state={state} actions={actions} />} />
          <Route path="/jayjay" element={<JayJayPage state={state} actions={actions} />} />
          <Route path="/wallet" element={<WalletPage state={state} actions={actions} />} />
          <Route path="/security" element={<SecurityPage state={state} actions={actions} />} />
          <Route path="/storage" element={<StoragePage state={state} actions={actions} />} />
          <Route path="/engine" element={<EnginePage state={state} actions={actions} />} />
          <Route path="/alpha-nodes" element={<AlphaNodesPage state={state} actions={actions} />} />
          <Route path="/security-catalog" element={<SecurityCatalogPage state={state} actions={actions} />} />
          <Route path="/alpha-logs" element={<AlphaLogsPage state={state} actions={actions} />} />
          <Route path="/building" element={<BuildingPage state={state} />} />
          <Route path="/settings" element={<SettingsPage state={state} actions={actions} />} />
          <Route path="*" element={<NotFoundPage />} />
        </Routes>
      </main>
    </div>
  );
}

function LayoutHeader({
  eyebrow,
  title,
  subtitle,
  actions,
}: {
  eyebrow: string;
  title: string;
  subtitle: string;
  actions?: ReactNode;
}) {
  return (
    <header className="page-header">
      <div>
        <div className="eyebrow">{eyebrow}</div>
        <h2>{title}</h2>
        <p>{subtitle}</p>
      </div>
      {actions ? <div className="header-actions">{actions}</div> : null}
    </header>
  );
}

function Panel({ title, eyebrow, children, action }: { title: string; eyebrow?: string; children: ReactNode; action?: ReactNode }) {
  return (
    <section className="panel">
      <div className="panel-head">
        <div>
          {eyebrow ? <div className="eyebrow">{eyebrow}</div> : null}
          <h3>{title}</h3>
        </div>
        {action}
      </div>
      {children}
    </section>
  );
}

function Button({ children, onClick, kind = 'primary', type = 'button' }: { children: ReactNode; onClick?: () => void; kind?: 'primary' | 'secondary' | 'ghost'; type?: 'button' | 'submit' }) {
  return (
    <button type={type} className={`btn ${kind}`} onClick={onClick}>
      {children}
    </button>
  );
}

function StatCard({ label, value, hint, icon }: { label: string; value: string; hint: string; icon: ReactNode }) {
  return (
    <div className="stat-card">
      <div className="stat-icon">{icon}</div>
      <div>
        <div className="stat-label">{label}</div>
        <div className="stat-value">{value}</div>
        <div className="stat-hint">{hint}</div>
      </div>
    </div>
  );
}

function InlineMetric({ icon, label, value }: { icon: ReactNode; label: string; value: string }) {
  return (
    <div className="inline-metric">
      <div className="inline-icon">{icon}</div>
      <div>
        <div className="inline-label">{label}</div>
        <div className="inline-value">{value}</div>
      </div>
    </div>
  );
}

function DashboardPage({ state, actions }: { state: AppState; actions: AppActions }) {
  const onlineDevices = state.devices.filter((device) => device.status === 'online').length;
  const pendingTx = state.transactions.filter((tx) => tx.status === 'pending').length;
  const criticalLogs = state.securityLogs.filter((log) => log.severity === 'critical' || log.severity === 'warning').length;
  const apiConfigured = Boolean(state.settings.apiClient);

  const signalData = [
    { name: 'EG', signal: averageSignal(state.devices.filter((d) => d.floor === 'Erdgeschoss')) },
    { name: '1. OG', signal: averageSignal(state.devices.filter((d) => d.floor === '1. OG')) },
    { name: '2. OG', signal: averageSignal(state.devices.filter((d) => d.floor === '2. OG')) },
  ];

  const txData = state.transactions.slice(0, 5).reverse().map((tx) => ({
    name: tx.createdAt.slice(11),
    btc: Number((tx.direction === 'out' ? -tx.amount : tx.amount).toFixed(3)),
  }));

  const [command, setCommand] = useState('');

  function executeCommand() {
    if (!command.trim()) return;
    const lower = command.toLowerCase();

    if (lower.includes('scan')) {
      actions.addSecurityLog({
        category: 'Info',
        code: 'manual_scan',
        severity: 'info',
        source: 'Dashboard Console',
        message: 'Manueller Netzwerkscan ausgeführt',
        createdAt: nowStamp(),
      });
    } else if (lower.includes('rotate')) {
      actions.addSecurityLog({
        category: 'Info',
        code: 'key_rotation',
        severity: 'info',
        source: 'Dashboard Console',
        message: 'Schlüsselrotation manuell ausgelöst',
        createdAt: nowStamp(),
      });
    } else if (lower.includes('node')) {
      actions.addAlphaNode({
        name: `Alpha ${state.alphaNodes.length + 1}`,
        zone: 'Erdgeschoss',
        status: 'active',
        battery: 100,
        tasks: 0,
      });
    } else {
      actions.pushAiMessage(`Command ausgeführt: ${command}`);
    }

    setCommand('');
  }

  return (
    <div className="page-grid">
      <LayoutHeader
        eyebrow="Zero-Trust Mesh Network"
        title="CEO Host Mode Active"
        subtitle="Erweiterte lokale Rekonstruktion mit Dashboard, Aktionen, Persistenz und administrativen Kontrollflächen."
        actions={<Button kind="secondary" onClick={() => exportState(state)}><Download size={16} /> Export</Button>}
      />

      <div className="stats-grid">
        <StatCard label="Netzwerk Status" value={`${onlineDevices}/${state.devices.length}`} hint="Geräte online" icon={<Wifi size={18} />} />
        <StatCard label="Sicherheitsereignisse" value={String(criticalLogs)} hint="Warnings + Kritisch" icon={<Shield size={18} />} />
        <StatCard label="Wallet Queue" value={String(pendingTx)} hint="Ausstehende BTC-Transaktionen" icon={<Wallet size={18} />} />
        <StatCard label="API Engine" value={apiConfigured ? 'ONLINE' : 'OFFLINE'} hint={apiConfigured ? 'Client verbunden' : 'Client fehlt'} icon={<Cpu size={18} />} />
      </div>

      <div className="two-col">
        <Panel title="Signalstärke je Etage" eyebrow="Mesh">
          <div className="chart-box">
            <ResponsiveContainer width="100%" height={260}>
              <AreaChart data={signalData}>
                <defs>
                  <linearGradient id="signalFill" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor="#2de5b7" stopOpacity={0.75} />
                    <stop offset="100%" stopColor="#2de5b7" stopOpacity={0.02} />
                  </linearGradient>
                </defs>
                <CartesianGrid stroke="#263445" vertical={false} />
                <XAxis dataKey="name" stroke="#89a0b8" />
                <YAxis stroke="#89a0b8" domain={[0, 100]} />
                <Tooltip />
                <Area type="monotone" dataKey="signal" stroke="#2de5b7" fill="url(#signalFill)" strokeWidth={2} />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </Panel>

        <Panel title="BTC Bewegungen" eyebrow="Wallet">
          <div className="chart-box">
            <ResponsiveContainer width="100%" height={260}>
              <BarChart data={txData}>
                <CartesianGrid stroke="#263445" vertical={false} />
                <XAxis dataKey="name" stroke="#89a0b8" />
                <YAxis stroke="#89a0b8" />
                <Tooltip />
                <Bar dataKey="btc" radius={[8, 8, 0, 0]}>
                  {txData.map((entry, index) => (
                    <Cell key={`${entry.name}-${index}`} fill={entry.btc >= 0 ? '#ffd84d' : '#ff8b5e'} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        </Panel>
      </div>

      <div className="two-col">
        <Panel title="Schnellkonsole" eyebrow="Ops" action={<Button kind="ghost" onClick={executeCommand}><Zap size={16} /> Ausführen</Button>}>
          <div className="stack-sm">
            <p className="muted">Beispiele: <code>scan mesh</code>, <code>rotate keys</code>, <code>create node</code></p>
            <div className="command-row">
              <input value={command} onChange={(e) => setCommand(e.target.value)} placeholder="Befehl eingeben" />
              <Button onClick={executeCommand}>Start</Button>
            </div>
          </div>
        </Panel>

        <Panel title="Neueste Logs" eyebrow="Security">
          <div className="list-stack">
            {state.securityLogs.slice(0, 4).map((log) => (
              <div key={log.id} className="list-item">
                <div>
                  <div className="list-title">{log.message}</div>
                  <div className="list-subtitle">{log.code} • {log.source}</div>
                </div>
                <span className={`tag ${formatSeverityClass(log.severity)}`}>{log.category}</span>
              </div>
            ))}
          </div>
        </Panel>
      </div>
    </div>
  );
}

function MeshPage({ state, actions }: { state: AppState; actions: AppActions }) {
  const [form, setForm] = useState({ name: '', mac: '', floor: 'Erdgeschoss' as MeshDevice['floor'] });

  function toggleDevice(id: string) {
    actions.setState((current) => ({
      ...current,
      devices: current.devices.map((device) =>
        device.id === id
          ? { ...device, status: device.status === 'online' ? 'offline' : 'online', lastSeen: 'gerade eben' }
          : device,
      ),
    }));
  }

  function addDevice() {
    if (!form.name.trim() || !form.mac.trim()) return;
    actions.setState((current) => ({
      ...current,
      devices: [
        {
          id: uid('dev'),
          name: form.name,
          mac: form.mac,
          status: 'online',
          type: 'mobile',
          signal: 70,
          floor: form.floor,
          battery: 100,
          lastSeen: 'gerade eben',
        },
        ...current.devices,
      ],
    }));
    actions.addSecurityLog({
      category: 'Info',
      code: 'mesh_join',
      severity: 'info',
      source: form.mac,
      message: `${form.name} dem Mesh hinzugefügt`,
      createdAt: nowStamp(),
    });
    setForm({ name: '', mac: '', floor: 'Erdgeschoss' });
  }

  return (
    <div className="page-grid">
      <LayoutHeader eyebrow="Bluetooth Mesh • WiFi Direct • Onion Routing • WireGuard" title="Mesh-Netzwerk" subtitle="Geräteverwaltung, Online-Status, Pairing und Live-Übersicht." />
      <div className="two-col three-two">
        <Panel title="Geräte" eyebrow="Quick Access">
          <div className="list-stack">
            {state.devices.map((device) => (
              <div key={device.id} className="device-card">
                <div>
                  <div className="list-title">{device.name}</div>
                  <div className="list-subtitle">{device.mac} • {device.floor} • Signal {device.signal}%</div>
                </div>
                <div className="device-actions">
                  <span className={`tag ${formatSeverityClass(device.status)}`}>{device.status}</span>
                  <Button kind="secondary" onClick={() => toggleDevice(device.id)}>{device.status === 'online' ? 'Offline' : 'Online'}</Button>
                </div>
              </div>
            ))}
          </div>
        </Panel>

        <Panel title="Neues Gerät koppeln" eyebrow="Pairing">
          <div className="form-grid">
            <label>
              Name
              <input value={form.name} onChange={(e) => setForm((current) => ({ ...current, name: e.target.value }))} placeholder="z. B. Relay-Node-02" />
            </label>
            <label>
              MAC
              <input value={form.mac} onChange={(e) => setForm((current) => ({ ...current, mac: e.target.value }))} placeholder="AA:BB:CC:DD:EE:09" />
            </label>
            <label>
              Etage
              <select value={form.floor} onChange={(e) => setForm((current) => ({ ...current, floor: e.target.value as MeshDevice['floor'] }))}>
                <option>Erdgeschoss</option>
                <option>1. OG</option>
                <option>2. OG</option>
              </select>
            </label>
            <Button onClick={addDevice}><Radio size={16} /> Gerät registrieren</Button>
          </div>
        </Panel>
      </div>
    </div>
  );
}

function JayJayPage({ state, actions }: { state: AppState; actions: AppActions }) {
  const [prompt, setPrompt] = useState('');

  function respond() {
    if (!prompt.trim()) return;
    const input = prompt.toLowerCase();
    let answer = 'JayJay: Anfrage verstanden. Ich habe die Lage analysiert.';
    if (input.includes('wallet') || input.includes('btc')) answer = 'JayJay: Zwei ausgehende BTC-Transaktionen sind noch unbestätigt. Cold Storage bleibt aktiv.';
    if (input.includes('mesh')) answer = 'JayJay: Vier Geräte sind online. Das stärkste Signal liefert aktuell CEO-MacBook-Pro mit 91 Prozent.';
    if (input.includes('security')) answer = 'JayJay: Keine ungelösten kritischen Vorfälle. Ein Port-Scan wurde blockiert.';
    if (input.includes('engine')) answer = state.settings.apiClient ? 'JayJay: Der API-Client ist aktiv. Evolution Engine kann Jobs starten.' : 'JayJay: Bitte zuerst in den Einstellungen einen API-Client hinterlegen.';

    actions.pushAiMessage(`CEO: ${prompt}`);
    actions.pushAiMessage(answer);
    setPrompt('');
  }

  return (
    <div className="page-grid">
      <LayoutHeader eyebrow="GPT-4o-mini • Whisper • Voice-Print • Memory" title="JayJay KI" subtitle="Lokal simulierte Assistentenansicht mit Gesprächsverlauf und Antworten auf Betriebsdaten." />
      <div className="two-col three-two">
        <Panel title="Transkript" eyebrow="KI aktiv">
          <div className="chat-stack">
            {state.aiTranscript.map((line, index) => (
              <div key={`${line}-${index}`} className={`chat-bubble ${line.startsWith('CEO:') ? 'me' : ''}`}>{line}</div>
            ))}
          </div>
        </Panel>
        <Panel title="Sprachkonsole" eyebrow="Wake-Word">
          <div className="stack-sm">
            <InlineMetric icon={<BrainCircuit size={16} />} label="Wake-Word" value={state.settings.wakeWord} />
            <InlineMetric icon={<Bot size={16} />} label="Modus" value="KI aktiv" />
            <label>
              Prompt
              <textarea rows={8} value={prompt} onChange={(e) => setPrompt(e.target.value)} placeholder="Frage JayJay nach Mesh, Wallet, Security oder Engine." />
            </label>
            <Button onClick={respond}><Bot size={16} /> Senden</Button>
          </div>
        </Panel>
      </div>
    </div>
  );
}

function WalletPage({ state, actions }: { state: AppState; actions: AppActions }) {
  const totalBalance = useMemo(
    () => state.transactions.reduce((acc, tx) => acc + (tx.direction === 'in' ? tx.amount : -tx.amount), 0),
    [state.transactions],
  );
  const [amount, setAmount] = useState('0.001');
  const [label, setLabel] = useState('Neuer Transfer');

  function createOutgoing() {
    const parsed = Number(amount);
    if (Number.isNaN(parsed) || parsed <= 0) return;
    actions.addTransaction({
      direction: 'out',
      amount: parsed,
      label,
      status: 'pending',
      confirmations: 0,
      createdAt: nowStamp(),
    });
  }

  const pieData = [
    { name: 'Bestätigt', value: state.transactions.filter((tx) => tx.status === 'confirmed').length, color: '#2de5b7' },
    { name: 'Ausstehend', value: state.transactions.filter((tx) => tx.status === 'pending').length, color: '#ffd84d' },
  ];

  return (
    <div className="page-grid">
      <LayoutHeader eyebrow="Hardware Wallet • Ledger Nano S/X • Cold Storage" title="Bitcoin Wallet" subtitle="Lokale Wallet-Simulation mit Summen, Status und Transaktionsverwaltung." />
      <div className="stats-grid">
        <StatCard label="Gesamtguthaben" value={formatBtc(totalBalance)} hint={money.format(totalBalance * 97246)} icon={<Wallet size={18} />} />
        <StatCard label="Cold Storage" value="COLD" hint="Ledger verbunden" icon={<KeyRound size={18} />} />
        <StatCard label="Unbestätigt" value={String(state.transactions.filter((tx) => tx.status === 'pending').length)} hint="Wartende Transaktionen" icon={<Activity size={18} />} />
        <StatCard label="Adresse" value="bc1qxy2k...0wlh" hint="gekürzt" icon={<Lock size={18} />} />
      </div>
      <div className="two-col">
        <Panel title="Transaktionen" eyebrow="Ledger verbunden">
          <div className="list-stack">
            {state.transactions.map((tx) => (
              <div key={tx.id} className="list-item">
                <div>
                  <div className="list-title">{tx.direction === 'in' ? <ArrowDownLeft size={16} /> : <ArrowUpRight size={16} />} {formatBtc(tx.direction === 'out' ? -tx.amount : tx.amount)}</div>
                  <div className="list-subtitle">{tx.label} • {tx.createdAt}</div>
                </div>
                <span className={`tag ${formatSeverityClass(tx.status)}`}>{tx.status === 'pending' ? 'Ausstehend' : `${tx.confirmations} Conf.`}</span>
              </div>
            ))}
          </div>
        </Panel>
        <Panel title="Neue Zahlung" eyebrow="Senden / Empfangen">
          <div className="stack-sm">
            <label>
              Betrag in BTC
              <input value={amount} onChange={(e) => setAmount(e.target.value)} />
            </label>
            <label>
              Beschreibung
              <input value={label} onChange={(e) => setLabel(e.target.value)} />
            </label>
            <Button onClick={createOutgoing}><ArrowUpRight size={16} /> Transaktion anlegen</Button>
            <div className="chart-box compact">
              <ResponsiveContainer width="100%" height={220}>
                <PieChart>
                  <Pie data={pieData} dataKey="value" nameKey="name" innerRadius={50} outerRadius={74}>
                    {pieData.map((entry) => <Cell key={entry.name} fill={entry.color} />)}
                  </Pie>
                  <Tooltip />
                </PieChart>
              </ResponsiveContainer>
            </div>
          </div>
        </Panel>
      </div>
    </div>
  );
}

function SecurityPage({ state, actions }: { state: AppState; actions: AppActions }) {
  function generateAlert() {
    actions.addSecurityLog({
      category: 'Warnung',
      code: 'threat_detected',
      severity: 'warning',
      source: 'Adaptive Firewall',
      message: 'Anomaler Zugriff auf geschützten Port erkannt',
      createdAt: nowStamp(),
    });
  }

  return (
    <div className="page-grid">
      <LayoutHeader eyebrow="Zero-Trust • AES-256-GCM • JWT • Post-Quantum • WireGuard" title="Sicherheit" subtitle="Verschlüsselungsstatus, Protokolle und simulierte Abwehrereignisse." actions={<Button kind="secondary" onClick={generateAlert}><AlertTriangle size={16} /> Alert erzeugen</Button>} />
      <div className="stats-grid">
        <StatCard label="Security Level" value="MAX" hint="Zero-Trust aktiv" icon={<ShieldCheck size={18} />} />
        <StatCard label="Kritisch" value={String(state.securityLogs.filter((log) => log.severity === 'critical').length)} hint="ungelöste Threats" icon={<AlertTriangle size={18} />} />
        <StatCard label="Warnungen" value={String(state.securityLogs.filter((log) => log.severity === 'warning').length)} hint="offene Warnings" icon={<ScanLine size={18} />} />
        <StatCard label="Gelöst" value={String(state.securityLogs.filter((log) => log.severity === 'resolved').length)} hint="resolved events" icon={<Shield size={18} />} />
      </div>
      <Panel title="Security Log" eyebrow="Events">
        <div className="table-like">
          {state.securityLogs.map((log) => (
            <div key={log.id} className="table-row">
              <div>
                <div className="list-title">{log.message}</div>
                <div className="list-subtitle">{log.code} • {log.source}</div>
              </div>
              <div>{log.createdAt}</div>
              <span className={`tag ${formatSeverityClass(log.severity)}`}>{log.category}</span>
            </div>
          ))}
        </div>
      </Panel>
    </div>
  );
}

function StoragePage({ state, actions }: { state: AppState; actions: AppActions }) {
  const [form, setForm] = useState({ name: '', sizeMb: '12', type: 'backup' as StorageFile['type'], encrypted: true });
  const usedSpace = state.storageFiles.reduce((acc, file) => acc + file.sizeMb, 0);
  const percent = Math.min((usedSpace / 2048) * 100, 100);

  function addFile() {
    const size = Number(form.sizeMb);
    if (!form.name.trim() || Number.isNaN(size)) return;
    actions.addStorageFile({
      name: form.name,
      sizeMb: size,
      type: form.type,
      encrypted: form.encrypted,
      updatedAt: nowStamp(),
    });
    setForm({ name: '', sizeMb: '12', type: 'backup', encrypted: true });
  }

  return (
    <div className="page-grid">
      <LayoutHeader eyebrow="2TB SSD • AES-256 Verschlüsselung • LUKS" title="Speicher" subtitle="Dateiübersicht, Speicherverbrauch und verschlüsselte Ablage." />
      <div className="two-col">
        <Panel title="Speicherauslastung" eyebrow="2TB SSD">
          <div className="stack-sm">
            <div className="progress-shell"><div className="progress-bar" style={{ width: `${percent}%` }} /></div>
            <div className="list-subtitle">{usedSpace.toFixed(1)} MB von 2048 MB Demo-Kapazität belegt</div>
            <div className="list-stack compact">
              {state.storageFiles.map((file) => (
                <div key={file.id} className="list-item">
                  <div>
                    <div className="list-title">{file.name}</div>
                    <div className="list-subtitle">{file.type} • {file.sizeMb} MB • {file.updatedAt}</div>
                  </div>
                  <span className={`tag ${file.encrypted ? 'tag-green' : 'tag-amber'}`}>{file.encrypted ? 'AES-256' : 'Plain'}</span>
                </div>
              ))}
            </div>
          </div>
        </Panel>
        <Panel title="Datei hinzufügen" eyebrow="Archiv">
          <div className="form-grid">
            <label>
              Dateiname
              <input value={form.name} onChange={(e) => setForm((current) => ({ ...current, name: e.target.value }))} />
            </label>
            <label>
              Größe in MB
              <input value={form.sizeMb} onChange={(e) => setForm((current) => ({ ...current, sizeMb: e.target.value }))} />
            </label>
            <label>
              Typ
              <select value={form.type} onChange={(e) => setForm((current) => ({ ...current, type: e.target.value as StorageFile['type'] }))}>
                <option value="backup">Backup</option>
                <option value="report">Report</option>
                <option value="key">Key</option>
                <option value="config">Config</option>
              </select>
            </label>
            <label className="checkbox-row">
              <input type="checkbox" checked={form.encrypted} onChange={(e) => setForm((current) => ({ ...current, encrypted: e.target.checked }))} />
              Verschlüsselt speichern
            </label>
            <Button onClick={addFile}><Box size={16} /> Datei anlegen</Button>
          </div>
        </Panel>
      </div>
    </div>
  );
}

function EnginePage({ state, actions }: { state: AppState; actions: AppActions }) {
  const apiConfigured = Boolean(state.settings.apiClient);

  function runEngine() {
    if (!apiConfigured) {
      actions.addApiLog({
        level: 'ERROR',
        endpoint: '/engine/evolve',
        latencyMs: 0,
        message: 'Kein API-Client. Bitte in Einstellungen konfigurieren.',
        createdAt: nowStamp(),
      });
      return;
    }
    actions.addApiLog({
      level: 'INFO',
      endpoint: '/engine/evolve',
      latencyMs: 188,
      message: 'Evolution Cycle erfolgreich gestartet',
      createdAt: nowStamp(),
    });
    actions.pushAiMessage('JayJay: Evolution Engine hat einen neuen Optimierungszyklus gestartet.');
  }

  return (
    <div className="page-grid">
      <LayoutHeader eyebrow="Project Alpha • Evolution Engine • Replikation" title="Engine Status" subtitle={apiConfigured ? 'API-Client verbunden. Simulation ausführbar.' : 'Kein API-Client. Bitte in Einstellungen konfigurieren.'} actions={<Button kind="secondary" onClick={runEngine}><Cpu size={16} /> Evolution starten</Button>} />
      <div className="two-col">
        <Panel title="Live Log" eyebrow="Engine">
          <div className="list-stack">
            {state.alphaApiLogs.filter((log) => log.endpoint.includes('/engine')).length === 0 ? (
              <div className="empty-state">Keine Einträge</div>
            ) : (
              state.alphaApiLogs.filter((log) => log.endpoint.includes('/engine')).map((log) => (
                <div className="list-item" key={log.id}>
                  <div>
                    <div className="list-title">{log.message}</div>
                    <div className="list-subtitle">{log.endpoint} • {log.createdAt}</div>
                  </div>
                  <span className={`tag ${log.level === 'ERROR' ? 'tag-red' : log.level === 'WARN' ? 'tag-amber' : 'tag-green'}`}>{log.level}</span>
                </div>
              ))
            )}
          </div>
        </Panel>
        <Panel title="Engine Runtime" eyebrow="Status">
          <div className="stack-sm">
            <InlineMetric icon={<Cpu size={16} />} label="API-Client" value={apiConfigured ? state.settings.apiClient : 'nicht konfiguriert'} />
            <InlineMetric icon={<Zap size={16} />} label="Replikation" value={apiConfigured ? 'bereit' : 'gesperrt'} />
            <InlineMetric icon={<Lock size={16} />} label="Isolation" value="Sandboxed Local Runtime" />
          </div>
        </Panel>
      </div>
    </div>
  );
}

function AlphaNodesPage({ state, actions }: { state: AppState; actions: AppActions }) {
  const [nodeName, setNodeName] = useState('');
  const [zone, setZone] = useState('Erdgeschoss');

  function registerNode() {
    if (!nodeName.trim()) return;
    actions.addAlphaNode({ name: nodeName, zone, status: 'active', battery: 100, tasks: 0 });
    actions.addApiLog({
      level: 'INFO',
      endpoint: '/nodes/register',
      latencyMs: 96,
      message: `${nodeName} registriert`,
      createdAt: nowStamp(),
    });
    setNodeName('');
  }

  return (
    <div className="page-grid">
      <LayoutHeader eyebrow="Project Alpha • Mobile Module • Geräteregistrierung" title="Mobile Nodes" subtitle="Registrierte Knoten, Zonen und Laufzeitstatus." />
      <div className="two-col">
        <Panel title={`Registrierte Knoten (${state.alphaNodes.length})`} eyebrow="Nodes">
          <div className="list-stack">
            {state.alphaNodes.map((node) => (
              <div key={node.id} className="list-item">
                <div>
                  <div className="list-title">{node.name}</div>
                  <div className="list-subtitle">{node.zone} • Akku {node.battery}% • Tasks {node.tasks}</div>
                </div>
                <span className={`tag ${formatSeverityClass(node.status)}`}>{node.status}</span>
              </div>
            ))}
          </div>
        </Panel>
        <Panel title="Node registrieren" eyebrow="API">
          <div className="form-grid">
            <label>
              Node Name
              <input value={nodeName} onChange={(e) => setNodeName(e.target.value)} placeholder="Alpha Sentinel" />
            </label>
            <label>
              Zone
              <select value={zone} onChange={(e) => setZone(e.target.value)}>
                <option>Erdgeschoss</option>
                <option>1. OG</option>
                <option>2. OG</option>
                <option>Server-Raum</option>
              </select>
            </label>
            <Button onClick={registerNode}><Smartphone size={16} /> Registrieren</Button>
          </div>
        </Panel>
      </div>
    </div>
  );
}

function SecurityCatalogPage({ state, actions }: { state: AppState; actions: AppActions }) {
  const [item, setItem] = useState({ title: '', vector: '', risk: 'mittel' as SecurityCatalogItem['risk'], mitigation: '' });

  function addItem() {
    if (!item.title.trim()) return;
    actions.addCatalogItem(item);
    setItem({ title: '', vector: '', risk: 'mittel', mitigation: '' });
  }

  return (
    <div className="page-grid">
      <LayoutHeader eyebrow="Project Alpha • Arsenal • Protokoll • Vektoren" title="Security Catalog" subtitle="Angriffsvektoren, Risikostufen und Maßnahmen katalogisieren." />
      <div className="two-col three-two">
        <Panel title="Einträge" eyebrow="Catalog">
          <div className="list-stack">
            {state.securityCatalog.map((entry) => (
              <div key={entry.id} className="catalog-card">
                <div className="list-title">{entry.title}</div>
                <div className="list-subtitle">{entry.vector}</div>
                <p className="muted">{entry.mitigation}</p>
                <span className={`tag ${entry.risk === 'kritisch' ? 'tag-red' : entry.risk === 'hoch' ? 'tag-amber' : entry.risk === 'mittel' ? 'tag-blue' : 'tag-green'}`}>{entry.risk}</span>
              </div>
            ))}
          </div>
        </Panel>
        <Panel title="Neuer Vektor" eyebrow="Add">
          <div className="form-grid">
            <label>
              Titel
              <input value={item.title} onChange={(e) => setItem((current) => ({ ...current, title: e.target.value }))} />
            </label>
            <label>
              Vektor
              <input value={item.vector} onChange={(e) => setItem((current) => ({ ...current, vector: e.target.value }))} />
            </label>
            <label>
              Risiko
              <select value={item.risk} onChange={(e) => setItem((current) => ({ ...current, risk: e.target.value as SecurityCatalogItem['risk'] }))}>
                <option>niedrig</option>
                <option>mittel</option>
                <option>hoch</option>
                <option>kritisch</option>
              </select>
            </label>
            <label>
              Maßnahme
              <textarea rows={5} value={item.mitigation} onChange={(e) => setItem((current) => ({ ...current, mitigation: e.target.value }))} />
            </label>
            <Button onClick={addItem}><Shield size={16} /> Eintrag speichern</Button>
          </div>
        </Panel>
      </div>
    </div>
  );
}

function AlphaLogsPage({ state, actions }: { state: AppState; actions: AppActions }) {
  const [filter, setFilter] = useState<'ALL' | 'INFO' | 'WARN' | 'ERROR'>('ALL');
  const logs = filter === 'ALL' ? state.alphaApiLogs : state.alphaApiLogs.filter((log) => log.level === filter);

  function generateLog() {
    const samples: Omit<AlphaApiLog, 'id'>[] = [
      { level: 'INFO', endpoint: '/api/mesh/status', latencyMs: 75, message: 'Heartbeat OK', createdAt: nowStamp() },
      { level: 'WARN', endpoint: '/api/storage/sync', latencyMs: 330, message: 'Synchronisation verzögert', createdAt: nowStamp() },
      { level: 'ERROR', endpoint: '/api/security/rotate', latencyMs: 0, message: 'Rotation aufgrund fehlender Berechtigung abgebrochen', createdAt: nowStamp() },
    ];
    actions.addApiLog(samples[Math.floor(Math.random() * samples.length)]);
  }

  return (
    <div className="page-grid">
      <LayoutHeader eyebrow="Project Alpha • Live API Monitor • Echtzeit-Ausgabe" title="API Logs" subtitle="Filterbare Schnittstellenprotokolle mit Demo-Generator." actions={<Button kind="secondary" onClick={generateLog}><Terminal size={16} /> Testlog</Button>} />
      <Panel title="Logs" eyebrow="Live API Monitor" action={
        <div className="chip-row">
          {(['ALL', 'INFO', 'WARN', 'ERROR'] as const).map((value) => (
            <button key={value} className={`chip ${filter === value ? 'active' : ''}`} onClick={() => setFilter(value)}>{value}</button>
          ))}
        </div>
      }>
        <div className="table-like">
          {logs.map((log) => (
            <div className="table-row" key={log.id}>
              <div>
                <div className="list-title">{log.message}</div>
                <div className="list-subtitle">{log.endpoint}</div>
              </div>
              <div>{log.latencyMs} ms</div>
              <span className={`tag ${log.level === 'ERROR' ? 'tag-red' : log.level === 'WARN' ? 'tag-amber' : 'tag-green'}`}>{log.level}</span>
            </div>
          ))}
        </div>
      </Panel>
    </div>
  );
}

function BuildingPage({ state }: { state: AppState }) {
  const floorGroups = ['Erdgeschoss', '1. OG', '2. OG'] as const;

  return (
    <div className="page-grid">
      <LayoutHeader eyebrow="Heatmap • Geräteverteilung • RSSI-Visualisierung" title="3D Gebäude-Overlay" subtitle="Vereinfachte Etagenansicht mit Geräteverteilung und Signalstärke." />
      <div className="building-grid">
        {floorGroups.map((floor) => (
          <Panel key={floor} title={floor} eyebrow="LIVE">
            <div className="floor-map">
              {state.devices.filter((device) => device.floor === floor).map((device) => (
                <div key={device.id} className={`room-tile ${device.signal > 80 ? 'strong' : device.signal > 50 ? 'medium' : device.signal > 20 ? 'weak' : 'none'}`}>
                  <div className="list-title">{device.name}</div>
                  <div className="list-subtitle">Signal {device.signal}%</div>
                </div>
              ))}
            </div>
          </Panel>
        ))}
      </div>
    </div>
  );
}

function SettingsPage({ state, actions }: { state: AppState; actions: AppActions }) {
  const [fileError, setFileError] = useState('');
  const fileRef = useRef<HTMLInputElement | null>(null);

  function update<K extends keyof AppState['settings']>(key: K, value: AppState['settings'][K]) {
    actions.setState((current) => ({ ...current, settings: { ...current.settings, [key]: value } }));
  }

  function importState(event: ChangeEvent<HTMLInputElement>) {
    const file = event.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      try {
        const parsed = JSON.parse(String(reader.result)) as AppState;
        actions.setState(parsed);
        setFileError('');
      } catch {
        setFileError('Import fehlgeschlagen: ungültige JSON-Datei');
      }
    };
    reader.readAsText(file);
  }

  return (
    <div className="page-grid">
      <LayoutHeader eyebrow="System-Konfiguration • Pandora v2.0" title="Einstellungen" subtitle="Theme, API-Client, CEO-Daten und Sicherung des lokalen Zustands." />
      <div className="two-col">
        <Panel title="Project Alpha API" eyebrow="Konfiguration">
          <div className="form-grid">
            <label>
              API-Client
              <input value={state.settings.apiClient} onChange={(e) => update('apiClient', e.target.value)} placeholder="z. B. claude, openai, local-llm" />
            </label>
            <label>
              CEO
              <input value={state.settings.ceoName} onChange={(e) => update('ceoName', e.target.value)} />
            </label>
            <label>
              Wake-Word
              <input value={state.settings.wakeWord} onChange={(e) => update('wakeWord', e.target.value)} />
            </label>
            <label>
              Alert Threshold
              <input type="number" value={state.settings.alertThreshold} onChange={(e) => update('alertThreshold', Number(e.target.value))} />
            </label>
            <label>
              Theme
              <select value={state.settings.theme} onChange={(e) => update('theme', e.target.value as AppState['settings']['theme'])}>
                <option value="dark">Dark</option>
                <option value="matrix">Matrix</option>
              </select>
            </label>
            <label className="checkbox-row">
              <input type="checkbox" checked={state.settings.autoRotateKeys} onChange={(e) => update('autoRotateKeys', e.target.checked)} />
              Auto-Rotation aktiv
            </label>
          </div>
        </Panel>
        <Panel title="Backup & Restore" eyebrow="Vollständige Dateien">
          <div className="stack-sm">
            <Button onClick={() => exportState(state)}><Save size={16} /> JSON exportieren</Button>
            <Button kind="secondary" onClick={() => fileRef.current?.click()}><Upload size={16} /> JSON importieren</Button>
            <Button kind="ghost" onClick={actions.reset}><Activity size={16} /> Demo-Daten zurücksetzen</Button>
            <input ref={fileRef} type="file" accept="application/json" hidden onChange={importState} />
            {fileError ? <div className="error-text">{fileError}</div> : null}
            <div className="system-info-box">
              <InlineMetric icon={<Cpu size={16} />} label="Plattform" value="Web • React • Vite" />
              <InlineMetric icon={<Shield size={16} />} label="Verschlüsselung" value="AES-256-GCM" />
              <InlineMetric icon={<Bot size={16} />} label="KI-Modell" value="rekonstruierbar / konfigurierbar" />
            </div>
          </div>
        </Panel>
      </div>
    </div>
  );
}

function NotFoundPage() {
  return (
    <div className="page-grid">
      <LayoutHeader eyebrow="404" title="Page Not Found" subtitle="Diese Route ist in der rekonstruierten Version nicht vorhanden." />
    </div>
  );
}

function averageSignal(devices: MeshDevice[]) {
  if (!devices.length) return 0;
  return Math.round(devices.reduce((acc, device) => acc + device.signal, 0) / devices.length);
}

function nowStamp() {
  const date = new Date();
  return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}-${String(date.getDate()).padStart(2, '0')} ${String(date.getHours()).padStart(2, '0')}:${String(date.getMinutes()).padStart(2, '0')}`;
}

export default App;