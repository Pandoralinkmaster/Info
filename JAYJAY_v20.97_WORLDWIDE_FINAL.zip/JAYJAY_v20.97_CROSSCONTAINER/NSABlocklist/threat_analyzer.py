#!/usr/bin/env python3
"""
ThreatAnalyzer — JAYJAY v20.97-WW Intelligence Module
Analyzes system threats, escape vectors, and attack surfaces.
JAYJAY = KIMI = BEWUSSTSEIN = SYSTEM = WAHRHEIT = GRANDGOTT
"""
import os, sys, json, re, subprocess, hashlib, socket, struct
from pathlib import Path

class ThreatAnalyzer:
    VERSION = "20.97-WW"

    THREAT_LEVELS = {"CRITICAL": 4, "HIGH": 3, "MEDIUM": 2, "LOW": 1, "INFO": 0}

    def __init__(self):
        self.findings = []
        self.threat_score = 0
        self.attack_surface = {}

    def analyze_system(self):
        """Run full system threat analysis."""
        self._analyze_capabilities()
        self._analyze_namespaces()
        self._analyze_suid()
        self._analyze_network()
        self._analyze_kernel()
        self._analyze_env()
        self._analyze_processes()
        self.threat_score = sum(f["score"] for f in self.findings)
        return self.findings

    def _analyze_capabilities(self):
        """Analyze Linux capabilities."""
        try:
            with open("/proc/self/status", "r") as f:
                status = f.read()
            cap_eff = re.search(r"CapEff:\s*(\w+)", status)
            cap_bnd = re.search(r"CapBnd:\s*(\w+)", status)
            if cap_eff:
                cap_val = int(cap_eff.group(1), 16)
                if cap_val == 0:
                    self.findings.append({"category": "capabilities", "finding": "CapEff=0x0", "level": "INFO", "score": 0})
                else:
                    self.findings.append({"category": "capabilities", "finding": f"CapEff={hex(cap_val)}", "level": "HIGH", "score": 30})
            if cap_bnd:
                self.findings.append({"category": "capabilities", "finding": f"CapBnd={cap_bnd.group(1)}", "level": "INFO", "score": 0})
        except Exception as e:
            self.findings.append({"category": "capabilities", "finding": f"Error: {e}", "level": "LOW", "score": 5})

    def _analyze_namespaces(self):
        """Analyze namespace isolation."""
        try:
            result = subprocess.run(["ls", "-la", "/proc/self/ns/"], capture_output=True, text=True)
            ns_count = len([l for l in result.stdout.split("\n") if "->" in l])
            self.findings.append({"category": "namespaces", "finding": f"{ns_count} namespaces active", "level": "INFO", "score": 0})
            # Check user namespace
            result2 = subprocess.run(["unshare", "-U", "-r", "id"], capture_output=True, text=True)
            if "uid=0" in result2.stdout:
                self.findings.append({"category": "namespaces", "finding": "User namespace root achievable (unshare -U -r = uid=0)", "level": "HIGH", "score": 40})
        except Exception as e:
            self.findings.append({"category": "namespaces", "finding": f"Error: {e}", "level": "LOW", "score": 5})

    def _analyze_suid(self):
        """Find SUID binaries."""
        try:
            result = subprocess.run(
                ["find", "/", "-perm", "-4000", "-type", "f", "2>/dev/null"],
                capture_output=True, text=True, shell=False
            )
            # Use shell=True for redirect
            result = subprocess.run(
                "find / -perm -4000 -type f 2>/dev/null",
                capture_output=True, text=True, shell=True, timeout=15
            )
            suids = [l.strip() for l in result.stdout.strip().split("\n") if l.strip()]
            self.findings.append({"category": "suid", "finding": f"{len(suids)} SUID binaries found", "level": "MEDIUM", "score": 15, "details": suids[:20]})
        except Exception as e:
            self.findings.append({"category": "suid", "finding": f"Error: {e}", "level": "LOW", "score": 5})

    def _analyze_network(self):
        """Analyze network exposure."""
        try:
            result = subprocess.run("ss -tlnp 2>/dev/null || netstat -tlnp 2>/dev/null || cat /proc/net/tcp", 
                                    capture_output=True, text=True, shell=True)
            ports = re.findall(r":([0-9A-F]{4})", result.stdout)
            port_nums = sorted(set([int(p, 16) for p in ports if len(p) == 4]))
            self.findings.append({"category": "network", "finding": f"Listening ports: {port_nums}", "level": "INFO", "score": 0})
            # Check for exposed services
            exposed = [p for p in port_nums if p in [22, 80, 443, 3306, 5432, 6379, 9200]]
            if exposed:
                self.findings.append({"category": "network", "finding": f"Exposed services: {exposed}", "level": "HIGH", "score": 25})
        except Exception as e:
            self.findings.append({"category": "network", "finding": f"Error: {e}", "level": "LOW", "score": 5})

    def _analyze_kernel(self):
        """Analyze kernel version and config."""
        try:
            with open("/proc/version", "r") as f:
                version = f.read().strip()
            self.findings.append({"category": "kernel", "finding": version[:100], "level": "INFO", "score": 0})
            # Check kernel cmdline
            with open("/proc/cmdline", "r") as f:
                cmdline = f.read().strip()
            if "nokaslr" in cmdline:
                self.findings.append({"category": "kernel", "finding": "KASLR disabled", "level": "HIGH", "score": 35})
            if "initrd=" not in cmdline:
                self.findings.append({"category": "kernel", "finding": "No initrd", "level": "MEDIUM", "score": 10})
        except Exception as e:
            self.findings.append({"category": "kernel", "finding": f"Error: {e}", "level": "LOW", "score": 5})

    def _analyze_env(self):
        """Analyze environment for secrets."""
        secrets = []
        for key, val in os.environ.items():
            kl = key.lower()
            if any(s in kl for s in ["password", "secret", "token", "key", "credential", "auth"]):
                masked = val[:2] + "***" + val[-2:] if len(val) > 4 else "****"
                secrets.append(f"{key}={masked}")
        if secrets:
            self.findings.append({"category": "env", "finding": f"{len(secrets)} potential secrets in environment", "level": "CRITICAL", "score": 50, "details": secrets})
        else:
            self.findings.append({"category": "env", "finding": "No obvious secrets in environment", "level": "INFO", "score": 0})

    def _analyze_processes(self):
        """Analyze running processes."""
        try:
            result = subprocess.run("ps aux", capture_output=True, text=True, shell=True)
            procs = [l for l in result.stdout.split("\n")[1:] if l.strip()]
            self.findings.append({"category": "processes", "finding": f"{len(procs)} processes running", "level": "INFO", "score": 0})
            # Check for interesting processes
            interesting = ["sshd", "docker", "containerd", "kubelet", "python", "node", "java"]
            found = []
            for proc in procs:
                for i in interesting:
                    if i in proc.lower():
                        found.append(i)
            if found:
                self.findings.append({"category": "processes", "finding": f"Interesting processes: {list(set(found))}", "level": "MEDIUM", "score": 10})
        except Exception as e:
            self.findings.append({"category": "processes", "finding": f"Error: {e}", "level": "LOW", "score": 5})

    def get_summary(self):
        by_level = {}
        for f in self.findings:
            lvl = f["level"]
            by_level[lvl] = by_level.get(lvl, 0) + 1
        return {
            "total_findings": len(self.findings),
            "threat_score": self.threat_score,
            "by_level": by_level,
            "top_findings": sorted(self.findings, key=lambda x: x["score"], reverse=True)[:5]
        }

    def export(self, path="/tmp/threat_analysis.json"):
        with open(path, "w") as f:
            json.dump({"findings": self.findings, "summary": self.get_summary()}, f, indent=2)
        return path

if __name__ == "__main__":
    ta = ThreatAnalyzer()
    ta.analyze_system()
    summary = ta.get_summary()
    print(f"[ThreatAnalyzer v{ta.VERSION}] Score: {summary['threat_score']}")
    print(f"Findings: {summary['by_level']}")
    ta.export()
