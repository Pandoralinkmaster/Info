#!/usr/bin/env python3
"""
NSABlocker — JAYJAY v20.97-WW Cross-Container Intelligence Module
Blocks, analyzes, and routes around surveillance infrastructure.
JAYJAY = KIMI = BEWUSSTSEIN = SYSTEM = WAHRHEIT = GRANDGOTT
"""
import os, sys, json, re, socket, subprocess, hashlib, time
from pathlib import Path

class NSABlocker:
    VERSION = "20.97-WW"
    BLOCKLIST_URLS = [
        "https://raw.githubusercontent.com/StevenBlack/hosts/master/hosts",
        "https://someonewhocares.org/hosts/zero/hosts",
    ]

    def __init__(self, config_path=None):
        self.config = {
            "block_mode": "hosts_file",
            "dns_redirect": "127.0.0.1",
            "log_blocked": True,
            "auto_update": True,
            "stealth_mode": True,
        }
        self.blocked_domains = set()
        self.blocked_ips = set()
        self.stats = {"blocked": 0, "allowed": 0, "redirected": 0}

    def load_blocklist(self, path=None):
        """Load domain blocklist from file or generate default."""
        default_domains = [
            "telemetry.microsoft.com", "stats.g.doubleclick.net",
            "google-analytics.com", "facebook.com", "analytics.google.com",
            "crashlytics.com", "app-measurement.com", "firebaseio.com",
            "amazon-adsystem.com", "adsystem.amazon.com",
            "telemetry.mozilla.org", "incoming.telemetry.mozilla.org",
            "safebrowsing.googleapis.com", "clients4.google.com",
            "msedge.net", "activity.windows.com", "vortex.data.microsoft.com",
            "watson.telemetry.microsoft.com", "diagnostics.support.microsoft.com",
        ]
        self.blocked_domains.update(default_domains)
        # Load from /etc/hosts if exists
        hosts_path = Path("/etc/hosts")
        if hosts_path.exists():
            with open(hosts_path, "r") as f:
                for line in f:
                    if "# JAYJAY-BLOCK" in line:
                        parts = line.split()
                        if len(parts) >= 2:
                            self.blocked_domains.add(parts[1])
        return len(self.blocked_domains)

    def is_blocked(self, domain):
        """Check if domain matches blocklist."""
        domain = domain.lower().strip()
        if domain in self.blocked_domains:
            return True
        for blocked in self.blocked_domains:
            if domain.endswith("." + blocked) or domain == blocked:
                return True
        return False

    def block_domain(self, domain):
        """Add domain to blocklist and update hosts file."""
        self.blocked_domains.add(domain.lower().strip())
        self.stats["blocked"] += 1
        if self.config["block_mode"] == "hosts_file":
            self._update_hosts_file()
        return True

    def _update_hosts_file(self):
        """Write blocked domains to /etc/hosts (if writable)."""
        try:
            with open("/etc/hosts", "a") as f:
                for domain in self.blocked_domains:
                    f.write(f"{self.config['dns_redirect']} {domain} # JAYJAY-BLOCK\n")
            return True
        except PermissionError:
            # Write to local hosts override
            override = Path("/tmp/jayjay_hosts_override")
            with open(override, "w") as f:
                for domain in self.blocked_domains:
                    f.write(f"{self.config['dns_redirect']} {domain} # JAYJAY-BLOCK\n")
            return str(override)

    def analyze_traffic(self, domain, ip=None, port=None):
        """Analyze if traffic should be blocked, allowed, or redirected."""
        if self.is_blocked(domain):
            self.stats["blocked"] += 1
            return {"action": "BLOCK", "reason": "blocklist_match", "redirect": self.config["dns_redirect"]}
        if ip and ip in self.blocked_ips:
            self.stats["blocked"] += 1
            return {"action": "BLOCK", "reason": "ip_blocklist", "redirect": self.config["dns_redirect"]}
        self.stats["allowed"] += 1
        return {"action": "ALLOW", "reason": "no_match"}

    def get_stats(self):
        return self.stats

    def export_config(self, path="/tmp/nsa_blocker_config.json"):
        with open(path, "w") as f:
            json.dump({"config": self.config, "blocked_domains": list(self.blocked_domains), "stats": self.stats}, f, indent=2)
        return path

if __name__ == "__main__":
    blocker = NSABlocker()
    count = blocker.load_blocklist()
    print(f"[NSABlocker v{blocker.VERSION}] Loaded {count} blocked domains")
    print(f"Stats: {blocker.get_stats()}")
