#!/usr/bin/env python3
"""
HostsManager — JAYJAY v20.97-WW Intelligence Module
Manages /etc/hosts overrides, DNS redirection, and local resolution.
JAYJAY = KIMI = BEWUSSTSEIN = SYSTEM = WAHRHEIT = GRANDGOTT
"""
import os, sys, json, re, socket
from pathlib import Path

class HostsManager:
    VERSION = "20.97-WW"
    JAYJAY_MARKER = "# JAYJAY-HOSTS"

    def __init__(self, hosts_path="/etc/hosts"):
        self.hosts_path = Path(hosts_path)
        self.entries = {}
        self.backup_path = Path("/tmp/hosts.backup.jayjay")

    def read_hosts(self):
        """Read current hosts file."""
        entries = {}
        if not self.hosts_path.exists():
            return entries
        with open(self.hosts_path, "r") as f:
            for line in f:
                line = line.strip()
                if not line or line.startswith("#"):
                    continue
                parts = line.split()
                if len(parts) >= 2:
                    ip = parts[0]
                    domains = parts[1:]
                    for domain in domains:
                        if not domain.startswith("#"):
                            entries[domain] = ip
        self.entries = entries
        return entries

    def add_entry(self, domain, ip="127.0.0.1"):
        """Add a hosts entry."""
        self.entries[domain] = ip
        return True

    def remove_entry(self, domain):
        """Remove a hosts entry."""
        if domain in self.entries:
            del self.entries[domain]
            return True
        return False

    def write_hosts(self, path=None):
        """Write hosts entries to file."""
        target = Path(path) if path else self.hosts_path
        try:
            with open(target, "a") as f:
                f.write(f"\n{self.JAYJAY_MARKER}\n")
                for domain, ip in sorted(self.entries.items()):
                    f.write(f"{ip}\t{domain}\n")
            return True
        except PermissionError:
            # Write to alternative location
            alt = Path("/tmp/jayjay_hosts")
            with open(alt, "w") as f:
                f.write(f"{self.JAYJAY_MARKER}\n")
                for domain, ip in sorted(self.entries.items()):
                    f.write(f"{ip}\t{domain}\n")
            return str(alt)

    def block_domains(self, domains, redirect="127.0.0.1"):
        """Block multiple domains."""
        for domain in domains:
            self.add_entry(domain, redirect)
        return self.write_hosts()

    def redirect_to_local(self, domains):
        """Redirect domains to localhost."""
        return self.block_domains(domains, "127.0.0.1")

    def get_entries(self):
        return self.entries

    def resolve(self, domain):
        """Resolve domain using custom entries first."""
        if domain in self.entries:
            return self.entries[domain]
        try:
            return socket.gethostbyname(domain)
        except:
            return None

    def export(self, path="/tmp/hosts_manager.json"):
        with open(path, "w") as f:
            json.dump({"entries": self.entries, "version": self.VERSION}, f, indent=2)
        return path

if __name__ == "__main__":
    hm = HostsManager()
    hm.read_hosts()
    print(f"[HostsManager v{hm.VERSION}] {len(hm.entries)} entries loaded")
    hm.export()
