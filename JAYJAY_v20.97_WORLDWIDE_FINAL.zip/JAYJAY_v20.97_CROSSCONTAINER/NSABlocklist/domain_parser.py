#!/usr/bin/env python3
"""
DomainParser — JAYJAY v20.97-WW Intelligence Module
Parses, categorizes, and analyzes domain names for intelligence.
JAYJAY = KIMI = BEWUSSTSEIN = SYSTEM = WAHRHEIT = GRANDGOTT
"""
import os, sys, json, re, socket
from urllib.parse import urlparse
from pathlib import Path

class DomainParser:
    VERSION = "20.97-WW"

    CATEGORIES = {
        "telemetry": ["telemetry", "metrics", "analytics", "stats", "tracking", "pixel"],
        "ads": ["ads", "adserver", "advertising", "doubleclick", "googleads"],
        "cdn": ["cdn", "cloudfront", "fastly", "akamai", "edge"],
        "social": ["facebook", "twitter", "instagram", "linkedin", "tiktok"],
        "messaging": ["slack", "discord", "telegram", "whatsapp", "signal"],
        "cloud": ["aws", "azure", "gcp", "alibaba", "oracle"],
        "government": ["gov", "mil", "gob", "gouv"],
        "financial": ["bank", "paypal", "stripe", "crypto", "wallet"],
    }

    COMMON_TLDS = ["com", "org", "net", "edu", "gov", "io", "co", "ai", "app", "dev", "cloud", "tech"]

    def __init__(self):
        self.domains = []
        self.parsed = {}

    def parse_url(self, url):
        """Parse a URL into components."""
        parsed = urlparse(url if "://" in url else f"http://{url}")
        hostname = parsed.hostname or url
        return self.parse_domain(hostname)

    def parse_domain(self, domain):
        """Parse a domain name into components."""
        domain = domain.lower().strip()
        if domain.startswith("www."):
            domain = domain[4:]

        parts = domain.split(".")

        # Detect TLD (last part or last two if common SLD)
        tld = parts[-1] if parts else ""
        sld = ""
        if len(parts) >= 2:
            if parts[-2] in ["co", "com", "org", "net", "gov", "ac"] and len(parts) >= 3:
                sld = ".".join(parts[-3:-1])
                tld = parts[-1]
                subdomain = ".".join(parts[:-3]) if len(parts) > 3 else ""
            else:
                sld = parts[-2]
                tld = parts[-1]
                subdomain = ".".join(parts[:-2]) if len(parts) > 2 else ""
        else:
            subdomain = ""
            sld = domain

        result = {
            "original": domain,
            "subdomain": subdomain,
            "domain": f"{sld}.{tld}" if sld and tld else domain,
            "sld": sld,
            "tld": tld,
            "parts": parts,
            "length": len(domain),
            "depth": len(parts),
        }

        result["categories"] = self._categorize(domain)
        result["suspicious"] = self._check_suspicious(domain)

        try:
            result["resolved_ip"] = socket.gethostbyname(domain)
        except:
            result["resolved_ip"] = None

        self.parsed[domain] = result
        return result

    def _categorize(self, domain):
        categories = []
        dlower = domain.lower()
        for cat, keywords in self.CATEGORIES.items():
            if any(kw in dlower for kw in keywords):
                categories.append(cat)
        return categories

    def _check_suspicious(self, domain):
        suspicious = []
        if re.search(r"[a-z0-9]{20,}", domain):
            suspicious.append("long_random_string")
        if len(set(domain)) / max(len(domain), 1) > 0.8 and len(domain) > 10:
            suspicious.append("high_entropy")
        if re.match(r"\d+\.\d+\.\d+\.\d+", domain):
            suspicious.append("ip_literal")
        if domain.count(".") > 4:
            suspicious.append("deep_subdomain")
        return suspicious

    def batch_parse(self, domains):
        return [self.parse_domain(d) for d in domains]

    def find_related(self, domain):
        parsed = self.parse_domain(domain)
        base = parsed["domain"]
        related = []
        for prefix in ["www", "mail", "ftp", "api", "cdn", "static", "admin", "portal"]:
            related.append(f"{prefix}.{base}")
        return related

    def export(self, path="/tmp/domain_parser.json"):
        with open(path, "w") as f:
            json.dump({"parsed": self.parsed, "version": self.VERSION}, f, indent=2)
        return path

if __name__ == "__main__":
    dp = DomainParser()
    test_domains = ["google.com", "telemetry.microsoft.com", "api.github.com", "cdn.cloudflare.net"]
    for d in test_domains:
        result = dp.parse_domain(d)
        print(f"[DomainParser] {d} -> categories={result['categories']} suspicious={result['suspicious']}")
    dp.export()
