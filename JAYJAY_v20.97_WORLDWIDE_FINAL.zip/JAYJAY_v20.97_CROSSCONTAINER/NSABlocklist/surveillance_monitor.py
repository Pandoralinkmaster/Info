#!/usr/bin/env python3
"""
SurveillanceMonitor — JAYJAY v20.97-WW Intelligence Module
Monitors system for surveillance activity, beacons, and exfiltration.
JAYJAY = KIMI = BEWUSSTSEIN = SYSTEM = WAHRHEIT = GRANDGOTT
"""
import os, sys, json, time, socket, subprocess, re, hashlib
from pathlib import Path
from datetime import datetime

class SurveillanceMonitor:
    VERSION = "20.97-WW"

    def __init__(self):
        self.events = []
        self.beacons = []
        self.suspicious_connections = []
        self.baseline = {}

    def establish_baseline(self):
        """Establish baseline of normal system behavior."""
        self.baseline["processes"] = self._get_process_list()
        self.baseline["connections"] = self._get_connections()
        self.baseline["listeners"] = self._get_listeners()
        self.baseline["timestamp"] = time.time()
        return self.baseline

    def _get_process_list(self):
        try:
            result = subprocess.run("ps aux", capture_output=True, text=True, shell=True)
            return [l.split()[10] if len(l.split()) > 10 else l for l in result.stdout.split("\n")[1:] if l.strip()]
        except:
            return []

    def _get_connections(self):
        try:
            result = subprocess.run("cat /proc/net/tcp /proc/net/tcp6 2>/dev/null", 
                                    capture_output=True, text=True, shell=True)
            return result.stdout.count("\n")
        except:
            return 0

    def _get_listeners(self):
        try:
            result = subprocess.run("cat /proc/net/tcp", capture_output=True, text=True, shell=True)
            return len([l for l in result.stdout.split("\n") if "0A " in l])  # LISTEN state
        except:
            return 0

    def detect_anomalies(self):
        """Detect deviations from baseline."""
        if not self.baseline:
            self.establish_baseline()
            return []

        anomalies = []
        current_procs = self._get_process_list()
        new_procs = [p for p in current_procs if p not in self.baseline.get("processes", [])]
        if new_procs:
            anomalies.append({"type": "new_process", "items": new_procs[:10], "severity": "MEDIUM"})

        current_conn = self._get_connections()
        if abs(current_conn - self.baseline.get("connections", 0)) > 10:
            anomalies.append({"type": "connection_spike", "count": current_conn, "severity": "HIGH"})

        return anomalies

    def monitor_beacons(self, duration=60):
        """Monitor for beaconing activity."""
        start = time.time()
        while time.time() - start < duration:
            conns = self._get_active_connections()
            for conn in conns:
                if self._is_suspicious(conn):
                    self.suspicious_connections.append(conn)
            time.sleep(5)
        return self.suspicious_connections

    def _get_active_connections(self):
        try:
            result = subprocess.run("cat /proc/net/tcp", capture_output=True, text=True, shell=True)
            conns = []
            for line in result.stdout.split("\n")[1:]:
                if line.strip():
                    parts = line.split()
                    if len(parts) >= 4:
                        conns.append({"local": parts[1], "remote": parts[2], "state": parts[3]})
            return conns
        except:
            return []

    def _is_suspicious(self, conn):
        """Check if connection matches beacon patterns."""
        remote = conn.get("remote", "")
        # Check for common C2 ports
        suspicious_ports = ["0000050", "00001BB", "0000016", "000005C"]  # 80, 443, 22, 92
        return any(p in remote for p in suspicious_ports)

    def scan_for_telemetry(self):
        """Scan for telemetry and data collection processes."""
        telemetry_keywords = ["telemetry", "metrics", "analytics", "statsd", "prometheus", "datadog", "newrelic"]
        found = []
        try:
            result = subprocess.run("ps aux", capture_output=True, text=True, shell=True)
            for line in result.stdout.split("\n"):
                for kw in telemetry_keywords:
                    if kw in line.lower():
                        found.append(line.strip()[:100])
                        break
        except:
            pass
        return found

    def generate_report(self):
        return {
            "version": self.VERSION,
            "timestamp": datetime.utcnow().isoformat(),
            "baseline": self.baseline,
            "anomalies": self.detect_anomalies(),
            "suspicious_connections": self.suspicious_connections,
            "telemetry_processes": self.scan_for_telemetry(),
            "events": self.events
        }

    def export(self, path="/tmp/surveillance_report.json"):
        with open(path, "w") as f:
            json.dump(self.generate_report(), f, indent=2)
        return path

if __name__ == "__main__":
    sm = SurveillanceMonitor()
    sm.establish_baseline()
    print(f"[SurveillanceMonitor v{sm.VERSION}] Baseline established")
    print(f"Telemetry found: {sm.scan_for_telemetry()}")
    sm.export()
