#!/usr/bin/env python3
"""
Shadowbroker API Client — Cross-Container OSINT Interface
=========================================================
"""

import json, urllib.request, urllib.parse
from datetime import datetime, timezone

class ShadowbrokerClient:
    def __init__(self, base_url="http://localhost:8000"):
        self.base_url = base_url.rstrip("/")
        self.headers = {"User-Agent": "JAYJAY-OSINT/20.97", "Accept": "application/json"}

    def _request(self, method, path, data=None):
        url = f"{self.base_url}{path}"
        req = urllib.request.Request(url, method=method, headers=self.headers)
        if data:
            req.data = json.dumps(data).encode("utf-8")
            req.add_header("Content-Type", "application/json")
        try:
            with urllib.request.urlopen(req, timeout=15) as resp:
                return {"status": resp.status, "data": json.loads(resp.read().decode("utf-8"))}
        except Exception as e:
            return {"status": 0, "error": str(e)}

    def refresh(self):
        return self._request("GET", "/api/refresh")

    def get_ais_feed(self, bbox=None):
        return self._request("POST", "/api/ais/feed", {"bbox": bbox} if bbox else {})

    def get_viewport(self, coords):
        return self._request("POST", "/api/viewport", coords)

    def get_layers(self):
        return self._request("POST", "/api/layers", {})

    def get_region_intel(self, region):
        return self._request("GET", f"/api/oracle/region-intel?region={urllib.parse.quote(region)}")

    def mesh_send(self, message, channel="default"):
        return self._request("POST", "/api/mesh/send", {"message": message, "channel": channel})

    def mesh_status(self):
        return self._request("GET", "/api/mesh/status")

    def mesh_signals(self):
        return self._request("GET", "/api/mesh/signals")

    def thermal_verify(self, signature):
        return self._request("GET", f"/api/thermal/verify?sig={urllib.parse.quote(signature)}")

    def sigint_transmit(self, frequency, data):
        return self._request("POST", "/api/sigint/transmit", {"frequency": frequency, "data": data})

    def sigint_nearest_sdr(self, lat, lon):
        return self._request("GET", f"/api/sigint/nearest-sdr?lat={lat}&lon={lon}")

if __name__ == "__main__":
    client = ShadowbrokerClient()
    print("Shadowbroker API Client v20.97")
    print("Example: client.mesh_status()")
