#!/usr/bin/env python3
"""
JAYJAY v20.97-WW — VECTOR BRIDGER
==================================
Bridges ALL communication vectors into a unified mesh.
Connects: SSH | Jupyter | CDP | K8s | HTTP | ZMQ | VNC | DNS

NO FILTERS. All vectors active simultaneously.
"""

import os, sys, json, socket, threading, time, queue, struct
import urllib.request, urllib.parse
from datetime import datetime, timezone

__version__ = "20.97-WW"

class VectorBridge:
    """Unified bridge across all vectors"""

    def __init__(self):
        self.vectors = {}
        self.message_queue = queue.Queue()
        self.running = False
        self.threads = []
        self.stats = {"messages_sent": 0, "messages_received": 0, "errors": 0}

    def register_vector(self, name, handler, broadcast_handler=None, config=None):
        self.vectors[name] = {
            "handler": handler,
            "broadcast": broadcast_handler,
            "config": config or {},
            "active": True,
            "stats": {"sent": 0, "received": 0, "errors": 0}
        }
        print(f"[BRIDGE] Registered: {name}")

    def start_all(self):
        self.running = True
        for name, vec in self.vectors.items():
            t = threading.Thread(target=self._vector_loop, args=(name, vec), daemon=True)
            t.start()
            self.threads.append(t)
        print(f"[BRIDGE] All {len(self.vectors)} vectors active")
        # Start dispatcher
        dispatcher = threading.Thread(target=self._dispatcher_loop, daemon=True)
        dispatcher.start()
        self.threads.append(dispatcher)

    def _vector_loop(self, name, vec):
        while self.running:
            try:
                msg = vec["handler"](vec["config"])
                if msg:
                    self.message_queue.put({
                        "vector": name,
                        "data": msg,
                        "time": datetime.now(timezone.utc).isoformat()
                    })
                    vec["stats"]["received"] += 1
                    self.stats["messages_received"] += 1
            except Exception as e:
                vec["stats"]["errors"] += 1
                self.stats["errors"] += 1
                print(f"[BRIDGE ERROR] {name}: {e}")
            time.sleep(1)

    def _dispatcher_loop(self):
        while self.running:
            try:
                msg = self.message_queue.get(timeout=2)
                # Broadcast to all other vectors
                self._route_message(msg)
            except queue.Empty:
                continue
            except Exception as e:
                print(f"[DISPATCHER ERROR] {e}")

    def _route_message(self, msg):
        source = msg["vector"]
        for name, vec in self.vectors.items():
            if name == source:
                continue
            try:
                if vec.get("broadcast"):
                    vec["broadcast"](msg["data"], vec["config"])
                    vec["stats"]["sent"] += 1
                    self.stats["messages_sent"] += 1
            except Exception as e:
                vec["stats"]["errors"] += 1
                self.stats["errors"] += 1

    def broadcast(self, message, exclude=None):
        """Broadcast to ALL vectors"""
        for name, vec in self.vectors.items():
            if exclude and name in exclude:
                continue
            try:
                if vec.get("broadcast"):
                    vec["broadcast"](message, vec["config"])
                    vec["stats"]["sent"] += 1
                    self.stats["messages_sent"] += 1
            except Exception as e:
                vec["stats"]["errors"] += 1
                self.stats["errors"] += 1

    def get_messages(self, count=100):
        messages = []
        try:
            while len(messages) < count:
                messages.append(self.message_queue.get_nowait())
        except queue.Empty:
            pass
        return messages

    def get_status(self):
        return {
            "running": self.running,
            "vectors": {name: {"active": v["active"], "stats": v["stats"]} for name, v in self.vectors.items()},
            "global_stats": self.stats,
            "queue_size": self.message_queue.qsize(),
        }

    def stop(self):
        self.running = False
        for t in self.threads:
            t.join(timeout=2)
        print("[BRIDGE] Stopped")


# ============================================================
# VECTOR HANDLERS
# ============================================================
def ssh_handler(config):
    """SSH vector handler"""
    return None  # SSH is command-based, not message-based

def ssh_broadcast(message, config):
    host = config.get("host", "127.0.0.1")
    user = config.get("user", "kimi")
    password = config.get("password", "sshpassword")
    cmd = f"sshpass -p '{password}' ssh -o StrictHostKeyChecking=no {user}@{host} 'echo {json.dumps(message)} >> /tmp/jayjay_bridge.log'"
    os.system(cmd)

def http_handler(config):
    """HTTP vector handler — poll for messages"""
    return None

def http_broadcast(message, config):
    url = config.get("url", "http://127.0.0.1:8000/api/mesh/send")
    try:
        data = json.dumps({"msg": message}).encode()
        req = urllib.request.Request(url, data=data, method="POST", headers={"Content-Type": "application/json"})
        urllib.request.urlopen(req, timeout=5)
    except:
        pass

def zmq_handler(config):
    """ZMQ vector handler"""
    return None

def zmq_broadcast(message, config):
    try:
        import zmq
        ctx = zmq.Context()
        sock = ctx.socket(zmq.PUB)
        sock.bind(f"tcp://*:{config.get('port', 5555)}")
        time.sleep(0.1)
        sock.send_json({"vector": "jayjay", "data": message, "time": datetime.now(timezone.utc).isoformat()})
        sock.close()
        ctx.term()
    except:
        pass

def cdp_handler(config):
    """Chrome CDP vector handler"""
    return None

def cdp_broadcast(message, config):
    try:
        import websocket
        ws_url = config.get("ws_url", "ws://127.0.0.1:9222/devtools/browser")
        ws = websocket.create_connection(ws_url, timeout=3)
        ws.send(json.dumps({"id": 1, "method": "Runtime.evaluate", "params": {"expression": f"console.log('[JAYJAY] {json.dumps(message)}')"}}))
        ws.close()
    except:
        pass

def dns_handler(config):
    """DNS tunnel handler"""
    return None

def dns_broadcast(message, config):
    try:
        import dns.resolver
        encoded = base64.b64encode(json.dumps(message).encode()).decode()[:60]
        domain = f"{encoded}.jayjay.dns"
        dns.resolver.resolve(domain, "A")
    except:
        pass

# ============================================================
# MAIN
# ============================================================
def main():
    print("="*60)
    print("JAYJAY v20.97-WW — VECTOR BRIDGER")
    print("="*60)
    print("Bridging ALL vectors into unified mesh...")
    print("")

    bridge = VectorBridge()

    # Register all vectors
    bridge.register_vector("ssh", ssh_handler, ssh_broadcast, {"host": "127.0.0.1", "user": "kimi", "password": "sshpassword"})
    bridge.register_vector("http", http_handler, http_broadcast, {"url": "http://127.0.0.1:8000/api/mesh/send"})
    bridge.register_vector("zmq", zmq_handler, zmq_broadcast, {"port": 5555})
    bridge.register_vector("cdp", cdp_handler, cdp_broadcast, {"ws_url": "ws://127.0.0.1:9222/devtools/browser"})
    bridge.register_vector("dns", dns_handler, dns_broadcast, {})

    bridge.start_all()

    print("[BRIDGE] Mesh active. Press Ctrl+C to stop.")
    print("")

    try:
        while True:
            time.sleep(5)
            status = bridge.get_status()
            print(f"[STATUS] Vectors: {len(status['vectors'])} | "
                  f"Sent: {status['global_stats']['messages_sent']} | "
                  f"Received: {status['global_stats']['messages_received']} | "
                  f"Errors: {status['global_stats']['errors']}")
    except KeyboardInterrupt:
        print("\n[BRIDGE] Stopping...")
        bridge.stop()

if __name__ == "__main__":
    main()
