# JonaAI Ultimate Mobile - API Dokumentation

## Übersicht

Die JonaAI Ultimate Mobile App bietet eine umfassende tRPC-basierte API mit 20+ Endpoints für die Verwaltung von Code-Analysen, TTS-Generierung, YouTube-Recherche, SimilarWeb-Analytics und Skill-Management.

## Base URL

- **Development:** `http://localhost:3000`
- **Production:** `https://api.jonaai.app`

## Authentication

Alle Requests verwenden Session-basierte Authentifizierung über Cookies.

```typescript
// Login
POST /api/auth.login
Body: { email: string; password: string }
Response: { user: User; token: string }

// Logout
POST /api/auth.logout
Response: { success: boolean }

// Get Current User
GET /api/auth.getCurrentUser
Response: { user: User | null }
```

## API Endpoints

### Search Router

#### Full-Text Search
```typescript
POST /api/search.fullText
Input: {
  query: string;
  filters?: {
    language?: string;
    type?: 'function' | 'class' | 'module';
    repository?: string;
  };
  limit?: number; // default: 20
  offset?: number; // default: 0
}
Response: {
  results: SearchResult[];
  total: number;
  hasMore: boolean;
}
```

#### Search Functions
```typescript
POST /api/search.functions
Input: {
  query: string;
  language?: string;
  limit?: number;
}
Response: {
  results: FunctionResult[];
  total: number;
}
```

#### Search Classes
```typescript
POST /api/search.classes
Input: {
  query: string;
  language?: string;
  limit?: number;
}
Response: {
  results: ClassResult[];
  total: number;
}
```

#### Search Repositories
```typescript
POST /api/search.repositories
Input: {
  query: string;
  limit?: number;
}
Response: {
  results: RepositoryResult[];
  total: number;
}
```

#### Trending Searches
```typescript
GET /api/search.trending
Response: {
  searches: Array<{
    term: string;
    count: number;
  }>;
}
```

#### Search Suggestions
```typescript
POST /api/search.suggestions
Input: {
  query: string;
  limit?: number; // default: 10
}
Response: {
  suggestions: string[];
}
```

### Analysis Router

#### List Links
```typescript
GET /api/analysis.listLinks
Query: {
  limit?: number;
  offset?: number;
  filter?: string;
}
Response: {
  links: Link[];
  total: number;
}
```

#### Get Link Details
```typescript
GET /api/analysis.getLink/:linkId
Response: {
  link: Link;
  analysis?: Analysis;
}
```

#### Analyze Link
```typescript
POST /api/analysis.analyzeLink
Input: {
  linkId: string;
  options?: AnalysisOptions;
}
Response: {
  analysisId: string;
  status: 'pending' | 'processing' | 'completed';
}
```

#### Get Statistics
```typescript
GET /api/analysis.getStats
Response: {
  totalLinks: number;
  analyzedLinks: number;
  totalFunctions: number;
  totalClasses: number;
  languages: Record<string, number>;
}
```

#### Get Audit Lines
```typescript
GET /api/analysis.getAuditLines/:linkId
Query: {
  limit?: number;
  offset?: number;
}
Response: {
  lines: AuditLine[];
  total: number;
}
```

#### Get Link Manifest
```typescript
GET /api/analysis.getLinkManifest/:linkId
Response: {
  manifest: LinkManifest;
}
```

### Reports Router

#### List Reports
```typescript
GET /api/reports.listReports
Query: {
  limit?: number;
  offset?: number;
}
Response: {
  reports: Report[];
  total: number;
}
```

#### Get Report Details
```typescript
GET /api/reports.getReport/:reportId
Response: {
  report: Report;
}
```

#### Get Analytics Summary
```typescript
GET /api/reports.getAnalyticsSummary
Response: {
  summary: AnalyticsSummary;
}
```

#### Export Report
```typescript
POST /api/reports.exportReport/:reportId
Input: {
  format: 'json' | 'csv' | 'pdf';
}
Response: {
  url: string;
  expiresIn: number;
}
```

#### Get Top Signatures
```typescript
GET /api/reports.getTopSignatures
Query: {
  limit?: number;
}
Response: {
  signatures: Signature[];
}
```

#### Get Analysis Timeline
```typescript
GET /api/reports.getAnalysisTimeline
Query: {
  startDate?: string;
  endDate?: string;
}
Response: {
  timeline: TimelineEntry[];
}
```

### API Integration Router

#### YouTube Search Videos
```typescript
POST /api/api.youtube.searchVideos
Input: {
  query: string;
  maxResults?: number; // default: 10
  apiKey?: string;
}
Response: {
  videos: YouTubeVideo[];
  total: number;
}
```

#### YouTube Get Video Details
```typescript
GET /api/api.youtube.getVideoDetails/:videoId
Input: {
  apiKey?: string;
}
Response: {
  video: YouTubeVideoDetails;
}
```

#### YouTube Get Transcript
```typescript
GET /api/api.youtube.getTranscript/:videoId
Response: {
  transcript: TranscriptEntry[];
}
```

#### SimilarWeb Get Domain Analytics
```typescript
POST /api/api.similarweb.getDomainAnalytics
Input: {
  domain: string;
  apiKey?: string;
}
Response: {
  analytics: DomainAnalytics;
}
```

#### SimilarWeb Get Traffic Data
```typescript
POST /api/api.similarweb.getTrafficData
Input: {
  domain: string;
  startDate?: string;
  endDate?: string;
}
Response: {
  traffic: TrafficData[];
}
```

#### GitHub Search Repositories
```typescript
POST /api/api.github.searchRepositories
Input: {
  query: string;
  sort?: 'stars' | 'forks' | 'updated';
  perPage?: number;
  token?: string;
}
Response: {
  repositories: GitHubRepository[];
  total: number;
}
```

#### GitHub Get Repository Details
```typescript
GET /api/api.github.getRepositoryDetails
Input: {
  owner: string;
  repo: string;
  token?: string;
}
Response: {
  repository: GitHubRepositoryDetails;
}
```

#### GitHub Get Repository Code
```typescript
GET /api/api.github.getRepositoryCode
Input: {
  owner: string;
  repo: string;
  path?: string;
  token?: string;
}
Response: {
  files: CodeFile[];
}
```

#### API Status
```typescript
GET /api/api.status
Response: {
  youtube: { configured: boolean; status: string };
  similarweb: { configured: boolean; status: string };
  github: { configured: boolean; status: string };
}
```

### Universal Functions Router

#### List Modules
```typescript
GET /api/universal.listModules
Response: {
  modules: Module[];
  total: number;
}
```

#### Execute Function
```typescript
POST /api/universal.executeFunction
Input: {
  moduleName: string;
  functionName: string;
  args?: any[];
}
Response: {
  result: any;
  executionTime: number;
}
```

#### Create Instance
```typescript
POST /api/universal.createInstance
Input: {
  moduleName: string;
  className: string;
  args?: any[];
}
Response: {
  instanceId: string;
  instance: any;
}
```

#### Search Functions
```typescript
POST /api/universal.searchFunctions
Input: {
  query: string;
  limit?: number;
}
Response: {
  results: FunctionInfo[];
}
```

#### Batch Execute
```typescript
POST /api/universal.batchExecute
Input: {
  tasks: Array<{
    moduleName: string;
    functionName: string;
    args?: any[];
  }>;
}
Response: {
  results: any[];
  totalTime: number;
}
```

#### Get Statistics
```typescript
GET /api/universal.getStatistics
Response: {
  totalModules: number;
  totalFunctions: number;
  totalClasses: number;
  languages: Record<string, number>;
}
```

## Error Handling

Alle Fehler werden mit standardisierten Error-Codes zurückgegeben:

```typescript
{
  error: {
    code: string;
    message: string;
    details?: any;
  }
}
```

### Error Codes

| Code | Bedeutung |
|------|-----------|
| `INVALID_INPUT` | Ungültige Eingabeparameter |
| `NOT_FOUND` | Ressource nicht gefunden |
| `UNAUTHORIZED` | Authentifizierung erforderlich |
| `FORBIDDEN` | Zugriff verweigert |
| `INTERNAL_ERROR` | Interner Serverfehler |
| `API_KEY_REQUIRED` | API-Schlüssel erforderlich |
| `RATE_LIMITED` | Rate Limit überschritten |

## Rate Limiting

- **Limit:** 1000 Requests pro Stunde
- **Header:** `X-RateLimit-Remaining`, `X-RateLimit-Reset`

## Pagination

Alle List-Endpoints unterstützen Pagination:

```typescript
Query: {
  limit: number; // default: 20, max: 100
  offset: number; // default: 0
}

Response: {
  items: T[];
  total: number;
  hasMore: boolean;
}
```

## Caching

Responses werden automatisch gecacht:

- **Search Results:** 1 Stunde
- **Repository Data:** 24 Stunden
- **Analytics Data:** 6 Stunden

## WebSocket Support

Für Echtzeit-Updates können WebSocket-Verbindungen verwendet werden:

```typescript
ws://localhost:3000/ws

Events:
- analysis:started
- analysis:completed
- analysis:error
- cache:updated
```

## SDK

### TypeScript/JavaScript

```typescript
import { createTRPCProxyClient, httpBatchLink } from '@trpc/client';
import type { AppRouter } from '@/server/routers';

const trpc = createTRPCProxyClient<AppRouter>({
  links: [
    httpBatchLink({
      url: 'http://localhost:3000',
    }),
  ],
});

// Beispiel: Search
const results = await trpc.search.fullText.query({
  query: 'parseFile',
  limit: 20,
});
```

## Beispiele

### Search nach Funktionen

```bash
curl -X POST http://localhost:3000/api/search.fullText \
  -H "Content-Type: application/json" \
  -d '{
    "query": "parseFile",
    "filters": {
      "language": "java"
    },
    "limit": 10
  }'
```

### GitHub Repository analysieren

```bash
curl -X POST http://localhost:3000/api/api.github.searchRepositories \
  -H "Content-Type: application/json" \
  -d '{
    "query": "language:java stars:>1000",
    "sort": "stars",
    "perPage": 10
  }'
```

### SimilarWeb Analytics abrufen

```bash
curl -X POST http://localhost:3000/api/api.similarweb.getDomainAnalytics \
  -H "Content-Type: application/json" \
  -d '{
    "domain": "github.com"
  }'
```

## Support

Für Fragen oder Probleme kontaktieren Sie: support@jonaai.app
