import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Lese data-links.json
const linksPath = path.join(__dirname, 'data-links.json');
const linksData = JSON.parse(fs.readFileSync(linksPath, 'utf-8'));

// Importiere Datenbank-Funktionen
import { getDb } from './server/db.js';
import { links } from './drizzle/schema.js';

async function seedLinks() {
  try {
    const db = await getDb();
    if (!db) {
      console.error('Database unavailable');
      process.exit(1);
    }

    console.log(`Importing ${linksData.length} links...`);

    for (const item of linksData) {
      const occurrences = item.occurrences?.length || 1;
      
      await db.insert(links).values({
        url: item.url,
        host: item.host || '',
        path: item.path || '',
        kind: item.kind || 'unknown',
        sha256: item.sha256 || '',
        occurrences: occurrences,
      }).onDuplicateKeyUpdate({
        set: { occurrences: occurrences }
      });
    }

    console.log(`✓ Successfully imported ${linksData.length} links`);
    process.exit(0);
  } catch (error) {
    console.error('Error seeding links:', error);
    process.exit(1);
  }
}

seedLinks();
