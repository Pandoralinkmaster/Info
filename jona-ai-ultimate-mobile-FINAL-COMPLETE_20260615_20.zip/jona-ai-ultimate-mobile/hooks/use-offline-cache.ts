import { useEffect, useState } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';

interface CacheEntry<T> {
  data: T;
  timestamp: number;
  ttl?: number; // Time to live in milliseconds
}

/**
 * Hook für Offline-Caching mit AsyncStorage
 * Speichert API-Responses lokal und stellt sie offline zur Verfügung
 */
export function useOfflineCache<T>(
  key: string,
  fetchFn: () => Promise<T>,
  options?: {
    ttl?: number; // Default: 1 Stunde
    forceRefresh?: boolean;
  }
) {
  const [data, setData] = useState<T | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<Error | null>(null);
  const [isOffline, setIsOffline] = useState(false);

  const defaultTTL = 60 * 60 * 1000; // 1 Stunde
  const ttl = options?.ttl || defaultTTL;

  useEffect(() => {
    const loadData = async () => {
      try {
        setLoading(true);
        setError(null);

        // Versuche, frische Daten zu fetchen
        if (!options?.forceRefresh) {
          const cached = await AsyncStorage.getItem(`cache_${key}`);
          if (cached) {
            const entry: CacheEntry<T> = JSON.parse(cached);
            const now = Date.now();
            
            // Prüfe, ob Cache noch gültig ist
            if (!entry.ttl || now - entry.timestamp < entry.ttl) {
              setData(entry.data);
              setIsOffline(false);
              setLoading(false);
              return;
            }
          }
        }

        // Fetche neue Daten
        try {
          const freshData = await fetchFn();
          
          // Speichere im Cache
          const cacheEntry: CacheEntry<T> = {
            data: freshData,
            timestamp: Date.now(),
            ttl
          };
          
          await AsyncStorage.setItem(
            `cache_${key}`,
            JSON.stringify(cacheEntry)
          );
          
          setData(freshData);
          setIsOffline(false);
        } catch (fetchError) {
          // Wenn Fetch fehlschlägt, versuche Cache zu laden
          const cached = await AsyncStorage.getItem(`cache_${key}`);
          if (cached) {
            const entry: CacheEntry<T> = JSON.parse(cached);
            setData(entry.data);
            setIsOffline(true);
          } else {
            throw fetchError;
          }
        }
      } catch (err) {
        setError(err instanceof Error ? err : new Error('Unknown error'));
        setData(null);
      } finally {
        setLoading(false);
      }
    };

    loadData();
  }, [key, options?.forceRefresh]);

  const clearCache = async () => {
    try {
      await AsyncStorage.removeItem(`cache_${key}`);
      setData(null);
    } catch (err) {
      console.error('Error clearing cache:', err);
    }
  };

  const refresh = async () => {
    setLoading(true);
    try {
      const freshData = await fetchFn();
      
      const cacheEntry: CacheEntry<T> = {
        data: freshData,
        timestamp: Date.now(),
        ttl
      };
      
      await AsyncStorage.setItem(
        `cache_${key}`,
        JSON.stringify(cacheEntry)
      );
      
      setData(freshData);
      setIsOffline(false);
      setError(null);
    } catch (err) {
      setError(err instanceof Error ? err : new Error('Refresh failed'));
    } finally {
      setLoading(false);
    }
  };

  return {
    data,
    loading,
    error,
    isOffline,
    clearCache,
    refresh
  };
}

/**
 * Batch-Cache für mehrere Einträge
 */
export async function batchCacheGet<T>(keys: string[]): Promise<Map<string, T>> {
  const results = new Map<string, T>();
  
  try {
    const values = await AsyncStorage.multiGet(keys.map(k => `cache_${k}`));
    
    for (const [key, value] of values) {
      if (value) {
        const entry: CacheEntry<T> = JSON.parse(value);
        const cacheKey = key.replace('cache_', '');
        results.set(cacheKey, entry.data);
      }
    }
  } catch (error) {
    console.error('Batch cache get error:', error);
  }
  
  return results;
}

/**
 * Batch-Cache für mehrere Einträge speichern
 */
export async function batchCacheSet<T>(
  entries: Map<string, T>,
  ttl?: number
): Promise<void> {
  try {
    const items = Array.from(entries.entries()).map(([key, data]) => {
      const cacheEntry: CacheEntry<T> = {
        data,
        timestamp: Date.now(),
        ttl
      };
      return [`cache_${key}`, JSON.stringify(cacheEntry)];
    });
    
    await AsyncStorage.multiSet(items as any);
  } catch (error) {
    console.error('Batch cache set error:', error);
  }
}

/**
 * Cache-Statistiken
 */
export async function getCacheStats(): Promise<{
  totalSize: number;
  itemCount: number;
  items: Array<{ key: string; size: number; timestamp: number }>;
}> {
  try {
    const allKeys = await AsyncStorage.getAllKeys();
    const cacheKeys = allKeys.filter(k => k.startsWith('cache_'));
    
    const values = await AsyncStorage.multiGet(cacheKeys);
    let totalSize = 0;
    const items: Array<{ key: string; size: number; timestamp: number }> = [];
    
    for (const [key, value] of values) {
      if (value) {
        const entry: CacheEntry<any> = JSON.parse(value);
        const size = JSON.stringify(value).length;
        totalSize += size;
        items.push({
          key: key.replace('cache_', ''),
          size,
          timestamp: entry.timestamp
        });
      }
    }
    
    return {
      totalSize,
      itemCount: cacheKeys.length,
      items
    };
  } catch (error) {
    console.error('Cache stats error:', error);
    return { totalSize: 0, itemCount: 0, items: [] };
  }
}

/**
 * Cache leeren
 */
export async function clearAllCache(): Promise<void> {
  try {
    const allKeys = await AsyncStorage.getAllKeys();
    const cacheKeys = allKeys.filter(k => k.startsWith('cache_'));
    await AsyncStorage.multiRemove(cacheKeys);
  } catch (error) {
    console.error('Clear cache error:', error);
  }
}
