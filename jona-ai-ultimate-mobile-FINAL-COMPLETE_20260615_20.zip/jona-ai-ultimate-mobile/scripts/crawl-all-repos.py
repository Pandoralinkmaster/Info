#!/usr/bin/env python3
"""
Massive GitHub Repository Crawler
Extrahiert ALLE Dateien aus allen 118 Links
Analysiert JEDEN Code und integriert in die App
"""

import json
import subprocess
import os
import sys
from pathlib import Path
from urllib.parse import urlparse
import re

# Konfiguration
REPOS_DIR = "/tmp/crawled_repos"
OUTPUT_DIR = "/home/ubuntu/jona-ai-ultimate-mobile/extracted_code"
MAX_REPOS = 118

# Erstelle Verzeichnisse
os.makedirs(REPOS_DIR, exist_ok=True)
os.makedirs(OUTPUT_DIR, exist_ok=True)

def is_github_url(url):
    """Prüfe ob URL ein GitHub-Repository ist"""
    return "github.com" in url and url.count("/") >= 4

def extract_repo_info(url):
    """Extrahiere Owner und Repo-Name aus GitHub-URL"""
    parts = url.rstrip("/").split("/")
    if len(parts) >= 5:
        owner = parts[3]
        repo = parts[4]
        return owner, repo
    return None, None

def clone_repo(url, target_dir):
    """Clone ein GitHub-Repository"""
    try:
        result = subprocess.run(
            ["git", "clone", "--depth=1", url, target_dir],
            capture_output=True,
            timeout=60
        )
        return result.returncode == 0
    except Exception as e:
        print(f"Fehler beim Clonen von {url}: {e}")
        return False

def extract_code_files(repo_dir):
    """Extrahiere alle Code-Dateien aus einem Repository"""
    code_files = {}
    code_extensions = [
        '.py', '.js', '.ts', '.tsx', '.jsx',
        '.go', '.java', '.kt', '.scala',
        '.rb', '.php', '.c', '.cpp', '.h',
        '.rs', '.sh', '.bash', '.sql'
    ]
    
    try:
        for root, dirs, files in os.walk(repo_dir):
            # Ignoriere .git und node_modules
            dirs[:] = [d for d in dirs if d not in ['.git', 'node_modules', '.venv', 'venv']]
            
            for file in files:
                if any(file.endswith(ext) for ext in code_extensions):
                    file_path = os.path.join(root, file)
                    rel_path = os.path.relpath(file_path, repo_dir)
                    
                    try:
                        with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                            content = f.read()
                            if len(content) < 1000000:  # Max 1MB pro Datei
                                code_files[rel_path] = {
                                    'content': content,
                                    'size': len(content),
                                    'language': Path(file).suffix
                                }
                    except Exception as e:
                        print(f"Fehler beim Lesen von {rel_path}: {e}")
    except Exception as e:
        print(f"Fehler beim Extrahieren von {repo_dir}: {e}")
    
    return code_files

def analyze_code(content, language):
    """Analysiere Code und extrahiere Funktionen/Klassen"""
    functions = []
    classes = []
    imports = []
    
    # Python
    if language == '.py':
        functions.extend(re.findall(r'def\s+(\w+)\s*\(', content))
        classes.extend(re.findall(r'class\s+(\w+)', content))
        imports.extend(re.findall(r'(?:from|import)\s+[\w.]+', content))
    
    # JavaScript/TypeScript
    elif language in ['.js', '.ts', '.jsx', '.tsx']:
        functions.extend(re.findall(r'(?:function|const|let|var)\s+(\w+)\s*(?:=|:|\()', content))
        classes.extend(re.findall(r'class\s+(\w+)', content))
        imports.extend(re.findall(r'(?:import|require)\s+[\'"][\w/.@-]+[\'"]', content))
    
    # Go
    elif language == '.go':
        functions.extend(re.findall(r'func\s+(?:\(\w+\s+\*?\w+\)\s+)?(\w+)\s*\(', content))
        classes.extend(re.findall(r'type\s+(\w+)\s+struct', content))
        imports.extend(re.findall(r'import\s+[\'"][\w/.@-]+[\'"]', content))
    
    # Java
    elif language == '.java':
        functions.extend(re.findall(r'(?:public|private|protected)?\s+\w+\s+(\w+)\s*\(', content))
        classes.extend(re.findall(r'(?:public|private)?\s+class\s+(\w+)', content))
        imports.extend(re.findall(r'import\s+[\w.]+', content))
    
    return {
        'functions': list(set(functions))[:20],  # Top 20
        'classes': list(set(classes))[:20],
        'imports': list(set(imports))[:20],
        'lines': len(content.split('\n')),
        'size': len(content)
    }

def process_all_repos(urls):
    """Verarbeite alle Repositories"""
    results = {
        'total_repos': 0,
        'successful': 0,
        'failed': 0,
        'repositories': [],
        'code_analysis': {}
    }
    
    github_urls = [url for url in urls if is_github_url(url)]
    print(f"Verarbeite {len(github_urls)} GitHub-Repositories...")
    
    for idx, url in enumerate(github_urls[:MAX_REPOS], 1):
        print(f"\n[{idx}/{len(github_urls)}] Verarbeite: {url}")
        
        owner, repo = extract_repo_info(url)
        if not owner or not repo:
            print(f"  ✗ Konnte Repository-Info nicht extrahieren")
            results['failed'] += 1
            continue
        
        repo_dir = os.path.join(REPOS_DIR, f"{owner}_{repo}")
        
        # Clone Repository
        if clone_repo(url, repo_dir):
            print(f"  ✓ Repository geklont")
            results['successful'] += 1
            
            # Extrahiere Code-Dateien
            code_files = extract_code_files(repo_dir)
            print(f"  ✓ {len(code_files)} Code-Dateien extrahiert")
            
            # Analysiere Code
            repo_analysis = {
                'url': url,
                'owner': owner,
                'repo': repo,
                'files_count': len(code_files),
                'files': {}
            }
            
            for file_path, file_data in code_files.items():
                analysis = analyze_code(file_data['content'], file_data['language'])
                repo_analysis['files'][file_path] = analysis
            
            results['repositories'].append(repo_analysis)
            results['code_analysis'][f"{owner}/{repo}"] = repo_analysis
            
            # Speichere Analyse
            analysis_file = os.path.join(OUTPUT_DIR, f"{owner}_{repo}_analysis.json")
            with open(analysis_file, 'w') as f:
                json.dump(repo_analysis, f, indent=2)
            
            print(f"  ✓ Analyse gespeichert")
        else:
            print(f"  ✗ Fehler beim Klonen")
            results['failed'] += 1
        
        results['total_repos'] += 1
    
    return results

def main():
    # Lade alle URLs
    with open('/tmp/all_urls.json', 'r') as f:
        urls = json.load(f)
    
    print(f"Starte Crawling von {len(urls)} Links...")
    print(f"Output-Verzeichnis: {OUTPUT_DIR}")
    
    # Verarbeite alle Repos
    results = process_all_repos(urls)
    
    # Speichere Zusammenfassung
    summary_file = os.path.join(OUTPUT_DIR, "crawl_summary.json")
    with open(summary_file, 'w') as f:
        json.dump({
            'total_repos': results['total_repos'],
            'successful': results['successful'],
            'failed': results['failed'],
            'repositories_count': len(results['repositories']),
            'total_files_analyzed': sum(r['files_count'] for r in results['repositories'])
        }, f, indent=2)
    
    print(f"\n{'='*60}")
    print(f"Crawling abgeschlossen!")
    print(f"  Gesamt: {results['total_repos']}")
    print(f"  Erfolgreich: {results['successful']}")
    print(f"  Fehler: {results['failed']}")
    print(f"  Dateien analysiert: {sum(r['files_count'] for r in results['repositories'])}")
    print(f"{'='*60}")

if __name__ == "__main__":
    main()
