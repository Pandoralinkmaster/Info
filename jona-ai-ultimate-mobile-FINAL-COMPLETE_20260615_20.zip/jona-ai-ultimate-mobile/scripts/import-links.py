#!/usr/bin/env python3
import json
import sys

# Lese data-links.json
with open('/home/ubuntu/jona-ai-ultimate-mobile/data-links.json', 'r') as f:
    data = json.load(f)

# Generiere SQL INSERT Statements
print("-- Import 118 Links from data-links.json")
print("INSERT INTO links (url, host, path, kind, sha256, occurrences) VALUES")

values = []
for item in data:
    url = item['url'].replace("'", "\\'")
    host = item.get('host', '').replace("'", "\\'")
    path = item.get('path', '').replace("'", "\\'")
    kind = item.get('kind', 'unknown').replace("'", "\\'")
    sha256 = item.get('sha256', '')
    occurrences = len(item.get('occurrences', []))
    
    value = f"('{url}', '{host}', '{path}', '{kind}', '{sha256}', {occurrences})"
    values.append(value)

print(",\n".join(values) + ";")
print("\n-- Total links imported:", len(data))
