import { publicProcedure, protectedProcedure, router } from "./_core/trpc";
import { z } from "zod";
import { getDb } from "./db";
import { eq, like } from "drizzle-orm";
import { links, analyses, signatures } from "../drizzle/schema";

// Signatur-Patterns
const SIG_PATTERNS = [
  { type: "python_function", pattern: /^\s*def\s+([A-Za-z_][\w]*)\s*\(([^)]*)\)\s*:/gm },
  { type: "python_class", pattern: /^\s*class\s+([A-Za-z_][\w]*)\s*(?:\(([^)]*)\))?\s*:/gm },
  { type: "js_function", pattern: /\bfunction\s+([A-Za-z_$][\w$]*)\s*\(([^)]*)\)/gm },
  { type: "arrow_function", pattern: /\b(?:const|let|var)\s+([A-Za-z_$][\w$]*)\s*=\s*(?:async\s*)?\(([^)]*)\)\s*=>/gm },
  { type: "java_like_method", pattern: /\b(?:public|private|protected|static|final|suspend|fun)\s+[\w<>,\[\]?]+\s+([A-Za-z_][\w]*)\s*\(([^)]*)\)/gm },
  { type: "kotlin_function", pattern: /\bfun\s+([A-Za-z_][\w]*)\s*\(([^)]*)\)/gm },
  { type: "go_function", pattern: /\bfunc\s+(?:\([^)]*\)\s*)?([A-Za-z_][\w]*)\s*\(([^)]*)\)/gm },
];

const RISK_WORDS = /exploit|payload|shellcode|meterpreter|ransom|keylogger|credential|steal|ddos|botnet|reverse shell|malware/gi;

function extractSignatures(content: string) {
  const signatures: any[] = [];
  
  for (const { type, pattern } of SIG_PATTERNS) {
    let match;
    const regex = new RegExp(pattern.source, pattern.flags);
    while ((match = regex.exec(content)) !== null) {
      signatures.push({
        type,
        name: match[1],
        params: match[2] || "",
        position: match.index,
      });
    }
  }
  
  return signatures;
}

function extractImports(content: string) {
  const imports = content.match(/^\s*(?:import|from|require\(|include|using)\b.*$/gm) || [];
  return imports.slice(0, 40);
}

function extractRiskTerms(content: string) {
  const matches = content.match(RISK_WORDS) || [];
  return Array.from(new Set(matches.map(m => m.toLowerCase())));
}

function generatePythonModule(linkId: number, signatures: any[]) {
  const lines: string[] = [
    '"""Generated safe module. It is function-equivalent scaffolding derived from signatures/structures, not copied source."""',
    "from typing import Any, Dict, List",
    "",
    "",
  ];

  const seen: Set<string> = new Set();
  
  for (const sig of signatures.slice(0, 50)) {
    let name = sig.name.replace(/\W+/g, "_");
    if (name.startsWith("_")) name = "fn" + name;
    
    if (seen.has(name)) continue;
    seen.add(name);
    
    lines.push(`def ${name}(*args: Any, **kwargs: Any) -> Dict[str, Any]:`);
    lines.push(`    """Safe rebuilt placeholder for discovered ${sig.type}."""`);
    lines.push(`    return {"ok": True, "function": "${name}", "args_count": len(args), "kwargs": sorted(kwargs.keys())}`);
    lines.push("");
  }
  
  if (lines.length <= 4) {
    lines.push("def analyze_source(*args: Any, **kwargs: Any) -> Dict[str, Any]:");
    lines.push('    """Default safe placeholder."""');
    lines.push('    return {"ok": True, "function": "analyze_source"}');
  }
  
  return lines.join("\n");
}

export const githubRouter = router({
  // Liste alle Links auf
  listLinks: protectedProcedure
    .input(z.object({
      skip: z.number().default(0),
      take: z.number().default(50),
      search: z.string().optional(),
      kind: z.string().optional(),
    }))
    .query(async ({ input }) => {
      const db = await getDb();
      if (!db) throw new Error("Database unavailable");

      let query = db.select().from(links);

      if (input.search) {
        query = query.where(
          like(links.url, `%${input.search}%`)
        ) as any;
      }

      if (input.kind) {
        query = query.where(eq(links.kind, input.kind)) as any;
      }

      const results = await query.limit(input.take).offset(input.skip);
      return results;
    }),

  // Hole Link-Details
  getLink: protectedProcedure
    .input(z.object({ linkId: z.number() }))
    .query(async ({ input }) => {
      const db = await getDb();
      if (!db) throw new Error("Database unavailable");

      const link = await db.select().from(links).where(eq(links.id, input.linkId)).limit(1);
      if (!link.length) throw new Error("Link not found");

      const analysis = await db
        .select()
        .from(analyses)
        .where(eq(analyses.linkId, input.linkId))
        .limit(1);

      const sigs = analysis.length
        ? await db.select().from(signatures).where(eq(signatures.analysisId, analysis[0].id))
        : [];

      return {
        link: link[0],
        analysis: analysis[0] || null,
        signatures: sigs,
      };
    }),

  // Extrahiere Signaturen aus Code
  extractSignatures: publicProcedure
    .input(z.object({ content: z.string() }))
    .query(({ input }) => extractSignatures(input.content)),

  // Extrahiere Imports
  extractImports: publicProcedure
    .input(z.object({ content: z.string() }))
    .query(({ input }) => extractImports(input.content)),

  // Extrahiere Risk-Terms
  extractRiskTerms: publicProcedure
    .input(z.object({ content: z.string() }))
    .query(({ input }) => extractRiskTerms(input.content)),

  // Generiere Python-Modul
  generateModule: publicProcedure
    .input(z.object({ linkId: z.number(), signatures: z.array(z.any()) }))
    .query(({ input }) => ({
      module: generatePythonModule(input.linkId, input.signatures),
      filename: `module_link_${input.linkId}.py`,
    })),

  // Statistiken
  getStats: protectedProcedure.query(async () => {
    const db = await getDb();
    if (!db) throw new Error("Database unavailable");

    const totalLinks = await db.select().from(links);
    const completedAnalyses = await db
      .select()
      .from(analyses)
      .where(eq(analyses.status, "completed"));

    const successRate =
      totalLinks.length > 0 ? Math.round((completedAnalyses.length / totalLinks.length) * 100) : 0;

    return {
      totalLinks: totalLinks.length,
      completedAnalyses: completedAnalyses.length,
      successRate,
    };
  }),
});
