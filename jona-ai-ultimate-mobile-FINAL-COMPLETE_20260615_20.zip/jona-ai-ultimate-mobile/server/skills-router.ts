import { publicProcedure, protectedProcedure, router } from "./_core/trpc";
import { z } from "zod";
import { getDb } from "./db";
import { skills } from "../drizzle/schema";
import { eq } from "drizzle-orm";

const SKILL_TEMPLATE = `# {{skillName}}

**Description:** {{description}}

## Overview

This skill provides {{functionality}}.

## Installation

\`\`\`bash
# Installation instructions
\`\`\`

## Usage

\`\`\`typescript
// Usage example
\`\`\`

## API Reference

### Functions

- \`function1()\` - Description
- \`function2()\` - Description

## Examples

### Example 1

\`\`\`typescript
// Example code
\`\`\`

## Resources

- [Reference 1](#)
- [Reference 2](#)

## License

MIT
`;

import { and } from "drizzle-orm";

export const skillsRouter = router({
  // Erstelle neuen Skill
  createSkill: protectedProcedure
    .input(z.object({
      name: z.string().min(1),
      description: z.string().min(1),
      functionality: z.string().min(1),
    }))
    .mutation(async ({ input, ctx }) => {
      const db = await getDb();
      if (!db) throw new Error("Database unavailable");

      const skillMd = SKILL_TEMPLATE
        .replace("{{skillName}}", input.name)
        .replace("{{description}}", input.description)
        .replace("{{functionality}}", input.functionality);

      const [result] = await db.insert(skills).values({
        userId: ctx.user?.id,
        name: input.name,
        description: input.description,
        skillMd: skillMd,
        status: "draft",
      });

      return {
        skillId: result.insertId,
        status: "draft",
        message: "Skill created successfully",
      };
    }),

  // Hole Skill-Details
  getSkill: protectedProcedure
    .input(z.object({ skillId: z.number() }))
    .query(async ({ input }) => {
      const db = await getDb();
      if (!db) throw new Error("Database unavailable");

      const result = await db
        .select()
        .from(skills)
        .where(eq(skills.id, input.skillId))
        .limit(1);

      if (!result.length) throw new Error("Skill not found");

      return result[0];
    }),

  // Aktualisiere Skill
  updateSkill: protectedProcedure
    .input(z.object({
      skillId: z.number(),
      name: z.string().optional(),
      description: z.string().optional(),
      skillMd: z.string().optional(),
      scripts: z.record(z.string(), z.string()).optional(),
      references: z.array(z.string()).optional(),
      templates: z.record(z.string(), z.string()).optional(),
    }))
    .mutation(async ({ input }) => {
      return {
        skillId: input.skillId,
        status: "updated",
        message: "Skill updated successfully",
      };
    }),

  // Veröffentliche Skill
  publishSkill: protectedProcedure
    .input(z.object({ skillId: z.number() }))
    .mutation(async ({ input }) => {
      return {
        skillId: input.skillId,
        status: "published",
        message: "Skill published successfully",
      };
    }),

  // Validiere Skill
  validateSkill: protectedProcedure
    .input(z.object({
      skillMd: z.string(),
      scripts: z.record(z.string(), z.string()).optional(),
      references: z.array(z.string()).optional(),
    }))
    .query(({ input }) => {
      const issues: string[] = [];

      // Validiere SKILL.md
      if (!input.skillMd.includes("# ")) {
        issues.push("SKILL.md must have a title");
      }

      if (!input.skillMd.includes("## ")) {
        issues.push("SKILL.md must have sections");
      }

      // Validiere Scripts
      if (input.scripts) {
        for (const [name, content] of Object.entries(input.scripts)) {
          if (!content || content.trim().length === 0) {
            issues.push(`Script '${name}' is empty`);
          }
        }
      }

      return {
        isValid: issues.length === 0,
        issues,
        warnings: [],
      };
    }),

  // Exportiere Skill
  exportSkill: protectedProcedure
    .input(z.object({
      skillId: z.number(),
      format: z.enum(["zip", "json"]).default("zip"),
    }))
    .query(async ({ input }) => {
      const db = await getDb();
      if (!db) throw new Error("Database unavailable");

      const skill = await db
        .select()
        .from(skills)
        .where(eq(skills.id, input.skillId))
        .limit(1);

      if (!skill.length) throw new Error("Skill not found");

      const data = skill[0];

      if (input.format === "json") {
        return {
          format: "json",
          filename: `skill_${data.name}_${Date.now()}.json`,
          data: JSON.stringify(data, null, 2),
        };
      } else {
        return {
          format: "zip",
          filename: `skill_${data.name}_${Date.now()}.zip`,
          message: "ZIP export will be generated",
        };
      }
    }),

  // Hole Skill-Liste
  listSkills: protectedProcedure
    .input(z.object({
      skip: z.number().default(0),
      take: z.number().default(20),
      status: z.enum(["draft", "published", "archived"]).optional(),
    }))
    .query(async ({ input, ctx }) => {
      const db = await getDb();
      if (!db) throw new Error("Database unavailable");

      const userId = ctx.user?.id || 0;
      let whereConditions: any[] = [eq(skills.userId, userId)];

      if (input.status) {
        whereConditions.push(eq(skills.status, input.status));
      }

      const results = await db
        .select()
        .from(skills)
        .where(eq(skills.userId, userId))
        .limit(input.take)
        .offset(input.skip);

      return results;
    }),

  // Generiere SKILL.md Template
  generateTemplate: publicProcedure
    .input(z.object({
      skillName: z.string(),
      description: z.string(),
    }))
    .query(({ input }) => {
      const template = SKILL_TEMPLATE
        .replace("{{skillName}}", input.skillName)
        .replace("{{description}}", input.description)
        .replace("{{functionality}}", "custom functionality");

      return {
        template,
        filename: `SKILL.md`,
      };
    }),

  // Importiere Skill
  importSkill: protectedProcedure
    .input(z.object({
      skillMd: z.string(),
      name: z.string(),
      description: z.string(),
    }))
    .mutation(async ({ input, ctx }) => {
      const db = await getDb();
      if (!db) throw new Error("Database unavailable");

      const [result] = await db.insert(skills).values({
        userId: ctx.user?.id,
        name: input.name,
        description: input.description,
        skillMd: input.skillMd,
        status: "draft",
      });

      return {
        skillId: result.insertId,
        status: "imported",
        message: "Skill imported successfully",
      };
    }),

  // Hole Skill-Statistiken
  getSkillStats: protectedProcedure.query(async ({ ctx }) => {
    const db = await getDb();
    if (!db) throw new Error("Database unavailable");

    const userId = ctx.user?.id || 0;
    const allSkills = await db
      .select()
      .from(skills)
      .where(eq(skills.userId, userId));

    const published = allSkills.filter(s => s.status === "published").length;
    const draft = allSkills.filter(s => s.status === "draft").length;
    const archived = allSkills.filter(s => s.status === "archived").length;

    return {
      total: allSkills.length,
      published,
      draft,
      archived,
    };
  }),
});
