import { publicProcedure, protectedProcedure, router } from "./_core/trpc";
import { z } from "zod";
import { getDb } from "./db";
import { ttsSessions } from "../drizzle/schema";

// 30 verfügbare Stimmen
const VOICES = [
  "Zephyr", "Puck", "Charon", "Kore", "Fenrir",
  "Leda", "Orus", "Aoede", "Callirrhoe", "Autonoe",
  "Enceladus", "Iapetus", "Umbriel", "Algieba", "Despina",
  "Erinome", "Algenib", "Rasalgethi", "Laomedeia", "Achernar",
  "Alnilam", "Schedar", "Gacrux", "Pulcherrima", "Achird",
  "Zubenelgenubi", "Vindemiatrix", "Sadachbia", "Sadaltager", "Sulafat"
];

// 50+ Sprachen mit BCP-47 Codes
const LANGUAGES = [
  { code: "ar-EG", name: "Arabic (Egypt)" },
  { code: "bn-BD", name: "Bangla (Bangladesh)" },
  { code: "nl-NL", name: "Dutch (Netherlands)" },
  { code: "en-IN", name: "English (India)" },
  { code: "en-US", name: "English (United States)" },
  { code: "en-GB", name: "English (United Kingdom)" },
  { code: "en-AU", name: "English (Australia)" },
  { code: "fr-FR", name: "French (France)" },
  { code: "fr-CA", name: "French (Canada)" },
  { code: "de-DE", name: "German (Germany)" },
  { code: "hi-IN", name: "Hindi (India)" },
  { code: "id-ID", name: "Indonesian (Indonesia)" },
  { code: "it-IT", name: "Italian (Italy)" },
  { code: "ja-JP", name: "Japanese (Japan)" },
  { code: "ko-KR", name: "Korean (South Korea)" },
  { code: "pt-BR", name: "Portuguese (Brazil)" },
  { code: "pt-PT", name: "Portuguese (Portugal)" },
  { code: "ru-RU", name: "Russian (Russia)" },
  { code: "es-ES", name: "Spanish (Spain)" },
  { code: "es-MX", name: "Spanish (Mexico)" },
  { code: "es-419", name: "Spanish (Latin America)" },
  { code: "sv-SE", name: "Swedish (Sweden)" },
  { code: "tr-TR", name: "Turkish (Turkey)" },
  { code: "uk-UA", name: "Ukrainian (Ukraine)" },
  { code: "vi-VN", name: "Vietnamese (Vietnam)" },
  { code: "zh-CN", name: "Chinese Mandarin (China)" },
  { code: "zh-TW", name: "Chinese Mandarin (Taiwan)" },
  { code: "th-TH", name: "Thai (Thailand)" },
  { code: "pl-PL", name: "Polish (Poland)" },
  { code: "cs-CZ", name: "Czech (Czech Republic)" },
  { code: "da-DK", name: "Danish (Denmark)" },
  { code: "fi-FI", name: "Finnish (Finland)" },
  { code: "el-GR", name: "Greek (Greece)" },
  { code: "hu-HU", name: "Hungarian (Hungary)" },
  { code: "nb-NO", name: "Norwegian Bokmål (Norway)" },
  { code: "ro-RO", name: "Romanian (Romania)" },
  { code: "sk-SK", name: "Slovak (Slovakia)" },
  { code: "sl-SI", name: "Slovenian (Slovenia)" },
  { code: "ca-ES", name: "Catalan (Spain)" },
  { code: "eu-ES", name: "Basque (Spain)" },
  { code: "gl-ES", name: "Galician (Spain)" },
  { code: "af-ZA", name: "Afrikaans (South Africa)" },
  { code: "sq-AL", name: "Albanian (Albania)" },
  { code: "am-ET", name: "Amharic (Ethiopia)" },
  { code: "hy-AM", name: "Armenian (Armenia)" },
  { code: "az-AZ", name: "Azerbaijani (Azerbaijan)" },
  { code: "be-BY", name: "Belarusian (Belarus)" },
  { code: "bg-BG", name: "Bulgarian (Bulgaria)" },
  { code: "ceb-PH", name: "Cebuano (Philippines)" },
  { code: "hr-HR", name: "Croatian (Croatia)" },
  { code: "et-EE", name: "Estonian (Estonia)" },
  { code: "fil-PH", name: "Filipino (Philippines)" },
  { code: "ka-GE", name: "Georgian (Georgia)" },
  { code: "gu-IN", name: "Gujarati (India)" },
  { code: "he-IL", name: "Hebrew (Israel)" },
  { code: "is-IS", name: "Icelandic (Iceland)" },
  { code: "jv-JV", name: "Javanese (Java)" },
  { code: "kn-IN", name: "Kannada (India)" },
  { code: "lv-LV", name: "Latvian (Latvia)" },
  { code: "lt-LT", name: "Lithuanian (Lithuania)" },
  { code: "mk-MK", name: "Macedonian (North Macedonia)" },
  { code: "mg-MG", name: "Malagasy (Madagascar)" },
  { code: "ms-MY", name: "Malay (Malaysia)" },
  { code: "ml-IN", name: "Malayalam (India)" },
  { code: "mn-MN", name: "Mongolian (Mongolia)" },
  { code: "ne-NP", name: "Nepali (Nepal)" },
  { code: "pa-IN", name: "Punjabi (India)" },
  { code: "sr-RS", name: "Serbian (Serbia)" },
  { code: "si-LK", name: "Sinhala (Sri Lanka)" },
  { code: "sw-KE", name: "Swahili (Kenya)" },
  { code: "ta-IN", name: "Tamil (India)" },
  { code: "te-IN", name: "Telugu (India)" },
  { code: "ur-PK", name: "Urdu (Pakistan)" },
];

export const ttsRouter = router({
  // Liste alle verfügbaren Stimmen auf
  listVoices: publicProcedure.query(() => VOICES),

  // Liste alle verfügbaren Sprachen auf
  listLanguages: publicProcedure.query(() => LANGUAGES),

  // Generiere TTS-Audio
  generateSpeech: protectedProcedure
    .input(z.object({
      prompt: z.string().min(1),
      voiceName: z.string(),
      languageCode: z.string(),
    }))
    .mutation(async ({ input, ctx }) => {
      const db = await getDb();
      if (!db) throw new Error("Database unavailable");

      // Validiere Voice und Language
      if (!VOICES.includes(input.voiceName)) {
        throw new Error(`Invalid voice: ${input.voiceName}`);
      }

      if (!LANGUAGES.find(l => l.code === input.languageCode)) {
        throw new Error(`Invalid language: ${input.languageCode}`);
      }

      // Erstelle Session
      const [session] = await db.insert(ttsSessions).values({
        userId: ctx.user?.id,
        prompt: input.prompt,
        voiceName: input.voiceName,
        languageCode: input.languageCode,
        status: "pending",
      });

      return {
        sessionId: session.insertId,
        status: "pending",
        message: "TTS generation started. Audio will be available shortly.",
      };
    }),

  // Hole Session-Status
  getSessionStatus: protectedProcedure
    .input(z.object({ sessionId: z.number() }))
    .query(async ({ input }) => {
      const db = await getDb();
      if (!db) throw new Error("Database unavailable");

      const { eq } = await import("drizzle-orm");
      const session = await db
        .select()
        .from(ttsSessions)
        .where(eq(ttsSessions.id, input.sessionId))
        .limit(1);

      if (!session.length) throw new Error("Session not found");

      return session[0];
    }),

  // Voice-Charakteristiken
  getVoiceInfo: publicProcedure
    .input(z.object({ voiceName: z.string() }))
    .query(({ input }) => {
      const voiceCharacteristics: Record<string, string> = {
        "Zephyr": "Female, Bright",
        "Puck": "Male, Upbeat",
        "Charon": "Male, Informative",
        "Kore": "Female, Firm",
        "Fenrir": "Male, Excitable",
        "Leda": "Female, Youthful",
        "Orus": "Male, Firm",
        "Aoede": "Female, Breezy",
        "Callirrhoe": "Female, Easy-going",
        "Autonoe": "Female, Bright",
        "Enceladus": "Male, Breathy",
        "Iapetus": "Male, Clear",
        "Umbriel": "Male, Easy-going",
        "Algieba": "Male, Smooth",
        "Despina": "Female, Smooth",
        "Erinome": "Female, Clear",
        "Algenib": "Male, Gravelly",
        "Rasalgethi": "Male, Informative",
        "Laomedeia": "Female, Upbeat",
        "Achernar": "Female, Soft",
        "Alnilam": "Male, Firm",
        "Schedar": "Male, Even",
        "Gacrux": "Female, Mature",
        "Pulcherrima": "Female, Forward",
        "Achird": "Male, Friendly",
        "Zubenelgenubi": "Male, Casual",
        "Vindemiatrix": "Female, Gentle",
        "Sadachbia": "Male, Lively",
        "Sadaltager": "Male, Knowledgeable",
        "Sulafat": "Female, Warm",
      };

      return {
        voiceName: input.voiceName,
        characteristics: voiceCharacteristics[input.voiceName] || "Unknown",
      };
    }),

  // Sprach-Informationen
  getLanguageInfo: publicProcedure
    .input(z.object({ languageCode: z.string() }))
    .query(({ input }) => {
      const language = LANGUAGES.find(l => l.code === input.languageCode);
      if (!language) throw new Error("Language not found");

      return language;
    }),
});
