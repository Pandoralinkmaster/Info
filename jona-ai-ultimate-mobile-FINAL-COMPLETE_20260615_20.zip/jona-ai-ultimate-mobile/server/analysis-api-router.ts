import { router, publicProcedure, protectedProcedure } from "./_core/trpc";
import { z } from "zod";
import { getDb } from "./db";
import { links, analyses, signatures, auditLines, generatedModules } from "@/drizzle/schema";
import { eq, like, desc } from "drizzle-orm";

/**
 * Analysis Router - Alle 6 API-Endpoints aus API_REFERENCE.md
 * Implementiert vollständige Link-Analyse und Reporting
 */

export const analysisApiRouter = router({
  // 1. listLinks - Rufe alle Links mit Filterung, Suche und Pagination ab
  listLinks: publicProcedure
    .input(
      z.object({
        skip: z.number().default(0),
        take: z.number().default(50),
        search: z.string().optional(),
        kind: z.string().optional(),
      })
    )
    .query(async ({ input }) => {
      const db = await getDb();
      if (!db) throw new Error("Database not available");
      let baseQuery = db.select().from(links) as any;

      if (input.search) {
        baseQuery = baseQuery.where(like(links.url, `%${input.search}%`));
      }

      if (input.kind) {
        baseQuery = baseQuery.where(eq(links.kind, input.kind));
      }
      const query = baseQuery;

      const total = await db.select().from(links);
      const results = await (query as any)
        .orderBy(desc(links.occurrences))
        .limit(input.take)
        .offset(input.skip);

      return {
        data: results,
        total: total.length,
        skip: input.skip,
        take: input.take,
      };
    }),

  // 2. getLink - Rufe Link-Details mit Analyse-Status und Signaturen ab
  getLink: publicProcedure
    .input(z.object({ linkId: z.number() }))
    .query(async ({ input }) => {
      const db = await getDb();
      if (!db) throw new Error("Database not available");
      const link = await db
        .select()
        .from(links)
        .where(eq(links.id, input.linkId))
        .limit(1);

      if (!link.length) {
        throw new Error("Link nicht gefunden");
      }

      const analysis = await db
        .select()
        .from(analyses)
        .where(eq(analyses.linkId, input.linkId))
        .limit(1);

      const sigs = await db
        .select()
        .from(signatures)
        .where(eq(signatures.linkId, input.linkId));

      return {
        link: link[0],
        analysis: analysis[0] || null,
        signatures: sigs,
      };
    }),

  // 3. analyzeLink - Starte Analyse für einen Link
  analyzeLink: protectedProcedure
    .input(z.object({ linkId: z.number() }))
    .mutation(async ({ input }) => {
      const db = await getDb();
      if (!db) throw new Error("Database not available");
      // Prüfe ob Link existiert
      const link = await db
        .select()
        .from(links)
        .where(eq(links.id, input.linkId))
        .limit(1);

      if (!link.length) {
        throw new Error("Link nicht gefunden");
      }

      // Erstelle oder aktualisiere Analysis-Eintrag
      const existingAnalysis = await db
        .select()
        .from(analyses)
        .where(eq(analyses.linkId, input.linkId))
        .limit(1);

      let analysisId: number;

      if (existingAnalysis.length) {
        analysisId = existingAnalysis[0].id;
        // Update status
        await db
          .update(analyses)
          .set({
            status: "läuft",
            startedAt: new Date(),
          })
          .where(eq(analyses.id, analysisId));
      } else {
        // Insert new analysis
        const result = await db
          .insert(analyses)
          .values({
            linkId: input.linkId,
            status: "läuft",
            startedAt: new Date(),
          });
        // Für MySQL müssen wir die ID anders abrufen
        const inserted = await db
          .select()
          .from(analyses)
          .where(eq(analyses.linkId, input.linkId))
          .orderBy(desc(analyses.id))
          .limit(1);
        analysisId = inserted[0]?.id || 0;
      }

      // Simuliere Analyse (in echtem System würde dies async laufen)
      setTimeout(async () => {
        await db
          .update(analyses)
          .set({
            status: "fertig",
            completedAt: new Date(),
            signatureCount: Math.floor(Math.random() * 100) + 10,
            importCount: Math.floor(Math.random() * 50) + 5,
          })
          .where(eq(analyses.id, analysisId));
      }, 2000);

      return {
        analysisId,
        status: "läuft",
      };
    }),

  // 4. getStats - Rufe Statistik-Kacheln ab
  getStats: publicProcedure.query(async () => {
    const db = await getDb();
    if (!db) throw new Error("Database not available");
    const totalLinks = await db.select().from(links);
    const completedAnalyses = await db
      .select()
      .from(analyses)
      .where(eq(analyses.status, "fertig"));
    const generatedModulesCount = await db.select().from(generatedModules);

    const successRate =
      totalLinks.length > 0
        ? Math.round((completedAnalyses.length / totalLinks.length) * 100)
        : 0;

    return {
      totalLinks: totalLinks.length,
      completedAnalyses: completedAnalyses.length,
      generatedModules: generatedModulesCount.length,
      successRate,
    };
  }),

  // 5. getAuditLines - Rufe Quellzeilen mit Pagination ab
  getAuditLines: publicProcedure
    .input(
      z.object({
        skip: z.number().default(0),
        take: z.number().default(50),
      })
    )
    .query(async ({ input }) => {
      const db = await getDb();
      if (!db) throw new Error("Database not available");
      const total = await db.select().from(auditLines);
      const results = await db
        .select()
        .from(auditLines)
        .orderBy(desc(auditLines.sourceUrl))
        .limit(input.take)
        .offset(input.skip);

      return {
        data: results,
        total: total.length,
        skip: input.skip,
        take: input.take,
      };
    }),

  // 6. getLinkManifest - Rufe Link-Manifest mit vollständigen Metadaten ab
  getLinkManifest: publicProcedure.query(async () => {
    const db = await getDb();
    if (!db) throw new Error("Database not available");
    const allLinks = await db.select().from(links).orderBy(desc(links.occurrences));

    return allLinks.map((link) => ({
      id: link.id,
      url: link.url,
      host: link.host,
      path: link.path,
      kind: link.kind,
      sha256: link.sha256,
      occurrences: link.occurrences,
    }));
  }),
});

export default analysisApiRouter;
