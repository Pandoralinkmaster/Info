import { router, publicProcedure, protectedProcedure } from "./_core/trpc";
import { z } from "zod";
import { getDb } from "./db";
import { analyses, signatures, links, generatedModules } from "@/drizzle/schema";
import { eq, desc } from "drizzle-orm";

/**
 * Reports Router - Alle 6 Report-Endpoints aus API_REFERENCE.md
 * Implementiert Reporting und Analytics
 */

export const reportsRouter = router({
  // 1. listReports - Rufe alle Berichte mit Filterung ab
  listReports: publicProcedure
    .input(
      z.object({
        skip: z.number().default(0),
        take: z.number().default(50),
        status: z.string().optional(),
      })
    )
    .query(async ({ input }) => {
      const db = await getDb();
      if (!db) throw new Error("Database not available");

      let query = db.select().from(analyses) as any;

      if (input.status) {
        query = query.where(eq(analyses.status, input.status));
      }

      const total = await db.select().from(analyses);
      const results = await (query as any)
        .orderBy(desc(analyses.completedAt))
        .limit(input.take)
        .offset(input.skip);

      return {
        data: results,
        total: total.length,
        skip: input.skip,
        take: input.take,
      };
    }),

  // 2. getReport - Rufe detaillierten Bericht ab
  getReport: publicProcedure
    .input(z.object({ analysisId: z.number() }))
    .query(async ({ input }) => {
      const db = await getDb();
      if (!db) throw new Error("Database not available");

      const analysis = await db
        .select()
        .from(analyses)
        .where(eq(analyses.id, input.analysisId))
        .limit(1);

      if (!analysis.length) {
        throw new Error("Bericht nicht gefunden");
      }

      const sigs = await db
        .select()
        .from(signatures)
        .where(eq(signatures.analysisId, input.analysisId));

      const link = await db
        .select()
        .from(links)
        .where(eq(links.id, analysis[0].linkId))
        .limit(1);

      return {
        analysis: analysis[0],
        link: link[0] || null,
        signatures: sigs,
      };
    }),

  // 3. getAnalyticsSummary - Rufe Analytics-Zusammenfassung ab
  getAnalyticsSummary: publicProcedure.query(async () => {
    const db = await getDb();
    if (!db) throw new Error("Database not available");

    const allAnalyses = await db.select().from(analyses);
    const completedAnalyses = allAnalyses.filter((a) => a.status === "fertig");
    const allSignatures = await db.select().from(signatures);

    const byStatus: Record<string, number> = {};
    const byLinkType: Record<string, number> = {};

    for (const analysis of allAnalyses) {
      byStatus[analysis.status || "unknown"] =
        (byStatus[analysis.status || "unknown"] || 0) + 1;
    }

    const allLinks = await db.select().from(links);
    for (const link of allLinks) {
      byLinkType[link.kind || "unknown"] =
        (byLinkType[link.kind || "unknown"] || 0) + 1;
    }

    const avgSignaturesPerAnalysis =
      completedAnalyses.length > 0
        ? Math.round(allSignatures.length / completedAnalyses.length)
        : 0;

    const completionRate =
      allAnalyses.length > 0
        ? Math.round((completedAnalyses.length / allAnalyses.length) * 100)
        : 0;

    return {
      summary: {
        totalLinks: allLinks.length,
        totalAnalyses: allAnalyses.length,
        completedAnalyses: completedAnalyses.length,
        totalSignatures: allSignatures.length,
        averageSignaturesPerAnalysis: avgSignaturesPerAnalysis,
        completionRate,
      },
      byStatus,
      byLinkType,
      bySignatureType: {
        function: allSignatures.filter((s) => s.signatureType === "function")
          .length,
        class: allSignatures.filter((s) => s.signatureType === "class").length,
        import: allSignatures.filter((s) => s.signatureType === "import").length,
      },
    };
  }),

  // 4. exportReport - Exportiere Bericht als JSON
  exportReport: protectedProcedure
    .input(z.object({ analysisId: z.number() }))
    .query(async ({ input }) => {
      const db = await getDb();
      if (!db) throw new Error("Database not available");

      const analysis = await db
        .select()
        .from(analyses)
        .where(eq(analyses.id, input.analysisId))
        .limit(1);

      if (!analysis.length) {
        throw new Error("Bericht nicht gefunden");
      }

      const sigs = await db
        .select()
        .from(signatures)
        .where(eq(signatures.analysisId, input.analysisId));

      const link = await db
        .select()
        .from(links)
        .where(eq(links.id, analysis[0].linkId))
        .limit(1);

      return {
        exportedAt: new Date().toISOString(),
        analysis: analysis[0],
        link: link[0] || null,
        signatures: sigs,
        summary: {
          totalSignatures: sigs.length,
          functionCount: sigs.filter((s) => s.signatureType === "function")
            .length,
          classCount: sigs.filter((s) => s.signatureType === "class").length,
          importCount: sigs.filter((s) => s.signatureType === "import").length,
        },
      };
    }),

  // 5. getTopSignatures - Rufe häufigste Signaturen ab
  getTopSignatures: publicProcedure
    .input(z.object({ limit: z.number().default(20) }))
    .query(async ({ input }) => {
      const db = await getDb();
      if (!db) throw new Error("Database not available");

      const allSignatures = await db.select().from(signatures);

      // Zähle Vorkommen
      const signatureCounts: Record<string, number> = {};
      for (const sig of allSignatures) {
        const key = `${sig.signatureType}:${sig.name}`;
        signatureCounts[key] = (signatureCounts[key] || 0) + 1;
      }

      // Sortiere und begrenze
      const sorted = Object.entries(signatureCounts)
        .sort((a, b) => b[1] - a[1])
        .slice(0, input.limit)
        .map(([key, count]) => {
          const [type, name] = key.split(":");
          return { type, name, count };
        });

      return sorted;
    }),

  // 6. getAnalysisTimeline - Rufe Analyse-Timeline ab
  getAnalysisTimeline: publicProcedure.query(async () => {
    const db = await getDb();
    if (!db) throw new Error("Database not available");

    const allAnalyses = await db
      .select()
      .from(analyses)
      .orderBy(desc(analyses.startedAt));

    return allAnalyses
      .filter((a) => a.startedAt)
      .map((a) => ({
        id: a.id,
        linkId: a.linkId,
        status: a.status,
        startedAt: a.startedAt,
        completedAt: a.completedAt,
        duration: a.completedAt && a.startedAt
          ? Math.round(
              (new Date(a.completedAt).getTime() -
                new Date(a.startedAt).getTime()) /
                1000
            )
          : null,
        signatureCount: a.signatureCount || 0,
      }))
      .slice(0, 100); // Top 100 timeline events
  }),
});

export default reportsRouter;
