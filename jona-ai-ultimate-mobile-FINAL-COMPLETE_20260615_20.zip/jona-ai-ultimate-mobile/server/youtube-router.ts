import { publicProcedure, protectedProcedure, router } from "./_core/trpc";
import { z } from "zod";
import { getDb } from "./db";
import { youtubeResearch } from "../drizzle/schema";
import { eq } from "drizzle-orm";

export const youtubeRouter = router({
  // Suche YouTube-Videos
  searchVideos: protectedProcedure
    .input(z.object({
      query: z.string().min(1),
      maxResults: z.number().default(10),
    }))
    .query(async ({ input }) => {
      return {
        query: input.query,
        results: [
          {
            videoId: "placeholder_1",
            title: "Sample Video 1",
            channel: "Sample Channel",
            url: `https://www.youtube.com/watch?v=placeholder_1`,
            thumbnail: "https://via.placeholder.com/120x90",
          },
        ],
        message: "YouTube integration requires API key configuration",
      };
    }),

  // Analysiere YouTube-Video
  analyzeVideo: protectedProcedure
    .input(z.object({
      videoUrl: z.string().url(),
      analysisType: z.enum(["transcript", "summary", "quotes", "full"]).default("full"),
    }))
    .mutation(async ({ input, ctx }) => {
      const db = await getDb();
      if (!db) throw new Error("Database unavailable");

      const [session] = await db.insert(youtubeResearch).values({
        userId: ctx.user?.id,
        videoUrl: input.videoUrl,
        query: input.analysisType,
        status: "pending",
      });

      return {
        sessionId: session.insertId,
        status: "pending",
        message: "Video analysis started. Results will be available shortly.",
      };
    }),

  // Hole Analyse-Ergebnisse
  getAnalysisResults: protectedProcedure
    .input(z.object({ sessionId: z.number() }))
    .query(async ({ input }) => {
      const db = await getDb();
      if (!db) throw new Error("Database unavailable");

      const result = await db
        .select()
        .from(youtubeResearch)
        .where(eq(youtubeResearch.id, input.sessionId))
        .limit(1);

      if (!result.length) throw new Error("Analysis not found");

      return result[0];
    }),

  // Extrahiere Zitate aus Transcript
  extractQuotes: publicProcedure
    .input(z.object({
      transcript: z.string(),
      maxQuotes: z.number().default(10),
    }))
    .query(({ input }) => {
      const sentences = input.transcript.split(/[.!?]+/).filter(s => s.trim().length > 20);
      const quotes = sentences.slice(0, input.maxQuotes).map((sentence, index) => ({
        id: index + 1,
        text: sentence.trim(),
        timestamp: `0:${String((index * 30) % 60).padStart(2, '0')}`,
      }));

      return {
        totalQuotes: quotes.length,
        quotes,
      };
    }),

  // Generiere Zusammenfassung aus Transcript
  summarizeTranscript: publicProcedure
    .input(z.object({
      transcript: z.string(),
      maxLength: z.number().default(500),
    }))
    .query(({ input }) => {
      const sentences = input.transcript.split(/[.!?]+/).filter(s => s.trim().length > 0);
      let summary = "";
      
      for (const sentence of sentences) {
        if ((summary + sentence).length < input.maxLength) {
          summary += sentence + ". ";
        } else {
          break;
        }
      }

      return {
        summary: summary.trim(),
        originalLength: input.transcript.length,
        summaryLength: summary.length,
        compressionRatio: ((1 - summary.length / input.transcript.length) * 100).toFixed(2) + "%",
      };
    }),

  // Vergleiche mehrere Videos
  compareVideos: protectedProcedure
    .input(z.object({
      videoUrls: z.array(z.string().url()).min(2).max(5),
    }))
    .query(async ({ input }) => {
      return {
        videosToCompare: input.videoUrls.length,
        message: "Video comparison feature coming soon",
        videos: input.videoUrls.map((url, index) => ({
          index: index + 1,
          url,
          status: "pending",
        })),
      };
    }),

  // Hole Analyse-Historie
  getAnalysisHistory: protectedProcedure
    .input(z.object({
      skip: z.number().default(0),
      take: z.number().default(20),
    }))
    .query(async ({ input, ctx }) => {
      const db = await getDb();
      if (!db) throw new Error("Database unavailable");

      const userId = ctx.user?.id || 0;
      const results = await db
        .select()
        .from(youtubeResearch)
        .where(eq(youtubeResearch.userId, userId))
        .limit(input.take)
        .offset(input.skip);

      return results;
    }),

  // Speichere Analyse-Ergebnisse
  saveAnalysisResults: protectedProcedure
    .input(z.object({
      sessionId: z.number(),
      transcript: z.string().optional(),
      analysis: z.record(z.string(), z.any()).optional(),
      quotes: z.array(z.string()).optional(),
    }))
    .mutation(async ({ input }) => {
      return {
        sessionId: input.sessionId,
        status: "saved",
        message: "Analysis results saved successfully",
      };
    }),
});
