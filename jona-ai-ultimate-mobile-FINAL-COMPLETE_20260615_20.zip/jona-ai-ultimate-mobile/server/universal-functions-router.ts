import { router, publicProcedure } from "./_core/trpc";
import { z } from "zod";
import * as universalFunctions from "@/lib/universal-functions";

/**
 * Universal Functions Router - Exponiert alle 274,405 Funktionen
 * aus 99 Repositories über tRPC API
 * 
 * Endpoints:
 * - universal.listAllModules() - Alle 69 Module auflisten
 * - universal.getModuleInfo() - Modul-Details
 * - universal.listModuleFunctions() - Funktionen eines Moduls
 * - universal.executeFunction() - Funktion ausführen
 * - universal.searchFunctions() - Funktionen suchen
 * - universal.getStatistics() - Gesamt-Statistiken
 */

export const universalFunctionsRouter = router({
  // 1. Alle Module auflisten
  listAllModules: publicProcedure.query(async () => {
    const stats = universalFunctions.getModuleStatistics();
    return {
      modules: stats.modules,
      total: stats.totalModules,
      totalFunctions: stats.totalFunctions,
      totalClasses: stats.totalClasses,
    };
  }),

  // 2. Modul-Informationen abrufen
  getModuleInfo: publicProcedure
    .input(z.object({ moduleName: z.string() }))
    .query(async ({ input }) => {
      const stats = universalFunctions.getModuleStatistics();
      const module = stats.modules.find((m) => m.name === input.moduleName);

      if (!module) {
        throw new Error(`Module ${input.moduleName} not found`);
      }

      return {
        name: module.name,
        functions: module.functions,
        classes: module.classes,
        files: module.files,
        description: `Module from ${module.name} repository`,
      };
    }),

  // 3. Funktionen eines Moduls auflisten
  listModuleFunctions: publicProcedure
    .input(
      z.object({
        moduleName: z.string(),
        skip: z.number().default(0),
        take: z.number().default(50),
      })
    )
    .query(async ({ input }) => {
      const allFunctions = universalFunctions.getAllFunctions();
      const moduleFunctions = allFunctions[input.moduleName] || [];

      const paginated = moduleFunctions.slice(
        input.skip,
        input.skip + input.take
      );

      return {
        module: input.moduleName,
        functions: paginated,
        total: moduleFunctions.length,
        skip: input.skip,
        take: input.take,
      };
    }),

  // 4. Funktion ausführen
  executeFunction: publicProcedure
    .input(
      z.object({
        moduleName: z.string(),
        functionName: z.string(),
        args: z.array(z.any()).optional(),
      })
    )
    .mutation(async ({ input }) => {
      try {
        const result = await universalFunctions.executeUniversalFunction(
          input.moduleName,
          input.functionName,
          input.args || []
        );

        return {
          success: true,
          result,
          module: input.moduleName,
          function: input.functionName,
        };
      } catch (error) {
        return {
          success: false,
          error: error instanceof Error ? error.message : "Unknown error",
          module: input.moduleName,
          function: input.functionName,
        };
      }
    }),

  // 5. Funktionen suchen
  searchFunctions: publicProcedure
    .input(
      z.object({
        query: z.string(),
        limit: z.number().default(20),
      })
    )
    .query(async ({ input }) => {
      const allFunctions = universalFunctions.getAllFunctions();
      const results: Array<{ module: string; function: string }> = [];

      const queryLower = input.query.toLowerCase();

      for (const [moduleName, functions] of Object.entries(allFunctions)) {
        for (const func of functions) {
          if (func.toLowerCase().includes(queryLower)) {
            results.push({
              module: moduleName,
              function: func,
            });

            if (results.length >= input.limit) {
              break;
            }
          }
        }

        if (results.length >= input.limit) {
          break;
        }
      }

      return {
        query: input.query,
        results: results.slice(0, input.limit),
        total: results.length,
      };
    }),

  // 6. Gesamt-Statistiken
  getStatistics: publicProcedure.query(async () => {
    const stats = universalFunctions.getModuleStatistics();
    const allFunctions = universalFunctions.getAllFunctions();

    const totalFunctionsCount = Object.values(allFunctions).reduce(
      (sum, funcs) => sum + funcs.length,
      0
    );

    return {
      totalModules: stats.totalModules,
      totalFunctions: stats.totalFunctions,
      totalClasses: stats.totalClasses,
      totalCodeFiles: 56792,
      sourceRepositories: 99,
      generatedAt: new Date().toISOString(),
      modules: stats.modules,
      moduleBreakdown: stats.modules.map((m) => ({
        name: m.name,
        functions: m.functions,
        classes: m.classes,
        files: m.files,
        functionDensity: (m.functions / Math.max(m.files, 1)).toFixed(2),
      })),
    };
  }),

  // 7. Batch-Ausführung
  batchExecute: publicProcedure
    .input(
      z.object({
        operations: z.array(
          z.object({
            moduleName: z.string(),
            functionName: z.string(),
            args: z.array(z.any()).optional(),
          })
        ),
      })
    )
    .mutation(async ({ input }) => {
      const results = [];

      for (const op of input.operations) {
        try {
          const result = await universalFunctions.executeUniversalFunction(
            op.moduleName,
            op.functionName,
            op.args || []
          );

          results.push({
            success: true,
            module: op.moduleName,
            function: op.functionName,
            result,
          });
        } catch (error) {
          results.push({
            success: false,
            module: op.moduleName,
            function: op.functionName,
            error: error instanceof Error ? error.message : "Unknown error",
          });
        }
      }

      return {
        total: input.operations.length,
        successful: results.filter((r) => r.success).length,
        failed: results.filter((r) => !r.success).length,
        results,
      };
    }),

  // 8. Top-Funktionen nach Modul
  getTopFunctions: publicProcedure
    .input(z.object({ limit: z.number().default(10) }))
    .query(async ({ input }) => {
      const stats = universalFunctions.getModuleStatistics();

      return {
        topModules: stats.modules
          .sort((a, b) => b.functions - a.functions)
          .slice(0, input.limit)
          .map((m) => ({
            name: m.name,
            functions: m.functions,
            classes: m.classes,
            percentageOfTotal: (
              (m.functions / stats.totalFunctions) *
              100
            ).toFixed(2),
          })),
      };
    }),

  // 9. Modul-Vergleich
  compareModules: publicProcedure
    .input(
      z.object({
        modules: z.array(z.string()),
      })
    )
    .query(async ({ input }) => {
      const stats = universalFunctions.getModuleStatistics();
      const comparison = [];

      for (const moduleName of input.modules) {
        const module = stats.modules.find((m) => m.name === moduleName);
        if (module) {
          comparison.push({
            name: module.name,
            functions: module.functions,
            classes: module.classes,
            files: module.files,
            avgFunctionsPerFile: (module.functions / module.files).toFixed(2),
            avgClassesPerFile: (module.classes / module.files).toFixed(2),
          });
        }
      }

      return {
        modules: comparison,
        comparison: {
          totalFunctions: comparison.reduce((sum, m) => sum + m.functions, 0),
          totalClasses: comparison.reduce((sum, m) => sum + m.classes, 0),
          totalFiles: comparison.reduce((sum, m) => sum + m.files, 0),
        },
      };
    }),
});

export default universalFunctionsRouter;
