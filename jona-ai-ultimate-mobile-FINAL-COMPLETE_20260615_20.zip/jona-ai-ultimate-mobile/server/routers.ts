import { router } from "./_core/trpc";
import { authRouter } from "./auth-router";
import { githubRouter } from "./github-router";
import { ttsRouter } from "./tts-router";
import { youtubeRouter } from "./youtube-router";
import { analyticsRouter } from "./analytics-router";
import { skillsRouter } from "./skills-router";
import { universalRouter } from "./universal-router";
import { analysisApiRouter } from "./analysis-api-router";
import { reportsRouter } from "./reports-router";
import { searchRouter } from "./search-router";
import { apiIntegrationRouter } from "./api-integration-router";

/**
 * This is the primary router for your app.
 * All routers should be merged here.
 */
export const appRouter = router({
  auth: authRouter,
  github: githubRouter,
  tts: ttsRouter,
  youtube: youtubeRouter,
  analytics: analyticsRouter,
  skills: skillsRouter,
  universal: universalRouter,
  analysis: analysisApiRouter,
  reports: reportsRouter,
  search: searchRouter,
  api: apiIntegrationRouter,
});

// export type definition of API
export type AppRouter = typeof appRouter;
