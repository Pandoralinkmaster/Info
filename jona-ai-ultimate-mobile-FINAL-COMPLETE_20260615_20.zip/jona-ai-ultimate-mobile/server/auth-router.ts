import { publicProcedure, protectedProcedure, router } from "./_core/trpc";
import { z } from "zod";
import type { Response } from "express";

declare global {
  namespace Express {
    interface Response {
      clearCookie(name: string): this;
    }
  }
}

export const authRouter = router({
  // Logout
  logout: protectedProcedure.mutation(async ({ ctx }) => {
    // Lösche Session-Cookie via Response
    if (ctx.res) {
      ctx.res.clearCookie("session");
    }
    return { success: true };
  }),

  // Hole aktuellen Benutzer
  me: protectedProcedure.query(({ ctx }) => {
    return ctx.user || null;
  }),

  // Überprüfe Auth-Status
  checkAuth: publicProcedure.query(({ ctx }) => {
    return {
      isAuthenticated: !!ctx.user,
      user: ctx.user || null,
    };
  }),
});
