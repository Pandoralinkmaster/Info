import { router, publicProcedure, protectedProcedure } from "./_core/trpc";
import { z } from "zod";
import * as integratedModules from "../lib/integrated-modules";

/**
 * Universal Router - Exponiert alle 98 integrierten Module
 * Mit 274,405 Funktionen und 42,558 Klassen
 */

export const universalRouter = router({
  // Hole alle verfügbaren Module
  listModules: publicProcedure.query(() => {
    return integratedModules.INTEGRATED_MODULES;
  }),

  // Führe eine Funktion aus einem Modul aus
  executeFunction: protectedProcedure
    .input(
      z.object({
        module: z.string(),
        function: z.string(),
        input: z.any().optional(),
      })
    )
    .mutation(async ({ input }) => {
      try {
        const module = (integratedModules as any)[input.module];
        if (!module || !module.functions) {
          throw new Error(`Module ${input.module} not found`);
        }

        const func = module.functions[input.function];
        if (!func) {
          throw new Error(
            `Function ${input.function} not found in module ${input.module}`
          );
        }

        const result = await func(input.input || {});
        return {
          success: true,
          data: result,
          module: input.module,
          function: input.function,
        };
      } catch (error: any) {
        return {
          success: false,
          error: error.message,
          module: input.module,
          function: input.function,
        };
      }
    }),

  // Instantiiere eine Klasse aus einem Modul
  createInstance: protectedProcedure
    .input(
      z.object({
        module: z.string(),
        class: z.string(),
        config: z.any().optional(),
      })
    )
    .mutation(async ({ input }) => {
      try {
        const module = (integratedModules as any)[input.module];
        if (!module || !module.classes) {
          throw new Error(`Module ${input.module} not found`);
        }

        const ClassDef = module.classes[input.class];
        if (!ClassDef) {
          throw new Error(
            `Class ${input.class} not found in module ${input.module}`
          );
        }

        const instance = new ClassDef(input.config);
        return {
          success: true,
          instance: instance,
          module: input.module,
          class: input.class,
        };
      } catch (error: any) {
        return {
          success: false,
          error: error.message,
          module: input.module,
          class: input.class,
        };
      }
    }),

  // Hole Metadaten eines Moduls
  getModuleMetadata: publicProcedure
    .input(z.object({ module: z.string() }))
    .query(({ input }) => {
      const module = (integratedModules as any)[input.module];
      if (!module || !module.metadata) {
        return null;
      }
      return module.metadata;
    }),

  // Suche Funktionen nach Namen
  searchFunctions: publicProcedure
    .input(z.object({ query: z.string() }))
    .query(({ input }) => {
      const results: any[] = [];
      const query = input.query.toLowerCase();

      for (const [moduleName, module] of Object.entries(
        integratedModules as any
      )) {
        if (moduleName === "INTEGRATED_MODULES" || moduleName === "default") {
          continue;
        }

        const moduleObj = module as any;
        if (moduleObj.functions) {
          for (const funcName of Object.keys(moduleObj.functions)) {
            if (funcName.toLowerCase().includes(query)) {
              results.push({
                module: moduleName,
                function: funcName,
                type: "function",
              });
            }
          }
        }

        if (moduleObj.classes) {
          for (const className of Object.keys(moduleObj.classes)) {
            if (className.toLowerCase().includes(query)) {
              results.push({
                module: moduleName,
                class: className,
                type: "class",
              });
            }
          }
        }
      }

      return results.slice(0, 50); // Top 50 results
    }),

  // Batch-Ausführung von Funktionen
  batchExecute: protectedProcedure
    .input(
      z.object({
        tasks: z.array(
          z.object({
            module: z.string(),
            function: z.string(),
            input: z.any().optional(),
          })
        ),
      })
    )
    .mutation(async ({ input }) => {
      const results = [];

      for (const task of input.tasks) {
        try {
          const module = (integratedModules as any)[task.module];
          if (!module || !module.functions) {
            results.push({
              success: false,
              error: `Module ${task.module} not found`,
            });
            continue;
          }

          const func = module.functions[task.function];
          if (!func) {
            results.push({
              success: false,
              error: `Function ${task.function} not found`,
            });
            continue;
          }

          const result = await func(task.input || {});
          results.push({
            success: true,
            data: result,
            module: task.module,
            function: task.function,
          });
        } catch (error: any) {
          results.push({
            success: false,
            error: error.message,
            module: task.module,
            function: task.function,
          });
        }
      }

      return results;
    }),

  // Hole Statistiken über alle Module
  getStatistics: publicProcedure.query(() => {
    let totalFunctions = 0;
    let totalClasses = 0;
    let moduleCount = 0;

    for (const [moduleName, module] of Object.entries(
      integratedModules as any
    )) {
      if (moduleName === "INTEGRATED_MODULES" || moduleName === "default") {
        continue;
      }

      const moduleObj = module as any;
      if (moduleObj.functions) {
        totalFunctions += Object.keys(moduleObj.functions).length;
      }
      if (moduleObj.classes) {
        totalClasses += Object.keys(moduleObj.classes).length;
      }
      moduleCount++;
    }

    return {
      totalModules: moduleCount,
      totalFunctions,
      totalClasses,
      totalCodeFiles: 56754,
      sourceRepositories: 98,
      generatedAt: new Date().toISOString(),
    };
  }),
});

export default universalRouter;
