import { ScrollView, Text, View, TextInput, TouchableOpacity, FlatList } from "react-native";
import { ScreenContainer } from "@/components/screen-container";
import { useState } from "react";
import MaterialIcons from "@expo/vector-icons/MaterialIcons";
import { useColors } from "@/hooks/use-colors";

interface Video {
  id: string;
  title: string;
  channel: string;
  duration: number;
  views: number;
  analyzed: boolean;
}

const MOCK_VIDEOS: Video[] = [
  {
    id: "1",
    title: "Introduction to Data Processing",
    channel: "Tech Academy",
    duration: 1200,
    views: 125000,
    analyzed: false,
  },
  {
    id: "2",
    title: "Security Analysis Best Practices",
    channel: "Security Experts",
    duration: 1800,
    views: 89000,
    analyzed: false,
  },
  {
    id: "3",
    title: "Network Tools Overview",
    channel: "Network Pro",
    duration: 900,
    views: 45000,
    analyzed: false,
  },
];

export default function YouTubeScreen() {
  const colors = useColors();
  const [searchText, setSearchText] = useState("");
  const [videos, setVideos] = useState(MOCK_VIDEOS);
  const [selectedVideo, setSelectedVideo] = useState<Video | null>(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [analysisResults, setAnalysisResults] = useState<any>(null);

  const filteredVideos = videos.filter(
    (video) =>
      video.title.toLowerCase().includes(searchText.toLowerCase()) ||
      video.channel.toLowerCase().includes(searchText.toLowerCase())
  );

  const handleAnalyze = async (video: Video) => {
    setSelectedVideo(video);
    setIsAnalyzing(true);

    setTimeout(() => {
      setAnalysisResults({
        videoId: video.id,
        title: video.title,
        transcriptLength: Math.floor(Math.random() * 5000) + 1000,
        quotes: Math.floor(Math.random() * 20) + 5,
        keyTopics: ["Data Processing", "Security", "Analysis", "Best Practices"],
        sentiment: "positive",
        summary: "This video provides comprehensive insights into the topic with practical examples.",
      });

      setVideos(
        videos.map((v) => (v.id === video.id ? { ...v, analyzed: true } : v))
      );
      setIsAnalyzing(false);
    }, 2000);
  };

  const formatDuration = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    return `${mins}m`;
  };

  return (
    <ScreenContainer className="p-0">
      <ScrollView contentContainerStyle={{ flexGrow: 1 }} className="flex-1">
        {/* Header */}
        <View className="bg-red-600 px-4 py-6">
          <Text className="text-2xl font-bold text-white mb-1">YouTube Research</Text>
          <Text className="text-sm text-red-100">Analysiere Videos und extrahiere Insights</Text>
        </View>

        {/* Search */}
        <View className="px-4 py-4 gap-3">
          <View className="flex-row items-center bg-surface border border-border rounded-lg px-3 py-2">
            <MaterialIcons name="search" size={20} color={colors.muted} />
            <TextInput
              placeholder="Video suchen..."
              placeholderTextColor={colors.muted}
              value={searchText}
              onChangeText={setSearchText}
              className="flex-1 ml-2 text-foreground"
            />
          </View>

          <View className="flex-row gap-2">
            <TouchableOpacity className="flex-1 bg-red-600 rounded-lg py-2 px-3 flex-row items-center justify-center gap-2">
              <MaterialIcons name="search" size={18} color="white" />
              <Text className="text-white font-semibold text-sm">Search</Text>
            </TouchableOpacity>
            <TouchableOpacity className="flex-1 bg-surface border border-border rounded-lg py-2 px-3 flex-row items-center justify-center gap-2">
              <MaterialIcons name="history" size={18} color={colors.foreground} />
              <Text className="text-foreground font-semibold text-sm">History</Text>
            </TouchableOpacity>
          </View>
        </View>

        {/* Videos List */}
        <View className="flex-1 px-4 pb-4">
          <Text className="text-sm font-semibold text-muted mb-3">
            {filteredVideos.length} Videos
          </Text>

          <FlatList
            scrollEnabled={false}
            data={filteredVideos}
            keyExtractor={(item) => item.id}
            renderItem={({ item }) => (
              <TouchableOpacity onPress={() => handleAnalyze(item)}>
                <View className="bg-surface border border-border rounded-lg p-3 mb-3">
                  <View className="flex-row items-start justify-between mb-2">
                    <View className="flex-1">
                      <Text className="text-sm font-semibold text-foreground">
                        {item.title}
                      </Text>
                      <Text className="text-xs text-muted mt-1">{item.channel}</Text>
                    </View>
                    {item.analyzed && (
                      <View className="bg-green-100 rounded px-2 py-1 ml-2">
                        <MaterialIcons name="check-circle" size={16} color="#16a34a" />
                      </View>
                    )}
                  </View>
                  <View className="flex-row items-center justify-between">
                    <View className="flex-row gap-3 text-xs text-muted">
                      <Text className="text-xs text-muted">
                        {formatDuration(item.duration)}
                      </Text>
                      <Text className="text-xs text-muted">
                        {(item.views / 1000).toFixed(0)}K views
                      </Text>
                    </View>
                    <TouchableOpacity
                      onPress={() => handleAnalyze(item)}
                      className="bg-red-600 rounded px-3 py-1"
                    >
                      <Text className="text-xs font-semibold text-white">
                        {item.analyzed ? "Re-analyze" : "Analyze"}
                      </Text>
                    </TouchableOpacity>
                  </View>
                </View>
              </TouchableOpacity>
            )}
          />
        </View>

        {/* Analysis Results */}
        {analysisResults && (
          <View className="px-4 pb-4 bg-surface border-t border-border">
            <View className="bg-red-50 border border-red-200 rounded-lg p-4 mt-4">
              <View className="flex-row items-center gap-2 mb-3">
                {isAnalyzing ? (
                  <MaterialIcons name="hourglass-empty" size={20} color="#dc2626" />
                ) : (
                  <MaterialIcons name="check-circle" size={20} color="#16a34a" />
                )}
                <Text className="font-semibold text-red-900">
                  {isAnalyzing ? "Analyzing..." : "Analysis Complete"}
                </Text>
              </View>

              {!isAnalyzing && (
                <View className="gap-2">
                  <View className="flex-row items-center justify-between">
                    <Text className="text-sm text-red-800">Transcript</Text>
                    <Text className="text-sm font-semibold text-red-900">
                      {analysisResults.transcriptLength} chars
                    </Text>
                  </View>
                  <View className="flex-row items-center justify-between">
                    <Text className="text-sm text-red-800">Quotes</Text>
                    <Text className="text-sm font-semibold text-red-900">
                      {analysisResults.quotes}
                    </Text>
                  </View>
                  <View className="flex-row items-center justify-between">
                    <Text className="text-sm text-red-800">Sentiment</Text>
                    <Text className="text-sm font-semibold text-red-900">
                      {analysisResults.sentiment}
                    </Text>
                  </View>
                  <View className="mt-2">
                    <Text className="text-xs text-red-700 font-semibold mb-1">Key Topics:</Text>
                    <View className="flex-row flex-wrap gap-1">
                      {analysisResults.keyTopics.map((topic: string, idx: number) => (
                        <View key={idx} className="bg-red-200 rounded px-2 py-1">
                          <Text className="text-xs text-red-800">{topic}</Text>
                        </View>
                      ))}
                    </View>
                  </View>
                </View>
              )}
            </View>
          </View>
        )}
      </ScrollView>
    </ScreenContainer>
  );
}
