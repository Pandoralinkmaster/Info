import { useState, useEffect, useMemo } from 'react';
import { ScrollView, Text, View, TextInput, Pressable, FlatList, ActivityIndicator } from 'react-native';
import { ScreenContainer } from '@/components/screen-container';
import { useColors } from '@/hooks/use-colors';
import { trpc } from '@/lib/trpc';

interface SearchResult {
  id: string;
  name: string;
  type: 'function' | 'class' | 'module';
  repository: string;
  language: string;
  relevance: number;
  preview?: string;
}

export default function SearchScreen() {
  const colors = useColors();
  const [query, setQuery] = useState('');
  const [results, setResults] = useState<SearchResult[]>([]);
  const [loading, setLoading] = useState(false);
  const [filters, setFilters] = useState({
    language: 'all',
    type: 'all',
    repository: 'all'
  });

  // Simuliere Full-Text-Suche über alle 274,405 Funktionen
  const performSearch = async (searchQuery: string) => {
    if (!searchQuery.trim()) {
      setResults([]);
      return;
    }

    setLoading(true);
    try {
      // In Produktion würde dies die echte API aufrufen
      // const response = await trpc.search.fullText.query({ query: searchQuery, filters });
      
      // Simulierte Ergebnisse
      const mockResults: SearchResult[] = [
        {
          id: '1',
          name: 'parseJavaFile',
          type: 'function',
          repository: 'NationalSecurityAgency/ghidra',
          language: 'java',
          relevance: 0.95,
          preview: 'public static void parseJavaFile(String path) { ... }'
        },
        {
          id: '2',
          name: 'DataProcessor',
          type: 'class',
          repository: 'NationalSecurityAgency/datawave',
          language: 'java',
          relevance: 0.87,
          preview: 'public class DataProcessor implements Processor { ... }'
        },
        {
          id: '3',
          name: 'analyzeCode',
          type: 'function',
          repository: 'ozoneplatform/owf-framework',
          language: 'javascript',
          relevance: 0.82,
          preview: 'function analyzeCode(source) { ... }'
        }
      ];

      // Filtere nach Query
      const filtered = mockResults.filter(r => 
        r.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        r.repository.toLowerCase().includes(searchQuery.toLowerCase())
      );

      setResults(filtered);
    } catch (error) {
      console.error('Search error:', error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    const timer = setTimeout(() => {
      performSearch(query);
    }, 300);

    return () => clearTimeout(timer);
  }, [query, filters]);

  const renderResult = ({ item }: { item: SearchResult }) => (
    <Pressable
      style={({ pressed }) => [
        {
          backgroundColor: colors.surface,
          borderRadius: 12,
          padding: 12,
          marginBottom: 8,
          opacity: pressed ? 0.7 : 1,
          borderLeftWidth: 4,
          borderLeftColor: 
            item.type === 'function' ? colors.primary :
            item.type === 'class' ? '#10b981' :
            '#f59e0b'
        }
      ]}
    >
      <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-start' }}>
        <View style={{ flex: 1 }}>
          <Text style={{ fontSize: 16, fontWeight: '600', color: colors.foreground }}>
            {item.name}
          </Text>
          <Text style={{ fontSize: 12, color: colors.muted, marginTop: 4 }}>
            {item.repository} • {item.language}
          </Text>
          {item.preview && (
            <Text 
              style={{ fontSize: 11, color: colors.muted, marginTop: 4, fontFamily: 'monospace' }}
              numberOfLines={2}
            >
              {item.preview}
            </Text>
          )}
        </View>
        <View style={{ marginLeft: 8, alignItems: 'flex-end' }}>
          <Text style={{ fontSize: 12, fontWeight: '600', color: colors.primary }}>
            {Math.round(item.relevance * 100)}%
          </Text>
          <Text style={{ fontSize: 10, color: colors.muted, marginTop: 2 }}>
            {item.type}
          </Text>
        </View>
      </View>
    </Pressable>
  );

  return (
    <ScreenContainer className="p-4">
      <ScrollView contentContainerStyle={{ flexGrow: 1 }}>
        <View className="gap-4">
          {/* Header */}
          <View className="gap-2">
            <Text className="text-3xl font-bold text-foreground">
              Advanced Search
            </Text>
            <Text className="text-sm text-muted">
              Durchsuche alle 274,405 Funktionen aus 163 Repositories
            </Text>
          </View>

          {/* Search Input */}
          <View className="gap-2">
            <TextInput
              placeholder="Suche nach Funktionen, Klassen, Repositories..."
              placeholderTextColor={colors.muted}
              value={query}
              onChangeText={setQuery}
              style={{
                backgroundColor: colors.surface,
                borderColor: colors.border,
                borderWidth: 1,
                borderRadius: 8,
                padding: 12,
                color: colors.foreground,
                fontSize: 14
              }}
            />
          </View>

          {/* Filter Buttons */}
          <View className="gap-2">
            <Text className="text-sm font-semibold text-foreground">Filter:</Text>
            <View className="flex-row gap-2 flex-wrap">
              {['all', 'java', 'javascript', 'python', 'c'].map(lang => (
                <Pressable
                  key={lang}
                  onPress={() => setFilters({ ...filters, language: lang })}
                  style={({ pressed }) => [
                    {
                      backgroundColor: filters.language === lang ? colors.primary : colors.surface,
                      borderRadius: 6,
                      paddingHorizontal: 12,
                      paddingVertical: 6,
                      opacity: pressed ? 0.8 : 1
                    }
                  ]}
                >
                  <Text style={{
                    color: filters.language === lang ? '#fff' : colors.foreground,
                    fontSize: 12,
                    fontWeight: '500'
                  }}>
                    {lang === 'all' ? 'Alle Sprachen' : lang.toUpperCase()}
                  </Text>
                </Pressable>
              ))}
            </View>
          </View>

          {/* Results */}
          <View className="gap-2">
            {loading ? (
              <View className="items-center justify-center py-8">
                <ActivityIndicator size="large" color={colors.primary} />
              </View>
            ) : query.trim() ? (
              <>
                <Text className="text-sm font-semibold text-foreground">
                  {results.length} Ergebnisse gefunden
                </Text>
                <FlatList
                  data={results}
                  renderItem={renderResult}
                  keyExtractor={item => item.id}
                  scrollEnabled={false}
                />
              </>
            ) : (
              <View className="items-center justify-center py-12">
                <Text className="text-center text-muted">
                  Geben Sie einen Suchbegriff ein, um zu beginnen
                </Text>
              </View>
            )}
          </View>
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}
