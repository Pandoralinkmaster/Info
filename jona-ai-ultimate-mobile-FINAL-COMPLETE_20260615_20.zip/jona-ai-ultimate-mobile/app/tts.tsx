import { ScrollView, Text, View, TextInput, TouchableOpacity, FlatList, Modal, Pressable } from "react-native";
import { ScreenContainer } from "@/components/screen-container";
import { useState } from "react";
import MaterialIcons from "@expo/vector-icons/MaterialIcons";
import { useColors } from "@/hooks/use-colors";

const VOICES = ["Zephyr", "Puck", "Charon", "Kore", "Fenrir", "Leda", "Orus", "Aoede", "Callirrhoe", "Autonoe"];
const LANGUAGES = [
  { code: "en-US", name: "English (US)" },
  { code: "de-DE", name: "German" },
  { code: "fr-FR", name: "French" },
  { code: "es-ES", name: "Spanish" },
  { code: "ja-JP", name: "Japanese" },
  { code: "zh-CN", name: "Chinese" },
  { code: "pt-BR", name: "Portuguese (Brazil)" },
  { code: "it-IT", name: "Italian" },
];

export default function TTSScreen() {
  const colors = useColors();
  const [prompt, setPrompt] = useState("");
  const [selectedVoice, setSelectedVoice] = useState("Zephyr");
  const [selectedLanguage, setSelectedLanguage] = useState("en-US");
  const [isGenerating, setIsGenerating] = useState(false);
  const [generatedAudios, setGeneratedAudios] = useState<any[]>([]);
  const [showVoicePicker, setShowVoicePicker] = useState(false);
  const [showLanguagePicker, setShowLanguagePicker] = useState(false);

  const handleGenerate = async () => {
    if (!prompt.trim()) return;

    setIsGenerating(true);
    setTimeout(() => {
      setGeneratedAudios([
        ...generatedAudios,
        {
          id: Date.now(),
          prompt: prompt.substring(0, 50) + (prompt.length > 50 ? "..." : ""),
          voice: selectedVoice,
          language: selectedLanguage,
          duration: Math.floor(Math.random() * 300) + 30,
        },
      ]);
      setPrompt("");
      setIsGenerating(false);
    }, 2000);
  };

  return (
    <ScreenContainer className="p-0">
      <ScrollView contentContainerStyle={{ flexGrow: 1 }} className="flex-1">
        {/* Header */}
        <View className="bg-purple-600 px-4 py-6">
          <Text className="text-2xl font-bold text-white mb-1">TTS Generator</Text>
          <Text className="text-sm text-purple-100">30 Stimmen • 70+ Sprachen</Text>
        </View>

        {/* Input Section */}
        <View className="px-4 py-6 gap-4">
          {/* Prompt Input */}
          <View>
            <Text className="text-sm font-semibold text-foreground mb-2">Text eingeben</Text>
            <TextInput
              placeholder="Geben Sie den Text ein, der gesprochen werden soll..."
              placeholderTextColor={colors.muted}
              value={prompt}
              onChangeText={setPrompt}
              multiline
              numberOfLines={4}
              className="bg-surface border border-border rounded-lg px-3 py-2 text-foreground"
            />
            <Text className="text-xs text-muted mt-1">{prompt.length} / 5000 Zeichen</Text>
          </View>

          {/* Voice Selection */}
          <View>
            <Text className="text-sm font-semibold text-foreground mb-2">Stimme</Text>
            <Pressable
              onPress={() => setShowVoicePicker(true)}
              className="bg-surface border border-border rounded-lg px-3 py-2 flex-row items-center justify-between"
            >
              <Text className="text-foreground">{selectedVoice}</Text>
              <MaterialIcons name="expand-more" size={20} color={colors.muted} />
            </Pressable>
          </View>

          {/* Language Selection */}
          <View>
            <Text className="text-sm font-semibold text-foreground mb-2">Sprache</Text>
            <Pressable
              onPress={() => setShowLanguagePicker(true)}
              className="bg-surface border border-border rounded-lg px-3 py-2 flex-row items-center justify-between"
            >
              <Text className="text-foreground">
                {LANGUAGES.find((l) => l.code === selectedLanguage)?.name}
              </Text>
              <MaterialIcons name="expand-more" size={20} color={colors.muted} />
            </Pressable>
          </View>

          {/* Generate Button */}
          <TouchableOpacity
            disabled={!prompt.trim() || isGenerating}
            onPress={handleGenerate}
            className={`rounded-lg py-3 px-4 flex-row items-center justify-center gap-2 ${
              isGenerating || !prompt.trim() ? "bg-gray-400" : "bg-purple-600"
            }`}
          >
            {isGenerating ? (
              <>
                <MaterialIcons name="hourglass-empty" size={20} color="white" />
                <Text className="text-white font-semibold">Generiere...</Text>
              </>
            ) : (
              <>
                <MaterialIcons name="mic" size={20} color="white" />
                <Text className="text-white font-semibold">Audio generieren</Text>
              </>
            )}
          </TouchableOpacity>
        </View>

        {/* Generated Audios */}
        {generatedAudios.length > 0 && (
          <View className="px-4 pb-4">
            <Text className="text-sm font-semibold text-foreground mb-3">
              Generierte Audios ({generatedAudios.length})
            </Text>
            <FlatList
              scrollEnabled={false}
              data={generatedAudios}
              keyExtractor={(item) => item.id.toString()}
              renderItem={({ item }) => (
                <View className="bg-surface border border-border rounded-lg p-3 mb-3 flex-row items-center justify-between">
                  <View className="flex-1">
                    <Text className="text-sm font-semibold text-foreground truncate">
                      {item.prompt}
                    </Text>
                    <Text className="text-xs text-muted mt-1">
                      {item.voice} • {item.language} • {item.duration}s
                    </Text>
                  </View>
                  <View className="flex-row gap-2">
                    <TouchableOpacity className="bg-purple-600 rounded-lg p-2">
                      <MaterialIcons name="play-arrow" size={20} color="white" />
                    </TouchableOpacity>
                    <TouchableOpacity className="bg-surface border border-border rounded-lg p-2">
                      <MaterialIcons name="download" size={20} color={colors.foreground} />
                    </TouchableOpacity>
                  </View>
                </View>
              )}
            />
          </View>
        )}
      </ScrollView>

      {/* Voice Picker Modal */}
      <Modal visible={showVoicePicker} transparent animationType="slide">
        <View className="flex-1 bg-black/50 justify-end">
          <View className="bg-surface rounded-t-2xl p-4 max-h-96">
            <View className="flex-row items-center justify-between mb-4">
              <Text className="text-lg font-semibold text-foreground">Stimme wählen</Text>
              <Pressable onPress={() => setShowVoicePicker(false)}>
                <MaterialIcons name="close" size={24} color={colors.foreground} />
              </Pressable>
            </View>
            <ScrollView>
              {VOICES.map((voice) => (
                <Pressable
                  key={voice}
                  onPress={() => {
                    setSelectedVoice(voice);
                    setShowVoicePicker(false);
                  }}
                  className={`py-3 px-4 border-b border-border ${
                    selectedVoice === voice ? "bg-purple-100" : ""
                  }`}
                >
                  <Text
                    className={selectedVoice === voice ? "text-purple-600 font-semibold" : "text-foreground"}
                  >
                    {voice}
                  </Text>
                </Pressable>
              ))}
            </ScrollView>
          </View>
        </View>
      </Modal>

      {/* Language Picker Modal */}
      <Modal visible={showLanguagePicker} transparent animationType="slide">
        <View className="flex-1 bg-black/50 justify-end">
          <View className="bg-surface rounded-t-2xl p-4 max-h-96">
            <View className="flex-row items-center justify-between mb-4">
              <Text className="text-lg font-semibold text-foreground">Sprache wählen</Text>
              <Pressable onPress={() => setShowLanguagePicker(false)}>
                <MaterialIcons name="close" size={24} color={colors.foreground} />
              </Pressable>
            </View>
            <ScrollView>
              {LANGUAGES.map((lang) => (
                <Pressable
                  key={lang.code}
                  onPress={() => {
                    setSelectedLanguage(lang.code);
                    setShowLanguagePicker(false);
                  }}
                  className={`py-3 px-4 border-b border-border ${
                    selectedLanguage === lang.code ? "bg-purple-100" : ""
                  }`}
                >
                  <Text
                    className={
                      selectedLanguage === lang.code ? "text-purple-600 font-semibold" : "text-foreground"
                    }
                  >
                    {lang.name}
                  </Text>
                </Pressable>
              ))}
            </ScrollView>
          </View>
        </View>
      </Modal>
    </ScreenContainer>
  );
}
