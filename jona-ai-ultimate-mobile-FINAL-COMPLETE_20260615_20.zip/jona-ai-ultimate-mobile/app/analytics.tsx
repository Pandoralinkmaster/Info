import { ScrollView, Text, View, TextInput, TouchableOpacity, FlatList } from "react-native";
import { ScreenContainer } from "@/components/screen-container";
import { useState } from "react";
import MaterialIcons from "@expo/vector-icons/MaterialIcons";
import { useColors } from "@/hooks/use-colors";

interface AnalysisResult {
  id: string;
  domain: string;
  globalRank: number;
  totalVisits: number;
  bounceRate: number;
  analyzed: boolean;
}

const MOCK_RESULTS: AnalysisResult[] = [
  {
    id: "1",
    domain: "github.com",
    globalRank: 52,
    totalVisits: 5000000,
    bounceRate: 35.2,
    analyzed: true,
  },
  {
    id: "2",
    domain: "stackoverflow.com",
    globalRank: 87,
    totalVisits: 3500000,
    bounceRate: 42.1,
    analyzed: true,
  },
];

export default function AnalyticsScreen() {
  const colors = useColors();
  const [domainInput, setDomainInput] = useState("");
  const [results, setResults] = useState(MOCK_RESULTS);
  const [selectedResult, setSelectedResult] = useState<AnalysisResult | null>(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [detailedData, setDetailedData] = useState<any>(null);

  const handleAnalyze = async () => {
    if (!domainInput.trim()) return;

    setIsAnalyzing(true);

    setTimeout(() => {
      const newResult: AnalysisResult = {
        id: Date.now().toString(),
        domain: domainInput,
        globalRank: Math.floor(Math.random() * 10000),
        totalVisits: Math.floor(Math.random() * 10000000),
        bounceRate: Math.random() * 100,
        analyzed: true,
      };

      setResults([newResult, ...results]);
      setSelectedResult(newResult);

      setDetailedData({
        domain: domainInput,
        trafficSources: [
          { source: "Organic Search", percentage: 45.2 },
          { source: "Direct", percentage: 25.1 },
          { source: "Referral", percentage: 15.3 },
          { source: "Paid Search", percentage: 8.4 },
          { source: "Social Media", percentage: 4.2 },
          { source: "Display Ads", percentage: 1.8 },
        ],
        countries: [
          { country: "United States", percentage: 35.2 },
          { country: "United Kingdom", percentage: 12.1 },
          { country: "Canada", percentage: 8.3 },
          { country: "Australia", percentage: 6.7 },
          { country: "Germany", percentage: 5.4 },
        ],
        engagement: {
          pagesPerVisit: (Math.random() * 10).toFixed(2),
          avgVisitDuration: Math.floor(Math.random() * 600),
          returnVisitorRate: (Math.random() * 100).toFixed(2),
        },
      });

      setDomainInput("");
      setIsAnalyzing(false);
    }, 2000);
  };

  const formatNumber = (num: number) => {
    if (num >= 1000000) return (num / 1000000).toFixed(1) + "M";
    if (num >= 1000) return (num / 1000).toFixed(1) + "K";
    return num.toString();
  };

  return (
    <ScreenContainer className="p-0">
      <ScrollView contentContainerStyle={{ flexGrow: 1 }} className="flex-1">
        {/* Header */}
        <View className="bg-green-600 px-4 py-6">
          <Text className="text-2xl font-bold text-white mb-1">Analytics</Text>
          <Text className="text-sm text-green-100">Website Traffic & Insights</Text>
        </View>

        {/* Input Section */}
        <View className="px-4 py-4 gap-3">
          <View className="flex-row gap-2">
            <View className="flex-1 flex-row items-center bg-surface border border-border rounded-lg px-3 py-2">
              <MaterialIcons name="language" size={20} color={colors.muted} />
              <TextInput
                placeholder="Domain eingeben..."
                placeholderTextColor={colors.muted}
                value={domainInput}
                onChangeText={setDomainInput}
                className="flex-1 ml-2 text-foreground"
              />
            </View>
            <TouchableOpacity
              disabled={!domainInput.trim() || isAnalyzing}
              onPress={handleAnalyze}
              className={`rounded-lg px-4 items-center justify-center ${
                isAnalyzing || !domainInput.trim() ? "bg-gray-400" : "bg-green-600"
              }`}
            >
              <MaterialIcons
                name={isAnalyzing ? "hourglass-empty" : "search"}
                size={20}
                color="white"
              />
            </TouchableOpacity>
          </View>

          <View className="flex-row gap-2">
            <TouchableOpacity className="flex-1 bg-surface border border-border rounded-lg py-2 px-3 flex-row items-center justify-center gap-2">
              <MaterialIcons name="download" size={18} color={colors.foreground} />
              <Text className="text-foreground font-semibold text-sm">Export</Text>
            </TouchableOpacity>
            <TouchableOpacity className="flex-1 bg-surface border border-border rounded-lg py-2 px-3 flex-row items-center justify-center gap-2">
              <MaterialIcons name="compare-arrows" size={18} color={colors.foreground} />
              <Text className="text-foreground font-semibold text-sm">Compare</Text>
            </TouchableOpacity>
          </View>
        </View>

        {/* Results List */}
        {results.length > 0 && (
          <View className="px-4 pb-4">
            <Text className="text-sm font-semibold text-muted mb-3">Recent Analyses</Text>

            <FlatList
              scrollEnabled={false}
              data={results}
              keyExtractor={(item) => item.id}
              renderItem={({ item }) => (
                <TouchableOpacity onPress={() => setSelectedResult(item)}>
                  <View className="bg-surface border border-border rounded-lg p-3 mb-3">
                    <View className="flex-row items-center justify-between mb-2">
                      <Text className="text-sm font-semibold text-foreground">
                        {item.domain}
                      </Text>
                      <View className="bg-green-100 rounded px-2 py-1">
                        <Text className="text-xs font-semibold text-green-700">
                          #{item.globalRank}
                        </Text>
                      </View>
                    </View>

                    <View className="gap-2">
                      <View className="flex-row items-center justify-between">
                        <Text className="text-xs text-muted">Total Visits</Text>
                        <Text className="text-xs font-semibold text-foreground">
                          {formatNumber(item.totalVisits)}
                        </Text>
                      </View>
                      <View className="flex-row items-center justify-between">
                        <Text className="text-xs text-muted">Bounce Rate</Text>
                        <Text className="text-xs font-semibold text-foreground">
                          {item.bounceRate.toFixed(1)}%
                        </Text>
                      </View>
                    </View>
                  </View>
                </TouchableOpacity>
              )}
            />
          </View>
        )}

        {/* Detailed Analysis */}
        {detailedData && (
          <View className="px-4 pb-4 bg-surface border-t border-border">
            <View className="mt-4">
              <Text className="text-lg font-semibold text-foreground mb-3">
                {detailedData.domain}
              </Text>

              {/* Traffic Sources */}
              <View className="mb-4">
                <Text className="text-sm font-semibold text-foreground mb-2">Traffic Sources</Text>
                {detailedData.trafficSources.map((source: any, idx: number) => (
                  <View key={idx} className="flex-row items-center justify-between mb-2">
                    <Text className="text-xs text-muted flex-1">{source.source}</Text>
                    <View className="flex-1 bg-gray-200 rounded-full h-2 mx-2">
                      <View
                        className="bg-green-600 h-2 rounded-full"
                        style={{ width: `${source.percentage}%` }}
                      />
                    </View>
                    <Text className="text-xs font-semibold text-foreground w-10 text-right">
                      {source.percentage.toFixed(1)}%
                    </Text>
                  </View>
                ))}
              </View>

              {/* Top Countries */}
              <View className="mb-4">
                <Text className="text-sm font-semibold text-foreground mb-2">Top Countries</Text>
                {detailedData.countries.map((country: any, idx: number) => (
                  <View key={idx} className="flex-row items-center justify-between mb-1">
                    <Text className="text-xs text-muted">{country.country}</Text>
                    <Text className="text-xs font-semibold text-foreground">
                      {country.percentage.toFixed(1)}%
                    </Text>
                  </View>
                ))}
              </View>

              {/* Engagement Metrics */}
              <View className="bg-green-50 border border-green-200 rounded-lg p-3">
                <Text className="text-sm font-semibold text-green-900 mb-2">
                  Engagement Metrics
                </Text>
                <View className="gap-1">
                  <View className="flex-row items-center justify-between">
                    <Text className="text-xs text-green-800">Pages/Visit</Text>
                    <Text className="text-xs font-semibold text-green-900">
                      {detailedData.engagement.pagesPerVisit}
                    </Text>
                  </View>
                  <View className="flex-row items-center justify-between">
                    <Text className="text-xs text-green-800">Avg Duration</Text>
                    <Text className="text-xs font-semibold text-green-900">
                      {detailedData.engagement.avgVisitDuration}s
                    </Text>
                  </View>
                  <View className="flex-row items-center justify-between">
                    <Text className="text-xs text-green-800">Return Visitors</Text>
                    <Text className="text-xs font-semibold text-green-900">
                      {detailedData.engagement.returnVisitorRate}%
                    </Text>
                  </View>
                </View>
              </View>
            </View>
          </View>
        )}
      </ScrollView>
    </ScreenContainer>
  );
}
