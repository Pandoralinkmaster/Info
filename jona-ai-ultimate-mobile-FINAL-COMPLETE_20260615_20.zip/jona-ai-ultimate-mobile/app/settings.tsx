import { useState, useEffect } from 'react';
import { ScrollView, Text, View, Pressable, Switch, TextInput, ActivityIndicator } from 'react-native';
import { ScreenContainer } from '@/components/screen-container';
import { useColors } from '@/hooks/use-colors';
import { getCacheStats, clearAllCache } from '@/hooks/use-offline-cache';

export default function SettingsScreen() {
  const colors = useColors();
  const [cacheStats, setCacheStats] = useState<any>(null);
  const [loading, setLoading] = useState(false);
  const [apiKeys, setApiKeys] = useState({
    youtube: '',
    similarweb: '',
    github: ''
  });
  const [settings, setSettings] = useState({
    offlineMode: false,
    autoCache: true,
    cacheExpiry: 3600,
    darkMode: true,
    notifications: true
  });

  useEffect(() => {
    loadCacheStats();
  }, []);

  const loadCacheStats = async () => {
    try {
      const stats = await getCacheStats();
      setCacheStats(stats);
    } catch (error) {
      console.error('Error loading cache stats:', error);
    }
  };

  const handleClearCache = async () => {
    setLoading(true);
    try {
      await clearAllCache();
      setCacheStats({ totalSize: 0, itemCount: 0, items: [] });
    } catch (error) {
      console.error('Error clearing cache:', error);
    } finally {
      setLoading(false);
    }
  };

  const formatBytes = (bytes: number) => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return Math.round(bytes / Math.pow(k, i) * 100) / 100 + ' ' + sizes[i];
  };

  return (
    <ScreenContainer className="p-4">
      <ScrollView contentContainerStyle={{ flexGrow: 1 }}>
        <View className="gap-6">
          {/* Header */}
          <View className="gap-2">
            <Text className="text-3xl font-bold text-foreground">
              Einstellungen
            </Text>
            <Text className="text-sm text-muted">
              Konfiguriere die App nach deinen Wünschen
            </Text>
          </View>

          {/* API Keys Section */}
          <View className="gap-3">
            <Text className="text-lg font-semibold text-foreground">API-Schlüssel</Text>
            
            {[
              { key: 'youtube', label: 'YouTube API Key', placeholder: 'sk-...' },
              { key: 'similarweb', label: 'SimilarWeb API Key', placeholder: 'sw-...' },
              { key: 'github', label: 'GitHub Token', placeholder: 'ghp_...' }
            ].map(({ key, label, placeholder }) => (
              <View key={key} className="gap-2">
                <Text className="text-sm font-medium text-foreground">{label}</Text>
                <TextInput
                  placeholder={placeholder}
                  placeholderTextColor={colors.muted}
                  value={apiKeys[key as keyof typeof apiKeys]}
                  onChangeText={(text) => setApiKeys({ ...apiKeys, [key]: text })}
                  secureTextEntry
                  style={{
                    backgroundColor: colors.surface,
                    borderColor: colors.border,
                    borderWidth: 1,
                    borderRadius: 8,
                    padding: 12,
                    color: colors.foreground,
                    fontSize: 14
                  }}
                />
              </View>
            ))}
          </View>

          {/* Settings Section */}
          <View className="gap-3">
            <Text className="text-lg font-semibold text-foreground">Allgemeine Einstellungen</Text>
            
            {[
              { key: 'offlineMode', label: 'Offline-Modus', description: 'Verwende gecachte Daten offline' },
              { key: 'autoCache', label: 'Auto-Caching', description: 'Cache Daten automatisch' },
              { key: 'darkMode', label: 'Dark Mode', description: 'Dunkles Design verwenden' },
              { key: 'notifications', label: 'Benachrichtigungen', description: 'Push-Benachrichtigungen aktivieren' }
            ].map(({ key, label, description }) => (
              <View
                key={key}
                style={{
                  backgroundColor: colors.surface,
                  borderRadius: 8,
                  padding: 12,
                  flexDirection: 'row',
                  justifyContent: 'space-between',
                  alignItems: 'center'
                }}
              >
                <View className="flex-1">
                  <Text className="text-sm font-medium text-foreground">{label}</Text>
                  <Text className="text-xs text-muted mt-1">{description}</Text>
                </View>
                <Switch
                  value={settings[key as keyof typeof settings] as boolean}
                  onValueChange={(value) =>
                    setSettings({ ...settings, [key]: value })
                  }
                  trackColor={{ false: colors.border, true: colors.primary }}
                />
              </View>
            ))}
          </View>

          {/* Cache Section */}
          <View className="gap-3">
            <Text className="text-lg font-semibold text-foreground">Cache-Verwaltung</Text>
            
            {cacheStats ? (
              <View style={{ backgroundColor: colors.surface, borderRadius: 8, padding: 12, gap: 8 }}>
                <View style={{ flexDirection: 'row', justifyContent: 'space-between' }}>
                  <Text className="text-sm text-muted">Gesamt Größe:</Text>
                  <Text className="text-sm font-semibold text-foreground">
                    {formatBytes(cacheStats.totalSize)}
                  </Text>
                </View>
                <View style={{ flexDirection: 'row', justifyContent: 'space-between' }}>
                  <Text className="text-sm text-muted">Einträge:</Text>
                  <Text className="text-sm font-semibold text-foreground">
                    {cacheStats.itemCount}
                  </Text>
                </View>
                
                {cacheStats.items.length > 0 && (
                  <View className="mt-2 gap-2">
                    <Text className="text-xs font-semibold text-muted">Gespeicherte Einträge:</Text>
                    {cacheStats.items.slice(0, 5).map((item: any) => (
                      <View
                        key={item.key}
                        style={{
                          flexDirection: 'row',
                          justifyContent: 'space-between',
                          paddingVertical: 4,
                          borderBottomColor: colors.border,
                          borderBottomWidth: 0.5
                        }}
                      >
                        <Text className="text-xs text-muted flex-1" numberOfLines={1}>
                          {item.key}
                        </Text>
                        <Text className="text-xs text-muted">
                          {formatBytes(item.size)}
                        </Text>
                      </View>
                    ))}
                  </View>
                )}
              </View>
            ) : (
              <ActivityIndicator size="small" color={colors.primary} />
            )}
            
            <Pressable
              onPress={handleClearCache}
              disabled={loading}
              style={({ pressed }) => [
                {
                  backgroundColor: '#ef4444',
                  borderRadius: 8,
                  padding: 12,
                  opacity: pressed || loading ? 0.8 : 1
                }
              ]}
            >
              <Text style={{ color: '#fff', textAlign: 'center', fontWeight: '600' }}>
                {loading ? 'Löschen...' : 'Cache leeren'}
              </Text>
            </Pressable>
          </View>

          {/* About Section */}
          <View className="gap-3">
            <Text className="text-lg font-semibold text-foreground">Über die App</Text>
            
            <View style={{ backgroundColor: colors.surface, borderRadius: 8, padding: 12, gap: 8 }}>
              <View style={{ flexDirection: 'row', justifyContent: 'space-between' }}>
                <Text className="text-sm text-muted">Version:</Text>
                <Text className="text-sm font-semibold text-foreground">2.0.0</Text>
              </View>
              <View style={{ flexDirection: 'row', justifyContent: 'space-between' }}>
                <Text className="text-sm text-muted">Build:</Text>
                <Text className="text-sm font-semibold text-foreground">20260615</Text>
              </View>
              <View style={{ flexDirection: 'row', justifyContent: 'space-between' }}>
                <Text className="text-sm text-muted">Repositories:</Text>
                <Text className="text-sm font-semibold text-foreground">163</Text>
              </View>
              <View style={{ flexDirection: 'row', justifyContent: 'space-between' }}>
                <Text className="text-sm text-muted">Funktionen:</Text>
                <Text className="text-sm font-semibold text-foreground">274,405</Text>
              </View>
            </View>
          </View>
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}
