import { ScrollView, Text, View, TextInput, TouchableOpacity, FlatList, Modal, Pressable } from "react-native";
import { ScreenContainer } from "@/components/screen-container";
import { useState } from "react";
import MaterialIcons from "@expo/vector-icons/MaterialIcons";
import { useColors } from "@/hooks/use-colors";

interface Skill {
  id: string;
  name: string;
  description: string;
  status: "draft" | "published" | "archived";
  createdAt: string;
}

const MOCK_SKILLS: Skill[] = [
  {
    id: "1",
    name: "Data Processing",
    description: "Process and analyze large datasets efficiently",
    status: "published",
    createdAt: "2024-01-15",
  },
  {
    id: "2",
    name: "Security Analysis",
    description: "Analyze security vulnerabilities and threats",
    status: "draft",
    createdAt: "2024-01-14",
  },
];

export default function SkillsScreen() {
  const colors = useColors();
  const [skills, setSkills] = useState(MOCK_SKILLS);
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [skillName, setSkillName] = useState("");
  const [skillDescription, setSkillDescription] = useState("");
  const [selectedSkill, setSelectedSkill] = useState<Skill | null>(null);
  const [showDetailModal, setShowDetailModal] = useState(false);

  const handleCreateSkill = () => {
    if (!skillName.trim() || !skillDescription.trim()) return;

    const newSkill: Skill = {
      id: Date.now().toString(),
      name: skillName,
      description: skillDescription,
      status: "draft",
      createdAt: new Date().toISOString().split("T")[0],
    };

    setSkills([newSkill, ...skills]);
    setSkillName("");
    setSkillDescription("");
    setShowCreateModal(false);
  };

  const handlePublish = (skill: Skill) => {
    setSkills(
      skills.map((s) =>
        s.id === skill.id ? { ...s, status: "published" as const } : s
      )
    );
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case "published":
        return "bg-green-100";
      case "draft":
        return "bg-yellow-100";
      case "archived":
        return "bg-gray-100";
      default:
        return "bg-gray-100";
    }
  };

  const getStatusTextColor = (status: string) => {
    switch (status) {
      case "published":
        return "text-green-700";
      case "draft":
        return "text-yellow-700";
      case "archived":
        return "text-gray-700";
      default:
        return "text-gray-700";
    }
  };

  return (
    <ScreenContainer className="p-0">
      <ScrollView contentContainerStyle={{ flexGrow: 1 }} className="flex-1">
        {/* Header */}
        <View className="bg-orange-600 px-4 py-6">
          <Text className="text-2xl font-bold text-white mb-1">Skill Creator</Text>
          <Text className="text-sm text-orange-100">Create & manage reusable skills</Text>
        </View>

        {/* Create Button */}
        <View className="px-4 py-4">
          <TouchableOpacity
            onPress={() => setShowCreateModal(true)}
            className="bg-orange-600 rounded-lg py-3 px-4 flex-row items-center justify-center gap-2"
          >
            <MaterialIcons name="add" size={20} color="white" />
            <Text className="text-white font-semibold">Create New Skill</Text>
          </TouchableOpacity>
        </View>

        {/* Stats */}
        <View className="px-4 pb-4">
          <View className="flex-row gap-2">
            <View className="flex-1 bg-surface border border-border rounded-lg p-3">
              <Text className="text-2xl font-bold text-orange-600">{skills.length}</Text>
              <Text className="text-xs text-muted mt-1">Total Skills</Text>
            </View>
            <View className="flex-1 bg-surface border border-border rounded-lg p-3">
              <Text className="text-2xl font-bold text-green-600">
                {skills.filter((s) => s.status === "published").length}
              </Text>
              <Text className="text-xs text-muted mt-1">Published</Text>
            </View>
            <View className="flex-1 bg-surface border border-border rounded-lg p-3">
              <Text className="text-2xl font-bold text-yellow-600">
                {skills.filter((s) => s.status === "draft").length}
              </Text>
              <Text className="text-xs text-muted mt-1">Draft</Text>
            </View>
          </View>
        </View>

        {/* Skills List */}
        <View className="px-4 pb-4">
          <Text className="text-sm font-semibold text-muted mb-3">My Skills</Text>

          <FlatList
            scrollEnabled={false}
            data={skills}
            keyExtractor={(item) => item.id}
            renderItem={({ item }) => (
              <Pressable
                onPress={() => {
                  setSelectedSkill(item);
                  setShowDetailModal(true);
                }}
              >
                <View className="bg-surface border border-border rounded-lg p-3 mb-3">
                  <View className="flex-row items-start justify-between mb-2">
                    <View className="flex-1">
                      <Text className="text-sm font-semibold text-foreground">
                        {item.name}
                      </Text>
                      <Text className="text-xs text-muted mt-1">
                        {item.description}
                      </Text>
                    </View>
                    <View className={`${getStatusColor(item.status)} rounded px-2 py-1 ml-2`}>
                      <Text className={`text-xs font-semibold ${getStatusTextColor(item.status)}`}>
                        {item.status}
                      </Text>
                    </View>
                  </View>

                  <View className="flex-row items-center justify-between">
                    <Text className="text-xs text-muted">{item.createdAt}</Text>
                    <View className="flex-row gap-2">
                      {item.status === "draft" && (
                        <TouchableOpacity
                          onPress={() => handlePublish(item)}
                          className="bg-green-600 rounded px-3 py-1"
                        >
                          <Text className="text-xs font-semibold text-white">Publish</Text>
                        </TouchableOpacity>
                      )}
                      <TouchableOpacity className="bg-surface border border-border rounded px-3 py-1">
                        <MaterialIcons name="more-vert" size={16} color={colors.foreground} />
                      </TouchableOpacity>
                    </View>
                  </View>
                </View>
              </Pressable>
            )}
          />
        </View>
      </ScrollView>

      {/* Create Skill Modal */}
      <Modal visible={showCreateModal} transparent animationType="slide">
        <View className="flex-1 bg-black/50 justify-end">
          <View className="bg-surface rounded-t-2xl p-4">
            <View className="flex-row items-center justify-between mb-4">
              <Text className="text-lg font-semibold text-foreground">Create New Skill</Text>
              <Pressable onPress={() => setShowCreateModal(false)}>
                <MaterialIcons name="close" size={24} color={colors.foreground} />
              </Pressable>
            </View>

            <ScrollView className="max-h-96">
              <View className="gap-3">
                {/* Name Input */}
                <View>
                  <Text className="text-sm font-semibold text-foreground mb-1">Skill Name</Text>
                  <TextInput
                    placeholder="Enter skill name..."
                    placeholderTextColor={colors.muted}
                    value={skillName}
                    onChangeText={setSkillName}
                    className="bg-background border border-border rounded-lg px-3 py-2 text-foreground"
                  />
                </View>

                {/* Description Input */}
                <View>
                  <Text className="text-sm font-semibold text-foreground mb-1">
                    Description
                  </Text>
                  <TextInput
                    placeholder="Enter skill description..."
                    placeholderTextColor={colors.muted}
                    value={skillDescription}
                    onChangeText={setSkillDescription}
                    multiline
                    numberOfLines={4}
                    className="bg-background border border-border rounded-lg px-3 py-2 text-foreground"
                  />
                </View>

                {/* Create Button */}
                <TouchableOpacity
                  disabled={!skillName.trim() || !skillDescription.trim()}
                  onPress={handleCreateSkill}
                  className={`rounded-lg py-3 px-4 flex-row items-center justify-center gap-2 ${
                    !skillName.trim() || !skillDescription.trim()
                      ? "bg-gray-400"
                      : "bg-orange-600"
                  }`}
                >
                  <MaterialIcons name="add" size={20} color="white" />
                  <Text className="text-white font-semibold">Create Skill</Text>
                </TouchableOpacity>
              </View>
            </ScrollView>
          </View>
        </View>
      </Modal>

      {/* Skill Detail Modal */}
      <Modal visible={showDetailModal} transparent animationType="slide">
        <View className="flex-1 bg-black/50 justify-end">
          <View className="bg-surface rounded-t-2xl p-4 max-h-96">
            <View className="flex-row items-center justify-between mb-4">
              <Text className="text-lg font-semibold text-foreground">
                {selectedSkill?.name}
              </Text>
              <Pressable onPress={() => setShowDetailModal(false)}>
                <MaterialIcons name="close" size={24} color={colors.foreground} />
              </Pressable>
            </View>

            <ScrollView>
              <View className="gap-3">
                <View>
                  <Text className="text-xs font-semibold text-muted mb-1">Description</Text>
                  <Text className="text-sm text-foreground">
                    {selectedSkill?.description}
                  </Text>
                </View>

                <View>
                  <Text className="text-xs font-semibold text-muted mb-1">Status</Text>
                  <View
                    className={`${getStatusColor(
                      selectedSkill?.status || ""
                    )} rounded px-2 py-1 w-fit`}
                  >
                    <Text
                      className={`text-xs font-semibold ${getStatusTextColor(
                        selectedSkill?.status || ""
                      )}`}
                    >
                      {selectedSkill?.status}
                    </Text>
                  </View>
                </View>

                <View>
                  <Text className="text-xs font-semibold text-muted mb-1">Created</Text>
                  <Text className="text-sm text-foreground">
                    {selectedSkill?.createdAt}
                  </Text>
                </View>

                <View className="flex-row gap-2 mt-4">
                  <TouchableOpacity className="flex-1 bg-orange-600 rounded-lg py-2 px-3 items-center">
                    <Text className="text-white font-semibold text-sm">Edit</Text>
                  </TouchableOpacity>
                  <TouchableOpacity className="flex-1 bg-surface border border-border rounded-lg py-2 px-3 items-center">
                    <Text className="text-foreground font-semibold text-sm">Export</Text>
                  </TouchableOpacity>
                </View>
              </View>
            </ScrollView>
          </View>
        </View>
      </Modal>
    </ScreenContainer>
  );
}
