import { ScrollView, Text, View, TouchableOpacity, Pressable } from "react-native";
import { ScreenContainer } from "@/components/screen-container";
import { useColors } from "@/hooks/use-colors";
import { trpc } from "@/lib/trpc";
import { useState } from "react";
import * as Haptics from "expo-haptics";

/**
 * Home Screen - JonaAI Ultimate Mobile
 * 
 * Zeigt alle 5 Core-Features mit Live-Statistiken
 * - GitHub Analyzer: 274,405 Funktionen aus 99 Repositories
 * - TTS Generator: 30 Stimmen, 70+ Sprachen
 * - YouTube Research: Video-Analyse und Transcript-Extraktion
 * - SimilarWeb Analytics: Traffic-Daten und geografische Verteilung
 * - Skill Creator: Template-Generator und Skill-Verwaltung
 */
export default function HomeScreen() {
  const colors = useColors();
  const [activeTab, setActiveTab] = useState<"overview" | "stats" | "modules">("overview");
  
  // Lade Statistiken
  const { data: stats, isLoading } = trpc.universal.getStatistics.useQuery();
  const { data: modulesData } = trpc.universal.listModules.useQuery();

  const handleFeatureTap = (feature: string) => {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
  };

  const features = [
    {
      id: "github",
      title: "GitHub Analyzer",
      description: "Analysiere 118 GitHub-Repositories und extrahiere Code-Signaturen",
      icon: "🔍",
      stats: `${stats?.totalFunctions || 0} Funktionen`,
      color: "#0a7ea4",
    },
    {
      id: "tts",
      title: "TTS Generator",
      description: "Generiere Sprache mit 30 Stimmen in 70+ Sprachen",
      icon: "🎙️",
      stats: "30 Voices",
      color: "#22C55E",
    },
    {
      id: "youtube",
      title: "YouTube Research",
      description: "Analysiere Videos, extrahiere Transcripts und Zitate",
      icon: "🎬",
      stats: "Video Analysis",
      color: "#EF4444",
    },
    {
      id: "analytics",
      title: "SimilarWeb Analytics",
      description: "Analysiere Website-Traffic und geografische Daten",
      icon: "📊",
      stats: "Real-time Data",
      color: "#F59E0B",
    },
    {
      id: "skills",
      title: "Skill Creator",
      description: "Erstelle und verwalte wiederverwendbare Skills",
      icon: "⚙️",
      stats: "Template Generator",
      color: "#8B5CF6",
    },
  ];

  return (
    <ScreenContainer className="p-0">
      <ScrollView contentContainerStyle={{ flexGrow: 1 }}>
        {/* Header */}
        <View className="bg-gradient-to-b from-primary to-primary/80 px-6 py-8">
          <Text className="text-4xl font-bold text-white mb-2">JonaAI</Text>
          <Text className="text-lg text-white/80">Ultimate Mobile Platform</Text>
          <View className="flex-row gap-4 mt-4">
            <View className="flex-1 bg-white/20 rounded-lg p-3">
              <Text className="text-white/60 text-xs">Links</Text>
              <Text className="text-white text-xl font-bold">118</Text>
            </View>
            <View className="flex-1 bg-white/20 rounded-lg p-3">
              <Text className="text-white/60 text-xs">Features</Text>
              <Text className="text-white text-xl font-bold">5</Text>
            </View>
            <View className="flex-1 bg-white/20 rounded-lg p-3">
              <Text className="text-white/60 text-xs">Languages</Text>
              <Text className="text-white text-xl font-bold">70+</Text>
            </View>
          </View>
        </View>

        {/* Tab Navigation */}
        <View className="flex-row border-b border-border bg-surface px-4 py-3">
          {(["overview", "stats", "modules"] as const).map((tab) => (
            <Pressable
              key={tab}
              onPress={() => setActiveTab(tab)}
              style={({ pressed }) => [
                { flex: 1, paddingVertical: 8, paddingHorizontal: 12, marginHorizontal: 4, borderRadius: 8 },
                pressed && { backgroundColor: colors.border },
                activeTab === tab && { backgroundColor: colors.primary },
              ]}
            >
              <Text
                className={`text-center font-semibold capitalize ${
                  activeTab === tab ? "text-white" : "text-foreground"
                }`}
              >
                {tab}
              </Text>
            </Pressable>
          ))}
        </View>

        {/* Content */}
        <View className="flex-1 px-4 py-6">
          {activeTab === "overview" && (
            <View className="gap-4">
              <Text className="text-2xl font-bold text-foreground mb-4">Features</Text>
              {features.map((feature) => (
                <Pressable
                  key={feature.id}
                  onPress={() => handleFeatureTap(feature.id)}
                  style={({ pressed }) => [
                    {
                      backgroundColor: colors.surface,
                      borderRadius: 12,
                      padding: 16,
                      marginBottom: 8,
                      borderLeftWidth: 4,
                      borderLeftColor: feature.color,
                    },
                    pressed && { opacity: 0.7 },
                  ]}
                >
                  <View className="flex-row items-start gap-3">
                    <Text className="text-3xl">{feature.icon}</Text>
                    <View className="flex-1">
                      <Text className="text-lg font-bold text-foreground">{feature.title}</Text>
                      <Text className="text-sm text-muted mt-1">{feature.description}</Text>
                      <Text className="text-xs text-primary font-semibold mt-2">{feature.stats}</Text>
                    </View>
                  </View>
                </Pressable>
              ))}
            </View>
          )}

          {activeTab === "stats" && (
            <View className="gap-4">
              <Text className="text-2xl font-bold text-foreground mb-4">Statistiken</Text>
              {isLoading ? (
                <Text className="text-muted">Lade Statistiken...</Text>
              ) : stats ? (
                <View className="gap-3">
                  <StatCard label="Repositories" value={stats.sourceRepositories} />
                  <StatCard label="Funktionen" value={stats.totalFunctions} />
                  <StatCard label="Klassen" value={stats.totalClasses} />
                  <StatCard label="Code-Dateien" value={stats.totalCodeFiles} />
                  <StatCard label="Module" value={stats.totalModules} />
                </View>
              ) : null}
            </View>
          )}

          {activeTab === "modules" && (
            <View className="gap-4">
              <Text className="text-2xl font-bold text-foreground mb-4">Top Module</Text>
              {modulesData?.modules.slice(0, 10).map((mod: any, idx: number) => (
                <View
                  key={idx}
                  className="bg-surface rounded-lg p-4 border border-border"
                >
                  <Text className="font-semibold text-foreground">{mod.name}</Text>
                  <View className="flex-row justify-between mt-2">
                    <Text className="text-xs text-muted">{mod.functions} Functions</Text>
                    <Text className="text-xs text-muted">{mod.classes} Classes</Text>
                    <Text className="text-xs text-muted">{mod.files} Files</Text>
                  </View>
                </View>
              ))}
            </View>
          )}
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}

function StatCard({ label, value }: { label: string; value: number }) {
  const colors = useColors();
  return (
    <View className="bg-surface rounded-lg p-4 border border-border">
      <Text className="text-sm text-muted">{label}</Text>
      <Text className="text-3xl font-bold text-primary mt-1">
        {value.toLocaleString()}
      </Text>
    </View>
  );
}
