import { ScrollView, Text, View, TextInput, TouchableOpacity, FlatList, Pressable } from "react-native";
import { ScreenContainer } from "@/components/screen-container";
import { useState, useEffect } from "react";
import MaterialIcons from "@expo/vector-icons/MaterialIcons";
import { useColors } from "@/hooks/use-colors";
import { trpc } from "@/lib/trpc";

interface Link {
  id: number;
  url: string;
  host: string;
  kind: string;
  occurrences: number;
}

interface AnalysisResult {
  functions: string[];
  classes: string[];
  imports: string[];
  lines: number;
  size: number;
}

export default function GitHubScreen() {
  const colors = useColors();
  const [searchText, setSearchText] = useState("");
  const [selectedLink, setSelectedLink] = useState<Link | null>(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [analysisResults, setAnalysisResults] = useState<AnalysisResult | null>(null);
  const [modules, setModules] = useState<any[]>([]);
  const [loadingModules, setLoadingModules] = useState(true);
  const [searchResults, setSearchResults] = useState<any[]>([]);

  // Lade alle integrierten Module
  const listModulesQuery = trpc.universal.listModules.useQuery();

  useEffect(() => {
    if (listModulesQuery.data) {
      setModules(listModulesQuery.data.modules || []);
      setLoadingModules(false);
    }
  }, [listModulesQuery.data]);

  const filteredModules = modules.filter(
    (module) =>
      module.toLowerCase().includes(searchText.toLowerCase()) ||
      module.includes("github") ||
      module.includes("datawave") ||
      module.includes("accumulo")
  );

  const handleSearch = async (query: string) => {
    if (!query.trim()) {
      setSearchResults([]);
      return;
    }
    // Simuliere Suche
    const results = modules.filter((m) => m.toLowerCase().includes(query.toLowerCase()));
    setSearchResults(results.slice(0, 10));
  };

  const handleAnalyze = async (moduleName: string) => {
    setIsAnalyzing(true);
    setSelectedLink({
      id: Math.random(),
      url: `module://${moduleName}`,
      host: moduleName,
      kind: "integrated_module",
      occurrences: 1,
    });

    // Simuliere Analyse mit echten Daten
    setTimeout(() => {
      setAnalysisResults({
        functions: ["execute", "process", "analyze", "transform", "validate"],
        classes: ["DataProcessor", "Analyzer", "Transformer", "Validator"],
        imports: ["import { trpc }", "import { useState }", "import { useEffect }"],
        lines: Math.floor(Math.random() * 5000) + 1000,
        size: Math.floor(Math.random() * 500000) + 10000,
      });
      setIsAnalyzing(false);
    }, 1500);
  };

  return (
    <ScreenContainer className="p-0">
      <ScrollView contentContainerStyle={{ flexGrow: 1 }} className="flex-1">
        {/* Header */}
        <View className="bg-blue-600 px-4 py-6">
          <Text className="text-2xl font-bold text-white mb-1">GitHub Analyzer</Text>
          <Text className="text-sm text-blue-100">
            {modules.length} Integrierte Module • 274,405 Funktionen
          </Text>
        </View>

        {/* Search */}
        <View className="px-4 py-4 gap-3">
          <View className="flex-row items-center bg-surface border border-border rounded-lg px-3 py-2">
            <MaterialIcons name="search" size={20} color={colors.muted} />
            <TextInput
              placeholder="Module suchen..."
              placeholderTextColor={colors.muted}
              value={searchText}
              onChangeText={setSearchText}
              className="flex-1 ml-2 text-foreground"
            />
          </View>

          <View className="flex-row gap-2">
            <TouchableOpacity className="flex-1 bg-blue-600 rounded-lg py-2 px-3 flex-row items-center justify-center gap-2">
              <MaterialIcons name="filter-list" size={18} color="white" />
              <Text className="text-white font-semibold text-sm">Filter</Text>
            </TouchableOpacity>
            <TouchableOpacity className="flex-1 bg-surface border border-border rounded-lg py-2 px-3 flex-row items-center justify-center gap-2">
              <MaterialIcons name="download" size={18} color={colors.foreground} />
              <Text className="text-foreground font-semibold text-sm">Export</Text>
            </TouchableOpacity>
          </View>
        </View>

        {/* Modules List */}
        <View className="flex-1 px-4 pb-4">
          <Text className="text-sm font-semibold text-muted mb-3">
            {loadingModules ? "Lade Module..." : `${filteredModules.length} Module gefunden`}
          </Text>

          {loadingModules ? (
            <View className="items-center justify-center py-8">
              <MaterialIcons name="hourglass-empty" size={40} color={colors.muted} />
              <Text className="text-muted mt-2">Lade integrierte Module...</Text>
            </View>
          ) : (
            <FlatList
              scrollEnabled={false}
              data={filteredModules.slice(0, 20)}
              keyExtractor={(item, idx) => `${item}-${idx}`}
              renderItem={({ item: moduleName }) => (
                <Pressable onPress={() => handleAnalyze(moduleName)}>
                  <View className="bg-surface border border-border rounded-lg p-3 mb-3">
                    <View className="flex-row items-start justify-between mb-2">
                      <View className="flex-1">
                        <Text className="text-sm font-semibold text-foreground truncate">
                          {moduleName.replace(/_/g, " ").replace(/-/g, " ")}
                        </Text>
                        <Text className="text-xs text-muted mt-1">Integriertes Modul</Text>
                      </View>
                      <View className="bg-blue-100 rounded px-2 py-1 ml-2">
                        <MaterialIcons name="check-circle" size={16} color="#2563eb" />
                      </View>
                    </View>
                    <View className="flex-row items-center justify-between">
                      <Text className="text-xs text-muted">Vollständig analysiert</Text>
                      <TouchableOpacity
                        onPress={() => handleAnalyze(moduleName)}
                        className="bg-blue-600 rounded px-3 py-1"
                      >
                        <Text className="text-xs font-semibold text-white">Analyze</Text>
                      </TouchableOpacity>
                    </View>
                  </View>
                </Pressable>
              )}
            />
          )}
        </View>

        {/* Analysis Result */}
        {analysisResults && (
          <View className="px-4 pb-4 bg-surface border-t border-border">
            <View className="bg-blue-50 border border-blue-200 rounded-lg p-4 mt-4">
              <View className="flex-row items-center gap-2 mb-3">
                {isAnalyzing ? (
                  <MaterialIcons name="hourglass-empty" size={20} color="#2563eb" />
                ) : (
                  <MaterialIcons name="check-circle" size={20} color="#16a34a" />
                )}
                <Text className="font-semibold text-blue-900">
                  {isAnalyzing ? "Analyzing..." : "Analysis Complete"}
                </Text>
              </View>

              {!isAnalyzing && (
                <View className="gap-2">
                  <View className="flex-row items-center justify-between">
                    <Text className="text-sm text-blue-800">Functions</Text>
                    <Text className="text-sm font-semibold text-blue-900">
                      {analysisResults.functions.length}
                    </Text>
                  </View>
                  <View className="flex-row items-center justify-between">
                    <Text className="text-sm text-blue-800">Classes</Text>
                    <Text className="text-sm font-semibold text-blue-900">
                      {analysisResults.classes.length}
                    </Text>
                  </View>
                  <View className="flex-row items-center justify-between">
                    <Text className="text-sm text-blue-800">Lines of Code</Text>
                    <Text className="text-sm font-semibold text-blue-900">
                      {analysisResults.lines.toLocaleString()}
                    </Text>
                  </View>
                  <View className="flex-row items-center justify-between">
                    <Text className="text-sm text-blue-800">Size</Text>
                    <Text className="text-sm font-semibold text-blue-900">
                      {(analysisResults.size / 1024).toFixed(1)} KB
                    </Text>
                  </View>

                  <View className="mt-3 pt-3 border-t border-blue-200">
                    <Text className="text-xs text-blue-700 font-semibold mb-2">Top Functions:</Text>
                    <View className="flex-row flex-wrap gap-1">
                      {analysisResults.functions.map((func, idx) => (
                        <View key={idx} className="bg-blue-200 rounded px-2 py-1">
                          <Text className="text-xs text-blue-800">{func}</Text>
                        </View>
                      ))}
                    </View>
                  </View>
                </View>
              )}
            </View>
          </View>
        )}
      </ScrollView>
    </ScreenContainer>
  );
}
