/**
 * Master Index - All Integrated Code Modules
 * Auto-generated from 274,405 functions and 42,558 classes
 * 98 Repositories from 118 Links
 */

export * as AppLocker_Guidance from './AppLocker-Guidance';
export * as AtomicWatch from './AtomicWatch';
export * as BAM from './BAM';
export * as BitLocker_Guidance from './BitLocker-Guidance';
export * as Blocking_Outdated_Web_Technologies from './Blocking-Outdated-Web-Technologies';
export * as Certificate_Authority_Situational_Awareness from './Certificate-Authority-Situational-Awareness';
export * as CodeGov from './CodeGov';
export * as Control_Flow_Integrity from './Control-Flow-Integrity';
export * as DCP from './DCP';
export * as Detect_CVE_2017_15361_TPM from './Detect-CVE-2017-15361-TPM';
export * as Driver_Collider from './Driver-Collider';
export * as Event_Forwarding_Guidance from './Event-Forwarding-Guidance';
export * as GRASSMARLIN from './GRASSMARLIN';
export * as HIRS from './HIRS';
export * as HTTP_Connectivity_Tester from './HTTP-Connectivity-Tester';
export * as Hardware_and_Firmware_Security_Guidance from './Hardware-and-Firmware-Security-Guidance';
export * as LOCKLEVEL from './LOCKLEVEL';
export * as MADCert from './MADCert';
export * as Maplesyrup from './Maplesyrup';
export * as Mitigating_Obsolete_TLS from './Mitigating-Obsolete-TLS';
export * as Mitigating_Web_Shells from './Mitigating-Web-Shells';
export * as PACE from './PACE';
export * as PACE_python from './PACE-python';
export * as PRUNE from './PRUNE';
export * as Pandora_link from './Pandora.link';
export * as Pass_the_Hash_Guidance from './Pass-the-Hash-Guidance';
export * as RandPassGenerator from './RandPassGenerator';
export * as SIMP from './SIMP';
export * as Splunk_Assessment_of_Mitigation_Implementations from './Splunk-Assessment-of-Mitigation-Implementations';
export * as WALKOFF from './WALKOFF';
export * as WALKOFF_Apps from './WALKOFF-Apps';
export * as Windows_Event_Log_Messages from './Windows-Event-Log-Messages';
export * as Windows_Secure_Host_Baseline from './Windows-Secure-Host-Baseline';
export * as XORSATFilter from './XORSATFilter';
export * as accumulo from './accumulo';
export * as accumulo_python3 from './accumulo-python3';
export * as beer_garden from './beer-garden';
export * as call_stack_profiler from './call-stack-profiler';
export * as college_choice from './college-choice';
export * as content from './content';
export * as datawave from './datawave';
export * as datawave_accumulo_service from './datawave-accumulo-service';
export * as datawave_accumulo_utils from './datawave-accumulo-utils';
export * as datawave_audit_service from './datawave-audit-service';
export * as datawave_authorization_service from './datawave-authorization-service';
export * as datawave_base_rest_responses from './datawave-base-rest-responses';
export * as datawave_common_utils from './datawave-common-utils';
export * as datawave_config_service from './datawave-config-service';
export * as datawave_dictionary_service from './datawave-dictionary-service';
export * as datawave_hazelcast_service from './datawave-hazelcast-service';
export * as datawave_in_memory_accumulo from './datawave-in-memory-accumulo';
export * as datawave_metadata_utils from './datawave-metadata-utils';
export * as datawave_metrics_reporter from './datawave-metrics-reporter';
export * as datawave_microservices_root from './datawave-microservices-root';
export * as datawave_muchos from './datawave-muchos';
export * as datawave_parent from './datawave-parent';
export * as datawave_query_metric_service from './datawave-query-metric-service';
export * as datawave_service_parent from './datawave-service-parent';
export * as datawave_spring_boot_starter_audit from './datawave-spring-boot-starter-audit';
export * as datawave_spring_boot_starter_cache from './datawave-spring-boot-starter-cache';
export * as datawave_type_utils from './datawave-type-utils';
export * as datawave_utils from './datawave-utils';
export * as dm3k from './dm3k';
export * as enigma_simulator from './enigma-simulator';
export * as femto from './femto';
export * as fractalrabbit from './fractalrabbit';
export * as ghidra from './ghidra';
export * as ghidra_data from './ghidra-data';
export * as goSecure from './goSecure';
export * as kmyth from './kmyth';
export * as lemongraph from './lemongraph';
export * as lemongrenade from './lemongrenade';
export * as netfil from './netfil';
export * as netman from './netman';
export * as notice_and_comment from './notice-and-comment';
export * as owf_framework from './owf-framework';
export * as paccor from './paccor';
export * as pelz from './pelz';
export * as petitions from './petitions';
export * as qgis_bulk_nominatim from './qgis-bulk-nominatim';
export * as qgis_d3datavis_plugin from './qgis-d3datavis-plugin';
export * as qgis_datetimetools_plugin from './qgis-datetimetools-plugin';
export * as qgis_earthsunmoon_plugin from './qgis-earthsunmoon-plugin';
export * as qgis_kmltools_plugin from './qgis-kmltools-plugin';
export * as qgis_latlontools_plugin from './qgis-latlontools-plugin';
export * as qgis_lockzoom_plugin from './qgis-lockzoom-plugin';
export * as qgis_mgrs_plugin from './qgis-mgrs-plugin';
export * as qgis_searchlayers_plugin from './qgis-searchlayers-plugin';
export * as qgis_shapetools_plugin from './qgis-shapetools-plugin';
export * as qonduit from './qonduit';
export * as seabee from './seabee';
export * as serial2pcap from './serial2pcap';
export * as simon_speck_supercop from './simon-speck-supercop';
export * as skills_client_examples from './skills-client-examples';
export * as skills_docs from './skills-docs';
export * as skills_stress_test from './skills-stress-test';
export * as unfetter from './unfetter';
export * as waterslide from './waterslide';

export const INTEGRATED_MODULES = {
  count: 98,
  modules: [
    'AppLocker-Guidance',
    'AtomicWatch',
    'BAM',
    'BitLocker-Guidance',
    'Blocking-Outdated-Web-Technologies',
    'Certificate-Authority-Situational-Awareness',
    'CodeGov',
    'Control-Flow-Integrity',
    'DCP',
    'Detect-CVE-2017-15361-TPM',
    'Driver-Collider',
    'Event-Forwarding-Guidance',
    'GRASSMARLIN',
    'HIRS',
    'HTTP-Connectivity-Tester',
    'Hardware-and-Firmware-Security-Guidance',
    'LOCKLEVEL',
    'MADCert',
    'Maplesyrup',
    'Mitigating-Obsolete-TLS',
    'Mitigating-Web-Shells',
    'PACE',
    'PACE-python',
    'PRUNE',
    'Pandora.link',
    'Pass-the-Hash-Guidance',
    'RandPassGenerator',
    'SIMP',
    'Splunk-Assessment-of-Mitigation-Implementations',
    'WALKOFF',
    'WALKOFF-Apps',
    'Windows-Event-Log-Messages',
    'Windows-Secure-Host-Baseline',
    'XORSATFilter',
    'accumulo',
    'accumulo-python3',
    'beer-garden',
    'call-stack-profiler',
    'college-choice',
    'content',
    'datawave',
    'datawave-accumulo-service',
    'datawave-accumulo-utils',
    'datawave-audit-service',
    'datawave-authorization-service',
    'datawave-base-rest-responses',
    'datawave-common-utils',
    'datawave-config-service',
    'datawave-dictionary-service',
    'datawave-hazelcast-service',
    'datawave-in-memory-accumulo',
    'datawave-metadata-utils',
    'datawave-metrics-reporter',
    'datawave-microservices-root',
    'datawave-muchos',
    'datawave-parent',
    'datawave-query-metric-service',
    'datawave-service-parent',
    'datawave-spring-boot-starter-audit',
    'datawave-spring-boot-starter-cache',
    'datawave-type-utils',
    'datawave-utils',
    'dm3k',
    'enigma-simulator',
    'femto',
    'fractalrabbit',
    'ghidra',
    'ghidra-data',
    'goSecure',
    'kmyth',
    'lemongraph',
    'lemongrenade',
    'netfil',
    'netman',
    'notice-and-comment',
    'owf-framework',
    'paccor',
    'pelz',
    'petitions',
    'qgis-bulk-nominatim',
    'qgis-d3datavis-plugin',
    'qgis-datetimetools-plugin',
    'qgis-earthsunmoon-plugin',
    'qgis-kmltools-plugin',
    'qgis-latlontools-plugin',
    'qgis-lockzoom-plugin',
    'qgis-mgrs-plugin',
    'qgis-searchlayers-plugin',
    'qgis-shapetools-plugin',
    'qonduit',
    'seabee',
    'serial2pcap',
    'simon-speck-supercop',
    'skills-client-examples',
    'skills-docs',
    'skills-stress-test',
    'unfetter',
    'waterslide',
  ]
};

export default INTEGRATED_MODULES;
