/**
 * Auto-generated module from datawave-parent
 * Extracted from 0 code files
 */

export namespace datawave_parent {
  export const functions = {
  };

  export const classes = {
  };

  export const metadata = {
    source: "datawave-parent",
    functions: 0,
    classes: 0,
    generatedAt: new Date().toISOString()
  };
}

export default datawave_parent;
