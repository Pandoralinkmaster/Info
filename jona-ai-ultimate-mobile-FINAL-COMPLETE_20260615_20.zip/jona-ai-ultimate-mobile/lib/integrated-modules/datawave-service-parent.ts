/**
 * Auto-generated module from datawave-service-parent
 * Extracted from 0 code files
 */

export namespace datawave_service_parent {
  export const functions = {
  };

  export const classes = {
  };

  export const metadata = {
    source: "datawave-service-parent",
    functions: 0,
    classes: 0,
    generatedAt: new Date().toISOString()
  };
}

export default datawave_service_parent;
