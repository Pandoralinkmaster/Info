import { z } from 'zod';

/**
 * Zod Schemas für Validierung
 */

// Search Schemas
export const SearchQuerySchema = z.object({
  query: z.string().min(1).max(500),
  limit: z.number().min(1).max(100).default(20),
  offset: z.number().min(0).default(0),
  filters: z.object({
    language: z.string().optional(),
    type: z.enum(['function', 'class', 'module']).optional(),
    repository: z.string().optional()
  }).optional()
});

export const FunctionSearchSchema = z.object({
  query: z.string().min(1).max(500),
  language: z.string().optional(),
  limit: z.number().min(1).max(100).default(20)
});

export const ClassSearchSchema = z.object({
  query: z.string().min(1).max(500),
  language: z.string().optional(),
  limit: z.number().min(1).max(100).default(20)
});

export const RepositorySearchSchema = z.object({
  query: z.string().min(1).max(500),
  limit: z.number().min(1).max(100).default(20)
});

export const SuggestionsSchema = z.object({
  query: z.string().min(1).max(500),
  limit: z.number().min(1).max(50).default(10)
});

// Analysis Schemas
export const LinkIdSchema = z.object({
  linkId: z.string().uuid()
});

export const AnalyzeLinkSchema = z.object({
  linkId: z.string().uuid(),
  options: z.object({
    deep: z.boolean().default(false),
    includeMetadata: z.boolean().default(true)
  }).optional()
});

export const AuditLinesSchema = z.object({
  linkId: z.string().uuid(),
  limit: z.number().min(1).max(1000).default(100),
  offset: z.number().min(0).default(0)
});

// Report Schemas
export const ReportIdSchema = z.object({
  reportId: z.string().uuid()
});

export const ExportReportSchema = z.object({
  reportId: z.string().uuid(),
  format: z.enum(['json', 'csv', 'pdf'])
});

export const TimelineSchema = z.object({
  startDate: z.string().datetime().optional(),
  endDate: z.string().datetime().optional(),
  limit: z.number().min(1).max(1000).default(100)
});

// API Integration Schemas
export const YouTubeSearchSchema = z.object({
  query: z.string().min(1).max(500),
  maxResults: z.number().min(1).max(50).default(10),
  apiKey: z.string().optional()
});

export const YouTubeVideoIdSchema = z.object({
  videoId: z.string().min(1),
  apiKey: z.string().optional()
});

export const SimilarWebDomainSchema = z.object({
  domain: z.string().url(),
  apiKey: z.string().optional()
});

export const SimilarWebTrafficSchema = z.object({
  domain: z.string().url(),
  startDate: z.string().datetime().optional(),
  endDate: z.string().datetime().optional()
});

export const GitHubSearchSchema = z.object({
  query: z.string().min(1).max(500),
  sort: z.enum(['stars', 'forks', 'updated']).optional(),
  perPage: z.number().min(1).max(100).default(30),
  token: z.string().optional()
});

export const GitHubRepoSchema = z.object({
  owner: z.string().min(1),
  repo: z.string().min(1),
  token: z.string().optional()
});

export const GitHubCodeSchema = z.object({
  owner: z.string().min(1),
  repo: z.string().min(1),
  path: z.string().optional(),
  token: z.string().optional()
});

// Universal Functions Schemas
export const ExecuteFunctionSchema = z.object({
  moduleName: z.string().min(1),
  functionName: z.string().min(1),
  args: z.any().array().optional()
});

export const CreateInstanceSchema = z.object({
  moduleName: z.string().min(1),
  className: z.string().min(1),
  args: z.any().array().optional()
});

export const BatchExecuteSchema = z.object({
  tasks: z.array(z.object({
    moduleName: z.string().min(1),
    functionName: z.string().min(1),
    args: z.any().array().optional()
  }))
});

// Cache Schemas
export const CacheKeySchema = z.object({
  key: z.string().min(1),
  ttl: z.number().min(0).optional()
});

export const BatchCacheSchema = z.object({
  keys: z.array(z.string().min(1))
});

// Auth Schemas
export const LoginSchema = z.object({
  email: z.string().email(),
  password: z.string().min(8)
});

export const RegisterSchema = z.object({
  email: z.string().email(),
  password: z.string().min(8),
  name: z.string().min(1)
});

/**
 * Validator Utility Klasse
 */
export class Validator {
  /**
   * Validiere Search Query
   */
  static validateSearchQuery(data: unknown) {
    return SearchQuerySchema.parse(data);
  }

  /**
   * Validiere Function Search
   */
  static validateFunctionSearch(data: unknown) {
    return FunctionSearchSchema.parse(data);
  }

  /**
   * Validiere Class Search
   */
  static validateClassSearch(data: unknown) {
    return ClassSearchSchema.parse(data);
  }

  /**
   * Validiere Repository Search
   */
  static validateRepositorySearch(data: unknown) {
    return RepositorySearchSchema.parse(data);
  }

  /**
   * Validiere Suggestions
   */
  static validateSuggestions(data: unknown) {
    return SuggestionsSchema.parse(data);
  }

  /**
   * Validiere Link ID
   */
  static validateLinkId(data: unknown) {
    return LinkIdSchema.parse(data);
  }

  /**
   * Validiere Analyze Link
   */
  static validateAnalyzeLink(data: unknown) {
    return AnalyzeLinkSchema.parse(data);
  }

  /**
   * Validiere YouTube Search
   */
  static validateYouTubeSearch(data: unknown) {
    return YouTubeSearchSchema.parse(data);
  }

  /**
   * Validiere SimilarWeb Domain
   */
  static validateSimilarWebDomain(data: unknown) {
    return SimilarWebDomainSchema.parse(data);
  }

  /**
   * Validiere GitHub Search
   */
  static validateGitHubSearch(data: unknown) {
    return GitHubSearchSchema.parse(data);
  }

  /**
   * Validiere Execute Function
   */
  static validateExecuteFunction(data: unknown) {
    return ExecuteFunctionSchema.parse(data);
  }

  /**
   * Validiere Login
   */
  static validateLogin(data: unknown) {
    return LoginSchema.parse(data);
  }

  /**
   * Validiere Register
   */
  static validateRegister(data: unknown) {
    return RegisterSchema.parse(data);
  }

  /**
   * Safe Validierung (gibt null statt Exception zurück)
   */
  static safeParse<T>(schema: z.ZodSchema<T>, data: unknown): T | null {
    try {
      return schema.parse(data);
    } catch (error) {
      console.error('Validation error:', error);
      return null;
    }
  }
}

/**
 * Custom Validators
 */
export const CustomValidators = {
  /**
   * Validiere URL
   */
  isValidUrl: (url: string): boolean => {
    try {
      new URL(url);
      return true;
    } catch {
      return false;
    }
  },

  /**
   * Validiere Email
   */
  isValidEmail: (email: string): boolean => {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
  },

  /**
   * Validiere UUID
   */
  isValidUUID: (uuid: string): boolean => {
    const uuidRegex = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
    return uuidRegex.test(uuid);
  },

  /**
   * Validiere GitHub URL
   */
  isValidGitHubUrl: (url: string): boolean => {
    return /^https?:\/\/(www\.)?github\.com\/[\w-]+\/[\w.-]+/.test(url);
  },

  /**
   * Validiere YouTube URL
   */
  isValidYouTubeUrl: (url: string): boolean => {
    return /^https?:\/\/(www\.)?(youtube\.com|youtu\.be)\//.test(url);
  },

  /**
   * Validiere Domain
   */
  isValidDomain: (domain: string): boolean => {
    const domainRegex = /^([a-z0-9]([a-z0-9-]*[a-z0-9])?\.)+[a-z]{2,}$/i;
    return domainRegex.test(domain);
  },

  /**
   * Validiere Programming Language
   */
  isValidLanguage: (lang: string): boolean => {
    const validLanguages = ['java', 'javascript', 'typescript', 'python', 'go', 'rust', 'c', 'cpp', 'csharp', 'kotlin', 'swift', 'ruby', 'php', 'scala'];
    return validLanguages.includes(lang.toLowerCase());
  }
};
