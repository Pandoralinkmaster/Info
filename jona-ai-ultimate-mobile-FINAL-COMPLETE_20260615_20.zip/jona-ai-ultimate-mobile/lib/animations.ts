import Animated, {
  useSharedValue,
  useAnimatedStyle,
  withTiming,
  withSpring,
  interpolate,
  Extrapolate,
  runOnJS,
  withDelay,
  withSequence,
  Easing,
} from 'react-native-reanimated';

/**
 * Fade In Animation
 */
export function useFadeInAnimation(duration: number = 300) {
  const opacity = useSharedValue(0);

  const animatedStyle = useAnimatedStyle(() => ({
    opacity: opacity.value,
  }));

  const startAnimation = () => {
    opacity.value = withTiming(1, {
      duration,
      easing: Easing.inOut(Easing.ease),
    });
  };

  return { animatedStyle, startAnimation, opacity };
}

/**
 * Slide In Animation
 */
export function useSlideInAnimation(
  direction: 'left' | 'right' | 'up' | 'down' = 'up',
  distance: number = 50,
  duration: number = 300
) {
  const translateX = useSharedValue(direction === 'left' ? -distance : direction === 'right' ? distance : 0);
  const translateY = useSharedValue(direction === 'up' ? distance : direction === 'down' ? -distance : 0);
  const opacity = useSharedValue(0);

  const animatedStyle = useAnimatedStyle(() => ({
    transform: [{ translateX: translateX.value }, { translateY: translateY.value }],
    opacity: opacity.value,
  }));

  const startAnimation = () => {
    translateX.value = withTiming(0, { duration, easing: Easing.out(Easing.cubic) });
    translateY.value = withTiming(0, { duration, easing: Easing.out(Easing.cubic) });
    opacity.value = withTiming(1, { duration });
  };

  return { animatedStyle, startAnimation };
}

/**
 * Scale Animation
 */
export function useScaleAnimation(duration: number = 300) {
  const scale = useSharedValue(0.8);
  const opacity = useSharedValue(0);

  const animatedStyle = useAnimatedStyle(() => ({
    transform: [{ scale: scale.value }],
    opacity: opacity.value,
  }));

  const startAnimation = () => {
    scale.value = withSpring(1, {
      damping: 10,
      mass: 1,
      overshootClamping: false,
    });
    opacity.value = withTiming(1, { duration });
  };

  return { animatedStyle, startAnimation };
}

/**
 * Bounce Animation
 */
export function useBounceAnimation() {
  const translateY = useSharedValue(0);

  const animatedStyle = useAnimatedStyle(() => ({
    transform: [{ translateY: translateY.value }],
  }));

  const startAnimation = () => {
    translateY.value = withSequence(
      withTiming(-10, { duration: 100 }),
      withTiming(0, { duration: 100 }),
      withTiming(-10, { duration: 100 }),
      withTiming(0, { duration: 100 })
    );
  };

  return { animatedStyle, startAnimation };
}

/**
 * Rotation Animation
 */
export function useRotationAnimation(duration: number = 1000) {
  const rotation = useSharedValue(0);

  const animatedStyle = useAnimatedStyle(() => ({
    transform: [
      {
        rotate: interpolate(
          rotation.value,
          [0, 1],
          [0, 360],
          Extrapolate.CLAMP
        ) + 'deg',
      },
    ],
  }));

  const startAnimation = () => {
    rotation.value = withTiming(1, {
      duration,
      easing: Easing.linear,
    });
  };

  const resetAnimation = () => {
    rotation.value = 0;
  };

  return { animatedStyle, startAnimation, resetAnimation };
}

/**
 * Pulse Animation
 */
export function usePulseAnimation(duration: number = 1000) {
  const opacity = useSharedValue(1);

  const animatedStyle = useAnimatedStyle(() => ({
    opacity: opacity.value,
  }));

  const startAnimation = () => {
    opacity.value = withSequence(
      withTiming(0.5, { duration: duration / 2 }),
      withTiming(1, { duration: duration / 2 })
    );
  };

  return { animatedStyle, startAnimation };
}

/**
 * Shake Animation
 */
export function useShakeAnimation() {
  const translateX = useSharedValue(0);

  const animatedStyle = useAnimatedStyle(() => ({
    transform: [{ translateX: translateX.value }],
  }));

  const startAnimation = () => {
    translateX.value = withSequence(
      withTiming(-10, { duration: 50 }),
      withTiming(10, { duration: 50 }),
      withTiming(-10, { duration: 50 }),
      withTiming(10, { duration: 50 }),
      withTiming(0, { duration: 50 })
    );
  };

  return { animatedStyle, startAnimation };
}

/**
 * Interpolation Helper
 */
export function useInterpolatedAnimation(
  inputRange: number[],
  outputRange: number[] | string[],
  extrapolate: 'clamp' | 'extend' | 'identity' = 'clamp'
) {
  const progress = useSharedValue(0);

  const animatedValue = useAnimatedStyle(() => {
    const extrapolateMode =
      extrapolate === 'clamp'
        ? Extrapolate.CLAMP
        : extrapolate === 'extend'
        ? Extrapolate.EXTEND
        : Extrapolate.IDENTITY;

    return {
      opacity: interpolate(
        progress.value,
        inputRange,
        outputRange as number[],
        extrapolateMode
      ),
    };
  });

  const animate = (toValue: number, duration: number = 300) => {
    progress.value = withTiming(toValue, {
      duration,
      easing: Easing.inOut(Easing.ease),
    });
  };

  return { animatedValue, animate, progress };
}

/**
 * Stagger Animation für Listen
 */
export function useStaggerAnimation(
  itemCount: number,
  itemDelay: number = 50,
  duration: number = 300
) {
  const animations = Array.from({ length: itemCount }, () => useSharedValue(0));

  const startAnimation = () => {
    animations.forEach((anim, index) => {
      anim.value = withDelay(
        index * itemDelay,
        withTiming(1, { duration, easing: Easing.out(Easing.cubic) })
      );
    });
  };

  const animatedStyles = animations.map((anim) =>
    useAnimatedStyle(() => ({
      opacity: anim.value,
      transform: [{ translateY: interpolate(anim.value, [0, 1], [20, 0]) }],
    }))
  );

  return { animatedStyles, startAnimation };
}

/**
 * Parallax Scroll Animation
 */
export function useParallaxAnimation(scrollY: any, parallaxFactor: number = 0.5) {
  const animatedStyle = useAnimatedStyle(() => ({
    transform: [{ translateY: scrollY.value * parallaxFactor }],
  }));

  return { animatedStyle };
}
