import React, { memo, useMemo, useCallback } from 'react';

/**
 * Debounce Hook für Performance-Optimierung
 */
export function useDebounce<T>(value: T, delay: number): T {
  const [debouncedValue, setDebouncedValue] = React.useState<T>(value);

  React.useEffect(() => {
    const handler = setTimeout(() => {
      setDebouncedValue(value);
    }, delay);

    return () => clearTimeout(handler);
  }, [value, delay]);

  return debouncedValue;
}

/**
 * Throttle Hook für Performance-Optimierung
 */
export function useThrottle<T>(value: T, interval: number): T {
  const [throttledValue, setThrottledValue] = React.useState<T>(value);
  const lastUpdated = React.useRef<number>(Date.now());

  React.useEffect(() => {
    const now = Date.now();
    if (now >= lastUpdated.current + interval) {
      lastUpdated.current = now;
      setThrottledValue(value);
    } else {
      const timer = setTimeout(() => {
        lastUpdated.current = Date.now();
        setThrottledValue(value);
      }, interval);

      return () => clearTimeout(timer);
    }
  }, [value, interval]);

  return throttledValue;
}

/**
 * Lazy Loading Hook für große Listen
 */
export function useLazyLoad<T>(
  items: T[],
  itemsPerPage: number = 20
) {
  const [displayedItems, setDisplayedItems] = React.useState<T[]>(
    items.slice(0, itemsPerPage)
  );
  const [page, setPage] = React.useState(1);

  const loadMore = useCallback(() => {
    const newItems = items.slice(0, (page + 1) * itemsPerPage);
    setDisplayedItems(newItems);
    setPage(page + 1);
  }, [items, page, itemsPerPage]);

  const hasMore = displayedItems.length < items.length;

  React.useEffect(() => {
    setDisplayedItems(items.slice(0, itemsPerPage));
    setPage(1);
  }, [items, itemsPerPage]);

  return {
    displayedItems,
    loadMore,
    hasMore,
    page,
    total: items.length
  };
}

/**
 * Memoized Selector für Redux/Context
 */
export function createSelector<T, R>(
  selector: (state: T) => R,
  equalityFn?: (a: R, b: R) => boolean
) {
  let lastState: T | undefined;
  let lastResult: R | undefined;

  return (state: T): R => {
    if (lastState !== state) {
      const newResult = selector(state);
      if (
        lastResult === undefined ||
        !equalityFn?.(lastResult, newResult)
      ) {
        lastResult = newResult;
      }
      lastState = state;
    }
    return lastResult!;
  };
}

/**
 * Virtualized List Hook für sehr große Listen
 */
export function useVirtualizedList<T>(
  items: T[],
  itemHeight: number,
  visibleCount: number = 10
) {
  const [scrollOffset, setScrollOffset] = React.useState(0);

  const startIndex = Math.floor(scrollOffset / itemHeight);
  const endIndex = Math.min(startIndex + visibleCount + 1, items.length);
  const visibleItems = items.slice(startIndex, endIndex);

  const offsetY = startIndex * itemHeight;
  const totalHeight = items.length * itemHeight;

  return {
    visibleItems,
    offsetY,
    totalHeight,
    setScrollOffset,
    startIndex,
    endIndex
  };
}

/**
 * Image Optimization Hook
 */
export function useOptimizedImage(
  uri: string,
  options?: {
    width?: number;
    height?: number;
    quality?: number;
  }
) {
  const [optimized, setOptimized] = React.useState<string>(uri);
  const [loading, setLoading] = React.useState(false);

  React.useEffect(() => {
    // In Produktion würde dies die Bilder optimieren
    // z.B. mit Image.resolveAssetSource, ImageResizer, etc.
    setOptimized(uri);
  }, [uri, options]);

  return { optimized, loading };
}

/**
 * Batch Processing für große Datenmengen
 */
export async function processBatch<T, R>(
  items: T[],
  processor: (item: T) => Promise<R>,
  batchSize: number = 10
): Promise<R[]> {
  const results: R[] = [];

  for (let i = 0; i < items.length; i += batchSize) {
    const batch = items.slice(i, i + batchSize);
    const batchResults = await Promise.all(batch.map(processor));
    results.push(...batchResults);
  }

  return results;
}

/**
 * Worker Pool für CPU-intensive Operationen
 */
export class WorkerPool {
  private workers: Worker[] = [];
  private taskQueue: Array<{ task: any; resolve: any; reject: any }> = [];
  private activeWorkers = 0;

  constructor(workerScript: string, poolSize: number = 4) {
    for (let i = 0; i < poolSize; i++) {
      const worker = new Worker(workerScript);
      worker.onmessage = (event) => {
        this.activeWorkers--;
        const { task, resolve } = this.taskQueue.shift() || {};
        if (task) {
          resolve(event.data);
          this.executeTask(task);
        }
      };
      this.workers.push(worker);
    }
  }

  async execute<T>(task: any): Promise<T> {
    return new Promise((resolve, reject) => {
      if (this.activeWorkers < this.workers.length) {
        this.executeTask(task);
        this.activeWorkers++;
      } else {
        this.taskQueue.push({ task, resolve, reject });
      }
    });
  }

  private executeTask(task: any) {
    const worker = this.workers[this.activeWorkers % this.workers.length];
    worker.postMessage(task);
  }

  terminate() {
    this.workers.forEach(w => w.terminate());
  }
}

/**
 * Memory Leak Detection
 */
export function useMemoryMonitor() {
  React.useEffect(() => {
    if (typeof window !== 'undefined' && (window as any).performance?.memory) {
      const checkMemory = () => {
        const memory = (window as any).performance.memory;
        console.log(`Memory: ${Math.round(memory.usedJSHeapSize / 1048576)}MB / ${Math.round(memory.jsHeapSizeLimit / 1048576)}MB`);
      };

      const interval = setInterval(checkMemory, 5000);
      return () => clearInterval(interval);
    }
  }, []);
}

/**
 * Render Performance Monitor
 */
export function useRenderCount(componentName: string) {
  const renderCount = React.useRef(0);

  React.useEffect(() => {
    renderCount.current++;
    console.log(`${componentName} rendered ${renderCount.current} times`);
  });

  return renderCount.current;
}
