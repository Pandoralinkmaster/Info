/**
 * Zentrale Logging- und Monitoring-Utilities
 */

export enum LogLevel {
  DEBUG = 'DEBUG',
  INFO = 'INFO',
  WARN = 'WARN',
  ERROR = 'ERROR',
  FATAL = 'FATAL'
}

export interface LogEntry {
  timestamp: number;
  level: LogLevel;
  message: string;
  context?: string;
  data?: any;
  stackTrace?: string;
}

export interface PerformanceMetric {
  name: string;
  duration: number;
  timestamp: number;
  metadata?: any;
}

/**
 * Logger Klasse
 */
export class Logger {
  private static logs: LogEntry[] = [];
  private static maxLogs = 500;
  private static isDevelopment = process.env.NODE_ENV === 'development';

  /**
   * Log Debug Message
   */
  static debug(message: string, data?: any, context?: string) {
    this.log(LogLevel.DEBUG, message, data, context);
  }

  /**
   * Log Info Message
   */
  static info(message: string, data?: any, context?: string) {
    this.log(LogLevel.INFO, message, data, context);
  }

  /**
   * Log Warning Message
   */
  static warn(message: string, data?: any, context?: string) {
    this.log(LogLevel.WARN, message, data, context);
  }

  /**
   * Log Error Message
   */
  static error(message: string, error?: any, context?: string) {
    this.log(LogLevel.ERROR, message, error, context, error?.stack);
  }

  /**
   * Log Fatal Message
   */
  static fatal(message: string, error?: any, context?: string) {
    this.log(LogLevel.FATAL, message, error, context, error?.stack);
  }

  /**
   * Zentrale Log-Methode
   */
  private static log(
    level: LogLevel,
    message: string,
    data?: any,
    context?: string,
    stackTrace?: string
  ) {
    const entry: LogEntry = {
      timestamp: Date.now(),
      level,
      message,
      context,
      data,
      stackTrace
    };

    this.logs.push(entry);

    // Behalte nur die letzten maxLogs Einträge
    if (this.logs.length > this.maxLogs) {
      this.logs = this.logs.slice(-this.maxLogs);
    }

    // Console Output
    this.printToConsole(entry);

    // Remote Logging (in Produktion)
    if (!this.isDevelopment && level === LogLevel.ERROR) {
      this.sendToRemote(entry);
    }
  }

  /**
   * Print zu Console
   */
  private static printToConsole(entry: LogEntry) {
    const timestamp = new Date(entry.timestamp).toISOString();
    const prefix = `[${timestamp}] [${entry.level}]${entry.context ? ` [${entry.context}]` : ''}`;

    switch (entry.level) {
      case LogLevel.DEBUG:
        console.debug(prefix, entry.message, entry.data);
        break;
      case LogLevel.INFO:
        console.info(prefix, entry.message, entry.data);
        break;
      case LogLevel.WARN:
        console.warn(prefix, entry.message, entry.data);
        break;
      case LogLevel.ERROR:
        console.error(prefix, entry.message, entry.data);
        if (entry.stackTrace) console.error(entry.stackTrace);
        break;
      case LogLevel.FATAL:
        console.error(prefix, entry.message, entry.data);
        if (entry.stackTrace) console.error(entry.stackTrace);
        break;
    }
  }

  /**
   * Send zu Remote Logging Service
   */
  private static async sendToRemote(entry: LogEntry) {
    try {
      // Hier würde die Integration mit einem Remote Logging Service erfolgen
      // z.B. Sentry, LogRocket, etc.
      console.log('Sending log to remote service:', entry);
    } catch (error) {
      console.error('Failed to send log to remote service:', error);
    }
  }

  /**
   * Get alle Logs
   */
  static getLogs(): LogEntry[] {
    return [...this.logs];
  }

  /**
   * Get Logs nach Level
   */
  static getLogsByLevel(level: LogLevel): LogEntry[] {
    return this.logs.filter(log => log.level === level);
  }

  /**
   * Get Logs nach Context
   */
  static getLogsByContext(context: string): LogEntry[] {
    return this.logs.filter(log => log.context === context);
  }

  /**
   * Get Recent Logs
   */
  static getRecentLogs(count: number = 50): LogEntry[] {
    return this.logs.slice(-count);
  }

  /**
   * Clear Logs
   */
  static clearLogs() {
    this.logs = [];
  }

  /**
   * Export Logs
   */
  static exportLogs(format: 'json' | 'csv' = 'json'): string {
    if (format === 'json') {
      return JSON.stringify(this.logs, null, 2);
    } else {
      // CSV Format
      const headers = ['Timestamp', 'Level', 'Message', 'Context', 'Data'];
      const rows = this.logs.map(log => [
        new Date(log.timestamp).toISOString(),
        log.level,
        log.message,
        log.context || '',
        JSON.stringify(log.data || {})
      ]);

      return [
        headers.join(','),
        ...rows.map(row => row.map(cell => `"${cell}"`).join(','))
      ].join('\n');
    }
  }
}

/**
 * Performance Monitor
 */
export class PerformanceMonitor {
  private static metrics: PerformanceMetric[] = [];
  private static maxMetrics = 1000;
  private static timers = new Map<string, number>();

  /**
   * Start Timer
   */
  static startTimer(name: string) {
    this.timers.set(name, performance.now());
  }

  /**
   * End Timer und Record Metric
   */
  static endTimer(name: string, metadata?: any) {
    const startTime = this.timers.get(name);
    if (!startTime) {
      Logger.warn(`Timer "${name}" not found`, {}, 'PerformanceMonitor');
      return;
    }

    const duration = performance.now() - startTime;
    const metric: PerformanceMetric = {
      name,
      duration,
      timestamp: Date.now(),
      metadata
    };

    this.metrics.push(metric);

    // Behalte nur die letzten maxMetrics Einträge
    if (this.metrics.length > this.maxMetrics) {
      this.metrics = this.metrics.slice(-this.maxMetrics);
    }

    this.timers.delete(name);

    // Log wenn Performance schlecht ist
    if (duration > 1000) {
      Logger.warn(`Slow operation detected: ${name} took ${duration.toFixed(2)}ms`, metadata, 'PerformanceMonitor');
    }

    return duration;
  }

  /**
   * Measure Funktion
   */
  static async measure<T>(
    name: string,
    fn: () => Promise<T>,
    metadata?: any
  ): Promise<T> {
    this.startTimer(name);
    try {
      const result = await fn();
      this.endTimer(name, metadata);
      return result;
    } catch (error: any) {
      this.endTimer(name, { ...metadata, error: error?.message });
      throw error;
    }
  }

  /**
   * Get Metrics
   */
  static getMetrics(): PerformanceMetric[] {
    return [...this.metrics];
  }

  /**
   * Get Metrics nach Name
   */
  static getMetricsByName(name: string): PerformanceMetric[] {
    return this.metrics.filter(m => m.name === name);
  }

  /**
   * Get Average Duration
   */
  static getAverageDuration(name: string): number {
    const metrics = this.getMetricsByName(name);
    if (metrics.length === 0) return 0;

    const sum = metrics.reduce((acc, m) => acc + m.duration, 0);
    return sum / metrics.length;
  }

  /**
   * Get Slowest Operations
   */
  static getSlowestOperations(count: number = 10): PerformanceMetric[] {
    return [...this.metrics]
      .sort((a, b) => b.duration - a.duration)
      .slice(0, count);
  }

  /**
   * Get Statistics
   */
  static getStatistics() {
    const metrics = this.metrics;
    if (metrics.length === 0) {
      return {
        totalOperations: 0,
        averageDuration: 0,
        minDuration: 0,
        maxDuration: 0
      };
    }

    const durations = metrics.map(m => m.duration);
    const sum = durations.reduce((a, b) => a + b, 0);

    return {
      totalOperations: metrics.length,
      averageDuration: sum / metrics.length,
      minDuration: Math.min(...durations),
      maxDuration: Math.max(...durations),
      p95Duration: this.getPercentile(durations, 0.95),
      p99Duration: this.getPercentile(durations, 0.99)
    };
  }

  /**
   * Get Percentile
   */
  private static getPercentile(values: number[], percentile: number): number {
    const sorted = [...values].sort((a, b) => a - b);
    const index = Math.ceil(sorted.length * percentile) - 1;
    return sorted[Math.max(0, index)];
  }

  /**
   * Clear Metrics
   */
  static clearMetrics() {
    this.metrics = [];
    this.timers.clear();
  }

  /**
   * Export Metrics
   */
  static exportMetrics(format: 'json' | 'csv' = 'json'): string {
    if (format === 'json') {
      return JSON.stringify({
        metrics: this.metrics,
        statistics: this.getStatistics()
      }, null, 2);
    } else {
      // CSV Format
      const headers = ['Name', 'Duration (ms)', 'Timestamp'];
      const rows = this.metrics.map(m => [
        m.name,
        m.duration.toFixed(2),
        new Date(m.timestamp).toISOString()
      ]);

      return [
        headers.join(','),
        ...rows.map(row => row.map(cell => `"${cell}"`).join(','))
      ].join('\n');
    }
  }
}

/**
 * Analytics Tracker
 */
export class AnalyticsTracker {
  private static events: any[] = [];
  private static maxEvents = 1000;

  /**
   * Track Event
   */
  static trackEvent(
    eventName: string,
    properties?: Record<string, any>
  ) {
    const event = {
      name: eventName,
      timestamp: Date.now(),
      properties
    };

    this.events.push(event);

    if (this.events.length > this.maxEvents) {
      this.events = this.events.slice(-this.maxEvents);
    }

    Logger.debug(`Event tracked: ${eventName}`, properties, 'Analytics');
  }

  /**
   * Track Page View
   */
  static trackPageView(pageName: string, properties?: Record<string, any>) {
    this.trackEvent('page_view', { page: pageName, ...properties });
  }

  /**
   * Track User Action
   */
  static trackUserAction(action: string, properties?: Record<string, any>) {
    this.trackEvent('user_action', { action, ...properties });
  }

  /**
   * Get Events
   */
  static getEvents(): any[] {
    return [...this.events];
  }

  /**
   * Get Events nach Name
   */
  static getEventsByName(name: string): any[] {
    return this.events.filter(e => e.name === name);
  }

  /**
   * Clear Events
   */
  static clearEvents() {
    this.events = [];
  }

  /**
   * Export Events
   */
  static exportEvents(format: 'json' | 'csv' = 'json'): string {
    if (format === 'json') {
      return JSON.stringify(this.events, null, 2);
    } else {
      const headers = ['Event', 'Timestamp', 'Properties'];
      const rows = this.events.map(e => [
        e.name,
        new Date(e.timestamp).toISOString(),
        JSON.stringify(e.properties || {})
      ]);

      return [
        headers.join(','),
        ...rows.map(row => row.map(cell => `"${cell}"`).join(','))
      ].join('\n');
    }
  }
}
