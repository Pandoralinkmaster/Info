/**
 * Standardisierte Error-Handling Utilities
 */

export enum ErrorCode {
  INVALID_INPUT = 'INVALID_INPUT',
  NOT_FOUND = 'NOT_FOUND',
  UNAUTHORIZED = 'UNAUTHORIZED',
  FORBIDDEN = 'FORBIDDEN',
  INTERNAL_ERROR = 'INTERNAL_ERROR',
  API_KEY_REQUIRED = 'API_KEY_REQUIRED',
  RATE_LIMITED = 'RATE_LIMITED',
  NETWORK_ERROR = 'NETWORK_ERROR',
  TIMEOUT = 'TIMEOUT',
  VALIDATION_ERROR = 'VALIDATION_ERROR',
  CACHE_ERROR = 'CACHE_ERROR',
  UNKNOWN = 'UNKNOWN'
}

export interface AppError {
  code: ErrorCode;
  message: string;
  details?: any;
  statusCode?: number;
  timestamp: number;
  requestId?: string;
}

/**
 * App Error Klasse
 */
export class ApplicationError extends Error implements AppError {
  code: ErrorCode;
  details?: any;
  statusCode: number;
  timestamp: number;
  requestId?: string;

  constructor(
    code: ErrorCode,
    message: string,
    options?: {
      details?: any;
      statusCode?: number;
      requestId?: string;
    }
  ) {
    super(message);
    this.code = code;
    this.message = message;
    this.details = options?.details;
    this.statusCode = options?.statusCode || 500;
    this.timestamp = Date.now();
    this.requestId = options?.requestId;

    Object.setPrototypeOf(this, ApplicationError.prototype);
  }

  toJSON() {
    return {
      code: this.code,
      message: this.message,
      details: this.details,
      statusCode: this.statusCode,
      timestamp: this.timestamp,
      requestId: this.requestId
    };
  }
}

/**
 * Error Handler für API Calls
 */
export async function handleApiError(error: any): Promise<AppError> {
  if (error instanceof ApplicationError) {
    return error;
  }

  if (error?.response?.status) {
    const status = error.response.status;
    const data = error.response.data;

    switch (status) {
      case 400:
        return {
          code: ErrorCode.INVALID_INPUT,
          message: data?.message || 'Invalid input',
          details: data?.details,
          statusCode: 400,
          timestamp: Date.now()
        };
      case 401:
        return {
          code: ErrorCode.UNAUTHORIZED,
          message: 'Unauthorized',
          statusCode: 401,
          timestamp: Date.now()
        };
      case 403:
        return {
          code: ErrorCode.FORBIDDEN,
          message: 'Forbidden',
          statusCode: 403,
          timestamp: Date.now()
        };
      case 404:
        return {
          code: ErrorCode.NOT_FOUND,
          message: 'Not found',
          statusCode: 404,
          timestamp: Date.now()
        };
      case 429:
        return {
          code: ErrorCode.RATE_LIMITED,
          message: 'Rate limited',
          statusCode: 429,
          timestamp: Date.now()
        };
      default:
        return {
          code: ErrorCode.INTERNAL_ERROR,
          message: data?.message || 'Internal server error',
          statusCode: status,
          timestamp: Date.now()
        };
    }
  }

  if (error?.code === 'ECONNABORTED') {
    return {
      code: ErrorCode.TIMEOUT,
      message: 'Request timeout',
      statusCode: 408,
      timestamp: Date.now()
    };
  }

  if (error?.code === 'ENOTFOUND' || error?.code === 'ECONNREFUSED') {
    return {
      code: ErrorCode.NETWORK_ERROR,
      message: 'Network error',
      statusCode: 0,
      timestamp: Date.now()
    };
  }

  return {
    code: ErrorCode.UNKNOWN,
    message: error?.message || 'Unknown error',
    details: error,
    statusCode: 500,
    timestamp: Date.now()
  };
}

/**
 * Error Logger
 */
export class ErrorLogger {
  private static logs: AppError[] = [];
  private static maxLogs = 100;

  static log(error: AppError | ApplicationError) {
    const appError = error instanceof ApplicationError ? error : error;
    
    this.logs.push(appError);
    
    // Behalte nur die letzten maxLogs Einträge
    if (this.logs.length > this.maxLogs) {
      this.logs = this.logs.slice(-this.maxLogs);
    }

    // Console logging
    console.error(`[${appError.code}] ${appError.message}`, appError.details);
  }

  static getLogs(): AppError[] {
    return [...this.logs];
  }

  static clearLogs() {
    this.logs = [];
  }

  static getLogsByCode(code: ErrorCode): AppError[] {
    return this.logs.filter(log => log.code === code);
  }

  static getRecentLogs(count: number = 10): AppError[] {
    return this.logs.slice(-count);
  }
}

/**
 * Error Boundary Hook (für React)
 */
export function useErrorBoundary() {
  const [error, setError] = React.useState<AppError | null>(null);

  const handleError = (err: any) => {
    const appError = err instanceof ApplicationError ? err : { code: ErrorCode.UNKNOWN, message: err?.message || 'Unknown error', timestamp: Date.now() };
    setError(appError);
    ErrorLogger.log(appError);
  };

  const clearError = () => {
    setError(null);
  };

  return { error, handleError, clearError };
}

/**
 * Retry Logic
 */
export async function retryAsync<T>(
  fn: () => Promise<T>,
  options?: {
    maxRetries?: number;
    delayMs?: number;
    backoffMultiplier?: number;
  }
): Promise<T> {
  const maxRetries = options?.maxRetries || 3;
  const delayMs = options?.delayMs || 1000;
  const backoffMultiplier = options?.backoffMultiplier || 2;

  let lastError: any;
  let currentDelay = delayMs;

  for (let i = 0; i < maxRetries; i++) {
    try {
      return await fn();
    } catch (error) {
      lastError = error;
      
      if (i < maxRetries - 1) {
        await new Promise(resolve => setTimeout(resolve, currentDelay));
        currentDelay *= backoffMultiplier;
      }
    }
  }

  throw lastError;
}

/**
 * Validation Error Helper
 */
export function createValidationError(
  field: string,
  message: string,
  value?: any
): ApplicationError {
  return new ApplicationError(
    ErrorCode.VALIDATION_ERROR,
    `Validation failed for field: ${field}`,
    {
      details: {
        field,
        message,
        value
      },
      statusCode: 400
    }
  );
}

/**
 * Error Recovery Strategies
 */
export const ErrorRecoveryStrategies = {
  /**
   * Fallback zu gecachten Daten
   */
  useCachedData: async <T>(
    fetchFn: () => Promise<T>,
    getCachedFn: () => Promise<T | null>
  ): Promise<T> => {
    try {
      return await fetchFn();
    } catch (error) {
      const cached = await getCachedFn();
      if (cached) {
        console.warn('Using cached data due to error:', error);
        return cached;
      }
      throw error;
    }
  },

  /**
   * Fallback zu Default-Wert
   */
  withDefault: async <T>(
    fetchFn: () => Promise<T>,
    defaultValue: T
  ): Promise<T> => {
    try {
      return await fetchFn();
    } catch (error) {
      console.warn('Using default value due to error:', error);
      return defaultValue;
    }
  },

  /**
   * Exponential Backoff Retry
   */
  exponentialBackoffRetry: async <T>(
    fetchFn: () => Promise<T>,
    maxRetries: number = 3
  ): Promise<T> => {
    return retryAsync(fetchFn, {
      maxRetries,
      delayMs: 1000,
      backoffMultiplier: 2
    });
  }
};

// React import für useErrorBoundary
import React from 'react';
