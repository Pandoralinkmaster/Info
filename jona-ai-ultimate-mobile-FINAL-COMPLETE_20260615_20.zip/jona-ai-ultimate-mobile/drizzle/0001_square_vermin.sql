CREATE TABLE `analyses` (
	`id` int AUTO_INCREMENT NOT NULL,
	`linkId` int NOT NULL,
	`status` varchar(32),
	`analysisType` varchar(64),
	`totalFiles` int,
	`analyzedFiles` int,
	`signatureCount` int,
	`importCount` int,
	`riskTermsFound` text,
	`aiSummary` text,
	`generatedModulePath` varchar(512),
	`errorMessage` text,
	`startedAt` timestamp,
	`completedAt` timestamp,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `analyses_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `analyticsResults` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int,
	`domain` varchar(255),
	`globalRank` int,
	`totalVisits` int,
	`uniqueVisitors` int,
	`bounceRate` decimal(5,2),
	`pagesPerVisit` decimal(5,2),
	`avgVisitDuration` decimal(8,2),
	`trafficSources` text,
	`geographicData` text,
	`status` varchar(32),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `analyticsResults_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `auditLines` (
	`id` int AUTO_INCREMENT NOT NULL,
	`lineNumber` int,
	`content` text,
	`sha256` varchar(64),
	`sourceUrl` varchar(512),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `auditLines_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `generatedModules` (
	`id` int AUTO_INCREMENT NOT NULL,
	`linkId` int,
	`analysisId` int,
	`content` text,
	`filename` varchar(255),
	`language` varchar(32),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `generatedModules_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `links` (
	`id` int AUTO_INCREMENT NOT NULL,
	`url` varchar(512) NOT NULL,
	`host` varchar(255),
	`path` text,
	`kind` varchar(64),
	`sha256` varchar(64),
	`occurrences` int DEFAULT 1,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `links_id` PRIMARY KEY(`id`),
	CONSTRAINT `links_url_unique` UNIQUE(`url`)
);
--> statement-breakpoint
CREATE TABLE `signatures` (
	`id` int AUTO_INCREMENT NOT NULL,
	`analysisId` int,
	`linkId` int,
	`filePath` varchar(512),
	`signatureType` varchar(64),
	`name` varchar(255),
	`params` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `signatures_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `skills` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int,
	`name` varchar(255),
	`description` text,
	`skillMd` text,
	`scripts` text,
	`references` text,
	`templates` text,
	`status` varchar(32),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `skills_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `ttsSessions` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int,
	`prompt` text,
	`voiceName` varchar(64),
	`languageCode` varchar(16),
	`audioUrl` varchar(512),
	`status` varchar(32),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `ttsSessions_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `youtubeResearch` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int,
	`query` varchar(512),
	`videoUrl` varchar(512),
	`transcript` text,
	`analysis` text,
	`quotes` text,
	`status` varchar(32),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `youtubeResearch_id` PRIMARY KEY(`id`)
);
