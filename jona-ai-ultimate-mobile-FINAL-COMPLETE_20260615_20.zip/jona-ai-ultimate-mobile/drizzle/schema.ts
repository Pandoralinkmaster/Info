import { int, mysqlEnum, mysqlTable, text, timestamp, varchar, decimal } from "drizzle-orm/mysql-core";

/**
 * Core user table backing auth flow.
 * Extend this file with additional tables as your product grows.
 * Columns use camelCase to match both database fields and generated types.
 */
export const users = mysqlTable("users", {
  /**
   * Surrogate primary key. Auto-incremented numeric value managed by the database.
   * Use this for relations between tables.
   */
  id: int("id").autoincrement().primaryKey(),
  /** Manus OAuth identifier (openId) returned from the OAuth callback. Unique per user. */
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

// GitHub Links & Analysis
export const links = mysqlTable("links", {
  id: int("id").autoincrement().primaryKey(),
  url: varchar("url", { length: 512 }).notNull().unique(),
  host: varchar("host", { length: 255 }),
  path: text("path"),
  kind: varchar("kind", { length: 64 }),
  sha256: varchar("sha256", { length: 64 }),
  occurrences: int("occurrences").default(1),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export const analyses = mysqlTable("analyses", {
  id: int("id").autoincrement().primaryKey(),
  linkId: int("linkId").notNull(),
  status: varchar("status", { length: 32 }),
  analysisType: varchar("analysisType", { length: 64 }),
  totalFiles: int("totalFiles"),
  analyzedFiles: int("analyzedFiles"),
  signatureCount: int("signatureCount"),
  importCount: int("importCount"),
  riskTermsFound: text("riskTermsFound"),
  aiSummary: text("aiSummary"),
  generatedModulePath: varchar("generatedModulePath", { length: 512 }),
  errorMessage: text("errorMessage"),
  startedAt: timestamp("startedAt"),
  completedAt: timestamp("completedAt"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export const signatures = mysqlTable("signatures", {
  id: int("id").autoincrement().primaryKey(),
  analysisId: int("analysisId"),
  linkId: int("linkId"),
  filePath: varchar("filePath", { length: 512 }),
  signatureType: varchar("signatureType", { length: 64 }),
  name: varchar("name", { length: 255 }),
  params: text("params"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export const auditLines = mysqlTable("auditLines", {
  id: int("id").autoincrement().primaryKey(),
  lineNumber: int("lineNumber"),
  content: text("content"),
  sha256: varchar("sha256", { length: 64 }),
  sourceUrl: varchar("sourceUrl", { length: 512 }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export const generatedModules = mysqlTable("generatedModules", {
  id: int("id").autoincrement().primaryKey(),
  linkId: int("linkId"),
  analysisId: int("analysisId"),
  content: text("content"),
  filename: varchar("filename", { length: 255 }),
  language: varchar("language", { length: 32 }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

// TTS Sessions
export const ttsSessions = mysqlTable("ttsSessions", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId"),
  prompt: text("prompt"),
  voiceName: varchar("voiceName", { length: 64 }),
  languageCode: varchar("languageCode", { length: 16 }),
  audioUrl: varchar("audioUrl", { length: 512 }),
  status: varchar("status", { length: 32 }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

// YouTube Research
export const youtubeResearch = mysqlTable("youtubeResearch", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId"),
  query: varchar("query", { length: 512 }),
  videoUrl: varchar("videoUrl", { length: 512 }),
  transcript: text("transcript"),
  analysis: text("analysis"),
  quotes: text("quotes"),
  status: varchar("status", { length: 32 }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

// Analytics Results
export const analyticsResults = mysqlTable("analyticsResults", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId"),
  domain: varchar("domain", { length: 255 }),
  globalRank: int("globalRank"),
  totalVisits: int("totalVisits"),
  uniqueVisitors: int("uniqueVisitors"),
  bounceRate: decimal("bounceRate", { precision: 5, scale: 2 }),
  pagesPerVisit: decimal("pagesPerVisit", { precision: 5, scale: 2 }),
  avgVisitDuration: decimal("avgVisitDuration", { precision: 8, scale: 2 }),
  trafficSources: text("trafficSources"),
  geographicData: text("geographicData"),
  status: varchar("status", { length: 32 }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

// Skills
export const skills = mysqlTable("skills", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId"),
  name: varchar("name", { length: 255 }),
  description: text("description"),
  skillMd: text("skillMd"),
  scripts: text("scripts"),
  references: text("references"),
  templates: text("templates"),
  status: varchar("status", { length: 32 }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});
