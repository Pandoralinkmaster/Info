#!/bin/bash
# THISISMYLIVE v7.0 — TUNNEL SCRIPT
# Creates public URL via localtunnel/ngrok

PORT="${THISISMYLIVE_PORT:-58133}"

echo "[+] Starting tunnel on port $PORT..."

# Try localtunnel
if command -v npx &> /dev/null; then
    npx localtunnel --port $PORT &
    echo "    Localtunnel started"
fi

# Try ngrok
if command -v ngrok &> /dev/null; then
    ngrok http $PORT &
    echo "    Ngrok started"
fi

# Try pinggy
if command -v ssh &> /dev/null; then
    ssh -p 443 -R0:localhost:$PORT a.pinggy.io &
    echo "    Pinggy started"
fi

echo "[+] Tunnels active"
