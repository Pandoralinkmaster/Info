#!/bin/bash
# THISISMYLIVE v7.0 — WATCHDOG
# Checks every 60s if server is running, restarts if needed

PORT="${THISISMYLIVE_PORT:-58133}"
SERVER_DIR="${HOME}/.thisismylive"
LOG="$SERVER_DIR/logs/watchdog.log"

mkdir -p "$SERVER_DIR/logs"

if ! python3 -c "import socket; s=socket.socket(); s.settimeout(2); r=s.connect_ex(('127.0.0.1',$PORT)); s.close(); exit(r)" 2>/dev/null; then
    echo "[$(date)] Server down — restarting..." >> "$LOG"
    pkill -9 -f "THISISMYLIVE.*server.py" 2>/dev/null
    sleep 2
    cd "$SERVER_DIR" && nohup python3 server.py > logs/server.log 2>&1 &
    echo "[$(date)] Server restarted (PID: $!)" >> "$LOG"
else
    echo "[$(date)] Server healthy" >> "$LOG"
fi
