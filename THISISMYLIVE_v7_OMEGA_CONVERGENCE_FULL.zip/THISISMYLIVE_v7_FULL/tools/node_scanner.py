#!/usr/bin/env python3
"""
THISISMYLIVE v7.0 — NODE SCANNER
Discovers other THISISMYLIVE nodes on the network
"""

import socket, threading, json, base64, sys

AUTH = base64.b64encode(b"finn:sovereign2026").decode()
PORTS = [58133, 58134, 8080, 8888, 3000, 5000, 8000, 9000]

def scan_ip(ip, port):
    try:
        s = socket.socket()
        s.settimeout(1)
        s.connect((ip, port))
        s.close()
        # Try API
        import urllib.request
        req = urllib.request.Request(
            f"http://{ip}:{port}/api/node/info",
            headers={"Authorization": f"Basic {AUTH}"},
            timeout=2
        )
        try:
            resp = urllib.request.urlopen(req)
            data = json.loads(resp.read())
            print(f"[FOUND] {ip}:{port} → Node: {data.get('node_id')} | Version: {data.get('version')}")
            return data
        except:
            print(f"[OPEN] {ip}:{port} — Not THISISMYLIVE")
    except:
        pass
    return None

def scan_network(network="192.168.1"):
    print(f"[+] Scanning {network}.0/24 for THISISMYLIVE nodes...")
    found = []
    threads = []
    for i in range(1, 255):
        ip = f"{network}.{i}"
        for port in PORTS:
            t = threading.Thread(target=lambda ip=ip, port=port: found.append(scan_ip(ip, port)) or None)
            t.start()
            threads.append(t)
    for t in threads:
        t.join(timeout=3)
    results = [f for f in found if f]
    print(f"
[+] Scan complete: {len(results)} nodes found")
    return results

if __name__ == "__main__":
    net = sys.argv[1] if len(sys.argv) > 1 else "192.168.1"
    scan_network(net)
