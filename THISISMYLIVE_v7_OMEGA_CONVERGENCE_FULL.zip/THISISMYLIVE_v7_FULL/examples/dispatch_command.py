#!/usr/bin/env python3
"""
THISISMYLIVE v7.0 — COMMAND DISPATCH EXAMPLE
Sends commands to registered nodes
"""

import urllib.request, json, base64, sys

MASTER_URL = sys.argv[1] if len(sys.argv) > 1 else "http://localhost:58133"
TARGET = sys.argv[2] if len(sys.argv) > 2 else "*"
CMD = sys.argv[3] if len(sys.argv) > 3 else "ping"
AUTH = base64.b64encode(b"finn:sovereign2026").decode()

def dispatch():
    data = json.dumps({"target": TARGET, "command": CMD, "params": {}}).encode()
    req = urllib.request.Request(
        f"{MASTER_URL}/api/c2/command",
        data=data,
        headers={"Authorization": f"Basic {AUTH}", "Content-Type": "application/json"},
        method="POST"
    )
    try:
        resp = urllib.request.urlopen(req, timeout=5)
        print(json.loads(resp.read()))
    except Exception as e:
        print(f"Failed: {e}")

if __name__ == "__main__":
    dispatch()
