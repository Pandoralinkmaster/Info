#!/usr/bin/env python3
"""
THISISMYLIVE v7.0 — HEALTH MONITOR EXAMPLE
Monitors all registered nodes
"""

import urllib.request, json, base64, time

AUTH = base64.b64encode(b"finn:sovereign2026").decode()

def check_node(url):
    try:
        req = urllib.request.Request(f"{url}/api/health", headers={"Authorization": f"Basic {AUTH}"}, timeout=3)
        resp = urllib.request.urlopen(req)
        return json.loads(resp.read())
    except:
        return None

if __name__ == "__main__":
    nodes = ["http://localhost:58133"]  # Add more nodes
    for node in nodes:
        status = check_node(node)
        if status:
            print(f"[OK] {node}: {status.get('status')} | Stealth: {status.get('stealth_level', 'N/A')}%")
        else:
            print(f"[DOWN] {node}")
